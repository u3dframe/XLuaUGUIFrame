--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIItemChoose = _G.UIController:Get("UIItemChoose")

local ItemConfig = _G.Database.ItemConfig

function UIItemChoose:InitBinds()
    return {
    }
end

function UIItemChoose:InitVM()
    return {
    }
end

function UIItemChoose:BindUI()
    self.stateCtrler = self:GetController("state")
    self.amountTxt = self:GetControl("amountTxt")
    self.SliderBar = self:GetControl("SliderBar")
    self.quickTxt = self:GetControl("quickTxt")
    self.ItemList = self:GetControl("ItemList")
end

function UIItemChoose:Start()
    self:InitItemList()
    self:InitSlider()
end

function UIItemChoose:InitItemList()
    self.ItemList.itemProvider = function(index)
        return "ui://xhjtsc0focmmq"
    end
    self.checkBtns = {}
    self.usepara = ItemConfig.ItemData[self.args.item.id_].usepara

    local function onClickCheck(context)
        local index = self.ItemList:GetChildIndex(context.sender.parent) + 1
        for _, btn in ipairs(self.checkBtns) do
            btn.selected = false
        end
        self.checkBtns[index].selected = true
        self.chosenIndex = index
    end

    self.ItemList.itemRenderer = function(idx, obj)
        local index = idx + 1
        local itemCfg = ItemManager:get_reward_cfg(self.usepara[index])
        local itemObj = obj:GetChild("ComItem")
        itemObj:GetController("quality").selectedIndex = itemCfg.quality - 1
        itemObj:GetChild("iconloader").url = "art/"..itemCfg.icon
        obj:GetChild("descriptionTxt").text = itemCfg.name
        if self.args.usable then
            obj:GetController("state").selectedIndex = 0
            local checkBtn = obj:GetChild("checkbutton")
            self.checkBtns[index] = checkBtn
            checkBtn.onClick:Add(onClickCheck)
            -- self.quickTxt.text = lang("RESOURCE_BUILDING_10")
        else
            self.quickTxt.text = lang("RESOURCE_BUILDING_10")
            obj:GetController("state").selectedIndex = 1
        end
    end

    self.ItemList:RemoveChildrenToPool()
    self.ItemList.numItems = #self.usepara
end

function UIItemChoose:InitSlider()
    self.stateCtrler.selectedIndex = self.args.usable and 0 or 1 
    self.chosenIndex = nil
    self.SliderBar.changeOnClick = false
    if self.args.usable then
        self.useCount = 1
        self.SliderBar.value = self.useCount
        self.SliderBar.min = 1
        self.SliderBar.max = self.args.item.count_
        self.amountTxt.text = string.format("%d/%d", self.useCount, self.SliderBar.max)
        local function onSliderChanged()
            self.useCount = self.SliderBar.value
            self.amountTxt.text = string.format("%d/%d", self.useCount, self.SliderBar.max)
        end
        self.SliderBar.onChanged:Add(onSliderChanged)
    end
end

function UIItemChoose:OnSureBtnClick()
    if not self.args.usable then self:Close() return end
    if not self.chosenIndex then return end
    self.args.item:confirm_to_use(self.useCount, self.args.on_success, self.chosenIndex)
    self:Hide()
end

function UIItemChoose:OnMinusBtnClick()
    if self.useCount <= 1 then return end
    self.useCount = self.useCount - 1
    self.SliderBar.value = self.useCount
    self.amountTxt.text = string.format("%d/%d", self.useCount, self.SliderBar.max)
end

function UIItemChoose:OnAddBtnClick()
    if self.useCount >= self.args.item.count_ then return end
    self.useCount = self.useCount + 1
    self.SliderBar.value = self.useCount
    self.amountTxt.text = string.format("%d/%d", self.useCount, self.SliderBar.max)
end

function UIItemChoose:OnCloseClick()
    self:Hide()
end

function UIItemChoose:OncancelClick()
    self:Hide()
end

