--This is an automatically generated class by FairyGUI. Please do not modify it.

    local UITrainPromot = _G.UIController:Get('UITrainPromot')
    Attribute = config.SOLDIER_ATTR
    local NUM_COST = 3
    local AttributeConfig = _G.Database.AttributeConfig
    function UITrainPromot:Awake()
        self.soldierId = self.args.currSoldierID
        self.nextSoldierId = self.args.nextSoldierID
        self.maxCount = self.args.soldierMaxCnt
        self.buildID = self.args.buildID
        self.soldierInfo = SoldierManager:get_soldier_info_by_id(self.soldierId)
        self.nextSoldierInfo = SoldierManager:get_soldier_info_by_id(self.nextSoldierId)
        self.upInfo = SoldierManager:get_lvup_info_by_lv(self.soldierInfo.id_, self.nextSoldierInfo.id_)
        self.proCost = self.upInfo.procost
        self.isSpineLoading = {}
        self:InitSlider()
        self:SetCostList()
        self:InitAttributeList()
    end
    
    function UITrainPromot:OnOpen()
        if self.soldierInfo and self.nextSoldierInfo then
            self.upInfo = SoldierManager:get_lvup_info_by_lv(self.soldierInfo.id_, self.nextSoldierInfo.id_)
            self.proCost = self.upInfo.procost
        --self:SetSliderValue()
        end
    end
    
    function UITrainPromot:InitAttributeList()
        self.LevelTxt1.text = lang('UI_SOLDIER_NAME_LV', self.soldierInfo.lv_)
        self.LevelTxt2.text = lang('UI_SOLDIER_NAME_LV', self.nextSoldierInfo.lv_)
        self.OverallTxt1.text = self.soldierInfo.fighting_power_
        self.OverallTxt2.text = self.nextSoldierInfo.fighting_power_
        self.OccupyTxt1.text = self.soldierInfo.number_
        self.OccupyTxt2.text = self.nextSoldierInfo.number_
        self.soldierIcon1.url = 'art/' .. self.soldierInfo.half_icon_path_
        self.soldierIcon2.url = 'art/' .. self.nextSoldierInfo.half_icon_path_
        self.CommonSoldier1:GetController('type').selectedIndex = self.soldierInfo.soldier_type_ - 1
        self.CommonSoldier2:GetController('type').selectedIndex = self.nextSoldierInfo.soldier_type_ - 1
        self.AttributeTxt1.itemProvider = function()
            return 'ui://eowykrgjlsg7q'
        end
        self.AttributeTxt1.itemRenderer = function(idx, obj)
            local attr1 = self.soldierInfo.attribute_
            local maxValue = self.soldierInfo.max_value_
            obj:GetChild('AttributeTxt').text = AttributeConfig.AttributeData[idx + 1].name_c
            obj:GetChild('AmountTxt').text = attr1[config.SOLDIER_ATTR[idx + 1]]
        end
        self.AttributeTxt2.itemProvider = function()
            return 'ui://eowykrgjlsg7q'
        end
        self.AttributeTxt2.itemRenderer = function(idx, obj)
            local attr2 = self.nextSoldierInfo.attribute_
            local maxValue = self.nextSoldierInfo.max_value_
            obj:GetChild('AttributeTxt').text = AttributeConfig.AttributeData[idx + 1].name_c
            obj:GetChild('AmountTxt').text = attr2[config.SOLDIER_ATTR[idx + 1]]
        end
    end
    
    function UITrainPromot:InitSlider()
        local maxValue = self.maxCount > self.soldierInfo.number_ and self.soldierInfo.number_ or self.maxCount
        self.Slider.max = maxValue
        self.Slider.min = 1
        self.Slider.value = maxValue
        self.Slider:CheckSlider()
        local value = self.Slider.value
        local remainTime = self.soldierInfo:GetPromoteTime(self.nextSoldierInfo.id_,value)
        self.timerTxt.text = UIUtil.format_time(remainTime)
        local function onSliderChanged()
            self:OnSliderChanged()
        end
        self.Slider.onChanged:Add(onSliderChanged)
    end
    
    function UITrainPromot:OnSliderChanged()
        local value = self.Slider.value
        self.CostList.numItems = table.size(self.proCost)
        local remainTime = self.soldierInfo:GetPromoteTime(self.nextSoldierInfo.id_,value)
        self.timerTxt.text = UIUtil.format_time(remainTime)
        local costMoney = self:GetGoldNumber(remainTime)
        self.costMoneyTxt.text = string.format('%d%s', UIUtil.res_num_to_str(costMoney), lang('ITEM7'))
    end
    function UITrainPromot:GetGoldNumber(remainTime)
        return SoldierManager:get_gold_drill_number(remainTime)
    end
    
    function UITrainPromot:SetCostList()
        self.CostList.itemProvider = function()
            return 'ui://eowykrgjlsg79'
        end
        self.CostList.itemRenderer = function(idx, obj)
            obj:GetController('state').selectedIndex = idx
            local costs = self.proCost
            if (costs[idx + 1]) then
                local num = self.Slider.value
                local cost = costs[idx + 1][3] * num
                local hadMoney = ItemManager:get_resource(costs[idx + 1][1])
                if hadMoney < cost then
                    cost = UIUtil.res_num_to_str(cost)
                    cost = lang('UI_SOLDIER_PROPS_COUNT', cost)
                    self.isEnough = false
                else
                    cost = UIUtil.res_num_to_str(cost)
                    self.isEnough = true
                end
                obj:GetChild('CostAmountTxt').text = cost
            end
        end
    end
    function UITrainPromot:InitBinds()
        return {}
    end
    
    function UITrainPromot:InitVM()
        return {}
    end
    
    --FIXME:This is automatically generated
    --FIXME:If no event to listen, Delete This function
    function UITrainPromot:InitEvents()
        self:AddEventListener(
            eventKey or eventKeys,
            function()
            end
        )
    end
    
    function UITrainPromot:BindUI()
        self.stateCtrler = self:GetController('state')
        self.BlueBtn = self:GetControl('BlueBtn')
        self.timerTxt = self:GetControl('BlueBtn.TimerTxt')
        self.YellowBtn = self:GetControl('YellowBtn')
        self.costMoneyTxt = self:GetControl('YellowBtn.CostTxt')
        self.CloseBtn = self:GetControl('CloseBtn')
        self.CostList = self:GetControl('CostList')
        self.RoundAddBtn = self:GetControl('RoundAddBtn')
        self.MinusBtn = self:GetControl('MinusBtn')
        self.ComArribute1 = self:GetControl('ComArribute1')
        self.OverallTxt1 = self:GetControl('ComArribute1.OverallTxt')
        self.OccupyTxt1 = self:GetControl('ComArribute1.OccupyTxt')
        self.icon1 = self:GetControl('ComArribute1.icon')
        self.CommonSoldier1 = self:GetControl('ComArribute1.CommonSoldier')
        self.soldierIcon1 = self:GetControl('ComArribute1.CommonSoldier.icon')
        self.LevelTxt1 = self:GetControl('ComArribute1.CommonSoldier.LevelTxt')
        self.AttributeTxt1 = self:GetControl('ComArribute1.AttributeTxt')
        self.ComArribute2 = self:GetControl('ComArribute2')
        self.OverallTxt2 = self:GetControl('ComArribute2.OverallTxt')
        self.OccupyTxt2 = self:GetControl('ComArribute2.OccupyTxt')
        self.icon2 = self:GetControl('ComArribute2.icon')
        self.CommonSoldier2 = self:GetControl('ComArribute2.CommonSoldier')
        self.soldierIcon2 = self:GetControl('ComArribute2.CommonSoldier.icon')
        self.SuffixTxt2 = self:GetControl('ComArribute2.CommonSoldier.SuffixTxt')
        self.LevelTxt2 = self:GetControl('ComArribute2.CommonSoldier.LevelTxt')
        self.AttributeTxt2 = self:GetControl('ComArribute2.AttributeTxt')
        self.Slider = self:GetControl('Slider')
        self.SliderValueTxt = self:GetControl('Slider.title')
    end
    
    function UITrainPromot:Start()
        self.CostList.numItems = table.size(self.proCost)
        self.AttributeTxt1.numItems = table.size(self.soldierInfo.attribute_)
        self.AttributeTxt2.numItems = table.size(self.nextSoldierInfo.attribute_)
    end
    
    --FIXME:Write logic Code here!
    
    function UITrainPromot:OnBlueBtnClick()
        self:OnNormalLvUP()
    end
    
    function UITrainPromot:OnYellowBtnClick()
        self:OnGoldLvUp()
    end
    
    function UITrainPromot:OnCloseBtnClick()
        self:Hide()
    end
    
    function UITrainPromot:OnRoundAddBtnClick()
        if self.Slider.value >= self.Slider.max then
            return
        end
        self.Slider.value = self.Slider.value + 1
        self:OnSliderChanged()
    end
    
    function UITrainPromot:OnMinusBtnClick()
        if self.Slider.value <= self.Slider.min then
            return
        end
        self.Slider.value = self.Slider.value - 1
        self:OnSliderChanged()
    end
    
    --金币晋升
    function UITrainPromot:OnGoldLvUp()
        local resMsg = {}
        resMsg.id = self.buildID
        resMsg.soldier = self.soldierId
        resMsg.soldiercnt = self.Slider.value
        resMsg.target = self.nextSoldierId
        local msg = {}
        msg.mode = 0
        msg.title = ''
        msg.content = lang('UI_SOLDIERDES_HINT4')
        msg.callback = function()
            Net.send(
                'promotion_soldier_finish',
                resMsg,
                function(result)
                    if result.e == 0 then
                        local str = lang('UI_SOLDIERDES_HINT5', self.soldierInfo.lv_, self.soldierInfo.name_)
                        MsgCenter.send_message(Msg.SHOW_HINT, str)
                        if self.soldierInfo.number_ <= 0 then
                            self:Hide()
                            return
                        end
                        self:OnOpen()
                    end
                end
            )
        end
        _G.UIController:ShowUI('UICommonPop', msg)
    end
    
    --普通晋升
    function UITrainPromot:OnNormalLvUP()
        local resMsg = {}
        resMsg.id = self.buildID
        resMsg.soldier = self.soldierId
        resMsg.soldiercnt = self.Slider.value
        resMsg.target = self.nextSoldierId
        Net.send(
            'promotion_soldier',
            resMsg,
            function(result)
                if result.e == 0 then
                    _G.event.fire(
                        _G.EventKey.CITY_SOIDIER_UPDATE,
                        {buildID = self.buildID, soldierID = self.soldierId, soldierClass = self.soldierInfo.class_}
                    )
                    self:Hide()
                end
            end
        )
    end
    