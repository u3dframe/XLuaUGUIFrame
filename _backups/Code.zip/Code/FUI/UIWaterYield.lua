--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIWaterYield = _G.UIController:Get('UIWaterYield')
_G.table.mixin(UIWaterYield, require('FUI/Patch/TopBannerPatch'))
local framIndex = config.BUILD_TYPE.FARM
function UIWaterYield:Awake()
    self.allResBuild = BuildManager:get_all_res_builds_by_type()
    self.lordInfo = BuildManager:get_build_info_by_build_type(config.BUILD_TYPE.KING)
    self.buildInfo = BuildManager:get_build_info_by_build_type(config.BUILD_TYPE.WATERWHEEL)
    self.Cityname.text = self.lordInfo.name_ .. lang('UI_BASIC_LV')
    self.CitylevelTxt.text = self.lordInfo.lv_
    self.buildTitle.text = self:GetBuildName() .. '  ' .. lang('UI_BUILDSPEND_LVDES', self.buildInfo.lv_)
    self.BuildDescribe.text = self.buildInfo.introduce_
    self.increaseInfo = self.args.increaseInfo
    self:SetTitle(self:GetBuildName())
    self:InitBuildList()
end
function UIWaterYield:InitBinds()
    return {}
end

function UIWaterYield:InitVM()
    return {}
end
function UIWaterYield:GetBuildName()
    return self.buildInfo and self.buildInfo.name_
end

function UIWaterYield:BindUI()
    self.BuildInterface = self:GetControl('BuildInterface')
    self.buildTitle = self:GetControl('BuildInterface.BuildTitle')
    self.BuildDescribe = self:GetControl('BuildInterface.BuildDescribe')
    self.YieldList = self:GetControl('YieldList')
    self.BuildIntertitle = self:GetControl('BuildIntertitle')
    self.CommonResTop = self:GetControl('CommonResTop')
    self.CitylevelTxt = self:GetControl('n8.CitylevelTxt')
    self.Cityname = self:GetControl('n8.Cityname')
end

function UIWaterYield:Start()
    self.YieldList.numItems = table.size(self.allResBuild)
end

function UIWaterYield:ReceiveUpgrade()
    Net.send('produce_info', {},
        function(result)
            if result.e == 0 then
                self.increaseInfo = result.info
                self.allResBuild = BuildManager:get_all_res_builds_by_type()
                self.YieldList.numItems = table.size(self.allResBuild)
            end
        end
    )
end

function UIWaterYield:onIncreaseClick(context)
    local buildIndex = self.YieldList:GetChildIndex(context.sender.parent)
    local typeBuilds = self.allResBuild[buildIndex + framIndex]
    --当前类型所有建筑
    local notBuffBuilds = {} --未增益建筑
    for i = 1, #typeBuilds do
        if not CollectManager:get_collect(typeBuilds[i].id_):has_buff() then
            table.insert(notBuffBuilds, typeBuilds[i])
        end
    end
    local buildInfo = notBuffBuilds[1]
    local collect = CollectManager:get_collect(buildInfo.id_)
    local propCost = ItemManager:get_item_by_id(collect.buff_item_)
    local goldCost = collect:get_prop()
    local msg_ = {}
    msg_.mode=0
    msg_.title = lang('UI_BASIC_HINT')
    msg_.content = lang('PRODUCE_INCREASE_TIP_1')
   -- msg_.buttons = {lang('UI_BASIC_CANCEL'), lang('UI_BASIC_SURE')}
   -- local CONFIRM = 2
    msg_.callback = function()
        -- if index ~= CONFIRM then
        --     return
        -- end
        --如果道具足够
        if propCost and propCost.count_ >= #notBuffBuilds then
            self:ConfirmClick(buildIndex, notBuffBuilds)
        elseif not propCost or propCost.count_ <= #notBuffBuilds then --道具不够
            local msg1 = {}
            msg1.mode=0
            local needMoney = #notBuffBuilds - (propCost and propCost.count_ or 0)
            msg1.title = lang('UI_BASIC_HINT')
            msg1.content =
                lang('PRODUCE_INCREASE_TIP_2', buildInfo.name_, #notBuffBuilds, collect:get_prop().gold, needMoney)
          --  msg1.buttons = {lang('UI_BASIC_CANCEL'), lang('UI_BASIC_SURE')}
            msg1.callback = function()
                -- if index ~= CONFIRM then
                --     return
                -- end
                local coin = ItemManager:get_coin(config.ITEM_GOLD)
                if coin < goldCost.gold * needMoney then -- 金币不够
                    local args = {}
                    args.goldCost = goldCost
                    args.needNum = needMoney
                    args.notBuffBuilds = notBuffBuilds
                    args.buildIndex = buildIndex
                    args.coin = coin
                    self:MsgCallBack(args)
                else
                    self:ConfirmClick(buildIndex, notBuffBuilds)
                end
            end
            _G.UIController:ShowUI('UICommonPop', msg1)
          --  MsgCenter.send_message(Msg.SHOW_NOTIFY, msg1)
        end
    end
    _G.UIController:ShowUI('UICommonPop', msg_)
  --  MsgCenter.send_message(Msg.SHOW_NOTIFY, msg_)
end
function UIWaterYield:InitBuildList()
    self.YieldList.itemProvider = function()
        return 'ui://kpsjlaghkj309'
    end

    self.YieldList.itemRenderer = function(idx, obj)
        local typeBuilds = self.allResBuild[idx + framIndex]
        local buildInfo = typeBuilds[1]
        obj:GetChild('TitleTxt').text = lang('ARCHITECTURE_0' .. (idx + framIndex))
        obj:GetChild('YieldTxt').text = lang('Production_' .. (idx + 1))
        obj:GetChild('icon').url = 'art/' .. _G.Database.CityConfig.BuildupdateData[(idx + framIndex) * 10000 + 1].path
        local index = 0
        for _, v in ipairs(typeBuilds) do
            local collectInfo = CollectManager:get_collect(v.id_)
            if collectInfo and not collectInfo:has_buff() then
                index = 1
                break
            end
        end
        if #typeBuilds == 0 or (buildInfo and buildInfo.lv_ == 0) then
            index = 2
        end
        obj:GetController('Buttontype').selectedIndex = index
        for index, value in ipairs(self.increaseInfo) do
            if value.buildtype == idx + framIndex then
                obj:GetChild('YieldSpeedTxt').text = value.speed
            end
        end
        local maxCount  --可修建最大数量（前提解锁一个建筑）
        if buildInfo and buildInfo.lv_ > 0 then
            obj:GetChild('YieldBtn').onClick:Set(_G.partial(self.onIncreaseClick, self))
            local collect = CollectManager:get_collect(buildInfo.id_)
            local propCost = ItemManager:get_item_by_id(collect.buff_item_)
            obj:GetChild('YieldItemTxt').text = propCost and #typeBuilds or 0
            obj:GetChild('Yield@icon').url = 'art/' .. ItemManager:get_item_prop_by_id(collect.buff_item_).icon
        end
        local maxTable = buildInfo and buildInfo.max_count_ or _G.Database.CityConfig.BuildData[idx + framIndex].maxcnt
        for i, v in ipairs(maxTable) do
            if self.lordInfo.lv_ >= maxTable[i][2] then
                maxCount = maxTable[i][1]
            end
        end
        if maxCount then
            obj:GetChild('YieldNumTxt').text = #typeBuilds .. '/' .. maxCount
            obj:GetController('ImageType').selectedIndex = 1
        else
            obj:GetChild('unlockTxt').text = lang('EXPEDITION_18', maxTable[1][2])
            obj:GetController('ImageType').selectedIndex = 0
        end
    end
end
--FIXME:Write logic Code here!

function UIWaterYield:ConfirmClick(index, notBuffBuilds)
    local data = {}
    data.buildtype = index + framIndex
    Net.send(
        'produce_buffadd_onekey',
        data,
        function(result)
            if result.e == 0 then
                for i = 1, #notBuffBuilds do
                    MsgCenter.send_message(Msg.CITY_COLLECT_REFRESH, notBuffBuilds[i].id_)
                end
                self.increaseInfo = result.info
                self.YieldList.numItems = table.size(self.allResBuild)
            end
        end
    )
end

function UIWaterYield:MsgCallBack(args)
    local msg2 = {}
    msg2.mode=0
    msg2.title = lang('UI_BASIC_HINT')
    msg2.content =
        lang(
        'PRODUCE_INCREASE_TIP_3',
        (args.goldCost.gold * args.needNum - args.coin),
        (args.goldCost.gold * args.needNum - args.coin)
    )
   -- msg2.buttons = {lang('UI_BASIC_CANCEL'), lang('UI_BASIC_SURE')}
    msg2.callback = function()
      --  if index == 2 then
            if ItemManager:get_coin(config.ITEM_GEM) < (args.goldCost.gold * args.needNum - args.coin) then --元宝不够
                local str = lang('RESOURCE_BUILDING_3', lang('ITEM5'))
                MsgCenter.send_message(Msg.SHOW_HINT, str)
                return
            else
                self:ConfirmClick(args.buildIndex, args.notBuffBuilds)
            end
       -- end
    end
    --MsgCenter.send_message(Msg.SHOW_NOTIFY, msg2)
    _G.UIController:ShowUI('UICommonPop', msg2)
end
function UIWaterYield:InitEvents()
    self:AddEventListener(
        {_G.EventKey.PRODUCE_UPDATE},
        function()
            self:ReceiveUpgrade()
        end
    )
end

function UIWaterYield:OnBackBtnClick()
    self:Hide()
end
