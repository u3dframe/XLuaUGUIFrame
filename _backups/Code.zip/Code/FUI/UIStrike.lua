--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIStrike = _G.UIController:Get("UIStrike")

_G.table.mixin(UIStrike, require("FUI/Patch/TopBannerPatch"))

local AttrsManager = _G.AttrsManager
local SoldierManager = _G.SoldierManager
local WorldManager = _G.WorldManager
local lang = _G.lang
local config = _G.config
local UIUtil = _G.UIUtil
local BasicConfig = _G.Database.BasicConfig

local PriorityType = {
	Level = 1,		--等级优先
	Load = 2,		--负重优先
	Speed = 3,		--速度优先
	Match = 4,		--搭配优先
}

local PriorityStr = {
	[PriorityType.Level] = lang("EXPEDITION_25"),
	[PriorityType.Load] = lang("EXPEDITION_26"),
	[PriorityType.Speed] = lang("EXPEDITION_27"),
	[PriorityType.Match] = lang("EXPEDITION_28"),
}

function UIStrike:Awake()
	self:SetTitle("出征")
	self.obj = self.args.obj
	self.soldierList = {}
	self.soldierCnt = {}
	self.heroTotalPower = 0
	self.soldierTotalPower = 0
	
	self.soldierNumTxtList = {}
	self.soldierSliderList = {}

	self.LevelCheckBtn:GetChild("title").text = PriorityStr[PriorityType.Level]
	self.LoadCheckBtn:GetChild("title").text = PriorityStr[PriorityType.Load]
	self.SpeedCheckBtn:GetChild("title").text = PriorityStr[PriorityType.Speed]
	self.MatchCheckBtn:GetChild("title").text = PriorityStr[PriorityType.Match]

	self:InitSoldierItemList()

	if type(self.callBack) == "function" then
		self.callBack()
	end

	self.ComMasterDeleteBtn.onClick:Set(function()
		self.heroes[1] = nil
		self:init_hero_panel()
	end)

	self.ComMasterSelectBtn.onClick:Set(function()
		self:OnClickHeroHead(1, self.heroes[1])
	end)

	self.ComSmallDeleteBtn.onClick:Set(function()
		self.heroes[2] = nil
		self:init_hero_panel()
	end)

	self.ComSmallSelectBtn.onClick:Set(function()
		self:OnClickHeroHead(2, self.heroes[2])
	end)
end

function UIStrike:InitBinds()
    return {
		priorityType = function(value)
			self.priorityType = value + 1
			self.CancelBlueBtn:GetChild("level").text = PriorityStr[self.priorityType]
			self.army_filterCtrler.selectedIndex = self.priorityType
			self:UpdateSoldierList()
		end,
		soldierList = function(value)
			self.soldierList = value
			self.soldierCnt = {}
			self.soldierNumTxtList = {}
			self.soldierSliderList = {}
			self.SoliderList.numItems = #self.soldierList
			self:MaximumSoldierCount()
		end,
		soldierCnt = function(value)
			self.soldierCnt = value
			self:OnSoldierCountChange()
		end,
		totalPower = function(value)
			self.PowerTxt.text = string.format("%s: %d", lang("UI_TROOPS_ALLPOWER"), value)
			self.obj:get_prop_power(function(propPower)
				if value <= propPower*BasicConfig.BasicData.force_combat[1] then
					self.PromptTxt.text = lang("EXPEDITION_20")
				elseif value <= propPower*BasicConfig.BasicData.force_combat[2] then
					self.PromptTxt.text = lang("EXPEDITION_19")
				elseif value <= propPower*BasicConfig.BasicData.force_combat[3] then
					self.PromptTxt.text = lang("EXPEDITION_21")
				elseif value <= propPower*BasicConfig.BasicData.force_combat[4] then
					self.PromptTxt.text = lang("EXPEDITION_22")
				else
					self.PromptTxt.text = lang("EXPEDITION_48")
				end
			end)
		end,
    }
end

function UIStrike:InitVM()
    return {
		priorityType = self.obj:get_troops_order() - 1,
		soldierList = {},
		soldierCnt = {},
		totalPower = 0,
    }
end

--FIXME:This is automatically generated
--FIXME:If no event to listen, Delete This function
function UIStrike:InitEvents()
	self:AddEventListener({_G.EventKey.SELECT_HERO_CONFIRM}, function(args)
        self:RefreshHero(args.index, args.hero)
    end)
end

function UIStrike:BindUI()
	self.army_filterCtrler = self:GetController("army_filter")
	self.ButtonzkCtrler = self:GetController("Buttonzk")
	self.slodierCtrler = self:GetController("slodier")
	self.BackGruond = self:GetControl("BackGruond")
	self.Bartop = self:GetControl("Bartop")
	self.Strike = self:GetControl("Strike")
	self.Commessage = self:GetControl("Commessage")
	self.ComSoldierNum = self:GetControl("ComSoldierNum")
	self.Comenery = self:GetControl("Comenery")
	self.TargetTypeCtrler = self:GetControl("Comenery"):GetController("TargetType")
	self.GooutBtn = self:GetControl("GooutBtn")
	self.CancelBtn = self:GetControl("CancelBtn")
	self.TargetTxt = self:GetControl("TargetTxt")
	self.SkilluseBtn = self:GetControl("SkilluseBtn")
	self.SkillBtn = self:GetControl("SkillBtn")
	self.Comformation = self:GetControl("Comformation")
	self.team2 = self:GetControl("Comformation.team2")
	self.team1 = self:GetControl("Comformation.team1")
	self.team3 = self:GetControl("Comformation.team3")
	self.team4 = self:GetControl("Comformation.team4")
	self.PowerTxt = self:GetControl("PowerTxt")
	self.HeroDetailsBtn = self:GetControl("HeroDetailsBtn")
	self.ComUnloceimage = self:GetControl("ComUnloceimage")
	self.unlockTxt = self:GetControl("ComUnloceimage.unlockTxt")
	self.BackBtn = self:GetControl("BackBtn")
	self.CommonResTop = self:GetControl("CommonResTop")
	self.SoliderList = self:GetControl("SoliderList")
	self.CancelBlueBtn = self:GetControl("CancelBlueBtn")
	self.ComHeromaster = self:GetControl("ComHeromaster")
	self.Hero1ColorRankCtrler = self:GetControl("ComHeromaster"):GetController("ColorRank")
	self.Hero1HeadCtrler = self:GetControl("ComHeromaster"):GetController("heroheadtype")
	self.Hero1TypeCtrler = self:GetControl("ComHeromaster"):GetController("herotype")
	self.Hero1NameColorCtrler = self:GetControl("ComHeromaster"):GetController("namecolor")
	self.headimage = self:GetControl("ComHeromaster.headimage")
	self.Master = self:GetControl("ComHeromaster.Master")
	self.green = self:GetControl("ComHeromaster.green")
	self.blue = self:GetControl("ComHeromaster.blue")
	self.hero_4 = self:GetControl("ComHeromaster.hero_4")
	self.orange = self:GetControl("ComHeromaster.orange")
	self.board_number_left = self:GetControl("ComHeromaster.board_number_left")
	self.herolevelTxt = self:GetControl("ComHeromaster.herolevelTxt")
	self.label_red = self:GetControl("ComHeromaster.label_red")
	self.Masterhero = self:GetControl("ComHeromaster.Masterhero")
	self.HeronameTxt = self:GetControl("ComHeromaster.HeronameTxt")
	self.Leader = self:GetControl("ComHeromaster.Leader")
	self.Gov = self:GetControl("ComHeromaster.Gov")
	self.IQ = self:GetControl("ComHeromaster.IQ")
	self.Comstar = self:GetControl("Comstar")
	self.DeleteBtn = self:GetControl("DeleteBtn")
	self.arrow3_down = self:GetControl("arrow3_down")
	self.arrow3_up = self:GetControl("arrow3_up")
	self.LevelCheckBtn = self:GetControl("LevelCheckBtn")
	self.LoadCheckBtn = self:GetControl("LoadCheckBtn")
	self.SpeedCheckBtn = self:GetControl("SpeedCheckBtn")
	self.MatchCheckBtn = self:GetControl("MatchCheckBtn")
	self.StrikeType = self:GetControl("StrikeType")
	self.AddBtn = self:GetControl("AddBtn")
	self.ComHerosmall = self:GetControl("ComHerosmall")
	self.Comstar2 = self:GetControl("Comstar2")
	self.Delete = self:GetControl("Delete")
	self.ComGirl = self:GetControl("ComGirl")
	self.TeamOpenBtn = self:GetControl("TeamOpenBtn")
	self.PromptTxt = self:GetControl("Commessage.PromptTxt")
	self.SoldierNumTxt = self:GetControl("ComSoldierNum.SoldierNumTxt")
	self.EnergyTxt = self:GetControl("Comenery.EnergyTxt")
	self.ResourcesTxt = self:GetControl("Comenery.ResourcesTxt")
	self.team2 = self:GetControl("Comformation.team2")
	self.team1 = self:GetControl("Comformation.team1")
	self.team3 = self:GetControl("Comformation.team3")
	self.team4 = self:GetControl("Comformation.team4")
	self.unlockTxt = self:GetControl("ComUnloceimage.unlockTxt")
	self.ColorRankCtrler = self:GetControl("ComHeromaster"):GetController("ColorRank")
	self.statusCtrler = self:GetControl("ComHeromaster"):GetController("status")
	self.herotypeCtrler = self:GetControl("ComHeromaster"):GetController("herotype")
	self.namecolorCtrler = self:GetControl("ComHeromaster"):GetController("namecolor")
	self.headimage = self:GetControl("ComHeromaster.headimage")
	self.Master = self:GetControl("ComHeromaster.Master")
	self.green = self:GetControl("ComHeromaster.green")
	self.blue = self:GetControl("ComHeromaster.blue")
	self.hero_4 = self:GetControl("ComHeromaster.hero_4")
	self.orange = self:GetControl("ComHeromaster.orange")
	self.board_number_left = self:GetControl("ComHeromaster.board_number_left")
	self.herolevelTxt = self:GetControl("ComHeromaster.herolevelTxt")
	self.label_red = self:GetControl("ComHeromaster.label_red")
	self.Masterhero = self:GetControl("ComHeromaster.Masterhero")
	self.HeronameTxt = self:GetControl("ComHeromaster.HeronameTxt")
	self.Leader = self:GetControl("ComHeromaster.Leader")
	self.Gov = self:GetControl("ComHeromaster.Gov")
	self.IQ = self:GetControl("ComHeromaster.IQ")
	self.Hero2TypeCtrler = self:GetControl("ComHerosmall"):GetController("Herotype")
	self.Hero2ColorCtrler = self:GetControl("ComHerosmall"):GetController("color")
	self.Hero2NameColorCtrler = self:GetControl("ComHerosmall"):GetController("namecolor")
	self.Hero2HeadCtrler = self:GetControl("ComHerosmall"):GetController("heroheadtype")
	self.headimage = self:GetControl("ComHerosmall.headimage")
	self.Master = self:GetControl("ComHerosmall.Master")
	self.green = self:GetControl("ComHerosmall.green")
	self.blue = self:GetControl("ComHerosmall.blue")
	self.orange = self:GetControl("ComHerosmall.orange")
	self.hero_4 = self:GetControl("ComHerosmall.hero_4")
	self.board_number_left = self:GetControl("ComHerosmall.board_number_left")
	self.herolevelTxt = self:GetControl("ComHerosmall.herolevelTxt")
	self.label_blue = self:GetControl("ComHerosmall.label_blue")
	self.Smallhero = self:GetControl("ComHerosmall.Smallhero")
	self.HeronameTxt = self:GetControl("ComHerosmall.HeronameTxt")
	self.headimage = self:GetControl("ComGirl.headimage")
	self.Master = self:GetControl("ComGirl.Master")
	self.board_number_left = self:GetControl("ComGirl.board_number_left")
	self.herolevelTxt = self:GetControl("ComGirl.herolevelTxt")
	self.HeronameTxt = self:GetControl("ComGirl.HeronameTxt")
	self.Girl = self:GetControl("ComGirl.Girl")

	self.ComMasterDeleteBtn = self:GetControl("ComHeromaster.DeleteBtn")
	self.ComSmallDeleteBtn = self:GetControl("ComHerosmall.DeleteBtn")
	self.ComMasterSelectBtn = self:GetControl("ComHeromaster.SelectBtn")
	self.ComSmallSelectBtn = self:GetControl("ComHerosmall.SelectBtn")
end

function UIStrike:Start()
	self.heroes = _G.HeroManager:get_heroes_troop()
	self:init_hero_panel()
	self.slodierCtrler.selectedIndex = #self.soldierList == 0 and 1 or 0
end

--FIXME:Write logic Code here!

function UIStrike:RefreshHero(index, hero)
	if not hero then return end
	for i=1,2 do
		if index == i then
			self.heroes[index] = hero
		elseif self.heroes[i] and hero and self.heroes[i].id_ == hero.id_ then
			self.heroes[i] = nil
		end
	end
	self:init_hero_panel()
end

function UIStrike:init_hero_panel()
	dump(self.heroes, "self.heroes")
	UIUtil.SetHeroHead(self.ComHeromaster, self.heroes[1], 0)
	self.ComHeromaster:GetController("heroheadtype").selectedIndex = self.heroes[1] and 0 or 1
	UIUtil.SetHeroHead(self.ComHerosmall, self.heroes[2], 1)
	self.ComHerosmall:GetController("heroheadtype").selectedIndex = self.heroes[2] and 0 or 1
end

function UIStrike:InitSoldierItemList()
	self.SoliderList.itemProvider = function()
		return "ui://zkv81kwl11mw991w"
	end
	local onSliderChanged = function(context)
		local index = self.SoliderList:GetChildIndex(context.sender.parent) + 1
		self:OnSoldierSliderChanged(index)
	end
	local onAddClick = function(context)
		local index = self.SoliderList:GetChildIndex(context.sender.parent) + 1
		local slider = self.soldierSliderList[index]
		if slider.value >= slider.max then return end
		slider.value = slider.value + 1
		self:OnSoldierSliderChanged(index)
	end
	local onSubClick = function(context)
		local index = self.SoliderList:GetChildIndex(context.sender.parent) + 1
		local slider = self.soldierSliderList[index]
		if slider.value <= slider.min then return end
		slider.value = slider.value - 1
		self:OnSoldierSliderChanged(index)
	end
	self.SoliderList.itemRenderer = function(idx, obj)
		local index = idx + 1
		local soldier = self.soldierList[index]
		local comSoldier = obj:GetChild("ComSoldier")
		local slider = obj:GetChild("Slider1")
		slider.changeOnClick = false
		self.soldierNumTxtList[index] = comSoldier:GetChild("QuantityTxt")
		comSoldier:GetChild("head").url = "art/"..soldier.small_icon_path_
		comSoldier:GetChild("ArmyTxt").text = lang("UI_SOLDIER_ICON_NAME_LV", soldier.lv_, soldier.name_)
		self.soldierSliderList[index] = slider
		slider.min = 0
		slider.max = soldier.number_
		slider.onChanged:Set(onSliderChanged)
		obj:GetChild("RoundAddBtn").onClick:Set(onAddClick)
		obj:GetChild("RduceBtn").onClick:Set(onSubClick)
	end
end

function UIStrike:GetMaxSoldierCount()
	return AttrsManager:get_attrs_value_by_name("march_num")
end

function UIStrike:GetSoldierTotalCount()
	local total = 0
	for _, cnt in pairs(self.soldierCnt) do
		total = total + cnt
	end
	return total
end

function UIStrike:CheckSoldierSliderValue(index)
	local slider = self.soldierSliderList[index]
	local to = self:GetSoldierTotalCount() + slider.value - self:GetSoldierCount(index)
	local over = to - self:GetMaxSoldierCount()
	if over > 0 then
		slider.value = slider.value - over
		slider.canDrag = false
	end
end

function UIStrike:OnSoldierSliderChanged(index)
	self:CheckSoldierSliderValue(index)
	local slider = self.soldierSliderList[index]
	self.soldierNumTxtList[index].text = string.format("%d/%d", slider.value, slider.max)
	local cnts = self.soldierCnt
	cnts[index] = slider.value
	self.vm.soldierCnt = cnts
end

function UIStrike:GetSoldierCount(index)
	return self.soldierCnt[index] or 0
end

function UIStrike:SetSoldierCount(index, value)
	local slider = self.soldierSliderList[index]
	slider.value = value
	self:OnSoldierSliderChanged(index)
end

function UIStrike:UpdateSoldierList()
    if self.priorityType == PriorityType.Level then
        self.vm.soldierList = SoldierManager:get_soldier_by_level_priority()
    elseif self.priorityType == PriorityType.Load then
        self.vm.soldierList = SoldierManager:get_soldier_by_weight_priority()
    elseif self.priorityType == PriorityType.Speed then
        self.vm.soldierList = SoldierManager:get_soldier_by_speed_priority()
    elseif self.priorityType == PriorityType.Match then
        self.vm.soldierList = SoldierManager:get_soldier_by_collocation_priority()
    else
        self.vm.soldierList = SoldierManager:get_soldier()
    end
end

function UIStrike:MaximumSoldierCount()
	local rest = self:GetMaxSoldierCount()
	for i, soldier in ipairs(self.soldierList) do
		local cnt = soldier.number_ > rest and rest or soldier.number_
		self:SetSoldierCount(i, cnt)
		rest = rest - cnt
	end
end

function UIStrike:MinimumSoldierCount()
	for i = 1, #self.soldierList do
		self:SetSoldierCount(i, 0)
	end
end

function UIStrike:UpdateSoldierPower()
	local power = 0
	for i, soldier in ipairs(self.soldierList) do
		power = power + soldier.fighting_power_ * self:GetSoldierCount(i)
	end
	self.soldierTotalPower = math.floor(power)
	self.vm.totalPower = self.heroTotalPower + self.soldierTotalPower
end

function UIStrike:OnSoldierCountChange()
	self:UpdateSoldierPower()
	self.SoldierNumTxt.text = string.format("%d/%d", self:GetSoldierTotalCount(), self.GetMaxSoldierCount())
	self:SetTime()
	self:SetWeight()
end

function UIStrike:SetTime()
    local soldierSpeed
	for i, v in ipairs(self.soldierList) do
		if self:GetSoldierCount(i) > 0 then
			local s = v:get_speed()
			soldierSpeed = soldierSpeed or s
            if soldierSpeed > s then
                soldierSpeed = s
            end
        end
	end
	soldierSpeed = soldierSpeed or 0
    local distance = WorldManager:GetLogicDistanceFromHome(self.obj)    
    local attrSpeed = WorldManager:GetSpeedAttrValue(self.obj)
    local time = UIUtil.get_march_time_by_distance(distance, soldierSpeed, attrSpeed)
    
	self.GooutBtn:GetChild("TimeTxt").text = UIUtil.format_time(time)
end

function UIStrike:SetWeight()
	if self.obj.obj_type_ == config.WORLD_RESPOINT then
		self.TargetTypeCtrler.selectedIndex = 1
		local weight = 0
		local density = self.obj:get_prop().para or 0
		for i, v in ipairs(self.soldierList) do
			local w = v:get_attribute_by_type(config.SOLDIER_ATTRIBUTES.WEIGHT)
			weight = weight + self:GetSoldierCount(i) * w * density
		end
		self.ResourcesTxt.text = math.floor(weight)
	else
		self.TargetTypeCtrler.selectedIndex = 0
		self.EnergyTxt.text = self.obj:get_energy_cost()
	end
end

function UIStrike:OnGooutBtnClick()
	local arr1 = {}
	local arr2 = {}
	for i, v in ipairs(self.soldierList) do
		local cnt = self:GetSoldierCount(i)
		if cnt > 0 then
			table.insert(arr1, v.id_)
			table.insert(arr2, cnt)
		end
	end
	WorldManager:StartBattle(self.obj, self.heroes, arr1, arr2, function()
		for _, v in pairs(self.heroes) do
			v.state_ = Hero.ST_OUT
		end
		self:Hide()
	end)
end

function UIStrike:OnClickHeroHead(index, hero)
	_G.UIController:ShowUI("UIHeroSelect", {troopsIndex = index, hero = hero})
end

function UIStrike:OnCancelBtnClick()
	self:MinimumSoldierCount()
end

function UIStrike:OnCancelBlueBtnClick()
	self.ButtonzkCtrler.selectedIndex = 1 - self.ButtonzkCtrler.selectedIndex
end

function UIStrike:OnSelectPriority(priority)
	self.ButtonzkCtrler.selectedIndex = 0
	self.vm.priorityType = priority - 1
end

function UIStrike:OnLevelCheckBtnClick()
	self:OnSelectPriority(PriorityType.Level)
end

function UIStrike:OnLoadCheckBtnClick()
	self:OnSelectPriority(PriorityType.Load)
end

function UIStrike:OnSpeedCheckBtnClick()
	self:OnSelectPriority(PriorityType.Speed)
end

function UIStrike:OnMatchCheckBtnClick()
	self:OnSelectPriority(PriorityType.Match)
end
