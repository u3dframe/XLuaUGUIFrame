--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIFortTroops = _G.UIController:Get("UIFortTroops")

local SoldierManager = _G.SoldierManager
local lang = _G.lang
local UIUtil = _G.UIUtil

function UIFortTroops:Awake()
	self.ItemList.itemRenderer = function(idx, item)
		local prop = self.firstReward[idx+1]
        UIUtil.SetItem(item, prop[1], prop[2], prop[3])
	end

	self.ComList.itemRenderer = function(idx, item)
		local data = self.soldierList[idx+1]
		UIUtil.SetSoldierHead(item, data)
	end
end

function UIFortTroops:InitBinds()
    return {
    }
end

function UIFortTroops:InitVM()
    return {
        ItemList = {},
        TroopList = {},
    }
end

function UIFortTroops:InitBinds()
    return {
		ItemList = function(val)
			self.ItemList.numItems = #val
		end,
		TroopList = function(val)
			dump(val, "val")
			self.ComList.numItems = #val
			self.allNum = 0
			for _, value in ipairs(val) do
				self.allNum = self.allNum + value[2]
			end
			self.HeroSkillTxt.text = string.format("武将详情       防守部队总数（%d）", self.allNum)
		end
    }
end

--FIXME:This is automatically generated
--FIXME:If no event to listen, Delete This function
function UIFortTroops:InitEvents()
    self:AddEventListener(eventKey or eventKeys, function()

    end)
end

function UIFortTroops:BindUI()
	self.RewardCtrler = self:GetController("Reward")
	self.HeroSkillTxt = self:GetControl("HeroSkillTxt")
	self.ComList = self:GetControl("ComList")
	self.ItemList = self:GetControl("ItemList")

	self.ComHerohead1 = self:GetControl("ComHerohead1")
	self.ComHerohead2 = self:GetControl("ComHerohead2")
end

function UIFortTroops:Start()
	self.RewardCtrler.selectedPage = self.args.fortObj:has_troop() and "NotShow" or "Show"
    _G.WorldManager:GetTroops(self.args.fortObj, function(troops)
        self.soldierList = troops.soldiers
        self.heroesList = troops.heroes
		local prop = self.args.fortObj:get_prop()
		self.firstReward = prop.first_reward
		self.heroId = prop.general

		self.vm.ItemList = self.firstReward
		self.vm.TroopList = self.soldierList
		dump(self.heroesList, "self.heroesList")
		local pos1 = self.heroesList[1] and self.heroesList[1].pos_ or 1
		local pos2 = self.heroesList[2] and self.heroesList[2].pos_ or (pos1 == 1 and 2 or 1)
		UIUtil.SetHeroHead(self["ComHerohead"..pos1], self.heroesList[1], pos1 - 1)
		UIUtil.SetHeroHead(self["ComHerohead"..pos2], self.heroesList[2], pos2 - 1)
    end)
end

--FIXME:Write logic Code here!

function UIFortTroops:OnCloseBtnClick()
	self:Hide()
end

function UIFortTroops:OnComHerohead1Click()
end

function UIFortTroops:OnComHerohead2Click()
end

