--This is an automatically generated class by FairyGUI. Please do not modify it.

	local UISoldierdetail = _G.UIController:Get("UISoldierdetail")

	function UISoldierdetail:Awake()
		self.marchInfo=self.args.marchInfo
		self:InitSoldierList()
	end
	
	function UISoldierdetail:InitSoldierList()
		self.SoldierList.itemProvider=function()
			return "ui://j3f1wdjywctqa"
		end
		self.SoldierList.itemRenderer=function(idx,obj)
			local soldier = self.marchInfo.soldiers_[idx + 1]
			local prop = SoldierManager:get_soldier_prop_by_id(soldier.id)
			obj:GetChild('SoldierTxt').text = lang('RESPOINT_3', prop.lv, prop.name)
			obj:GetChild('SoldierNumTxt').text =lang('UI_COLLECT_SURVIVAL',soldier.cnt)
		end
	end
	function UISoldierdetail:InitHero()
		if not self.ComHerohead then
			print("-----------------")
		end
		UIUtil.SetHeroHead(self.ComHerohead,nil,nil,true)
		UIUtil.SetHeroHead(self.ComMaster,nil,nil,true)
		self.PlayerTxt.text=self.marchInfo.name_
		local heroList=self.marchInfo.heroes_
		local num=0
		for _, v in ipairs(self.marchInfo.soldiers_) do
			num=num+v.cnt
		end
		self.SoliderNumTxt.text=num
		if heroList and #heroList > 0 then
			for _, v in ipairs(heroList) do
				if v.pos_==1 then
					UIUtil.SetHeroHead(self.ComHerohead, v,0)
				else
					UIUtil.SetHeroHead(self.ComMaster, v,1)
				end
			end
		end
	end
	function UISoldierdetail:InitBinds()
		return {
		}
	end	
	function UISoldierdetail:InitVM()
		return {
		}
	end
	--FIXME:This is automatically generated
	--FIXME:If no event to listen, Delete This function
	function UISoldierdetail:InitEvents()
		self:AddEventListener(
			_G.EventKey.WORLD_MARCH_DELETE,
			function(arg)
				if self.obj.idx_ ~= arg.id then
					return
				end
				self:Hide()
			end
		)
	end
	
	function UISoldierdetail:BindUI()
		self.HitZoneBtn = self:GetControl("HitZoneBtn")
		self.PlayerTxt = self:GetControl("PlayerTxt")
		self.SoldierList = self:GetControl("SoldierList")
		self.SoliderNumTxt = self:GetControl("SoliderNumTxt")
		self.ComHerohead = self:GetControl("ComHerohead")
		self.ComMaster = self:GetControl("ComMaster")
		self.CloseBtn = self:GetControl("Combg.CloseBtn")
	end
	
	function UISoldierdetail:Start()
		self.SoldierList.numItems=table.size(self.marchInfo.soldiers_)
		self:InitHero()
	end
	function UISoldierdetail:OnDestory()
		self.marchInfo=nil
	end
	--FIXME:Write logic Code here!
	function UISoldierdetail:OnHitZoneBtnClick()
		self:Hide()
	end
	function UISoldierdetail:OnCloseBtnClick()
		self:Hide()
	end