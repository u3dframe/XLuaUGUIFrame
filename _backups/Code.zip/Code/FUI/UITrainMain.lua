--This is an automatically generated class by FairyGUI. Please do not modify it.

local UITrainMain = UIController:Get("UITrainMain")

_G.table.mixin(UITrainMain, require("FUI/Patch/TopBannerPatch"))

local SoldierskillConfig = _G.Database.SoldierskillConfig
local AttributeConfig = _G.Database.AttributeConfig
local BuildManager = _G.BuildManager
local SoldierManager = _G.SoldierManager
local ItemManager = _G.ItemManager
local config = _G.config
local UIUtil = _G.UIUtil
local UIController = _G.UIController

local NUM_SKILL_SLOT = 3
local NUM_TRAIN_ATTR = 3
local NUM_TRAP_ATTR = 1
local NUM_COST = 4

function UITrainMain:Awake()
	self.soldierClass = self.args.soldierClass or config.SOLDIER_CLASS.COMMON
	if self.soldierClass == config.SOLDIER_CLASS.COMMON then
		self.GoldSpeedBtn:GetController("function").selectedIndex = 0
		self.trainBtn:GetController("function").selectedIndex = 0
	elseif self.soldierClass == config.SOLDIER_CLASS.TRAP then
		self.GoldSpeedBtn:GetController("function").selectedIndex = 1
		self.trainBtn:GetController("function").selectedIndex = 1
	end
	self.functionCtrler.selectedIndex = self.soldierClass - 1
	self.spaceClass = self.args.space
	local id = self.spaceClass.build_info_ and self.spaceClass.build_info_.id_
	self.buildInfo = BuildManager:get_build_info_by_id(id)
	self:SetTitle(self:GetBuildName())
	self.soldierInfoList = SoldierManager:get_soldier_info_by_build_type(self.buildInfo.build_type_, self.soldierClass)
	self:GetUnlockSoldiers()
	self.headObjs = {}
	self.isGestureInit = {}
	self:InitSkillList()
	self:InitAttributeList()
	self:InitSoldierList()
	self:InitSlider()
	self:InitSPainList()
	self.HeroList.numItems = #self.soldierInfoList
	
	if self.soldierClass == config.SOLDIER_CLASS.TRAP then
		return
	end
	self.soldierSpineList.numItems = #self.soldierInfoList
end

function UITrainMain:InitBinds()
    return {
		currIndex = function(value)
			local obj = self.headObjs[self.currIndex]
			if obj then
				obj:GetController("choose").selectedIndex = 0
			end
			self.currIndex = value
			self.selectedSoldier = self.soldierInfoList[self.currIndex]
			self.headObjs[self.currIndex]:GetController("choose").selectedIndex = 1
			self:RefreshSoldierInfo()
			self.soldierSpineList:ScrollToView(self.currIndex - 1)
		end,
    }
end

function UITrainMain:InitVM()
    return {
		currIndex = 1,
    }
end

function UITrainMain:InitEvents()
    self:AddEventListener(_G.EventKey.CITY_SOIDIER_FINISHED, function(arg)
		if self.buildInfo and self.buildInfo.id_ == arg.buildID then
			self.trainingSoldier = nil
			self:Hide()
		end
	end)
	if self.args.soldierClass == config.SOLDIER_CLASS.TRAP then
		self:AddEventListener(_G.EventKey.CITY_TRAP_CHANGE, function(arg)
			self:RefreshSoldierCount()
		end)
	end
	self:AddEventListener(_G.EventKey.CITY_SOIDIER_UPDATE, function(arg)
		self:RefreshSoldierInfo()
		self:RefreshSoldierCount()
	end)
end

function UITrainMain:BindUI()
	self.stateCtrler = self:GetController("state")
	self.functionCtrler = self:GetController("function")
	self.touchCtrler = self:GetController("touch")
	self.buttonCtrler = self:GetController("button")
	self.ComSkill = self:GetControl("ComSkill")
	self.comSkillStateCtrler = self:GetControl("ComSkill"):GetController("state")
	self.AmountTxt = self:GetControl("ComSkill.AmountTxt")
	self.overall = self:GetControl("ComSkill.overall")
	self.AttributeList = self:GetControl("ComSkill.AttributeList")
	self.Amount_1Txt = self:GetControl("ComSkill.Amount_1Txt")
	self.Amount_4Txt = self:GetControl("ComSkill.Amount_4Txt")
	self.Amount_2Txt = self:GetControl("ComSkill.Amount_2Txt")
	self.Amount_3Txt = self:GetControl("ComSkill.Amount_3Txt")
	self.unlock_infoTxt = self:GetControl("ComSkill.unlock_infoTxt")
	self.typeCtrler = self:GetControl("ComSoilderType"):GetController("type")
	self.DesicriptionTxt = self:GetControl("ComSoilderType.DesicriptionTxt")
	self.levelTxt = self:GetControl("ComSoilderType.levelTxt")
	self.PromotBtn = self:GetControl("PromotBtn")
	self.SkillList = self:GetControl("SkillList")
	self.HeroList = self:GetControl("HeroList")
	self.amount = self:GetControl("amount")
	self.slideprogress = self:GetControl("slideprogress")
	self.pro = self:GetControl("pro")
	self.time = self:GetControl("time")
	self.cancel = self:GetControl("cancel")
	self.GoldSpeedBtn = self:GetControl("GoldSpeedBtn")
	self.ImmBtn = self:GetControl("ImmBtn")
	self.trainBtn = self:GetControl("trainBtn")
	self.ItemSpeedBtn = self:GetControl("ItemSpeedBtn")
	self.TearBtn = self:GetControl("TearBtn")
	self.trapStateCtrler = self:GetControl("Trap"):GetController("state")
	self.trapLevelTxt = self:GetControl("Trap.levelTxt")
	self.trapDesicriptionTxt = self:GetControl("Trap.description")
	self.soldierSpineList = self:GetControl("iconloader.SoldierSlideList")
end

function UITrainMain:Start()
	self.vm.currIndex = self:GetInitIndex()
	self:ScrollHeadToView(false)
	for i, v in ipairs(self.soldierInfoList) do
		print("soldier info = ", v.soldier_type_, v.lv_)
	end
end

function UITrainMain:OnDestroy()
	self:CloseTimer()
    self:RemoveEventListener()
end

function UITrainMain:InitSoldierList()
	self.HeroList.itemProvider = function()
		return "ui://hnn2yjjpfg8d1e"
	end
	self.HeroList.itemRenderer = function(idx, obj)
		local index = idx + 1
		self.headObjs[index] = obj
		local soldierInfo = self.soldierInfoList[index]
		local unlock = self:IsUnlock(soldierInfo)
		obj:GetController("state").selectedIndex = unlock and 0 or 1
		obj:GetChild("icon").url = "art/"..soldierInfo.small_icon_path_
	end
	local function ItemClick(context)
		self.vm.currIndex = self.HeroList:GetChildIndex(context.data) + 1
    end
	self.HeroList.onClickItem:Add(ItemClick)
end

function UITrainMain:InitSkillList()
	self.SkillList.itemProvider = function()
		return "ui://hnn2yjjpfg8d23"
	end

	self.SkillList.itemRenderer = function(idx, obj)
		local index = idx + 1
		local skill = self.selectedSoldier.skill_info_[index]
		if skill then
			obj:GetController("state").selectedIndex = 0
			obj:GetChild("icon").url = "art/"..skill.path_
		else
			obj:GetController("state").selectedIndex = 1
			obj:GetChild("icon").url = nil
		end
		if not self.isGestureInit[index] then
			local OnPressStart = function()
				local i = self.SkillList:GetChildIndex(obj) + 1
				local skill = self.selectedSoldier.skill_info_[i]
				if not skill then return end
				obj:GetController("des").selectedIndex = 1
				obj:GetChild("name").text = skill.name_
				obj:GetChild("des").text = skill.des_
			end
			local OnPressEnd = function()
				obj:GetController("des").selectedIndex = 0
			end
			local gesture = _G.LongPressGesture(obj)
			gesture.once = false
			gesture.trigger = 0.3
			gesture.onBegin:Add(OnPressStart)
			gesture.onEnd:Add(OnPressEnd)
			self.isGestureInit[index] = true
		end
	end
end

function UITrainMain:InitAttributeList()
	self.AttributeList.itemProvider = function()
		return "ui://hnn2yjjpfg8d14"
	end
	self.AttributeList.itemRenderer = function(idx, obj)
		obj:GetController("state").selectedIndex = idx
		local attrs = self.selectedSoldier.attribute_
		local attr = attrs[config.SOLDIER_ATTR[idx + 1]]
		obj:GetChild("NameTxt").text = AttributeConfig.AttributeData[idx + 1].name_c
		obj:GetChild("DataTxt").text = attr
	end
end

local ExistPath = {
	[1] = 4,
	[2] = 3,
	[3] = 4,
	[4] = 4,
	[5] = 4,
	[6] = 4,
	[7] = 5,
	[8] = 5,
}

function UITrainMain:GetSpinePath(soldier)
	local soldierType = soldier.soldier_type_
	local lv = soldier.lv_
	local exist = false
	local existLv = ExistPath[soldierType]
	if existLv == lv then
		exist = true
	end
	local localPath = string.format("Model/Soldier/soldier_type_%d/lv_%d/siji_SkeletonData", soldierType, exist and lv or existLv)
	return localPath
end

function UITrainMain:InitSPainList()
	self.isSpineLoading = {}
	self.soldierSpineList.scrollPane.onScrollEnd:Set(function(context)
		self.vm.currIndex = context.sender.currentPageX + 1
		self:ScrollHeadToView(true)
    end)
 	self.soldierSpineList.itemRenderer = function(idx, item)
		local soldier = self.soldierInfoList[idx + 1]
        --如果spine正在加载，跳过
        if self.isSpineLoading[soldier.id_] then
            return
        end
        self.isSpineLoading[soldier.id_] = true

        local IconGraph = item:GetChild("IconGraph")
        if not _G.Slua.IsNull(IconGraph) then
            IconGraph.visible = false
		end

		local assetPath = self:GetSpinePath(soldier)
		_G.GameController.spineController:CreateSkeletonAnimObj(assetPath, function(obj)
			if _G.Slua.IsNull(obj) then
                self.isSpineLoading[soldier.id_] = false
                return
            end

            IconGraph = item:GetChild("IconGraph")
            if not _G.Slua.IsNull(IconGraph) and not _G.Slua.IsNull(IconGraph.displayObject.gameObject) then
                print("IconGraph.displayObject.name = "..IconGraph.displayObject.gameObject.name)
                if IconGraph.displayObject.gameObject.name == "GoWrapper" then
                    item.container:RemoveChild(IconGraph.displayObject, true);
                end
            end

            obj.name = soldier.id_

            local rect_data = soldier.prop_.scale
            dump(rect_data, "rect_data")
            local uiSpineScale = self:GetUISpineScale()
            dump(uiSpineScale, "uiSpineScale")
            obj.transform.position = _G.Vector3(rect_data[2][1], rect_data[2][2])
			obj.transform.localScale =  _G.Vector3(uiSpineScale.x*rect_data[1], uiSpineScale.y*rect_data[1], 1)
            local heroGraph = item:GetChild("IconGraph")
            local goWrapper = _G.UIController:LoadGameObjectToUI(heroGraph, obj)
            goWrapper.supportStencil = true
            _G.GameController.spineController:PlayAnimation(obj, "animation" , 0 , true, nil)
            IconGraph = item:GetChild("IconGraph")
            if not _G.Slua.IsNull(IconGraph) then
                IconGraph.visible = true
            end
            self.isSpineLoading[soldier.id_] = false
		end)
    end
	self.soldierSpineList:SetVirtual()
end

function UITrainMain:GetBuildName()
	return self.buildInfo and self.buildInfo.name_
end

function UITrainMain:IsUnlock(soldierInfo)
	local buildType = soldierInfo.build_type_
	local buildInfo = BuildManager:get_build_info_by_build_type(buildType)
	if not buildInfo then
		buildInfo = BuildManager:get_build_data(buildType)
		return false, buildInfo
	end
	local dependLv = soldierInfo.unlock_
	return dependLv <= buildInfo.lv_, buildInfo
end

function UITrainMain:IsCurrentUnlock()
	return self:IsUnlock(self.selectedSoldier)
end

function UITrainMain:GetUnlockSoldiers()
	self.unlockSoldiers = {}
	for k, v in pairs(self.soldierInfoList) do
		local unlock, _ = self:IsUnlock(v)
		if unlock then
			table.insert(self.unlockSoldiers, v)
		end
	end
	table.sort(self.unlockSoldiers, function(x, y)
		return x.lv_ > y.lv_
	end)
end

function UITrainMain:UpdateTrainingSoldier()
	local timerExists, _, id = SoldierManager:check_soldier_state(self.buildInfo.build_type_)
	if timerExists then
		self.trainingSoldier = SoldierManager:get_soldier_info_by_id(id, self.soldierClass)
	end
	self.timerExists = timerExists
end

function UITrainMain:GetInitIndex()
	--如果点了晋升按钮，就定位到点击晋升按钮时候的士兵
	--如果点了金币训练按钮，就定位到点击金币训练按钮的士兵
	-- if self.isClickLvUpBtn or self.isClickGoldLvupBtn then
	-- 	return
	-- end
	if self.trainingSoldier then
		for i = #self.soldierInfoList, 1, -1 do
			if self.soldierInfoList[i].id_ == self.trainingSoldier.id_ then
				return i
			end
		end
	end
	return #self.unlockSoldiers
end

function UITrainMain:ScrollHeadToView(smooth)
	self.HeroList:ScrollToView(self.vm.currIndex.value - 1, smooth)
end

function UITrainMain:RefreshSoldierInfo()
	self:CloseTimer()
	self:UpdateTrainingSoldier()
	local soldierInfo = self.selectedSoldier
	local unlocked = self:IsCurrentUnlock()
	if self.soldierClass == config.SOLDIER_CLASS.COMMON then
		self.SkillList.numItems = NUM_SKILL_SLOT
		self.AttributeList.numItems = NUM_TRAIN_ATTR
		self.typeCtrler.selectedIndex = soldierInfo.soldier_type_ - 1
		self.levelTxt.text = soldierInfo.lv_
		self.DesicriptionTxt.text = soldierInfo.describe_
	elseif self.soldierClass == config.SOLDIER_CLASS.TRAP then
		self.AttributeList.numItems = NUM_TRAP_ATTR
		self.trapStateCtrler.selectedIndex = soldierInfo.soldier_type_ - 101
		self.trapLevelTxt.text = soldierInfo.lv_
		self.trapDesicriptionTxt.text = soldierInfo.describe_
	end

	--晋升/拆除按钮状态
	local show = true
	if self.soldierClass == config.SOLDIER_CLASS.COMMON then
		--如果到达最大等级 则隐藏晋升按钮
		local not_max_lv = self.soldierInfoList[#self.soldierInfoList - 1].lv_ > soldierInfo.lv_
		self.PromotBtn:GetController("show").selectedIndex = not_max_lv and 0 or 1
		if not_max_lv then
			--1.已经解锁2.没有在训练3.数量不能为零 4.晋升的目标士兵不能是未解锁的(也就是已经解锁的士兵中，最后俩个肯定是置灰状态)
			local count = soldierInfo.number_
			local is_last_two
			if #self.unlockSoldiers <= 2 then
				is_last_two = true
			else
				is_last_two = soldierInfo.lv_ >= self.unlockSoldiers[2].lv_
			end
			show = unlocked and not self.timerExists and count > 0 and not is_last_two
		end
	end
	self.touchCtrler.selectedIndex = show and 0 or 1

	self.overall.text = soldierInfo.fighting_power_
	self:RefreshSoldierCount()
	if unlocked then
		self.comSkillStateCtrler.selectedIndex = 0
		self:RefreshTrainState()
	else
		self.stateCtrler.selectedIndex = 2
		self.comSkillStateCtrler.selectedIndex = 1
		local key
		if self.soldierClass == config.SOLDIER_CLASS.COMMON then
			key = "UI_SOLDIER_UNLOCK"
		elseif self.soldierClass == config.SOLDIER_CLASS.TRAP then
			key = "UI_TRAP_UNLOCK"
		end
		self.unlock_infoTxt.text = lang(key, self:GetBuildName(), soldierInfo.unlock_)
	end
	self:RefreshMaxTrainCount()
	self.sliderValue = self.maxCount
	self.slideprogress.value = self.maxCount
	self:OnSliderChanged()
end

function UITrainMain:RefreshMaxTrainCount()
	if self.soldierClass == config.SOLDIER_CLASS.COMMON then
		self.maxCount = self.selectedSoldier:get_drill_max_count()
	elseif self.soldierClass == config.SOLDIER_CLASS.TRAP then
		self.maxCount = SoldierManager:get_trap_train_max_cnt()
	end
	self.slideprogress.min = self.maxCount > 0 and 1 or self.maxCount
	self.slideprogress.max = self.maxCount
	local value = self.sliderValue
	if not value or value > self.slideprogress.max or value < self.slideprogress.min then
		self.slideprogress.value = self.slideprogress.max
		self.sliderValue = self.slideprogress.max
	end
	--self.slideprogress:CheckSlider()
	if self.slideprogress.max == self.slideprogress.min and self.slideprogress.min <= 1 then
		self.slideprogress.min = 0
		self.slideprogress.touchable = false
	else
		self.slideprogress.touchable = true
	end
end

function UITrainMain:RefreshSoldierCount()
	local amountTxt
	if self.soldierClass == config.SOLDIER_CLASS.COMMON then
		amountTxt = string.format("%s%d", lang("UI_SOLDIER_AMOUNT"), self.selectedSoldier.number_)
	elseif self.soldierClass == config.SOLDIER_CLASS.TRAP then
		local has = SoldierManager:get_trap_total_count()
		local cap = SoldierManager:get_trap_capacity()
		amountTxt = string.format("%s%d/%d", lang("UI_SOLDIER_AMOUNT_TOTAL"), has, cap)
	end
	self.AmountTxt.text = amountTxt
	if self.soldierClass == config.SOLDIER_CLASS.TRAP then
		self.touchCtrler.selectedIndex = (self:IsCurrentUnlock() and self.selectedSoldier.number_ > 0) and 0 or 1
	end
end

function UITrainMain:RefreshTrainState()
	if self.trainingSoldier then
		self.stateCtrler.selectedIndex = 1
		local gold = self.trainingSoldier:get_gold_drill_number()
		local enough = ItemManager:check_coin({config.ITEM_GOLD, 0, gold})
		local str = string.format("%s%s", UIUtil.res_num_to_str(gold), lang("ITEM7"))
		if not enough then
			str = lang("UI_SOLDIER_PROPS_COUNT", str)
		end
		self.ImmBtn:GetChild("AmountTxt").text = str
		--在训练中
		if self.trainingSoldier:is_training() then
			--self.hint_time_.text = lang("UI_SOLDIER_REMAINING_TIME")
			--self.cancel_txt_.text = lang("UI_SOLDIER_CANCEL_DRILL")
		elseif self.trainingSoldier:is_soldier_updating() then --在晋升中
			--self.hint_time_.text = lang("UI_SOLDIER_PROMOTION_TIME")
			--self.cancel_txt_.text = lang("UI_SOLDIER_CANCEL_PROMOTE")
		end
		self:PlayTimer(self.trainingSoldier)
	else
		self.stateCtrler.selectedIndex = 0
	end
end

function UITrainMain:PlayTimer(soldier)
	if not soldier then return end
	if not soldier.start_time_ or not soldier.end_time_ then return end
	local endTime = soldier.end_time_
	local totalTime = math.floor(soldier.total_time_)

	local currSecond = totalTime - (math.floor(endTime - Net.server_time()))
	if currSecond < 0 then currSecond = 0 end

	local lastTime = Net.server_time()
	self.pro.max = totalTime
 	self.luaTimer = LuaTimer.Add(0, 1000, function()
 		--时间不精确处理
        if Net.server_time() - lastTime > 1 then
            currSecond = currSecond + 1
        end
        lastTime = Net.server_time()

        if currSecond > totalTime then
            return false
		end
		local time = UIUtil.format_time(totalTime - currSecond)
        self.time.text = string.format("%s%s", lang("UI_SOLDIER_REMAINING_TIME"), time)
		self.pro.value = currSecond
		self.ItemSpeedBtn:GetChild("TimeTxt").text = time
        currSecond = currSecond + 1
 	end)
end

function UITrainMain:CloseTimer()
	if self.luaTimer then
    	LuaTimer.Delete(self.luaTimer)
    	self.luaTimer = nil
    end
end

function UITrainMain:InitSlider()
	local function onSliderChanged(context)
		self.sliderValue = self:CheckSliderValue(context.sender.value)
		self:OnSliderChanged()
	end
	self.slideprogress.onChanged:Set(onSliderChanged)
end

function UITrainMain:OnSliderChanged()
	local value = self.sliderValue
	if value > 0 then
		self.GoldSpeedBtn:GetController("type").selectedIndex = 0
		self.trainBtn:GetController("type").selectedIndex = 0
		self.buttonCtrler.selectedIndex = 0
	else
		self.GoldSpeedBtn:GetController("type").selectedIndex = 1
		self.trainBtn:GetController("type").selectedIndex = 1
		self.buttonCtrler.selectedIndex = 1
	end
	local spendData = self.trainingSoldier and self.trainingSoldier.spend_ or self.selectedSoldier.spend_
	self.amount.text = string.strfmt("{1}/{2}", value, self.maxCount)

	for i = 1, NUM_COST do
		if spendData[i] then
			local txt = self[string.format("Amount_%dTxt", i)]
			local str = UIUtil.res_num_to_str(spendData[i][3] * value)
			if not SoldierManager:IsResEnough(self.selectedSoldier.id_, value, i, self.soldierClass) then
				str = lang("UI_SOLDIER_PROPS_COUNT", str)
			end
			txt.text = str
			--if not self:is_alive() then return end
		else
			--if not self:is_alive() then return end
			self[string.format("Amount_%dTxt", i)].text = "0"
		end
	end

	local remainingTime = self.selectedSoldier:get_drill_time(value)
	self.trainBtn:GetChild("TimerTxt").text = UIUtil.format_time(remainingTime)
	local cnt = self.selectedSoldier:get_gold_drill_number(value)
	local enough = ItemManager:check_coin({config.ITEM_GOLD, 0, cnt})
	local str = string.format("%s%s", UIUtil.res_num_to_str(cnt), lang("ITEM7"))
	if not enough then
		str = lang("UI_SOLDIER_PROPS_COUNT", str)
	end
	self.GoldSpeedBtn:GetChild("CostTxt").text = str
end

function UITrainMain:OnPromotBtnClick()
	--正在训练无法晋升
	if self.timerExists then
		--local hint_str = self.build_info_.name_.."正在训练，暂时无法晋升"
		local hint = lang("UI_SOLDIERDES_HINT3", self.buildInfo.name_)
		_G.MsgCenter.send_message(Msg.SHOW_HINT, hint)
		return
	end
	if self.selectedSoldier and self.selectedSoldier.id_ then
		--当前兵未解锁
		if not self:IsCurrentUnlock() then
			self:ShowHintNotLock() -- 提示
			return
		end
		if self.selectedSoldier.number_ <= 0 then
			_G.MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_SOLDIERDES_HINT2"))
			return
		end
		-- -1 是因为要多算一个
		if self.unlockSoldiers[1].lv_ - 1 <= self.selectedSoldier.lv_ then
			self:ShowHintNotLock()
			return
		end
		local nextSoldier
		for _, v in ipairs(self.unlockSoldiers) do
			if v.soldier_type_ == self.selectedSoldier.soldier_type_ then
				nextSoldier = v
				break
			end
		end
		if _G.FairyGUI then
			UIController:ShowUI("UITrainPromot", {
				currSoldierID = self.selectedSoldier.id_,
				nextSoldierID = nextSoldier.id_,
				soldierMaxCnt = self.maxCount,
				buildID = self.buildInfo.id_,
			})
			return
		end
		--参数：士兵id ，晋升目标士兵的id，可晋升的最大数量，建筑id
		_G.UIManager.open_window("SoldierPromoteWindow", function()
			self.isClickLvUpBtn = true
			self.currSelectSoldierLv = self.selectedSoldier.lv_ 
		end, self.selectedSoldier.id_, nextSoldier.id_, self.maxCount, self.buildInfo.id_)		  
	end
end

--显示当前士兵或者晋升士兵未解锁 情况下的提示
function UITrainMain:ShowHintNotLock()
	local soldier = SoldierManager:get_soldier_info_by_id(self.selectedSoldier.id_ + 2, self.soldierClass)
	if soldier then
		local build_type = soldier.build_type_
		local build = BuildManager:get_build_info_by_build_type(build_type)
		local str = lang("UI_SOLDIER_PROMOTE_HINT", build.name_, soldier.unlock_, soldier.lv_, soldier.name_)
		_G.MsgCenter.send_message(Msg.SHOW_HINT, str)
	end
end

function UITrainMain:CheckSliderValue(value)
	if not value or UIUtil.IsNaN(value) or value > self.slideprogress.max then
		value = self.slideprogress.max
	elseif value < self.slideprogress.min then
		value = self.slideprogress.min
	end
	return value
end

function UITrainMain:OnInfoBtnClick()
	if not self.selectedSoldier or not self.buildInfo then return end
	if _G.FairyGUI then
		UIController:ShowUI("UITrainDetail", {soldierLv = self.selectedSoldier.lv_, buildID = self.buildInfo.id_})
		return
	end
	_G.UIManager.open_window("SoldierDetailsWindow", nil, self.selectedSoldier.lv_, self.buildInfo.id_)
end

function UITrainMain:OnArrow_upClick()
	if self.currIndex <= 1 then return end
	self.vm.currIndex = self.vm.currIndex.value - 1
	self:ScrollHeadToView(true)
end

function UITrainMain:OnArrow_downClick()
	if self.currIndex >= #self.soldierInfoList then return end
	self.vm.currIndex = self.vm.currIndex.value + 1
	self:ScrollHeadToView(true)
end

function UITrainMain:OnMinusBtnClick()
	if self.sliderValue <= 1 then return end
	self.sliderValue = self.sliderValue - 1
	self.slideprogress.value = self.sliderValue
	self:OnSliderChanged()
end

function UITrainMain:OnRoundAddBtnClick()
	if self.sliderValue >= self.slideprogress.max then return end
	self.sliderValue = self.sliderValue + 1
	self.slideprogress.value = self.sliderValue
	self:OnSliderChanged()
end

function UITrainMain:OnItemSpeedBtnClick()
	if UIController then
        UIController:ShowUI("UISpeedUp", {buildID = self.buildInfo.id_})
        return
    end
    _G.UIManager.open_window("SpeedUpWindow", nil, config.SPEEDUP_DRILL, self.buildInfo.id_)
end

function UITrainMain:OncancelClick()
	if not self.trainingSoldier then return end
	SoldierManager:CancelTrain(self.buildInfo.id_, self.trainingSoldier.id_, self.trainingSoldier.class_, function()
		self.trainingSoldier = nil
		self.spaceClass:stop_timer_2()
		self:Hide()
	end)
end

function UITrainMain:OntrainBtnClick()
	SoldierManager:TrainSoldier(self.buildInfo.id_, self.selectedSoldier.id_, 
		self.sliderValue, self.selectedSoldier.class_, false, function() self:Hide() end)
end

function UITrainMain:OnGoldSpeedBtnClick()
	self.isClickGoldLvupBtn = true
	SoldierManager:TrainSoldier(self.buildInfo.id_, self.selectedSoldier.id_, self.sliderValue, 
		self.selectedSoldier.class_, true, function()
			self.trainingSoldier = nil
			self:RefreshSoldierCount()
			self:RefreshMaxTrainCount()
			self:OnSliderChanged()
		end)
end

function UITrainMain:OnImmBtnClick()
	if not self.trainingSoldier then return end
	SoldierManager:GoldSpeedUp(self.buildInfo.id_, self.trainingSoldier.id_, self.trainingSoldier.class_, function()
		self.trainingSoldier = nil
	end)
end

function UITrainMain:OnTearBtnClick()
	UIController:ShowUI("UICommonPop", {
		mode = 3,
		title = lang("TRAP_TEAR_TITLE"),
		content = lang("TRAP_TEAR_CONTENT"),
		btnTxt = lang("TRAP_TEAR"),
		confirmTxt = lang("TRAP_TEAR_CONFIRM"),
		show = 1,
		max = self.selectedSoldier.number_,
		callback = function(cnt)
			SoldierManager:RemoveTrap(self.selectedSoldier.id_, cnt, function()
				self:RefreshMaxTrainCount()
				self:OnSliderChanged()
			end)
		end
	})
end

function UITrainMain:OnDestroy()
	self.trainingSoldier = nil
end

