--This is an automatically generated class by FairyGUI. Please do not modify it.

local Net = _G.Net
local Msg = _G.Msg
local lang = _G.lang
local MsgCenter = _G.MsgCenter
local BuildManager = _G.BuildManager
local cityConfig = _G.Database.CityConfig
local UIBuildUpdate = _G.UIController:Get("UIBuildUpdate")

_G.table.mixin(UIBuildUpdate, require("FUI/Patch/TopBannerPatch"))

function UIBuildUpdate:Awake()
	self.spaceClass = self.args.space--空地信息（服务器数据）
	self.level = self.args.level--当前空地上的建筑的信息
	self.buildType = self.args.buildType--要建造的建筑的类型
	self:InitData()
	self.BuildDescribe.text = self.buildInfo.introduce_
end
function UIBuildUpdate:InitData()
	self.spaceInfo = BuildManager:get_space_info_by_id(self.spaceClass.id_)--空地信息（表数据）
	self.selectedType = 2--下一等级信息的显示方式控制器
	self.buildInfo = BuildManager:get_build_data(self.buildType)--此类型建筑信息（表数据）
	self.buildData = self.spaceClass.build_info_--建筑信息（服务器数据） 这个里面有建筑时间
	self.nextInfo = self.buildInfo:get_update_info_by_level(self.level + 1)--下一等级建筑信息（表数据）
	local curLevel = self.level
	if curLevel == 0 then
		curLevel = 1
		self.BuildTitle.text = self.buildInfo.name_
	else
		self.BuildTitle.text = self.buildInfo.name_
	end
	self.curInfo = self.buildInfo:get_update_info_by_level(curLevel)--当前等级的建筑信息（表数据）
	self.conditionData = self.buildInfo:get_update_info_by_level(curLevel + 1)--升下级需要的资源列表
	self.buildQueue = {}--当前的建造对象
	self.buildQueueNum = 0--当前建造队列数量
	self.spendData = {} --花费(条件)表
	self.conditionNum = 0--花费（条件）的数量
end
function UIBuildUpdate:InitBinds()
    return {
    }
end

function UIBuildUpdate:InitVM()
    return {
    }
end
--添加消息事件self:AddEventListener(eventKey or eventKeys, function()end)
function UIBuildUpdate:InitEvents()
end

function UIBuildUpdate:BindUI()
	self.BuildInterface = self:GetControl("BuildInterface")
	self.BuildTitle = self:GetControl("BuildInterface.BuildTitle")
	self.BuildDescribe = self:GetControl("BuildInterface.BuildDescribe")
	self.BuildUpdate = self:GetControl("BuildUpdate")
	self.UpdateCtrler = self:GetControl("BuildUpdate"):GetController("Update")
	self.UpgradeLoader = self:GetControl("BuildUpdate.UpgradeLoader")
	self.BuildTitleTxt = self:GetControl("BuildUpdate.BuildTitleTxt")
	self.BuildContentTxt = self:GetControl("BuildUpdate.BuildContentTxt")
	self.UpgradeTitle = self:GetControl("BuildUpdate.UpgradeTitle")
	self.BuildUpgradeList = self:GetControl("BuildUpdate.BuildUpgradeList")
	self.BuildLevelTxt = self:GetControl("BuildUpdate.BuildLevelTxt")
	self.UpgradeCondition = self:GetControl("BuildUpdate.UpgradeCondition")
	self.BuildUpgradeBtn = self:GetControl("BuildUpdate.BuildUpgradeBtn")
	self.BuildFreeBtn = self:GetControl("BuildUpdate.BuildFreeBtn")
	self.UnLockTxt = self:GetControl("BuildUpdate.UnLockTxt")
	self.BuildIntertitle = self:GetControl("BuildIntertitle")
	self.TitleTxt = self:GetControl("BuildIntertitle.TitleTxt")
	self.BackBtn = self:GetControl("BuildIntertitle.BackBtn")
	self.CloseBtn = self:GetControl("BuildIntertitle.CloseBtn")
end

function UIBuildUpdate:Start()
	self:GetControl("BuildIntertitle.TitleTxt").text = lang("UI_BUILDSPEND_BUILD")
	self:InitView()
end
function UIBuildUpdate:InitView()
	self:InitUpdateState()
	self:InitConditionList()
	self:SetBtnShow()
	if self.level == 0 then
		self:SetTitle(lang("UI_BUILDCREATE_TITLE"))
	else
		self:SetTitle(lang("SKILL_LEVEL"))
	end
end
--FIXME:Write logic Code here!
function UIBuildUpdate:InitUpdateState()
	local stateController = self.UpdateCtrler
	self:GetSelectedType()
	stateController.selectedIndex = self.selectedType
	if self.selectedType == 0 then
		self:SetIconType()
	elseif self.selectedType == 1 then
		self:SetAddResourceType()
	else
		self:SetResourceType()
	end
end
function UIBuildUpdate:GetSelectedType()
	if #self.curInfo.updatepath > 0 then
		self.selectedType = 0
		self:SetIconType()
	else
		local num = #self.curInfo.introduce
		if num == 1 then
			self.selectedType = 2
		else
			self.selectedType = 1
		end
	end
	if self.level == 0 then
		self.selectedType = 2
	end
end
-- local function BuildUpgradeListItemRenderer(index,obj)
-- 	local data = UIBuildUpdate.curInfo
-- 	local descName = data.introduce
-- 	if #descName <= 1 or index + 1 > #descName then
-- 		_G.elog("跳出了---->"..tostring(#descName))
-- 		return
-- 	end
-- 	local descIndex = index + 1
-- 	if descIndex > 1 then
-- 		descIndex = descIndex+1
-- 	end
-- 	local numIndex = index + 3
-- 	local curNum = UIBuildUpdate.curInfo.moredetails[numIndex]
-- 	local addText = obj:GetChild("BuildNext2")
-- 	obj:GetChild("BuildNext3").text = lang(descName[descIndex])
-- 	if curNum == 0 then
-- 		addText.visible = false
-- 		return
-- 	end
-- 	local addNum = UIBuildUpdate.nextInfo.moredetails[numIndex] - curNum
-- 	addText.visible = true
-- 	addText.text = string.format(addText.text,curNum,addNum)
-- end

local function BuildUpgradeListItemProvider(index)
	return "ui://UIBuildUpdate/BuildUpgradeList"
end
--设置第一种界面显示类型的数据（有图片的）
function UIBuildUpdate:SetIconType()
	self.UpgradeLoader.url = "art/"..self.curInfo.updatepath[1]
	self.BuildTitleTxt.text = lang(self.curInfo.byinintroduce)
	self.BuildContentTxt.text = lang(self.curInfo.introduce[1])
	self.UnLockTxt.text = lang(self.curInfo.iconinintroduce)
end
--设置第二种显示类型的界面数据(显示下一级的数据)
function UIBuildUpdate:SetAddResourceType()
	local id = self.spaceClass.build_info_.id_
	self.build = _G.BuildManager:get_build_info_by_id(id)
	local whuteValue, offsetValue = self.build:get_moredes_value_offset()
	if  not whuteValue then
		return
	end
	self.updateValues = {}
	for i, v in ipairs(whuteValue) do
		local colorTxt = string.format('[color=#06A809]%s[/color]', '+' .. offsetValue[i])
		table.insert(self.updateValues, v .. colorTxt)
	end
	self.BuildUpgradeList.itemRenderer = function(idx, obj)
		local index = (idx + 1) + idx --取奇数
		local descName = self.curInfo.introduce[index]
		obj:GetChild("BuildNext3").text = lang(descName)
		obj:GetChild("BuildNext2").text = self.updateValues[idx + 1]
	end

	--self.BuildUpgradeList.itemRenderer = BuildUpgradeListItemRenderer
	self.BuildUpgradeList.itemProvider = BuildUpgradeListItemProvider
	self.BuildUpgradeList.numItems = #self.curInfo.introduce / 2
end
--设置第三种显示类型的（只显示一句话那种）
function UIBuildUpdate:SetResourceType()
	local cityData = cityConfig.BuildData[self.buildType]
	self.BuildLevelTxt.text = lang(cityData.introduce)
end
--获得表中的数据个数
local function GetTableNum(table)
	local num = 0
	for _,_ in pairs(table) do
		num = num+1
	end
	return num
end
local function ConditionLIstItemProvider(index)
	return "ui://UIBuildUpdate/UpgradeAccelerateList"
end
local function SetBuilCondition(index,obj)
	local descText = obj:GetChild("BuildAccelerateTxt")
	local descIcon = obj:GetChild("UpgradeLoad02")
	local timerText = obj:GetChild("AccelerateTimeTxt")
	obj:GetChild("UpgradeAccelerateBtn").visible = false--加速按钮
	obj:GetChild("UpgradeFreeBtn").visible = false--免费按钮
	descText.color = UnityEngine.Color.white
	timerText.visible = false
	
	local is_full, target_name, target_lv, target_build
	if UIBuildUpdate.buildData then
		is_full, target_name, target_lv, target_build = BuildManager:unlock_proviso_meet(UIBuildUpdate.buildData, index + 1)
	else
		is_full, target_name, target_lv, target_build = BuildManager:unlock_proviso_meet(UIBuildUpdate.buildInfo, index + 1)
	end
	
	if not is_full then--不满足升级条件
		descText.text = lang('UI_BUILDSPEND_LV4', target_name, target_lv)
		descIcon.grayed = true
		return
	else
		descText.text = lang('UI_BUILDSPEND_LV3', target_name, target_lv)
	end
	if not target_build then
		return
	end
	--判定建筑是否在升级或者建造
	local lv
	if target_build.lv_ > 0 then --建筑存在
		lv = nil
	else --建筑等级为0的时候 1.建筑没建造出来 2.建筑正在建造
		lv = 1
	end
	descIcon.url = "art/"..tostring(target_build:get_update_info_by_level(lv).path)
end
local function SetResourceCondition(index,obj)--设置资源限制条件
	obj:GetChild("AccelerateTimeTxt").visible = false--资源没有倒计时显示
	local data = UIBuildUpdate.spendData[index + 1]
	local descText = obj:GetChild("BuildAccelerateTxt")
	local descIcon = obj:GetChild("UpgradeLoad02")
	local itemData = _G.ItemManager:get_ui_info(data)
	local is_full = _G.ItemManager:check_resource(data)
	local spend_v = data[3]
	local had_money = _G.ItemManager:get_resource(data[1])
	obj:GetChild("UpgradeAccelerateBtn").visible = false--加速按钮
	obj:GetChild("UpgradeFreeBtn").visible = false--免费按钮
	descIcon.url =  "art/"..itemData.icon
	if not had_money then
		had_money = 0
	end
	--不满足条件 按钮置灰
	if not is_full then
		descIcon.grayed = true
		descText.color = UnityEngine.Color.red
		descText.text = lang('UI_BUILDSPEND_DES2', _G.UIUtil.res_num_to_str(had_money), _G.UIUtil.res_num_to_str(spend_v))
	else
		descIcon.grayed = false
		descText.color = UnityEngine.Color.white
		descText.text = lang('UI_BUILDSPEND_DES2', _G.UIUtil.res_num_to_str(had_money), _G.UIUtil.res_num_to_str(spend_v))
	end
end
local function SetBuildQueueData(index,obj)
	local queueData = UIBuildUpdate.buildQueue[index + 1]
	local buildData = BuildManager:get_build_info_by_id(queueData.value)
	local buildIcon = obj:GetChild("UpgradeLoad02")
	local buildName = obj:GetChild("BuildAccelerateTxt")
	local buildTime = obj:GetChild("AccelerateTimeTxt")
	local jumpBtn = obj:GetChild("UpgradeAccelerateBtn")
	local freeBtn = obj:GetChild("UpgradeFreeBtn")
	local freeState = false --免费状态
	local curFreeState = false--当前免费状态
	local freeTime = _G.AttrsManager:get_attrs_value_by_name('free_build_time')

	buildName.color = UnityEngine.Color.red
	buildTime.color = UnityEngine.Color.red
	buildIcon.url = "art/UI/Common/Basic/icon_speedup"
	buildName.text = string.format( lang("UI_BUILDSPEND_UPDATING"),buildData.name_)
	
	local function SetTime()--每秒回调
		local curr_second = buildData.total_time_ - (math.floor(buildData.end_time_ - Net.server_time()))
		buildTime.text = _G.UIUtil.format_time(buildData.total_time_ - curr_second)
		curFreeState = freeTime >= UIBuildUpdate.nextInfo.uplong / 1000
		if curFreeState == freeState then
			return
		end
		freeState = curFreeState
		if freeState then
			jumpBtn.visible = false
			freeBtn.visible = true
		else
			jumpBtn.visible = true
			freeBtn.visible = false
		end
	end
	
	jumpBtn.visible = true
	freeBtn.visible = false
	
	local function jumpBtnClick()
		_G.UIController:ShowUI("UISpeedUp", {type = buildData.build_type_, buildID = buildData.id_})
	end
	jumpBtn.onClick:Clear()
	jumpBtn.touchable = true
	jumpBtn.onClick:Add(jumpBtnClick)

	local function FreeBtnClick()
		local req_msg = {}
		req_msg.id = buildData.id_
		Net.send("build_levelup_dectime", req_msg, function(result)
			if result.e == 0 then
				MsgCenter.send_message(Msg.CITY_GOLD_UP_LV, buildData.id_)
				UIBuildUpdate:SetLevelUpCondition()
			end
		end)
	end

	freeBtn.onClick:Clear()
	freeBtn.onClick:Add(FreeBtnClick)

	local function TiemEndCall()--倒计时结束回调
		jumpBtn.visible = false
		UIBuildUpdate:SetLevelUpCondition()
	end
	local className = "buildLevelUpQueue+"..tostring(index + 1)
	UIBuildUpdate:SetEngineTimer(className,SetTime,TiemEndCall,
		buildData.total_time_ - (buildData.total_time_ - (math.floor(buildData.end_time_ - Net.server_time()))) + 1,1,true)
end
local function ConditionListItenRenderer(index,obj)
	if index < UIBuildUpdate.buildQueueNum then
		SetBuildQueueData(index,obj)
		return
	end
	local conditionIndex = index - UIBuildUpdate.buildQueueNum
	local data = UIBuildUpdate.spendData[conditionIndex + 1]
	if #data == 2 then--建筑等级限制条件格式为{1,1}
		--是否满足升级/解锁条件
		SetBuilCondition(conditionIndex,obj)
	elseif #data == 3 then--资源限制条件格式为{1,1,1}
		SetResourceCondition(conditionIndex, obj)
	end
end
function UIBuildUpdate:InitConditionList()
	self.UpgradeCondition.itemProvider = ConditionLIstItemProvider
	self.UpgradeCondition.itemRenderer = ConditionListItenRenderer
	self:SetLevelUpCondition()
end
function UIBuildUpdate:SetLevelUpCondition()
	if not self.nextInfo then
		elog("nextInfo == nill---->")
		return
	end
	self:GetCurBuildQualityNum()
	self:GetConditionListNum()
	self.UpgradeCondition.numItems = self.buildQueueNum + self.conditionNum--itemNum应该等于建造队列数量，加上升级条件数量，加上所需数量
end
--获取建造队列的数量
function UIBuildUpdate:GetCurBuildQualityNum()
	self.buildQueue = {}
	self.buildQueue = BuildManager:get_queue()
	self.buildQueueNum = GetTableNum(self.buildQueue)
end
--获取条件列表的数量(目前仅有建筑等级和资源数量)
function UIBuildUpdate:GetConditionListNum()
	self.spendData = {}
    if self.conditionData and self.conditionData.precondition then
        for _, v in pairs(self.conditionData.precondition) do
            if v then
                table.insert(self.spendData, v)
            end
        end
	end
    for _, v in ipairs(self.conditionData.upcost) do
        table.insert(self.spendData, v)
	end
	self.conditionNum = GetTableNum(self.spendData)
end
--设置按钮的显示
function UIBuildUpdate:SetBtnShow()
		self:SetBtnForBuild()
end
--设置建造的时候的按钮显示
function UIBuildUpdate:SetBtnForBuild()
	local free_build_time = _G.AttrsManager:get_attrs_value_by_name('free_build_time')
	if free_build_time >= self.nextInfo.uplong / 1000 then
        self.BuildFreeBtn.title = lang('UI_BASIC_FREE')
	else
		local goldNum = self:set_gold_number(free_build_time)--消耗的金币数量
		local curNum = _G.ItemManager:get_count(config.ITEM_GOLD, id)
		if curNum < goldNum then
			self.BuildFreeBtn.color = UnityEngine.Color.red
		else
			self.BuildFreeBtn.color = UnityEngine.Color.white
		end
        self.BuildFreeBtn.title = self:set_gold_number(free_build_time)
	end
	local time = _G.UIUtil.format_time(self.nextInfo.uplong / 1000)
	self.BuildUpgradeBtn.title = time
	if self.level == 0 then
		self.BuildFreeBtn:GetChild("NameTxt").text = lang("UI_BUILDSPEND_GLOD_BUILD")--立即建造
		self.BuildUpgradeBtn:GetChild("NameTxt").text = lang("UI_BUILDCREATE_TITLE")--建造
	else
		self.BuildFreeBtn:GetChild("NameTxt").text = lang("UI_BUILDSPEND_GOLD_LVUP")--立即升级
		self.BuildUpgradeBtn:GetChild("NameTxt").text = lang("SKILL_LEVEL")--升级
	end
end
function UIBuildUpdate:set_gold_number(freeTime)
    freeTime = freeTime or nil
    local remaining_time = self.nextInfo.uplong / 1000 - freeTime
    -- 金币=系数1*（训练时间）^系数2-系数3
    -- 结果四舍五入，最小值为1
    local basic = _G.Database.BasicConfig.BasicData
    local number = basic.build_gold1 * remaining_time ^ basic.build_gold2 - basic.build_gold3
    if not number then
        number = 1
    end
    local integer_num = math.floor(number + 0.5)
    if integer_num <= 0 then
        integer_num = 1
    end
    return integer_num
end
function UIBuildUpdate:SetResourceList()
end
function UIBuildUpdate:OnBuildInterfaceClick()
end

function UIBuildUpdate:OnBuildUpdateClick()
end

function UIBuildUpdate:OnBuildIntertitleClick()
end

function UIBuildUpdate:OnCommonResTopClick()
end

function UIBuildUpdate:OnBuildUpgradeBtnClick()
	-- 是否雇佣第二个队列
	if BuildManager:is_hire_sencond_queue(self.nextInfo.uplong) then
		self:CheckQueue()
		return
	end
	--队列不足提示
	if BuildManager:is_full_queue() then
		local str = lang('UI_BUILDSPEND_FULL')
		MsgCenter.send_message(Msg.SHOW_HINT, str)
		return
	end
	if self.level == 0 then--当前等级为0，建筑为建造状态
		local mesg = {buildtype = self.buildType,pos = self.spaceClass.id_ - cityConfig.BuildData[self.buildType].startpos + 1}
        Net.send( 'build_add',mesg,
					function(result)
						if result.e == 0 then
							self:RefreshData()
							self:OnCloseBtnClick()
						end
					end
				)
	else--建筑升级状态
        Net.send('build_levelup', {id = self.spaceClass.build_info_.id_},
					function(result)
						if result.e == 0 then
							MsgCenter.send_message(Msg.CITY_UP_LV_UPDATE, self.spaceClass.build_info_.id_)
							self:OnCloseBtnClick()
						elseif result.e == 7 then
							MsgCenter.send_message(Msg.SHOW_HINT, lang('ITEM_NOT_ENOUGH'))
						end
					end
				)
    end
end
function UIBuildUpdate:CheckQueue()
	local queue_item = _G.ItemManager:get_queue_item()
    if queue_item then
        local content = lang('UI_MAIN_UNLOCK_QUEUE_BY_ITEM', queue_item.prop_.name)
        self:request_unlock(content)
    else
        -- 队列没有解锁，并且没有道具 提示用户使用金币购买
		local remaining = _G.UIUtil.format_time(BuildManager:get_queue2_time())
        local name = self.buildInfo.name_
        local up_time = _G.UIUtil.format_time(self.nextInfo.uplong / 1000)
        local time = self.nextInfo.uplong / 1000 - BuildManager:get_queue2_time()
        local gold_cnt = BuildManager:get_glod_count_by_time(time)
		local days = BuildManager:get_days_by_gold(gold_cnt)
        local content = lang('UI_BUILDSPEND_UNLOCK_QUEUE_BY_GOLD', days, remaining, name, up_time)
        self:request_unlock(content, gold_cnt)
    end
end
function UIBuildUpdate:request_unlock(content, gold_cnt, func)
    local button_info
    if gold_cnt then
        button_info = {lang('UI_BASIC_SURE'), gold_cnt}
    else
        button_info = lang('UI_BASIC_SURE')
    end
    local msg_ = {}
    msg_.content = content
    msg_.buttons = { lang('UI_BASIC_CANCEL'), button_info }
    msg_.callback = function(index)
        if index == 2 then
		local req_msg = {}
		req_msg.long = self.nextInfo.uplong
		Net.send('mainqueue_passive_add', req_msg,
			function(result)
				if result.e == 0 then
					if func then
						func()
					end
					self:OnCloseBtnClick()
				elseif result.e == 2 then
					MsgCenter.send_message(Msg.SHOW_HINT, lang('ITEM_NOT_ENOUGH'))
				end
			end)
        end
    end
    MsgCenter.send_message(Msg.SHOW_GOLD_NOTIFY, msg_)
end
--立即建造按钮
function UIBuildUpdate:OnBuildFreeBtnClick()
	if self.level == 0 then--建造
        self:ReqBuild()
    elseif self.level > 0 then
		self:ReqBuildLevelUp()
    end
end
function UIBuildUpdate:ReqBuildLevelUp()
	local req_msg = {}
	req_msg.id = self.spaceClass.build_info_.id_
	Net.send( 'build_levelup_finish', req_msg,
		function(result)
			if result.e == 0 then
				self:RefreshData()
				--MsgCenter.send_message(Msg.CITY_GOLD_UP_LV, self.spaceClass.build_info_.id_)
			elseif result.e == 7 then
				MsgCenter.send_message(Msg.SHOW_HINT, lang('ITEM_NOT_ENOUGH'))
			end
		end
	)
end
function UIBuildUpdate:ReqBuild()
	local req_msg = {}
	req_msg.buildtype = self.buildType
	req_msg.pos = self.spaceClass.id_ - cityConfig.BuildData[self.buildType].startpos + 1
	Net.send('build_add_finish',req_msg,
	function(result)
		if result.e == 0 then
			self:RefreshData()
			_G.UIController:CloseUI("UIBuild")
		elseif result.e == 7 then
			MsgCenter.send_message(Msg.SHOW_HINT, lang('ITEM_NOT_ENOUGH'))
		end
	end
	)
end
function UIBuildUpdate:RefreshData()
	self.spaceClass:refresh_build_info() --刷新
	--self.spaceClass:show_img_by_path(self.nextInfo.path)
	self.level = self.spaceClass.build_info_.lv_
	self:InitData()
	if self.buildInfo and self.buildInfo.id_ then
		MsgCenter.send_message(Msg.CITY_GOLD_UP_LV, self.spaceClass.build_info_.id_)
	end
	if _G.EventKey then
		_G.event.fire(_G.EventKey.CITY_BUILDING_SUCCEED)
	else
		MsgCenter.send_message(Msg.CITY_BUILDING_SUCCEED)
	end
	self:InitView()
end
function UIBuildUpdate:OnBackBtnClick()
	if self.level > 0 then
		_G.SceneController.currentScene:GetCameraController():FocusBack()
	end

	self:Hide()
end

function UIBuildUpdate:OnCloseBtnClick()
	_G.SceneController.currentScene:GetCameraController():FocusBack()

	self:Close()
end