--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIHospitalPop = _G.UIController:Get("UIHospitalPop")
UIHospitalPop.url = "ui://5hr7pkjeiss62x"

local lang = _G.lang

function UIHospitalPop:InitBinds()
    return {
        selected = function(value)
            self.slider.value = value
            self:GetControl("AmountTxt").text = value.."/"..self.slider.max
        end
    }
end

function UIHospitalPop:InitVM()
    return {
        selected = 0,
    }
end

function UIHospitalPop:InitEvents()

end

function UIHospitalPop:BindUI()
    self.slider = self:GetControl("n85")
end
function UIHospitalPop:Start()
    self.soldier = self.args.soldier
    self:GetControl("contentTxt").text = lang("UI_SURE_KICK", self.soldier.lv_, self.soldier.name_)

    self.slider.max = self.args.count
    self.slider.min = 0
    self.vm.selected = 0 --滑动条默认为0

    self.slider.onChanged:Add(function(context)
        self.vm.selected = context.sender.value
    end)

    self:GetControl("MinusBtn_small").onClick:Add(function()
        if self.vm.selected.value <= 0 then
            return
        end
        self.vm.selected = self.vm.selected.value - 1
    end)

    self:GetControl("RoundAddBtn_small").onClick:Add(function()
        if self.vm.selected.value >= self.args.count then
            return
        end
        self.vm.selected = self.vm.selected.value + 1
    end)
end

function UIHospitalPop:OnCancelBlueBtnClick()
    self:Hide()
end

function UIHospitalPop:OnSureYellowBtnClick()
    _G.MsgCenter.send_message(_G.Msg.SHOW_HINT, lang("UI_MAIN_UNOPEN"))

    --向服务器发送解雇请求，服务器还没做
    -- local id = self.soldier.id_
    -- local count = self.vm.selected.value
end
