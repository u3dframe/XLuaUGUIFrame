--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIHeroSelect = _G.UIController:Get("UIHeroSelect")

local HeroAttrs = _G.Database.BasicConfig.BasicData.hero_attrs
local UIUtil = _G.UIUtil

function UIHeroSelect:Awake()
end

function UIHeroSelect:InitBinds()
	return {
		heroList = function(val)
			self.SelectHeroList.numItems = #val
		end,
		skillList = function(val)
			self.Skilllist.numItems = #val
		end,
		HeroBookList = function(val)
			self.Herobooklist.numItems = #val
		end,
	}
end

function UIHeroSelect:InitVM()
    return {
		heroList = {},
		skillList = {},
		HeroBookList = {},
    }
end

--FIXME:This is automatically generated
--FIXME:If no event to listen, Delete This function

function UIHeroSelect:BindUI()
	self.pop_longwin_title_bg = self:GetControl("pop_longwin_title_bg")
	self.TitleTxt = self:GetControl("TitleTxt")
	self.Compower = self:GetControl("Compower")
	--属性
	self.Com1 = self:GetControl("Com1")
	self.leaderTxt1 = self:GetControl("Com1.leaderTxt")
	self.CommanderNumTxt1 = self:GetControl("Com1.CommanderNumTxt")
	self.ProgressBar1 = self:GetControl("Com1.ProgressBar3")
	self.loadTypeCtroller1 = self.ProgressBar1:GetController("loadtype")
	self.Com2 = self:GetControl("Com2")
	self.leaderTxt2 = self:GetControl("Com2.leaderTxt")
	self.CommanderNumTxt2 = self:GetControl("Com2.CommanderNumTxt")
	self.ProgressBar2 = self:GetControl("Com2.ProgressBar3")
	self.loadTypeCtroller2 = self.ProgressBar2:GetController("loadtype")
	self.Com3 = self:GetControl("Com3")
	self.leaderTxt3 = self:GetControl("Com3.leaderTxt")
	self.CommanderNumTxt3 = self:GetControl("Com3.CommanderNumTxt")
	self.ProgressBar3 = self:GetControl("Com3.ProgressBar3")
	self.loadTypeCtroller3 = self.ProgressBar3:GetController("loadtype")

	self.ComHeroHead = self:GetControl("ComHeroHead")
	self.HeronameTxt = self:GetControl("HeronameTxt")
	self.SelectHeroList = self:GetControl("SelectedHeroList")
	self.Skilllist = self:GetControl("Skilllist")
	self.Herobooklist = self:GetControl("Herobooklist")
	self.PowerTxt = self:GetControl("Compower.PowerTxt")
end

function UIHeroSelect:Awake()
	self.curItem = nil
	self.SelectHeroList.itemRenderer = function(idx, item)
		local data = self.heroListData[idx+1]
		UIUtil.SetHeroHead(item, data)
		local isSelect = data.id_ == self.curHero.id_
		self:SetSelect(item, isSelect)
		if isSelect then
			self.curItem = item
		end
	end
	self.SelectHeroList.onClickItem:Set(function(context)
		if self.curItem then
			self:SetSelect(self.curItem, false)
		end
		self.curItem = context.data
        local childIndex =  self.SelectHeroList:GetChildIndex(self.curItem)
		local itemIndex = self.SelectHeroList:ChildIndexToItemIndex(childIndex)
		local data = self.heroListData[itemIndex+1]
		self:SetSelect(self.curItem, true)
        self:Refresh(data)
	end)
	self.SelectHeroList:SetVirtual()

	self.Skilllist.itemRenderer = function(idx, item)

	end

	self.Herobooklist.itemRenderer = function(idx, item)

	end
end

function UIHeroSelect:Start()
	self.heroListData = _G.HeroManager:get_heroes()
	self.curTroopsIndex = self.args.troopsIndex
	self.curHero = self.args.hero or self.heroListData[1]
	self.vm.heroList = self.heroListData
	self:Refresh(self.curHero)
end

--FIXME:Write logic Code here!

function UIHeroSelect:SetSelect(item, isSelect)
	item:GetController("choose").selectedIndex = isSelect == true and 0 or 1
end

function UIHeroSelect:Refresh(newHero)
	self.curHero = newHero
	--英雄选择展示头像
	UIUtil.SetHeroHead(self.ComHeroHead, self.curHero, self.curTroopsIndex-1)
	self.ComHeroHead:GetChild("HeroNameTxt").text = ""
	--属性，名字和战斗力
	self.HeronameTxt.text = self.curHero and self.curHero.name_ or ""
	self.PowerTxt.text = self.curHero and self.curHero:get_power() or 0
	self:SetAttribute(1, self.curHero)
	self:SetAttribute(2, self.curHero)
	self:SetAttribute(3, self.curHero)
end

function UIHeroSelect:SetAttribute(idx, hero)
	local type = "none"
	local progressBar = self["ProgressBar"..idx]
	if not hero then
		progressBar.min = 0
		progressBar.max = 1
		progressBar.value = 0
		self["leaderTxt"..idx].text = 0
		self["loadTypeCtroller"..idx].selectedPage = type
		return
	end

	local attrList = hero:get_attr()
	local oldAttrList = self.args.hero and self.args.hero:get_attr() or {[idx]=0}
	--self["CommanderNumTxt"..idx].text = “统帅”
	progressBar.min = 0
	progressBar.max = HeroAttrs[idx]
	progressBar.value = attrList[idx]
	self["leaderTxt"..idx].text = attrList[idx]
	if attrList[idx] > oldAttrList[idx] then
		type = "Add"
	elseif attrList[idx] < oldAttrList[idx] then
		type = "Less"
	end
	self["loadTypeCtroller"..idx].selectedPage = type
end

function UIHeroSelect:OnConfirmBtnClick()
	_G.event.fire(_G.EventKey.SELECT_HERO_CONFIRM, {index = self.curTroopsIndex, hero = self.curHero})
	self:Hide()
end

function UIHeroSelect:OnDetailBtnClick()
end

function UIHeroSelect:OnColseBtnClick()
	self:Hide()
end
