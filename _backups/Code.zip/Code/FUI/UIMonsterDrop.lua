--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIMonsterDrop = _G.UIController:Get("UIMonsterDrop")

local WorldManager = _G.WorldManager
local ItemManager = _G.ItemManager
local lang = _G.lang

function UIMonsterDrop:Awake()
	self.obj = self.args.obj
	self:InitLists()
end

function UIMonsterDrop:InitBinds()
    return {
    }
end

function UIMonsterDrop:InitVM()
    return {
    }
end

function UIMonsterDrop:BindUI()
	self.statusCtrler = self:GetController("status")
	self.Viptips = self:GetControl("Viptips")
	self.FirstRewardList = self:GetControl("FirstRewardList")
	self.RandomRewardList = self:GetControl("RandomRewardList")
	self.RandomRewardList1 = self:GetControl("RandomRewardList1")
	self.CoordinateTxt = self:GetControl("n3.CoordinateTxt")
	self.DistanceTxt = self:GetControl("n3.DistanceTxt")
	self.icon = self:GetControl("Commonster.icon")
	self.MonsterNameTxt = self:GetControl("Commonster.MonsterNameTxt")
	self.MonsterlevelTxt = self:GetControl("Commonster.MonsterlevelTxt")
	self.PowerTxt = self:GetControl("Commonster.PowerTxt")
end

function UIMonsterDrop:Start()
	local prop = self.obj.prop_
	self.icon.url = "art/" .. prop.drawpath
    self.MonsterNameTxt.text = prop.name
    self.MonsterlevelTxt.text = lang("UI_MONSTERINFO_LV")..prop.lv
    self.PowerTxt.text = prop.power
    self.DistanceTxt.text = lang("UI_MONSTERINFO_DISTANE", WorldManager:GetLogicDistanceFromHome(self.obj))
	self.CoordinateTxt.text = string.strfmt("{1}, {2}", self.obj.x_, self.obj.z_)
	self.Viptips.text = lang("EXPEDITION_3", 2)

	local title1 = self:GetControl("First.TitleTxt")
	local title2 = self:GetControl("Random.TitleTxt")
	if self:IsFirstReward() then
		self.statusCtrler.selectedIndex = 0
		title1.text = lang("BATTLE_MONSTER2")
		title2.text = lang("BATTLE_MONSTER3")
		self.FirstRewardList.numItems = #self.obj.prop_.firstreward
		self.RandomRewardList.numItems = #self.obj.prop_.reward
	else
		self.statusCtrler.selectedIndex = 1
		title1.text = lang("BATTLE_MONSTER3")
		self.RandomRewardList1.numItems = #self.obj.prop_.reward
	end
end

function UIMonsterDrop:InitLists()
	local itemProvider = function()
		return "ui://rj30gdr6pzmbg"
	end
	local itemRenderer = function(idx, obj, rewardList)
		rewardList = rewardList or {}
		local reward = rewardList[idx + 1]
		if not reward then return end
		local info = ItemManager:get_ui_info(reward)
		obj:GetController("color").selectedIndex = info.quality - 1
		obj:GetChild("icon").url = "art/"..info.icon
		obj:GetChild("ItemTxt").text = info.name
	end
	self.FirstRewardList.itemProvider = itemProvider
	self.FirstRewardList.itemRenderer = function(idx, obj)
		itemRenderer(idx, obj, self.obj.prop_.firstreward)
	end
	self.RandomRewardList.itemProvider = itemProvider
	self.RandomRewardList.itemRenderer = function(idx, obj)
		itemRenderer(idx, obj, self.obj.prop_.reward)
	end
	self.RandomRewardList1.itemProvider = itemProvider
	self.RandomRewardList1.itemRenderer = function(idx, obj)
		itemRenderer(idx, obj, self.obj.prop_.reward)
	end
end

function UIMonsterDrop:IsFirstReward()
    return WorldManager.monster_battle_lv_ < self.args.obj.lv_
end

--FIXME:Write logic Code here!

function UIMonsterDrop:OnConfirmBtnClick()
	self:Close()
	if _G.FairyGUI then
		_G.UIController:ShowUI("UIStrike", {obj = self.obj})
		return
	end
	UIManager.open_window("WorldTroopsWindow", nil, self.obj)
end

function UIMonsterDrop:OnCloseBtnClick()
	self:Close()
end

