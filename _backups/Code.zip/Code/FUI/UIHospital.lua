--医馆
local UIHospital = _G.UIController:Get("UIHospital")
UIHospital.url = "ui://2oxwseiadvb52c"
_G.table.mixin(UIHospital, require("FUI/Patch/TopBannerPatch"))

local SoldierManager = _G.SoldierManager
local ItemManager = _G.ItemManager
local UIUtil = _G.UIUtil
local lang = _G.lang
local Net = _G.Net
local BuildManager = _G.BuildManager
local MsgCenter = _G.MsgCenter
local Msg = _G.Msg

table.default = table.arithmetic

function UIHospital:InitBinds()
    return {
        --控制器
        healState = function(value)
            self:GetController('heal_state').selectedIndex = value
        end,
        choice = function(value)
            self:GetController('choice').selectedIndex = value
        end,
        --列表
        hurtsData = function(value)
            local list = self:GetControl('SoilderList')
            list:RemoveChildrenToPool()
            list.numItems = #value
        end,
        costData = function()
            local list = self:GetControl('CostList')
            list:RemoveChildrenToPool()
            list.numItems = _G.config.Prop_Max
        end,
        --金币
        goldCnt = function(value)
            self:GetControl('ImeHealYellowBtn'):GetChild('gold_costTxt').text = value
        end,
        --时间
        time = function(value)
            print("time =  ", value)
            self:GetControl('HealBlueBtn'):GetChild("TimeTxt").text = UIUtil.format_time(value)
        end,
        selected = function(value)
            local costMap = table.default(0) {}
            local time = 0
            for i, count in ipairs(value) do
                local prop = self.hurtsAll[i].hurts_spend_
                for type, v in ipairs(prop) do
                    costMap[type] = costMap[type] + count * v[3]
                end
                local uplong = self.hurtsAll[i].hurts_uplong_
                time = time + SoldierManager:get_hurts_uplog(uplong, count)
            end
            self.vm.costData = costMap --消耗
            self.vm.time = math.ceil(time) --时间
            self.vm.goldCnt = SoldierManager:get_glod_hurts_recover(math.ceil(time)) --金币
            self.vm.hurtsData = self.hurtsAll
        end
    }
end

function UIHospital:InitVM()
    self.hurtsAll = SoldierManager:get_hurts_all()
    self.default = {}
    for _, v in ipairs(self.hurtsAll) do
        local cnt = v.hurts_number_
        table.insert(self.default, cnt)
    end
    return {
        --控制器
        healState = 0,
        choice = 0,
        --列表
        hurtsData = {},
        costData = {},
        --数据
        selected = self.default,
        goldCnt = 0,
        time = 0,
    }
end

function UIHospital:InitEvents()
    return {
    }
end

function UIHospital:BindUI()
end

function UIHospital:Awake()
    --注册列表
    self:InitHurtList()
    self:RefreshCostList() --消耗列表
end

function UIHospital:Start()
    self.buildInfo = BuildManager:get_build_info_by_id(self.args.buildID)
    self:SetTitle(lang("UI_HOSPITAL_TITLE"))

    self:InitHurtSoilder() --控制器
    self:SetHurtTxt()
end

function UIHospital:InitHurtSoilder()
    if not next(self.hurtsAll or {}) then
        self.vm.healState = 0
        return
    end
    self.vm.healState = 1
    self.vm.hurtsData = self.hurtsAll
end

function UIHospital:SetHurtTxt()
    local hurtCnt = SoldierManager:GetHurtsCountAll()
    self:GetControl("FoodTxt").text = 0 --目前没有粮食车
    self:GetControl("HurtTxt").text = UIUtil.res_num_to_str(hurtCnt).."/"..self.buildInfo:get_hospital_max_cnt()
end

function UIHospital:InitHurtList()
    local list = self:GetControl("SoilderList")

    local function OnSliderValueChanged(context)
        local childIndex = list:GetChildIndex(context.sender.parent)
        local index = list:ChildIndexToItemIndex(childIndex) + 1

        self.vm.selected.value[index] = context.sender.value
        self.vm.selected = self.vm.selected.value
    end

    local function OnMaxBtnClick(context)
        local item = context.sender.parent
        local index = list:ChildIndexToItemIndex(list:GetChildIndex(item)) + 1
        self.vm.selected.value[index] = item:GetChild("n61").max
        self.vm.selected = self.vm.selected.value
    end

    local function OnAddBtnClick(context)
        local item = context.sender.parent
        local index = list:ChildIndexToItemIndex(list:GetChildIndex(item)) + 1
        if self.vm.selected.value[index] >= item:GetChild("n61").max then
            return
        end
        self.vm.selected.value[index] = self.vm.selected.value[index] + 1
        self.vm.selected = self.vm.selected.value
    end

    local function OnMinBtnClick(context)
        local item = context.sender.parent
        local index = list:ChildIndexToItemIndex(list:GetChildIndex(item)) + 1
        if self.vm.selected.value[index] <= 0 then
            return
        end
        self.vm.selected.value[index] = self.vm.selected.value[index] - 1
        self.vm.selected = self.vm.selected.value
    end

    local function OnKickBtnClick(context)
        local childIndex = list:GetChildIndex(context.sender.parent)
        local index = list:ChildIndexToItemIndex(childIndex) + 1
        local data = {
            soldier = self.hurtsAll[index],             --士兵
            count = self.hurtsAll[index].hurts_number_  --数量
        }
        _G.UIController:ShowUI("UIHospitalPop", data)
    end

    list.itemRenderer = function(idx, obj)
        local soldier = self.hurtsAll[idx + 1]
        if not soldier then
            return
        end
        local slider = obj:GetChild("n61")
        slider.max = soldier.hurts_number_
        slider.min = 0
        slider.onChanged:Set(OnSliderValueChanged)
        if self.vm.selected.value[idx + 1] then
            slider.value = self.vm.selected.value[idx + 1]
        else
            slider.value = 0
        end

        obj:GetChild("IconLoader").url = "art/" .. soldier.half_icon_path_
        obj:GetChild("SoilderTypeTxt").text = lang("SOLDIER_LEVEL_"..soldier.lv_)..soldier.name_
        obj:GetChild("HealAmountTxt").text = UIUtil.res_num_to_str(slider.value).."/"..UIUtil.res_num_to_str(slider.max)

        obj:GetChild("MaxBtn").onClick:Set(OnMaxBtnClick)
        obj:GetChild("AddBtn").onClick:Set(OnAddBtnClick)
        obj:GetChild("MinusBtn").onClick:Set(OnMinBtnClick)
        obj:GetChild("n68").onClick:Set(OnKickBtnClick)
    end
end

function UIHospital:RefreshCostList()
    local list = self:GetControl("CostList")

    local function OnGainBtnClick()
        --show window
    end
    list.itemRenderer = function(idx, obj)
        local index = idx + 1
        local spendData = self.vm.costData.value[index]
        local hadMoney = ItemManager:get_resource(index)
        local resTypeCtrl = obj:GetController("resource")
        local resState = obj:GetController("state")
        resTypeCtrl.selectedIndex = idx
        local txt = UIUtil.res_num_to_str(hadMoney or 0).."/"..UIUtil.res_num_to_str(spendData)
        if hadMoney > spendData then
            resState.selectedPage = "enough"
            obj:GetChild("WoodCostTxt").text = txt
        else
            resState.selectedPage = "notenough"
            obj:GetChild("NotEnoughTxt").text = txt
            obj:GetChild("GainBtn").onClick:Set(OnGainBtnClick)
        end
    end
end

function UIHospital:OnRedBtnClick()
    local temp = table.default(0) {}
    self.vm.selected = temp
    self.vm.hurtsData = self.hurtsAll
    self.vm.choice = 1
end

function UIHospital:OnAllChooseBlueBtnClick()
    self.vm.selected = self.default
    self.vm.hurtsData = self.hurtsAll
    self.vm.choice = 0
end

function UIHospital:GetSelectedHurts()
    --服务器消息结构
    local reqMsg = {
        list = {
            arr1 = {}, arr2 = {}
        }
    }
    for i, count in ipairs(self.vm.selected.value) do
        if count > 0 then
            table.insert(reqMsg.list.arr1, self.hurtsAll[i].id_)
            table.insert(reqMsg.list.arr2, count)
        end
    end
    return reqMsg
end


function UIHospital:OnImeHealYellowBtnClick()
    local reqMsg = self:GetSelectedHurts()
    if not next(reqMsg) then
        return
    end
    --要有一个二级弹窗
    Net.send("soldier_cure_finish", reqMsg, function(result)
        if result.e == 7 then
            MsgCenter.send_message(Msg.SHOW_HINT, lang("ITEM_NOT_ENOUGH"))
        end
        if result.e == 0 then
            _G.event.fire(_G.EventKey.CITY_SOLDIER_CURE_FINISHED)
            MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_SOLDIER_CURE_FINISHED"))
            self:close()
        end
    end)
end

function UIHospital:OnHealBlueBtnClick()
    local reqMsg = self:GetSelectedHurts()
    if not next(reqMsg) then
        return
    end
    Net.send("soldier_cure", reqMsg, function(result)
		if result.e == 0 then
			MsgCenter.send_message(Msg.CITY_SOLDIER_CURE_UPDATE, self.buildInfo.build_type_)
            self:close()
		end
    end)
end

function UIHospital:OnInfoBtnClick()
    MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_MAIN_UNOPEN"))
end