--This is an automatically generated class by FairyGUI. Please do not modify it.

local UICommonPop = _G.UIController:Get("UICommonPop")


local indexer = _G.Indexer.New()
local lang = _G.lang
local config = _G.config
local SoldierManager = _G.SoldierManager
local partial = _G.partial

local event

local MODE = {
    NORMAL = indexer(-1),   --普通提示框
    REBUILD = indexer(),    --城池摧毁提示
    SPEEDUP = indexer(),    --加速
    COUNT = indexer(),      --数量选择
    NOTITEM = indexer(),    --单个按钮
    INTIMACY = indexer()    --规则说明
}

function UICommonPop:Awake()
end

function UICommonPop:BindUI()
    self.PopCtrler = self:GetController("Pop")
    self.ShowCtrler = self:GetController("show")
	self.wall_bg = self:GetControl("wall_bg")
	self.HintTop = self:GetControl("HintTop")
	self.blueBtn = self:GetControl("blueBtn")
	self.yellowBtn = self:GetControl("yellowBtn")
	self.CheckBtn = self:GetControl("CheckBtn")
	self.Tipstxt = self:GetControl("Tipstxt")
	self.HintList = self:GetControl("HintList")
	self.RebuildBtn = self:GetControl("RebuildBtn")
	self.SpeedUpBtn = self:GetControl("SpeedUpBtn")
	self.CountCloseBtn = self:GetControl("CountCloseBtn")
	self.InfoTxt = self:GetControl("InfoTxt")
	self.CountBtn = self:GetControl("CountBtn")
	self.CountSilder = self:GetControl("CountSilder")
	self.CountRoundAddBtn = self:GetControl("CountRoundAddBtn")
	self.CountReduceBtn = self:GetControl("CountReduceBtn")
	self.CountMaxBtn = self:GetControl("CountMaxBtn")
	self.CountNumTxt = self:GetControl("CountNumTxt")
end

function UICommonPop:InitBinds()
    return {
        panelMode = function(value)
            self.PopCtrler.selectedIndex = value
            if event[value] then
                event[value](self)
            end
        end,
        title = function(value)
            self.HintTop.text = value
        end,
        content = function(value)
            self.HintList.itemRenderer = function(_, obj)
                obj:GetChild("HintTxt").text = value
            end
            self.HintList.numItems = 1
        end
    }
end

function UICommonPop:InitVM()
    return {
        panelMode = 0,
        title = "",
        content = "",
    }
end

--[[

    参数格式。 (title可空)
    {
        title = "",
        content = "",
    }

--]]

function UICommonPop:Start()
    if not self.args.mode then
        return
    end
    self.ShowCtrler.selectedIndex = self.args.show or 0
    self:InitView()
end

function UICommonPop:InitView()
    self.vm.panelMode = self.args.mode
    self.vm.title = self.args.title or lang("UI_BASIC_HINT")
    self.vm.content = self.args.content or ""
end

--mode0
function UICommonPop:OnblueBtnClick()
    self:Hide()
    if self.args.onCancel then
        self.args.onCancel()
    end
end

function UICommonPop:OnyellowBtnClick()
    self:Hide()
    if self.args.callback then
        self.args.callback()
    end
end

--mode1
function UICommonPop:OnRebuildBtnClick()
    if self.args.callback then
        self.args.callback()
    end
end

--mode2
function UICommonPop:OnSpeedUpBtnClick()
    self:Hide()
    if self.args.callback then
        self.args.callback()
    end
end

---------------------------↓Count页面↓----------------------------

function UICommonPop:ShowMode3()
    self.CountBtn:GetChild("title").text = self.args.btnTxt
    self.CountSilder.changeOnClick = false
    self.CountSilder.min = self.args.min or 1
    self.CountSilder.max = self.args.max
    self.CountSilder.value = self.args.initValue or self.CountSilder.min
    local onChanged = function() self:OnCountSliderChanged() end
    self.CountSilder.onChanged:Set(onChanged)
    self:OnCountSliderChanged()
end

function UICommonPop:OnCountSliderChanged()
    self.CountNumTxt.text = string.format("%d/%d", self.CountSilder.value, self.CountSilder.max)
end

function UICommonPop:OnCountCloseBtnClick()
    self:Hide()
end

function UICommonPop:OnCountBtnClick()
    self:Hide()
    local cb = self.args.callback
    local value = self.CountSilder.value
    local exec = function()
        if cb then cb(value) end
    end
    if self.args.confirmTxt then
        local args = table.copy(self.args)
        args.initValue = self.CountSilder.value
        _G.UIController:ShowUI("UICommonPop", {
            mode = 0,
            show = self.args.show,
            content = self.args.confirmTxt,
            callback = exec,
            onCancel = function()
                _G.UIController:ShowUI("UICommonPop", args)
            end
        })
    else
        exec()
    end
end

function UICommonPop:OnCountRoundAddBtnClick()
    if self.CountSilder.value >= self.CountSilder.max then return end
    self.CountSilder.value = self.CountSilder.value + 1
    self:OnCountSliderChanged()
end

function UICommonPop:OnCountReduceBtnClick()
    if self.CountSilder.value <= self.CountSilder.min then return end
    self.CountSilder.value = self.CountSilder.value - 1
    self:OnCountSliderChanged()
end

function UICommonPop:OnCountMaxBtnClick()
    self.CountSilder.value = self.CountSilder.max
    self:OnCountSliderChanged()
end

---------------------------↑Count页面↑----------------------------


function UICommonPop:SetSpeedupModeView()
    local goldCount = self:GetControl("SpeedUpBtn"):GetChild("timeTxt")
    goldCount.text = self.args.goldCount
end

function UICommonPop:SetInimacyModeVlie()
    local list = self:GetControl("IntimacyText")
    list.itemRenderer = function(_, obj)
        obj:GetChild("IntroduceTxt").text = self.args.rule
    end
    list.numItems = 1
end

event = {
    [MODE.SPEEDUP] = UICommonPop.SetSpeedupModeView,
    [MODE.COUNT] = UICommonPop.ShowMode3,
    [MODE.INTIMACY] = UICommonPop.SetInimacyModeVlie,
}