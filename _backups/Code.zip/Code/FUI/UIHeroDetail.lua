--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIHeroDetail = _G.UIController:Get("UIHeroDetail")

local lang = _G.lang

function UIHeroDetail:InitBinds()
    return {
    }
end

function UIHeroDetail:InitVM()
    return {
    }
end

function UIHeroDetail:BindUI()
	self.detaildata = self:GetControl("detaildata")
	self.CloseBtn = self:GetControl("CloseBtn")
	self.skilldata = self:GetControl("skilldata")
	self.SureBtn = self:GetControl("SureBtn")
	self.star = self:GetControl("star")
	self.attr_1_dataup = self:GetControl("attr_1_dataup")
	self.attribute_1 = self:GetControl("attribute_1")
	self.attr_1 = self:GetControl("attr_1")
	self.attr_2 = self:GetControl("attr_2")
	self.attr_3 = self:GetControl("attr_3")
	self.attr_1_data = self:GetControl("attr_1_data")
	self.attr_2_dataup = self:GetControl("attr_2_dataup")
	self.attribute_2 = self:GetControl("attribute_2")
	self.attr_2_data = self:GetControl("attr_2_data")
	self.attr_3_dataup = self:GetControl("attr_3_dataup")
	self.attribute_3 = self:GetControl("attribute_3")
	self.attr_3_data = self:GetControl("attr_3_data")
	self.NameLevelStarTxt = self:GetControl("NameLevelStarTxt")
	self.Level = self:GetControl("Level")
	self.Star = self:GetControl("Star")
end

function UIHeroDetail:Start()
	local hero = self.args.hero
	self.NameLevelStarTxt.text = hero.name_
	self.Level.text = lang("UI_HERO_LV2", hero.lv_)
	self.Star.text = lang("UI_HERO_STAR", hero.star_)
	self.star:GetController("star_state").selectedIndex = hero.star_ - 1
	self.attr_1_data.text = hero:get_attr(1)
	self.attr_2_data.text = hero:get_attr(2)
	self.attr_3_data.text = hero:get_attr(3)
end

function UIHeroDetail:OnCloseBtnClick()
	self:Hide()
end

function UIHeroDetail:OnSureBtnClick()
	self:Hide()
end

function UIHeroDetail:OnstarClick()
end

