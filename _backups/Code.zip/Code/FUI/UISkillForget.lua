--This is an automatically generated class by FairyGUI. Please do not modify it.

local UISkillForget = _G.UIController:Get("UISkillForget")

local BasicData = _G.Database.BasicConfig.BasicData
local ItemManager = _G.ItemManager

function UISkillForget:Awake()
	self.hero = self.args.hero
	self.skill = self.hero.skills_[self.args.pos]
	local name = _G.SkillManager:get_config(self.skill.skillid).name
	self.currentTxt.text = _G.lang("SKILL_RECYCLE", self.skill.level, name)
	self.items = self:CalcItemList()
	self:InitItemList()
end

function UISkillForget:InitBinds()
    return {
    }
end

function UISkillForget:InitVM()
    return {
    }
end

function UISkillForget:BindUI()
	self.ComPopBg = self:GetControl("ComPopBg")
	self.TitleTxt = self:GetControl("TitleTxt")
	self.board_pop_tips = self:GetControl("board_pop_tips")
	self.currentTxt = self:GetControl("currentTxt")
	self.ComtitleBg = self:GetControl("ComtitleBg")
	self.txttypeCtrler = self:GetControl("ComtitleBg"):GetController("txttype")
	self.GetskillTxt = self:GetControl("ComtitleBg.GetskillTxt")
	self.SkillitemList = self:GetControl("SkillitemList")
	self.txttypeCtrler = self:GetControl("ComtitleBg"):GetController("txttype")
	self.GetskillTxt = self:GetControl("ComtitleBg.GetskillTxt")
end

function UISkillForget:Start()
	self.SkillitemList.numItems = #self.items
end

function UISkillForget:InitItemList()
	self.SkillitemList.itemProvider = function()
		return "ui://UISkillForget/ComMaterial"
	end
	self.SkillitemList.itemRenderer = function(idx, obj)
		local index = idx + 1
		local item = self.items[index]
		local cfg = ItemManager:get_config(item[1])
		obj:GetController("quality").selectedIndex = cfg.quality - 1
		obj:GetController("state").selectedIndex = 1
		obj:GetChild("iconloader").url = string.format("art/%s", cfg.icon)
		obj:GetChild("propname").text = cfg.name
		obj:GetChild("leveltext").text = item[2]
	end
end

function UISkillForget:CalcItemList()
	local totalExp = _G.SkillManager:CalcAllExpOfSkill(self.skill)
	local rest = totalExp * BasicData.hero_skill_forget
	local expItemCfgs = {}
    for _, cfg in pairs(BasicData.hero_skill_items) do
        table.insert(expItemCfgs, cfg)
    end
    table.sort(expItemCfgs, function(a, b) return a[2] > b[2] end)
    local items = {}
    for _, cfg in ipairs(expItemCfgs) do
        local exp = cfg[2]
        local cnt = math.floor(rest / exp)
        if cnt > 0 then
            rest = rest % exp
            table.insert(items, {cfg[1], cnt})
        end
	end
	return items
end

function UISkillForget:OnConfirmBtnClick()
	SkillManager:forget_skill(self.hero.id_, self.args.pos, self.skill.skillid)
	self:Hide()
end

function UISkillForget:OnCancelBtnClick()
	self:Hide()
end
