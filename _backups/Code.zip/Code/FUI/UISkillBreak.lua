--This is an automatically generated class by FairyGUI. Please do not modify it.

local UISkillBreak = _G.UIController:Get("UISkillBreak")

local SkillManager = _G.SkillManager

function UISkillBreak:Awake()
	self.skill = SkillManager:get_skill_by_id(self.args.id)
end

function UISkillBreak:InitBinds()
    return {
		selectedCount = function(value)
			self.FragmentAmount.text = value
			self.ComFragment:GetChild("899Txt").text = value
			self.ComGeneralFragment:GetChild("100Txt").text = self.skill.cfg_.resolve[1][3] * value
		end,
    }
end

function UISkillBreak:InitVM()
    return {
		selectedCount = 1,
    }
end

--FIXME:This is automatically generated
--FIXME:If no event to listen, Delete This function
function UISkillBreak:InitEvents()
    self:AddEventListener(eventKey or eventKeys, function()

    end)
end

function UISkillBreak:BindUI()
	self.stateCtrler = self:GetController("state")
	self.ComFragment = self:GetControl("ComFragment")
	self.ComGeneralFragment = self:GetControl("ComGeneralFragment")
	self.FragmentAmount = self:GetControl("FragmentAmount")
end

function UISkillBreak:Start()
	self.ComFragment:GetChild("Fragmenttext").text = self.skill.cfg_.name
	self.ComFragment:GetChild("icon").url = string.format("art/%s", self.skill.cfg_.icon)
	local itemInfo = _G.ItemManager:get_ui_info(self.skill.cfg_.resolve[1])
	self.ComGeneralFragment:GetChild("generalfragName").text = itemInfo.name
	self.ComGeneralFragment:GetController("quality").selectedIndex = itemInfo.quality - 1
	self.ComGeneralFragment:GetChild("icon").url = string.format("art/%s", itemInfo.icon)
end

--FIXME:Write logic Code here!

function UISkillBreak:OnCloseBtnClick()
	self:Hide()
end

function UISkillBreak:OnMinusBtnClick()
	local cnt = self.vm.selectedCount.value
	if cnt <= 1 then return end
	self.vm.selectedCount = cnt - 1
end

function UISkillBreak:OnAddBtnClick()
	local cnt = self.vm.selectedCount.value
	if cnt >= self.skill.count_ then return end
	self.vm.selectedCount = cnt + 1
end

function UISkillBreak:OnPlus10Click()
	local cnt = self.vm.selectedCount.value
	local rest = self.skill.count_ - cnt
	local add = math.min(rest, 10)
	self.vm.selectedCount = cnt + add
end

function UISkillBreak:OnRedMaxClick()
	self.vm.selectedCount = self.skill.count_
end

function UISkillBreak:OnCancelBtnClick()
	self:Hide()
end

function UISkillBreak:OnConfirmBtnClick()
	SkillManager:resolve_skill(self.skill.id_, self.vm.selectedCount.value)
	self:Hide()
end

