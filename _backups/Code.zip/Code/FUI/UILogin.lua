local UILogin = _G.UIController:Get("UILogin")

local server_list = {
    {"花见花开", "106.53.91.60", 10240},
    --{"内网2服", "192.168.0.21", 1029},
    --{"内网3服", "192.168.0.24", 1030},
    --{"内网4服", "192.168.0.20", 1029},
    --{"内网5服", "192.168.0.20", 1030},
    --{"内网6服", "192.168.0.20", 1031},
    --{"内网7服", "192.168.0.23", 1027},
    --{"内网8服", "192.168.0.23", 1028},
    --{"内网9服", "192.168.0.23", 1029},
    --{"内网87服", "192.168.0.24", 1087},
    --{"内网95服", "192.168.0.24", 1095},
    --{"策划1001服", "192.168.0.25", 1001},
    --{"策划1002服", "192.168.0.25", 1002},
    --{"策划1003服", "192.168.0.25", 1003},
    --{"策划1004服", "192.168.0.25", 1004},
    --{"策划1005服", "192.168.0.25", 1005},
    --{"策划1006服", "192.168.0.25", 1006},
    --{"策划1007服", "192.168.0.25", 1007},
    --{"策划1008服", "192.168.0.25", 1008},
    --{"策划1009服", "192.168.0.25", 1009},
    --{"外网1服", "116.63.137.206", 10001},
    --{"外网2服", "116.63.137.206", 10002},
}
function UILogin:InitBinds()
    return {
        LoginBtnTxt = function(value)
            self:GetControl("LoginBtn").title = value
        end,
        ServerName = function(value)
            self:GetControl("ServerListBtn").title = value
        end,
        panelType = function(value)
            self.mainCom:GetController("page").selectedIndex = value
        end,
        serverList = function(value)
            local list = self:GetControl("ServerList")
            list:RemoveChildrenToPool()
            list.numItems = #value
            list:RefreshVirtualList()
        end
    }
end

function UILogin:InitVM()
    return {
        LoginBtnTxt = "Login",
        ServerName = server_list[self.account.serverId][1],
        id = "null",
        Port = 0,
        Ip = "",
        panelType = 0,
        serverList = {}
    }
end

function UILogin:InitEvents()
    self:AddEventListener(_G.EventKey.LOGIN_SUCCESS, function()
        _G.UIController:ShowUI("UILoading")
        print("linstener call")
        _G.SceneController:LoadScene("SceneMain")
        self:Hide()
    end)
end

local isLong = false
function UILogin:Awake()
    self.account = _G.Account:GetAccountInfo()
    self:LongPressTest()
    self:InitItemList()
end

function UILogin:LongPressTest()
    local last = 0
    local OnLongPress =  function (context)
        print("This is Long Press-------", os.clock() - last)
        last = os.clock()
    end
    local OnStart = function()
        startAt = os.clock()
        last = os.clock()
        print("OnLongPress.Start")
    end

    local OnEnd = function()
        isLong = true
        print("OnLongPress.end")
    end

    local testBtn = self:GetControl("TestBtn")

    local gesture = _G.LongPressGesture(testBtn)
    gesture.once = false
    gesture.trigger = 1
    gesture.interval = 0.5
    gesture.onBegin:Add(OnStart)
    gesture.onEnd:Add(OnEnd)
    gesture.onAction:Add(OnLongPress)
end

function UILogin:Start()
    -- self.vm.LoginBtnTxt = "LoginBtn"
    BgmManager.Play("Audio/Bgm/login")
    self.ServerList   = self:GetControl("ServerList")
    -- self.ServerList   = self:GetElement("ServerList")
    self.AccountInput = self:GetControl("AccountInput")
    self.NameInput    = self:GetControl("NameInput")

    self.AccountInput.text = self.account.rid
    dump(self.account, "self.account")
    self.NameInput.text = self.account.userName

    local server = server_list[self.account.serverId]
    self.vm.serverList  = server_list
    self.vm.ServerName = server[1]
end

function UILogin:InitItemList()
    local list =  self:GetControl("ServerList")
    --[[
    list.itemProvider = function(index)
        return "ui://31x61s81d6ls4"
    end
    --]]
    list.itemRenderer = function(index, obj)
        local v = server_list[index +1]
        obj.title = string.format("%s %s:%s", v[1], v[2], v[3]);
    end

    local function ItemClick(context)
        local item = context.data
        local childIndex =  list:GetChildIndex(item)
        local itemIndex = list:ChildIndexToItemIndex(childIndex)
        local v = server_list[itemIndex + 1]
        self.vm.ServerName = v[1]
        self.vm.panelType = 0

        _G.Account:SaveServerId(itemIndex+1)
        self.account.serverId = itemIndex+1
    end
    list.onClickItem:Add(ItemClick)
    list:SetVirtual()
end

--WARING:长按结束事件需要自己判断
function UILogin:OnTestBtnClick()
    if isLong then
        isLong = false
        return
    end
    print("myButton")
end

function UILogin:OnLoginBtnClick()
    if string.IsNullOrEmpty(self.AccountInput.text) then
        _G.GameLog.LogError("请输入账号")
        return
    end
    _G.Account:SaveRID(self.AccountInput.text)

    if string.IsNullOrEmpty(self.NameInput.text) then
        _G.GameLog.LogError("请输入名字")
        return
    end

    _G.Account:SaveName(self.NameInput.text)

    _G.Account:SaveAccount()
    local server = server_list[self.account.serverId]
    _G.Net:connect_server(server[2], server[3], 1)
end
