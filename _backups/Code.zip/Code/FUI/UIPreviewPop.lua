--This is an automatically generated class by FairyGUI. Please do not modify it.
--招募预览
local UIPreviewPop = _G.UIController:Get("UIPreviewPop")

local PopContainer
local indexer = _G.Indexer.New()
local ItemManager = _G.ItemManager
local ItemConfig = _G.Database.ItemConfig
local HeroConfig = _G.Database.HeroConfig
local RecruitConfig = _G.Database.RecruitConfig

local PopMode = {
	Hero       = indexer(-1),
	Skill      = indexer(),
	RandomShop = indexer()
	}
	
local ShowTypes = {
	Hero = 1,   --武将
	Item = 2,   --物品
}
		
function UIPreviewPop:Awake()
end

function UIPreviewPop:SetWindType()
	if self.type == 3 then
		self.previewtypeCtrler.selectedIndex = 1
	else
		self.previewtypeCtrler.selectedIndex = 0
	end
end

function UIPreviewPop:InitBinds()
	return {
		panelMode = function(mode)
			self.previewtypeCtrler.selectedIndex = mode
			if PopContainer[mode] then
				PopContainer[mode](self)
			end
		end,
		randomShopList = function(value)
			self.randomShopItemList.numItems = #value
		end
    }
end

function UIPreviewPop:InitVM()
	return {
		panelMode = PopMode.Hero,
		randomShopList = {}
    }
end

--FIXME:This is automatically generated
--FIXME:If no event to listen, Delete This function
function UIPreviewPop:InitEvents()
end

function UIPreviewPop:BindUI()
	self.stateCtrler = self:GetController("state")
	self.previewtypeCtrler = self:GetController("previewtype")
	self.previewtitleTxt = self:GetControl("previewtitleTxt")
	self.herolist = self:GetControl("herolist")
	self.CloseBtn = self:GetControl("CloseBtn")
	self.Skillpreview = self:GetControl("Skillpreview")
	self.Skilllist = self:GetControl("Skilllist")
	self.randomShopItemList = self:GetControl("ItemList")
end

function UIPreviewPop:Start()

	if self.args.mode then
		self.vm.panelMode = self.args.mode
		return
	end

	if self.args.type then
		self.type = self.args.type--1为普通招募预览，2为高级招募预览，3为技能预览
		self:SetWindType()
		self:InitHeroAndItemList()
		return
	end

end
--item提供者
local function HeroListItemProvider(index)
	if index < #UIPreviewPop.heroTitleList then
		return "ui://UIRecruit/Herotitle"
	end
	if index < #UIPreviewPop.heroTitleList + #UIPreviewPop.heroInfoList then
		return "ui://UIPreviewPop/SquareHead"
	end
	if index < #UIPreviewPop.heroTitleList + #UIPreviewPop.heroInfoList + #UIPreviewPop.itemTitleList then
		return "ui://UIRecruit/Itemtitle"
	end
	return "ui://UIPreviewPop/Item1"
end
--item渲染函数
local function HeroListItemRenderder(index,obj)
	if (index >= #UIPreviewPop.heroTitleList) and index < (#UIPreviewPop.heroTitleList + #UIPreviewPop.heroInfoList) then
		local endIndex = #UIPreviewPop.heroTitleList
		local heroIndex = index - endIndex + 1
		local heroData = UIPreviewPop.heroInfoList[heroIndex]
		if heroData.id < 0 then
			obj.visible = false
			return
		else
			obj.visible = true
		end

		obj:GetChild("ComHerohead"):GetChild("IconLoader").url = string.format( "art/%s",heroData.icon)
		obj:GetChild("HeroNameTxt").text = heroData.name
		obj:GetChild("ComHerohead"):GetController("color").selectedIndex = heroData.quality

		return
	end
	if index >= #UIPreviewPop.heroTitleList + #UIPreviewPop.heroInfoList + #UIPreviewPop.itemTitleList then
		local endIndex = #UIPreviewPop.heroTitleList + #UIPreviewPop.heroInfoList + #UIPreviewPop.itemTitleList
		local heroIndex = index - endIndex + 1
		local heroData = UIPreviewPop.itemInfoList[heroIndex]
		local item = obj:GetChild("ComItem")

		obj:GetChild("itemnameTxt").text = heroData.name
		item:GetChild("iconloader").url = string.format( "art/%s",heroData.icon)
		item:GetChild("18Txt").text = ""
		item:GetController("quality").selectedIndex = heroData.quality
		obj:GetController("color").selectedIndex = heroData.quality
	end
end
function UIPreviewPop:InitHeroAndItemList()
	self.heroInfoList = {}
	self.itemInfoList = {}
	self:SetHeroTitle()

	local configList = RecruitConfig.Re_showData

	for key,bin in pairs(configList) do
		if bin.type == self.type then
			local id = bin.items[2]
			if bin.show_type == ShowTypes.Hero then
				self:AddHeroList(id)
			elseif bin.show_type == ShowTypes.Item then
				self:AddItemList(id)
			end
		end
	end

	self:SortTable()

	self:MendList()

	self.herolist.itemRenderer = HeroListItemRenderder
	self.herolist.itemProvider = HeroListItemProvider
	self.herolist:SetVirtual()

	self.herolist.numItems = #self.heroTitleList + #self.heroInfoList + #self.itemTitleList + #self.itemInfoList
end

function UIPreviewPop:SortTable()
	table.sort( self.heroInfoList, function(a,b)
			return a.quality > b.quality
	end)

	table.sort( self.itemInfoList, function(a,b)
		return a.quality > b.quality
	end)
end

--补全herolist和itemList
function UIPreviewPop:MendList()
	local heroNum = #self.heroInfoList
	local itemNum = #self.itemInfoList
	local heroMendNum = self.lineItmeNum - (heroNum % self.lineItmeNum)
	for i = 1,heroMendNum do
		self:AddHeroList(-1)
	end
end

function UIPreviewPop:AddHeroList(heroId)
	if heroId < 0 then
		local heroData = {id = heroId,}
		table.insert(self.heroInfoList,heroData)
		return
	end

	local heroBin = HeroConfig.ListData[heroId]

	if not heroBin then
		elog("heroId异常---->"..heroId)
		return
	end

	local heroData = {
		id = heroId,
		name = heroBin.name,
		icon = heroBin.icon,
		quality = heroBin.quality
	}

	table.insert(self.heroInfoList,heroData)
end

function UIPreviewPop:AddItemList(itemId)

	local itemBin = ItemConfig.ItemData[itemId]

	if not itemBin then
		elog("itemId异常--->"..itemId)
		return
	end

	local itemData = {
		id = itemId,
		name = itemBin.name,
		icon = itemBin.icon,
		quality = itemBin.quality
	}

	table.insert( self.itemInfoList,itemData)
end
function UIPreviewPop:SetHeroTitle()
	self.heroTitleList = {}
	self.itemTitleList = {}
	local itemWidth = 188
	local item = _G.UIPackage.CreateObject("UIRecruit","Item")
	if item then
		itemWidth = item.width
		item:Dispose()
	end
	self.lineItmeNum = math.floor(self.herolist.width / itemWidth)
	
	for i = 1,self.lineItmeNum do
		table.insert( self.heroTitleList, 1)
		table.insert( self.itemTitleList, 1)
	end
end
--FIXME:Write logic Code here!

function UIPreviewPop:OnCloseBtnClick()
	_G.UIController:CloseUI("UIPreviewPop")
end




--商店奖品预览合并代码

local StateType = {
	Normal    = indexer(-1),
	Timelimit = indexer(),
	Amountlimit = indexer(),
	Label = indexer()
}

function UIPreviewPop:SetItem(itemData, obj)
	local cfg = ItemManager:get_ui_info({itemData[1], itemData[2]})
	local comItem = obj:GetChild("ComItem")
	obj:GetChild("itemnameTxt").text = cfg.name
	comItem:GetController("quality").selectedIndex = math.clamp(cfg.quality, 0, 5)
	comItem:GetController("state").selectedIndex = cfg.label and StateType.Label or StateType.Normal
	comItem:GetChild("5minute").text = cfg.label or ""
	comItem:GetChild("iconloader").url = string.format("art/%s", cfg.icon)
	comItem:GetChild("18Txt").text = itemData[3]
end

function UIPreviewPop:SetRandomShopView()
	local items = self.args.items
	self:InitRandomShopList(items)
	self.vm.randomShopList = items
end

function UIPreviewPop:InitRandomShopList(items)
	self.randomShopItemList.itemRenderer = function(idx, obj)
		local itemData = items[idx + 1]
		self:SetItem(itemData, obj)
	end
end

PopContainer = {
	[PopMode.RandomShop] = UIPreviewPop.SetRandomShopView,
}



