--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIItem = _G.UIController:Get("UIItem")
UIItem.url = "ui://68i81nkylmegz"

_G.table.mixin(UIItem, require("FUI/Patch/TopBannerPatch"))

local ItemManager = _G.ItemManager

local indexer = _G.Indexer.New()

local TabType = {
    ALL_TAB     	= indexer(), 	--全部
    RESOURCE_TAB  	= indexer(),	--资源
    EXPEDITE_TAB 	= indexer(),	--加速
    BUFF_TAB     	= indexer(), 	--增益
    OTHER_TAB     	= indexer(), 	--其他
}


function UIItem:InitBinds()
    return {
		itemDataList = function(value)
            local list = self:GetControl("ItemList")
            list:RemoveChildrenToPool()
			list.numItems = #value
			self:RefreshSelectedItemInfo()
        end,
		itemType = function(value)
			local oldTab = self.tabIndex
            self.tabIndex = value + 1
			self:UpdateItemList()
			if #self.itemList == 0 then
				self:GetController("ItemAmount").selectedIndex = 0
				self.selectedItemID = nil
			else
				self:GetController("ItemAmount").selectedIndex = 1
				if self.tabIndex ~= oldTab then
					self.selectedItemID = self.itemList[1].id_
				end
			end
            self.vm.itemDataList = self.itemList
        end
    }
end

function UIItem:InitVM()
    return {
		itemType = 0,
        itemDataList = {},
    }
end

function UIItem:InitEvents()
    return {
    }
end

function UIItem:BindUI()
	self.ComDetail = self:GetControl("ComDetail")

	local useBtn = self.ComDetail:GetChild("UseBtn")
	local function onClickUse()
		local item = ItemManager:get_item_by_id(self.selectedItemID)
		if not item or not item:can_use() then return end
		item:use()
	end
	useBtn.onClick:Add(onClickUse)

	local detailBtn = self.ComDetail:GetChild("DetailBtn")
	local function onClickDetail()
		local item = ItemManager:get_item_by_id(self.selectedItemID)
		if not item or not item:can_show_rewards() then return end
		item:show_rewards()
	end
	detailBtn.onClick:Add(onClickDetail)
end

function UIItem:Start()
	self:SetTitle("物品列表")
	self:BindUI()
	self.newItemInfo = {}
    self:UpdateItemList()
    self:InitItemList()
	self.vm.itemType = TabType.ALL_TAB - 1
	self:AddEventListener(_G.EventKey.ITEM_CHANGE, function()
		self.vm.itemType = self.tabIndex - 1
	end)
end

function UIItem:UpdateItemList()
    local ty
    if self.tabIndex ~= TabType.ALL_TAB then
        ty = self.tabIndex - 1
    end
    self.itemList = ItemManager:get_sorted_item_list_of_showpoint(ty, config.ITEM_SHOW_POINT.ITEM_BAG)
end

function UIItem:InitItemList()
    local list =  self:GetControl("ItemList")
    list.itemProvider = function(index)
        return "ui://68i81nkylmegy"
    end

    list.itemRenderer = function(idx, obj)
        local item = self.itemList[idx + 1]
        obj:GetController("quality").selectedIndex = item.prop_.quality - 1

        obj:GetChild("18Txt").text = UIUtil.res_num_to_str(item.count_)
        obj:GetChild("iconloader").url = "art/" .. item.prop_.icon

        local state  = obj:GetController("state")
        if item.prop_.label then
            state.selectedIndex = 3
            obj:GetChild("5minute").text = item.prop_.label
        else
            state.selectedIndex = 0
		end

		local itemid = item.id_
		local selectState = obj:GetController("select")
		if self.selectedItemID == itemid then
			selectState.selectedIndex = 1
			self.selectedObj = obj
		else
			selectState.selectedIndex = 0
		end

		--新物品标记
        local newInfo = self.newItemInfo[itemid]
        if not newInfo and ItemManager:is_item_new(itemid) then
            newInfo = {
                [TabType.ALL_TAB] = true,
                [item.prop_.type + 1] = true,
            }
            self.newItemInfo[itemid] = newInfo
		end
		local newState = obj:GetController("new")
        if newInfo and newInfo[self.tabIndex] then
            newState.selectedIndex = 1
            newInfo[self.tabIndex] = nil
            if not next(newInfo) then
                self.newItemInfo[itemid] = nil
                ItemManager:clear_new_tag(itemid)
            end
        else
            newState.selectedIndex = 0
        end
    end

    local function ItemClick(context)
        local obj = context.data
		local item = self.itemList[list:GetChildIndex(obj) + 1]
		if self.selectedObj then
			local index = list:GetChildIndex(self.selectedObj)
			if index >= 0 then
				self.selectedObj:GetController("select").selectedIndex = 0
			end
		end
		self.selectedItemID = item.id_
		self.selectedObj = obj
		obj:GetController("select").selectedIndex = 1
		
		self:RefreshSelectedItemInfo()
    end
    list.onClickItem:Add(ItemClick)
end

function UIItem:RefreshSelectedItemInfo()
	if not self.selectedItemID then return end
	local item = ItemManager:get_item_by_id(self.selectedItemID)
	if not item or item.count_ <= 0 then
		if #self.itemList == 0 then
			self.selectedItemID = nil
			return
		end
		item = self.itemList[1]
		self.selectedItemID = item.id_
	end
	self.ComDetail:GetChild("ItemName").text = item.prop_.name
	self.ComDetail:GetChild("Description").text = item.prop_.desc
	local comItem = self.ComDetail:GetChild("ComItem")
	comItem:GetChild("18Txt").text = item.count_
	comItem:GetController("quality").selectedIndex = item.prop_.quality - 1
	comItem:GetChild("iconloader").url = "art/" .. item.prop_.icon
	comItem:GetController("new").selectedIndex = 0
	comItem:GetController("select").selectedIndex = 0
	if item.prop_.label then
		comItem:GetController("state").selectedIndex = 3
		comItem:GetChild("5minute").text = item.prop_.label
	else
		comItem:GetController("state").selectedIndex = 0
	end
	local canUse = item:can_use()
	local canShow = item:can_show_rewards()
	local btnState = self.ComDetail:GetController("state")
	if not canUse and not canShow then
		btnState.selectedIndex = 0
	elseif not canShow then
		btnState.selectedIndex = 1
	else
		btnState.selectedIndex = 2
	end
end

function UIItem:OnBackBtnClick()
    self:Hide()
end

function UIItem:OnallClick()
	self:OnSelectTab(TabType.ALL_TAB)
end

function UIItem:OnresClick()
	self:OnSelectTab(TabType.RESOURCE_TAB)
end

function UIItem:OnspeedClick()
	self:OnSelectTab(TabType.EXPEDITE_TAB)
end

function UIItem:OnbuffClick()
	self:OnSelectTab(TabType.BUFF_TAB)
end

function UIItem:OnotherClick()
	self:OnSelectTab(TabType.OTHER_TAB)
end

function UIItem:OnSelectTab(index)
    self.vm.itemType = index - 1
end

function UIItem:OnComDetailClick()
end

