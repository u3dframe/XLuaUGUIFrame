--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIHeroInfo = _G.UIController:Get("UIHeroInfo")

local hero_items = _G.Database.BasicConfig.BasicData.hero_items
local ResourcesManager = _G.ResourcesManager

_G.table.mixin(UIHeroInfo, require("FUI/Patch/TopBannerPatch"))

local HeroConfig = _G.Database.HeroConfig
local lang = _G.lang
local config = _G.config
local HeroManager = _G.HeroManager

local NUM_SKILL_SLOT = 4    --技能槽数量

local indexer = _G.Indexer.New()

local TabType = {
    ATTRIBUTE   = indexer(),    --属性
    LEVEL_UP    = indexer(),    --升级
    STAR_UP     = indexer(),    --升星
    SKILL       = indexer(),    --技能
}

function UIHeroInfo:InitBinds()
    return {
        currIndex = function(var)
            if var < self.heroIndex then
                self:ReleaseSpineBundle(2, true)
                self:ReleaseSpineBundle(3, true)
            else
                self:ReleaseSpineBundle(4, false)
                self:ReleaseSpineBundle(5, false)
            end
            self.heroIndex = var
            self.curHero = self.heroList[self.heroIndex]
            self:RefreshHeroBaseInfo()
            self:RefreshTab()
        end,
        currTab = function(var)
            self.selectedTab = var + 1
            self:RefreshTab()
        end,
        heroDataList = function(var)
            local heroList = self:GetControl("HeroList.HeroInfoList")
            -- heroList:RemoveChildrenToPool()
            heroList.numItems = #var
            -- heroList:RefreshVirtualList()
        end,
    }
end

function UIHeroInfo:InitVM()
    return {
        heroDataList = {},
        currIndex = self.heroIndex,
        currTab = TabType.ATTRIBUTE - 1,
    }
end

function UIHeroInfo:InitEvents()
    return {
        self:AddEventListener({_G.EventKey.ENERGY_REFRESH, _G.EventKey.CITY_HERO_LVUP}, function()
            self:RefreshHeroLevelInfo()
        end),
        self:AddEventListener(_G.EventKey.CITY_HERO_STARUP, function(args)
            if self.curHero.id_ == args.id then
                self:RefreshHeroStarInfo()
            end
            _G.UIController:ShowUI("UIHeroStarUpSuccess", {id = args.id})
        end),
        self:AddEventListener(_G.EventKey.CHIP_EXCHANGE_SUCCESS, function(args)
            if self.curHero.id_ == args.id then
                self:RefreshHeroStarInfo()
            end
        end),
        self:AddEventListener({_G.EventKey.CITY_HERO_SKILL}, function(args)
            if self.curHero.id_ == args.id then
                self:RefreshHeroSkillInfo()
            end
        end),
    }
end

function UIHeroInfo:BindUI()
    self.skillDescPanel = self:GetControl("SkillDescribe")
    self.skillDescCtrler = self:GetController("Skilltype")
end

function UIHeroInfo:Awake()
    self:InitHeroList()
    self:SetTypeChangeController()

    self:GetControl("ComHeroAttribute.SmallBtn").onClick:Add(function(context)
        _G.UIController:ShowUI("UIHeroDetail", {hero=self.heroList[self.heroIndex]})
    end)
end

function UIHeroInfo:SetTypeChangeController()
    self.typeCrtl = self:GetController("c1")

    local function typeCrtlChange()
        self.vm.currTab = self.typeCrtl.selectedIndex
    end

    self.typeCrtl.onChanged:Add(typeCrtlChange)
end

function UIHeroInfo:InitHeroList()
    self.isSpineLoading = {}
    self.heroList = {}

    self.heroList = table.filter(self.args.heroList, function(v) return v.is_active_ end)

    -- for _, hero in ipairs(self.args.heroList) do
    --     if hero.is_active_ then
    --         table.insert(self.heroList, hero)
    --     end
    -- end
    self.heroIndex = self.args.heroIndex
    self.selectedTab = self.args.selectedTab or 1

    self:InitSkillList()

    --绑定列表
    local heroList = self:GetControl("HeroList.HeroInfoList")

    local function ListScrollEnd(context)
        self.vm.currIndex = context.sender.currentPageX + 1
    end

    local function ItemRenderer(idx,item)
        local hero = self.heroList[idx+1]
        if not hero then
            elog("no hero data idx=" .. idx)
        end
        local prop = hero:get_prop()
        --如果spine正在加载，跳过
        if self.isSpineLoading[prop.path] then
            return
        end
        self.isSpineLoading[prop.path] = true

        local IconGraph = item:GetChild("IconGraph")
        if not _G.Slua.IsNull(IconGraph) then
            IconGraph.visible = false
        end
        
        _G.GameUtil.CreateSkeletonAnimObj(prop.path, function(obj)
            if _G.Slua.IsNull(obj) then
                self.isSpineLoading[prop.path] = false
                return
            end

            IconGraph = item:GetChild("IconGraph")
            if not _G.Slua.IsNull(IconGraph) and not _G.Slua.IsNull(IconGraph.displayObject.gameObject) then
                print("IconGraph.displayObject.name = "..IconGraph.displayObject.gameObject.name)
                if IconGraph.displayObject.gameObject.name == "GoWrapper" then
                    item.container:RemoveChild(IconGraph.displayObject, true);
                end
            end

            obj.name = prop.path

            local rect_data = prop.scale
            local uiSpineScale = self:GetUISpineScale()
            obj.transform.position = _G.Vector3(rect_data[2][1], rect_data[2][2])
            obj.transform.localScale =  _G.Vector3(uiSpineScale.x*rect_data[1], uiSpineScale.y*rect_data[1], 1)
            local heroGraph = item:GetChild("IconGraph")
            local goWrapper = _G.UIController:LoadGameObjectToUI(heroGraph, obj)
            goWrapper.supportStencil = true
            _G.GameController.spineController:PlayAnimation(obj, "animation" , 0 , true, nil)
            IconGraph = item:GetChild("IconGraph")
            if not _G.Slua.IsNull(IconGraph) then
                IconGraph.visible = true
            end
            self.isSpineLoading[prop.path] = false
        end)
    end
    
    heroList.scrollPane.onScrollEnd:Set(ListScrollEnd)
    heroList.itemRenderer = ItemRenderer
    heroList:SetVirtual()
end


function UIHeroInfo:Start()
    self:SetTitle("英雄详情")
    self.skillDescCtrler.selectedIndex = 1
    self.vm.heroDataList = self.heroList
    self.vm.currIndex = self.args.heroIndex
    self.timeDelay = _G.Time.time
end

--刷新英雄的基础信息
function UIHeroInfo:RefreshHeroBaseInfo()

    local hero = self.heroList[self.heroIndex]
    if not hero then return end

    local heroList = self:GetControl("HeroList.HeroInfoList");
    heroList:ScrollToView(self.heroIndex - 1)
    self:GetController("arrow_state").selectedIndex = #self.heroList <= 1 and 0 or 3
    self:GetController("info_state").selectedIndex = hero.type_ - 1
    self:GetController("quality").selectedIndex = hero.quality_ - 1
    self:GetControl("HeroNameTxt").text = hero.name_
    self:GetControl("HeroProTxt").text = hero:get_prop().title
    self:GetControl("PowerTxt").text = hero:get_power()

end

function UIHeroInfo:RefreshTab()
    self.typeCrtl.selectedIndex = self.selectedTab - 1
    local hero = self.curHero
    if not hero then return end
    if self.selectedTab == TabType.ATTRIBUTE then
        self:RefreshAttributeInfo(hero)
    elseif self.selectedTab == TabType.LEVEL_UP then
        self:InitHeroLevelInfo()
        self:RefreshHeroLevelInfo(hero)
    elseif self.selectedTab == TabType.STAR_UP then
        self:InitHeroStarInfo()
        self:RefreshHeroStarInfo(hero)
    elseif self.selectedTab == TabType.SKILL then
        self:InitHeroSkillInfo()
        self:RefreshHeroSkillInfo(hero)
    end
end

function UIHeroInfo:RefreshAttributeInfo(hero)
    self:GetControl("ComHeroAttribute.herostar"):GetController("star_state").selectedIndex = hero:get_star_lv() - 1
        self:GetControl("ComHeroAttribute.LevelTxt").text = hero.lv_
        local progressBar = self:GetControl("ComHeroAttribute.progress")
        progressBar.max = hero:get_exp()
        if hero.lv_ < hero:get_max_hero_lv() then
            progressBar.value = hero.cur_exp_
        else
            progressBar.value = 0
        end
        local attrs = hero:get_attr()
        self:GetControl("ComHeroAttribute.LeadTxt").text = attrs[1]
        self:GetControl("ComHeroAttribute.GovernmentTxt").text = attrs[2]
        self:GetControl("ComHeroAttribute.IntelligentTxt").text = attrs[3]
        local list = self:GetControl("ComHeroAttribute.SkillList")
        list:RemoveChildrenToPool()
        list.numItems = NUM_SKILL_SLOT
end


function UIHeroInfo:InitSkillList()
    local list = self:GetControl("ComHeroAttribute.SkillList")
    list.itemProvider = function(index)
        return "ui://yqkvxn4qteyy1d"
    end
    local hero = self.heroList[self.heroIndex]
    local heroCfg = HeroConfig.ListData[hero.id_]
    list.itemRenderer = function(idx, obj)
        local index = idx + 1
        local state = obj:GetController("state")
        local skillCfg
        if index == 1 then
            skillCfg = HeroConfig.SkillData[heroCfg.innate]
            state.selectedIndex = 3
        elseif hero.lv_ >= heroCfg.skill_slot[index - 1] then
            if hero.skills_[index] then
                state.selectedIndex = 2
                local skill = hero.skills_[index]
                skillCfg = HeroConfig.SkillData[skill.id]
                obj:GetChild("LvTxt").text = skill.level
            else
                state.selectedIndex = 1
            end
        else
            state.selectedIndex = 0
            obj:GetChild("EmptyTipsTxt").text = lang("SKILL_UNLOCK", heroCfg.skill_slot[index - 1])
        end
        if skillCfg then
            obj:GetChild("IconLoader").url = "art/"..skillCfg.icon
            obj:GetController("occu").selectedIndex = skillCfg.type - 1
            obj:GetChild("UnlockTxt").text = skillCfg.name
        end
    end
end

function UIHeroInfo:OnCloseBtnClick()
    _G.UIController:CloseAllUI()
end

function UIHeroInfo:OnBackBtnClick()
    self:Hide()
end

function UIHeroInfo:OnLeftBtnClick()
    if _G.Time.time - self.timeDelay > 0.5 then
        self.timeDelay = _G.Time.time
        self.vm.currIndex = (self.vm.currIndex.value - 2) % #self.heroList + 1
    end
end

function UIHeroInfo:OnRightBtnClick()
    if _G.Time.time - self.timeDelay > 0.5 then
        self.timeDelay = _G.Time.time
        self.vm.currIndex = self.vm.currIndex.value % #self.heroList + 1
    end
end

function UIHeroInfo:ReleaseSpineBundle(offset, isReleaseRight)
    local releaseIndex
    if isReleaseRight then
        releaseIndex = (self.vm.currIndex.value + offset) % #self.heroList + 1
    else
        releaseIndex = (self.vm.currIndex.value - offset) % #self.heroList + 1
    end
    dump(releaseIndex, "releaseIndex..")
    if (releaseIndex == self.vm.currIndex.value or releaseIndex == self.vm.currIndex.value + 1) then
        return
    end

    local prop = self.heroList[releaseIndex]:get_prop()
    local unloadName = prop.path
    ResourcesManager.UnloadAssetBundle(string.format("Model/Drawing/%s", unloadName))
end

function UIHeroInfo:ReleaseAllSpineBundle()
    for _, v in pairs(self.heroList) do
        local prop = v:get_prop()
        local unloadName = prop.path
        ResourcesManager.UnloadAssetBundle(string.format("Model/Drawing/%s", unloadName))
    end
end

function UIHeroInfo:OnherostarClick()
end

function UIHeroInfo:InitHeroLevelInfo()
    if self.levelPanel then return end
    self:InitBindLevelInfo()
    self:GetHeroLevelUpExpList()
end

--绑定升级的界面
function UIHeroInfo:InitBindLevelInfo()
    self.levelPanel = {}
    self.levelPanel.SmallBtn = self:GetControl("ComHeroLevelUp.SmallBtn")
    self.levelPanel.HeroLevelTxt = self:GetControl("ComHeroLevelUp.HeroLevelTxt")
    self.levelPanel.ProgressBar = self:GetControl("ComHeroLevelUp.ProgressBar")
    self.levelPanel.SmallBtn.onClick:Set(function(context)
        --计算经验道具能提升的最大等级
        local totalExpOfItems = 0
        for i, info in ipairs(hero_items) do
            local cnt = ItemManager:get_count(config.ITEM_ITEM, info[1])
            totalExpOfItems = totalExpOfItems + info[2] * cnt
        end
        local maxLv = self.curHero.lv_
        local maxLvOfCurrStar = HeroManager:get_hero_max_lv(self.curHero.id_, self.curHero.star_)
        if maxLv == maxLvOfCurrStar then
            _G.MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_MASSIVE_LEVEL"))
            return
        end
        local currExp = self.curHero.cur_exp_
        while maxLv < maxLvOfCurrStar and totalExpOfItems > 0 do
            local total = HeroManager:GetExpOfLevel(self.curHero.id_, maxLv, self.curHero.star_)
            if not total then break end
            local addExp = math.min(totalExpOfItems, total - currExp)
            totalExpOfItems = totalExpOfItems - addExp
            currExp = currExp + addExp
            if currExp >= total then
                maxLv = maxLv + 1
                currExp = currExp - total
            end
        end
        if maxLv == self.curHero.lv_ then
            _G.MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_LEVEL_UP_ITEMLACK"))
            return
        end
        _G.UIController:ShowUI("UIHeroLevelUp",{hero = self.curHero, minLv = self.curHero.lv_ + 1, maxLv = maxLv})
    end)
end

function UIHeroInfo:ProgressChange()
    self.levelPanel.ProgressBar.max = self.curHero.max_exp_
    self.levelPanel.ProgressBar.value = self.curHero.cur_exp_
    self.levelPanel.ProgressBar.title = string.format( "%d/%d",self.curHero.cur_exp_,self.curHero.max_exp_)
end

function UIHeroInfo:RefreshHeroLevelInfo(hero)
    hero = hero or self.curHero
    self:RefreshExpItem()

    self.levelPanel.HeroLevelTxt.text = lang("UI_HERO_LV1",hero.lv_)
    self:ProgressChange()
end
--初始化升级道具
function UIHeroInfo:GetHeroLevelUpExpList()
    --获取升级的道具
    local levelItems = hero_items
    if not levelItems then
        elog("获取升级道具失败")
        return
    end
    local itemNum = #levelItems

    for i = 1,itemNum do
        local itemName = string.format( "Item%d",i)
        local item = self:GetControl("ComHeroLevelUp."..itemName)
        if not item then
            elog("未能获得界面item--->"..itemName.."    所属道具id为--->"..levelItems[i][1])
            return
        end
        self.levelPanel[itemName] = item

        local itemConfig = ItemManager:get_config(levelItems[i][1])
        item:GetController("quality").selectedIndex = itemConfig.quality - 1
        item:GetChild("iconloader").url = string.format("art/%s",itemConfig.icon)
        item:GetChild("propname").text = itemConfig.name
        item.onClick:Set(function()
            HeroManager:HeroLevelUp(self.curHero.id_, {{levelItems[i][1], 1}}, function()
                self:RefreshHeroLevelInfo()
            end)
        end)
    end

    self.levelPanel.expItems = levelItems

end

--升级成功后调用刷新道具界面
function UIHeroInfo:RefreshExpItem()
    local itemNum = #self.levelPanel.expItems
    for i=1,itemNum do
       self:SetLeveUpExpItem(i)
    end
end

function UIHeroInfo:SetLeveUpExpItem(index)
    local itemName = string.format( "Item%d",index)
    local item = self.levelPanel[itemName]

    if not item then
        elog("item == nil---->"..itemName)
        return
    end
    
    local itemProp = self.levelPanel.expItems[index]
    local itemConfig = ItemManager:get_config(itemProp[1])
    if not itemConfig then
        return
    end

    local itemData = ItemManager:get_item_by_id(itemProp[1])

    local itemNum = (itemData and itemData.count_) or 0 

    item:GetChild("leveltext").text = itemNum
    item:GetController("state").selectedIndex = (itemNum > 0 and 1) or 0
end

function UIHeroInfo:InitHeroStarInfo()
    if self.starPanel then return end
    self.starPanel = {}
    self.starPanel.ComStar = self:GetControl("ComHeroStarUp.ComStarUp")
    self.starPanel.ChipIcon = self:GetControl("ComHeroStarUp.icon")
    self.starPanel.StageCtrler = self:GetControl("ComHeroStarUp"):GetController("state")
    self.starPanel.StarTxt = self:GetControl("ComHeroStarUp.StarTxt")
    self.starPanel.ComChip = self:GetControl("ComHeroStarUp.ComFrag")
    self.starPanel.ComChip.onClick:Set(function(context)
        if ItemManager:get_count_by_prop(self.curHero:get_prop().trade_item) <= 0 then return end
        local star = self.curHero:get_star_and_stage()
        if star >= self.curHero:get_max_star() then return end
        _G.UIController:ShowUI("UIFragmentExchange", {id = self.curHero.id_})
    end)
    self.starPanel.HintTxt = self:GetControl("ComHeroStarUp.HintTxt")
    self.starPanel.SourceBtn = self:GetControl("ComHeroStarUp.SmallBtn")
    self.starPanel.StarBtn = self:GetControl("ComHeroStarUp.StarBtn")
    self.starPanel.StarBtn.onClick:Set(function(context)
        local hero = self.curHero
        if not hero:enable_stage() then return end
        --已经最大星级后，不可升星
        local star, stage = hero:get_star_and_stage()
        if star >= hero:get_max_star() then return end
        --检查碎片是否足够
        local chipNum = hero:get_chip_num()
        local cost = 0
        local target
        for i = stage, 4 do
            local key = hero.id_ * 100 + (star - 1) * 5 + i + 1 
            local star = HeroManager.star_prop_map_[key]
            if star then
                cost = cost + star.cost[3]
                --拥有的碎片小于 花费的时候 选择上一个阶段
                if chipNum < cost then
                    local star = HeroManager.star_prop_map_[key]
                    target = star.star_level
                    break
                end
            end
        end

        --如果拥有的碎片已经超过升级一星的了，直接选择下一星级
        if not target then
            local key = hero.id_ * 100 + star * 5 + 1
            local star = HeroManager.star_prop_map_[key]
            target = star.star_level
        end

        hero:set_attrs_snapshot()
        HeroManager:HeroStarUp(hero.id_, target)
    end)
end

function UIHeroInfo:RefreshHeroStarInfo(hero)
    hero = hero or self.curHero
    local star = hero:get_star_lv()
    local stage = hero:get_stage_lv()
    local chipID = hero:get_chip_id()
    local chipNum = hero:get_chip_num()
    local chipNeed = hero:get_stage_up_cost()
    local chipCfg = ItemManager:get_config(chipID)
    self.starPanel.ComStar:GetController("c1").selectedIndex = star - 1
    self.starPanel.ChipIcon.url = "art/" .. chipCfg.icon
    self.starPanel.StageCtrler.selectedIndex = stage
    self.starPanel.HintTxt.text = lang("UI_HERO_HINT_NEXT_STAGE", string.format("%d/%d", chipNum, chipNeed))
    local prop = hero:get_prop()
    local generalCfg = ItemManager:get_item_prop_by_id(prop.trade_item[2])
    self.starPanel.ComChip:GetController("quality").selectedIndex = generalCfg.quality - 2
    local generalChip = ItemManager:get_item_by_id(prop.trade_item[2])
    self.starPanel.ComChip:GetChild("AmountTxt").text = generalChip and generalChip.count_ or 0
    local  str
    if stage == 0 then
        str = lang("UI_HERO_STAR", star)
    else
        str = lang("UI_HERO_STAR", star)..lang("UI_HERO_STAGE", stage)
    end
    self.starPanel.StarTxt.text = str
end

function UIHeroInfo:InitHeroSkillInfo()
    if self.skillPanel then
        self.skillPanel.gestures = {}
        return
    end
    self.skillPanel = {}
    self.skillPanel.gestures = {}
    self.skillPanel.ComSkillInfo = self:GetControl("ComSkillInfo")
    self.skillPanel.SkillList = self:GetControl("ComSkillInfo.Skilllist")
    self.skillPanel.BagBtn = self:GetControl("ComSkillInfo.n9")
    self:InitHeroSkillList()
    self.skillPanel.BagBtn.onClick:Set(function()
        _G.UIController:ShowUI("UISkillku")
    end)
end

function UIHeroInfo:InitHeroSkillList()
    self.skillPanel.SkillList.itemProvider = function()
        return "ui://UIHeroInfo/ComSkilllist"
    end
    local onLevelUpBtnClick = function(context)
        local index = self.skillPanel.SkillList:GetChildIndex(context.sender.parent)
        _G.UIController:ShowUI("UISkillLevel", {id = self.curHero.id_, pos = index})
    end
    local onLearnBtnClick = function(context)
        local index = self.skillPanel.SkillList:GetChildIndex(context.sender.parent)
        _G.UIController:ShowUI("UISkillku", {id = self.curHero.id_, pos = index})
    end
    local onPressStart = function(context)
        local host = context.sender.host
        local index = self.skillPanel.SkillList:GetChildIndex(host.parent) + 1
        local cfg
        if index == 1 then
            cfg = HeroConfig.SkillData[self.curHero.innate_skillID_]
        else
            local skill = self.curHero.skills_[index - 1]
            if skill then cfg = HeroConfig.SkillData[skill.skillid] end
        end
        if not cfg then return end
        self.skillDescCtrler.selectedIndex = 0
        self.skillDescPanel:GetChild("nameTxt").text = cfg.name
        self.skillDescPanel:GetChild("desTxt").text = cfg.desc
        _G.GRoot.inst:ShowPopup(self.skillDescPanel, host)
    end
    local onPressEnd = function()
        _G.GRoot.inst:HidePopup()
    end
    self.skillPanel.SkillList.itemRenderer = function(idx, obj)
        local skillStateCtrler = obj:GetController("SkillType")
        local index = idx + 1
        local skillCfg
        if index == 1 then
            skillCfg = HeroConfig.SkillData[self.curHero.innate_skillID_]
            skillStateCtrler.selectedIndex = 0
            obj:GetChild("SkillnameTxt").text = skillCfg.name
        else
            local skill = self.curHero.skills_[index - 1]
            if skill then
                skillStateCtrler.selectedIndex = 1
                skillCfg = HeroConfig.SkillData[skill.skillid]
                obj:GetChild("Skillname2Txt").text = skillCfg.name
                obj:GetChild("SkilllevelTxt").text = skill.level
                obj:GetChild("LevelBtn").onClick:Set(onLevelUpBtnClick)
            else
                local unlockLv = HeroConfig.ListData[self.curHero.id_].skill_slot[index - 1]
                if self.curHero.lv_ >= unlockLv then
                    skillStateCtrler.selectedIndex = 2
                    obj:GetChild("StudyBtn").onClick:Set(onLearnBtnClick)
                else
                    skillStateCtrler.selectedIndex = 3
                    obj:GetChild("UnlockTxt").text = lang("SKILL_UNLOCK", unlockLv)
                end
            end
        end
        local icon = obj:GetChild("Skill@icon")
        if not self.skillPanel.gestures[index] then
            local gesture = _G.LongPressGesture(icon)
            self.skillPanel.gestures[index] = gesture
			gesture.once = false
			gesture.trigger = 0.3
			gesture.onBegin:Add(onPressStart)
			gesture.onEnd:Add(onPressEnd)
        end
        if skillCfg then
            icon.url = string.format("art/%s", skillCfg.icon)
            obj:GetController("HeroType").selectedIndex = skillCfg.type - 1
        end
    end
end

function UIHeroInfo:RefreshHeroSkillInfo()
    self.skillPanel.SkillList.numItems = 4
end

function UIHeroInfo:OnDestroy()
    self:ReleaseAllSpineBundle()
    self.levelPanel = nil
    self.starPanel = nil
    self.skillPanel = nil
end