local UIFortBenefit = _G.UIController:Get("UIFortBenefit")

local UIUtil = _G.UIUtil
local lang   = _G.lang

local State = {
	None  = 0,
	Being = 1
}

function UIFortBenefit:Awake()
	self.fort = self.args.data
	local prop = self.fort:get_prop()
	if not prop then
		return
	end
	self.fixedReward = prop.reward_show1
	self.randomReward = prop.reward_show2
	self:InitItemList()
end

function UIFortBenefit:InitBinds()
    return {
		fixReward = function(value)
			self.fixEarningList.numItems = #value
		end,
		randomReward = function(value)
			self.randomEarningList.numItems = #value
		end,
		panel = function(value)
			self.panelCtrl.selectedIndex = value
			if value == 0 then
				return
			end
			self:PlayTimer()
		end
    }
end

function UIFortBenefit:InitVM()
    return {
		fixReward = {},
		randomReward  = {},
		panel = State.None
    }
end

function UIFortBenefit:BindUI()
	self.panelCtrl = self:GetController("state")
	self.totalTimeTxt = self:GetControl("TotalTimeTxt")
	self.remainTimeTxt = self:GetControl("RemainTimeTxt")
	self.singleTributetxt = self:GetControl("SingleTimeLimitTxt")
	self.silder = self:GetControl("ProgressBar")
	self.timerTxt = self:GetControl("ProgressBar.CountDownTxt")
	self.NextTribute = self:GetControl("NextTribute")
	self.fixEarningList = self:GetControl("FixBenefit1List")
	self.randomEarningList = self:GetControl("FixBenefit2List")
end

function UIFortBenefit:InitEvents()
	self:AddEventListener(_G.EventKey.WORLD_FORT_DELETE, function(id)
		if self.fort.idx_ ~= id then
			return
		end
		self:Hide()
	end)
end

function UIFortBenefit:Start()
	self:InitPanel()
	self:InitInfoTxt()
end

function UIFortBenefit:InitItemList()
	self.fixEarningList.itemRenderer = function(idx, obj)
		local itemData = self.fixedReward[idx + 1]
		UIUtil.SetItem(obj, itemData[1], itemData[2], itemData[3])
	end

	self.randomEarningList.itemRenderer = function(idx, obj)
		local itemData = self.randomReward[idx + 1]
		UIUtil.SetItem(obj, itemData[1], itemData[2], itemData[3])
	end
end

function UIFortBenefit:InitPanel()
	self.vm.fixReward = self.fixedReward
	self.vm.randomReward = self.randomReward
	if not self.fort:has_troop() then
		self.vm.panel = State.None
		return
	end
	self.vm.panel = State.Being
end

function UIFortBenefit:InitInfoTxt()
	local prop = self.fort:get_prop()
	local time = UIUtil.get_format_time_sec(prop.tribute_time)
	self.totalTimeTxt.text = self:StrFormat(lang("UI_FORT_12"), prop.tribute_num)
	self.singleTributetxt.text = self:StrFormat(lang("UI_FORT_14"), time)
	self.remainTimeTxt.text = self:StrFormat(lang("UI_FORT_13"), self.fort.cnt_)
end

function UIFortBenefit:StrFormat(des, value)
	return string.format("%s %s", des, tostring(value))
end

local TimerKey = "fortbenefit"
function UIFortBenefit:PlayTimer()
	self.silder.min = 0
	self.silder.max = 1
	self.silder.value = self.fort:get_one_time_bar()
	self.timerTxt.text =  UIUtil.format_time(self.fort:get_one_time())
	local call = function()
		self.silder.value = self.fort:get_one_time_bar()
		self.timerTxt.text =  UIUtil.format_time(self.fort:get_one_time())
		self:InitInfoTxt()
		if self.fort.cnt_ <= 0 then
			self:Hide()
		end
	end
	self:SetIntervalCallTimer(TimerKey, call, 1, false)
end

function UIFortBenefit:OnCloseBtnClick()
	self:Hide()
end
