--This is an automatically generated class by FairyGUI. Please do not modify it.

local UISacrificeExchange = _G.UIController:Get("UISacrificeExchange")

local config = _G.config
local ItemManager = _G.ItemManager
local EventKey = _G.EventKey

function UISacrificeExchange:BindUI()
	self.freeCountTxt = self:GetControl("AmountTxt")
	self.itemComponent = self:GetControl("SacrificeItem")
	self.itemNameTxt = self:GetControl("ItemNameTxt")
	self.itemDesTxt = self:GetControl("ItemDesTxt")
	self.useBtn = self:GetControl("SacrificeExchageBtn")
end

function UISacrificeExchange:InitBinds()
    return {
		freeCount = function(value)
			self.freeCountTxt.text = value
		end
    }
end

function UISacrificeExchange:InitVM()
    return {
		freeCount = 0
    }
end

function UISacrificeExchange:InitEvents()
    self:AddEventListener(EventKey.CITY_FETE_UPDATE, function()
		self.vm.freeCount = self.fete:GetFreeTimes()
	end)
	self:AddEventListener(EventKey.ITEM_CHANGE, function(arg)
		self:RefreshUI()
	end)
end

function UISacrificeExchange:Start()
	self.fete = _G.BuildManager:GetFete()
	self:RefreshUI()
end

function UISacrificeExchange:RefreshUI()
	self.vm.freeCount = self.fete:GetFreeTimes()
	self:SetItem()
end

function UISacrificeExchange:SetItem()
	local basic = self.fete:GetSacBasic()
	local item = ItemManager:get_item_by_id(basic.free_item)
	local prop = {
        config.ITEM_ITEM,
        basic.free_item,
        item and item.count_ or 0
	}
	local cfg = ItemManager:get_ui_info({prop[1], prop[2]})
    if not cfg then
        return
	end
	local itemCard = _G.ItemCard:new()
	self.itemComponent:GetChild("iconloader").url = "art/"..cfg.icon
	self.itemComponent:GetChild("18Txt").text = prop[3]
	self.itemNameTxt.text = cfg.name
	self.itemDesTxt.text = cfg.desc

	local function onClickItem()
		if item then
			item:use()
		end
	end
	self.useBtn.onClick:Remove(onClickItem)
	self.useBtn.onClick:Add(onClickItem)
end

function UISacrificeExchange:OnSacrificeClostBtnClick()
	self:Hide()
end
