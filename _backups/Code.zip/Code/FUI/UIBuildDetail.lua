--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIBuildDetail = _G.UIController:Get("UIBuildDetail")
_G.table.mixin(UIBuildDetail, require("FUI/Patch/TopBannerPatch"))
_G.table.mixin(UIBuildDetail, require("FUI/Patch/UIBuildPatch"))

local BuildManager = _G.BuildManager
local lang = _G.lang
local config = _G.config
local UIController = _G.UIController
local Net = _G.Net
local event = _G.event
local EventKey = _G.EventKey

local BuildState

function UIBuildDetail:Awake()
	self.buildInfo = BuildManager:get_build_info_by_id(self.args.buildID)
	self.buildState = self:GetBuildState()

	self:InitDetailsList()
	self:InitMoreDetailsList()
end

function UIBuildDetail:InitBinds()
     return {
		buttonStyle = function(value)
			 self.buttonCtrler.selectedIndex = value
		end,
		detailsList = function(value)
			if not next(value) then
				self.detailsTitleCtrler.selectedIndex = 0
				local updateInfo = self.buildInfo:get_update_info_by_level()
				self.detailsWord.text = lang(updateInfo.details[1])
				return
			end
			self.detailsTitleCtrler.selectedIndex = 1
			self.detailList.numItems = #value
		end,
		moreDetailsList = function(moreDetails)
			self.detailsTitleCtrler.selectedIndex = 1
			self:SetMoreDetailsTitle()
			self.moreDetailList.numItems = #moreDetails
			self.moreDetailList:ScrollToView(self.buildInfo.lv_ - 1)
		end,
		detailsToggle = function(value)
			if value == 0 then
				local updateInfo = self.buildInfo:get_update_info_by_level(1)
				self.vm.detailsList = updateInfo.detailsicon
				return
			end
			self.vm.moreDetailsList = self.buildInfo:get_build_more_details()
		end
	}
end

function UIBuildDetail:InitVM()
    return {
		buttonStyle = 0,
		detailsList = {},
		moreDetailsList = {},
		detailsToggle = 0,
    }
end

function UIBuildDetail:BindUI()
	self.detailsCtrler = self:GetControl("BuildDetail"):GetController("Details")
	self.detailsTitleCtrler = self:GetControl("BuildDetail"):GetController("DetailsTitle")
	self.buttonCtrler = self:GetControl("BuildDetail"):GetController("button")
	self.titleCtrler = self:GetControl("BuildDetail"):GetController("title")

	self.detailList = self:GetControl("BuildDetail.BuildDetailList")
	self.moreDetailList = self:GetControl("BuildDetail.MoreList")

	self.detailsWord = self:GetControl("BuildDetail.DetailsWord")
	self.dismantleBtn = self:GetControl("BuildDetail.DismantleBtn")
end

function UIBuildDetail:Start()
	self:SetTitle(lang("UI_BUILDDETAILS_TITLE"))
	self:SetBuildInfo(self.buildInfo.id_)

	self:SetButtonStyle()
	self:SetButtonHandler()
	self.vm.detailsToggle = 0
end

function UIBuildDetail:OndetailsPaging2BtnClick()
	self.vm.detailsToggle = self.detailsCtrler.selectedIndex
end

function UIBuildDetail:OndetailsPaging1BtnClick()
	self.vm.detailsToggle = self.detailsCtrler.selectedIndex
end

--建筑移动
function UIBuildDetail:OnDetailsBtnClick()
	local data = {}
	data.mode = 0
	data.content = lang('UI_HINT_BUILD_MOVE')
	data.callback = function()
		MsgCenter.send_message(Msg.CITY_SHOW_CAN_EXCHANGE_BUILD, self.buildInfo.id_)
		self:OnCloseBtnClick()
	end
	UIController:ShowUI("UICommonPop", data)
end


--详情列表
function UIBuildDetail:InitDetailsList()
	local moreDetailsTitle = self.buildInfo.mdetails_title_
	local updateInfo = self.buildInfo:get_update_info_by_level()
	local details = lang(updateInfo.details)

	self.detailList.itemProvider  = function(index)
		return "ui://dmz4hql5lknw1e"
	end

	self.detailList.itemRenderer = function(idx, obj)
		local index = idx + 1
		obj:GetChild("DetailsIcon").url = "art/"..updateInfo.detailsicon[index]
		obj:GetChild("DetailsName").text = lang(details[index])

		--箭塔的临时处理
		if self.buildInfo.build_type_ == config.BUILD_TYPE.TOWER then
			local upInfo = self.buildInfo:get_update_info_by_level()
			local moreDetails = upInfo.moredetails
			if index == 1 then
				obj:GetChild("DetailsNum").text = moreDetails[2]
			elseif index == 2 then
				obj:GetChild("DetailsNum").text = moreDetails[3]
			end
			return
		end

		--陷阱作坊的临时处理
		if self.buildInfo.build_type_ == config.BUILD_TYPE.TRAP and
			index == 1 then
			obj:GetChild("DetailsNum").text = ""
			return
		end

		--有些建筑需要显示数值
		local describe
		for i, v in ipairs(moreDetailsTitle) do
			if lang(v[1]) == lang(details[index]) then
				describe = lang(updateInfo.moredetails[i])
				break
			end
		end
		if describe == "undefine" then
			describe = nil
		end
		if not describe then
			describe = self.buildInfo:get_details_value()
		end
		local attrsBuf = self.buildInfo:get_details_attrs(describe, index)
		if attrsBuf == 0 then
			obj:GetChild("DetailsNum").text = describe
		else
			local str = string.format("%d[color=%s]+%d[/color]", describe, config.FONT_COLOR.GREEN, attrsBuf)
			obj:GetChild("DetailsNum").text = str
		end
	end
end

function UIBuildDetail:SetMoreDetailsTitle()
	local mdetailStitle = self.buildInfo.mdetails_title_
	self.titleCtrler.selectedPage = "MoreTitle"..#mdetailStitle
	local titleObj = self:GetControl("BuildDetail.MoreTitle"..#mdetailStitle)
	for i, v in ipairs(mdetailStitle) do
		local name = string.format("Title%dTxt", i)
		titleObj:GetChild(name).text = lang(v[1])
	end
end

--更多详情列表
function UIBuildDetail:InitMoreDetailsList()
	local moreDetails = self.buildInfo:get_build_more_details()
	local mdetailStitle = self.buildInfo.mdetails_title_
	local columnsCount = #mdetailStitle
	local currLv = self.buildInfo.lv_
	self.moreDetailList.defaultItem = "ui://UIBuildDetail/MoreDetails"..columnsCount
	self.moreDetailList.itemRenderer = function(idx, obj)
		local index = idx + 1
		local isWhite = index == currLv
		local line = moreDetails[index]
		for i = 1, columnsCount do
			local name = string.format("num0%dTxt", i)
			local txt = lang(line[i]) == "undefine" and "" or lang(line[i])
			if not isWhite then
				txt = string.format("[color=#A8A8B8]%s[/color]", txt)
			else
				txt = string.format("[color=#FFFFFF]%s[/color]", txt)
			end
			obj:GetChild(name).text = txt
		end
		obj:GetChild("bgImg").visible = index % 2 == 0
	end
	self.moreDetailList:SetVirtual()
end

--设置按钮样式
function UIBuildDetail:SetButtonStyle()
	--可以建筑移动 显示俩个按钮
	--不可移动建筑 {显示一个 或者不显示按钮}
	local isMovable = self.buildInfo:is_movable()
	if isMovable then
		self.vm.buttonStyle = 0  --显示2个按钮
		return
	end

	if self.buildState == config.Build_State.NONE then
		self.vm.buttonStyle = 2  --不显示按钮
		return
	end
	self.vm.buttonStyle = 1  --显示一个按钮
end

--设置按钮事件
function UIBuildDetail:SetButtonHandler()
	local stateData = BuildState[self.buildState]
	if not stateData then
		return
	end

	self.dismantleBtn.title = stateData.buttonTxt

	local function OnButtonClickHandlder()
		local data = {}
		data.mode = 0
		data.content = stateData.popContent
		data.callback = function()
			if stateData.callback then
				stateData.callback(self)
			end
		end
		UIController:ShowUI("UICommonPop", data)
	end
	self.dismantleBtn.onClick:Set(OnButtonClickHandlder)
end

function UIBuildDetail:GetBuildState()
	local buildState = config.Build_State
	--如果正在拆除并且正在治疗中的时候  先显示取消拆除
    if self.buildInfo:is_curing() and self.buildInfo:is_removing() then
		return buildState.REMOVING
	end

    if self.buildInfo:is_curing() then
		return buildState.CURE
	end

    if self.buildInfo:is_removing() then
		return buildState.REMOVING
	end

    if self.buildInfo:is_lvup() then
		return buildState.LV_UP
	end

    if self.buildInfo:is_building() then
		return buildState.BUILDING
	end

    if self.buildInfo:is_trainning() then
        if self.buildInfo:is_lvup() then
			return buildState.DRILL_AND_LV_UP
		end
        return buildState.DRILL
	end

    return buildState.NONE
end


function UIBuildDetail:SetCancelCureHandler()
	if not self.buildInfo:is_hospital_build() then
		return
	end
	Net.send("soldier_cure_cancel", {}, function(r)
		if r.e == 0 then
			MsgCenter.send_message(Msg.CITY_SOLDIER_CURE_FINISHED, r.e)
			self:OnCloseBtnClick()
		end
	end)
end

function UIBuildDetail:SetRemovingHandler()
	local buildID = self.buildInfo.id_
	Net.send("build_dismantle", {id = buildID}, function(r)
		if r.e == 0 then
			MsgCenter.send_message(Msg.CITY_UP_LV_UPDATE, buildID)
			self:OnCloseBtnClick()
		end
	end)
end

function UIBuildDetail:SetCancelRemovingHandler()
	local buildID = self.buildInfo.id_
	Net.send("build_dismantle_cancel", {id = buildID}, function(r)
		if r.e == 0 then
			BuildManager:remove_queuq(self.buildInfo.id_)
			self.buildInfo:reset_dismantle() -- 清除状态
			MsgCenter.send_message(Msg.CITY_BUILD_REMOVED_CANCEL, self.buildInfo.id_)
			self:OnCloseBtnClick()
		end
	end)
end

function UIBuildDetail:SetCancelBuildingHandler()
	--取消升级比较特殊 有个二级弹窗
	local function SecondLevelPop()
		local buildID = self.buildInfo.id_
		Net.send("build_levelup_cancel", {id = buildID}, function(r)
			if r.e == 0 then
				self:OnCloseBtnClick()
			end
		end)
	end

	local data = {}
	data.mode = 0
	data.content = lang("UI_HINT_LVUP_CANCEL_RES_RETURN")
	data.callback = SecondLevelPop
	UIController:ShowUI("UICommonPop", data)
end

function UIBuildDetail:SetCancelDrillHandler()
	local buildID = self.buildInfo.id_
	Net.send("build_soldier_cancel", {id = buildID}, function(r)
		if r.e == 0 then
			event.fire(EventKey.CITY_STOP_TIMER2, self.buildInfo.space_id_)
			self:OnCloseBtnClick()
		end
	end)
end

function UIBuildDetail:OnBackBtnClick()
	_G.SceneController.currentScene:GetCameraController():FocusBack()

	self:Hide()
end

function UIBuildDetail:OnCloseBtnClick()
	_G.SceneController.currentScene:GetCameraController():FocusBack()

	self:Close()
end

BuildState = {
	--取消治疗
    [config.Build_State.CURE] = {
		buttonTxt = lang('UI_BUILDDETAILS_CURE_CANCEL1'), --按钮文本
		popContent = lang('UI_HINT_CURE_CANCEL'),         --弹窗提示
		callback = UIBuildDetail.SetCancelCureHandler  	  --回调
	},
	--拆除
    [config.Build_State.NONE] = {
		buttonTxt = lang('UI_BUILDDETAILS_REMOVED'),
		popContent = lang('UI_HINT_BUILD_REMOVED'),
		callback = UIBuildDetail.SetRemovingHandler
	},
	--建筑取消拆除
    [config.Build_State.REMOVING] = {
		buttonTxt = lang('UI_BUILDDETAILS_CANCEL_REMOVED'),
		popContent = lang('UI_HINT_BUILD_REMOVED_CANCEL'),
		callback = UIBuildDetail.SetCancelRemovingHandler
	},
	--建筑取消升级
    [config.Build_State.LV_UP] = {
		buttonTxt = lang('UI_BUILDDETAILS_LVUP_CANCEL'),
		popContent = lang('UI_HINT_LVUP_CANCEL'),
		callback = UIBuildDetail.SetCancelBuildingHandler
	},
	--取消训练
    [config.Build_State.DRILL] = {
		buttonTxt = lang('UI_SOLDIER_CANCEL_DRILL'),
		popContent = lang('UI_HINT_DRILL_CANCEL'),
		callback = UIBuildDetail.SetCancelDrillHandler
	},
	--如果在训练并且升级中。先显示训练
    [config.Build_State.DRILL_AND_LV_UP] = {
		buttonTxt = lang('UI_SOLDIER_CANCEL_DRILL'),
		popContent = lang('UI_HINT_DRILL_CANCEL'),
		callback = UIBuildDetail.SetCancelDrillHandler
	},
	--取消研究 (功能未开发)
    [config.Build_State.RESEARCH] = {}
}