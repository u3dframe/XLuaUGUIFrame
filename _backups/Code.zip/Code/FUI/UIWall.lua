--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIWall = _G.UIController:Get("UIWall")
UIWall.url = "ui://vs0kjej4tcbeh"
_G.table.mixin(UIWall, require("FUI/Patch/TopBannerPatch"))
_G.table.mixin(UIWall, require("FUI/Patch/UIBuildPatch"))

local UIUtil = _G.UIUtil
local Net = _G.Net
local BuildManager = _G.BuildManager
local LuaTimer = _G.LuaTimer
local lang = _G.lang
local config = _G.config

function UIWall:InitBinds()
    return {
        currDef = function(value)
            if value < 0 then
                value = 0
            end
            value = math.ceil(value)
            self.slider.value = value
        end,
        defBtnColorContorl = function(value)
            self:GetController("color").selectedPage = value
            local str
            if value == "grey" then
                str = lang("UI_BASIC_UBB_COLOR", config.FONT_COLOR.DRAK_GREY, lang("UI_CITYWALL_NOT_ATTACKED"))
            else
                str = self.cityWall:GetAddDefHint()
            end
            self:GetControl("citydef_desc1Txt").text = str
        end,
        cityDefContorl = function(value)
            self.citydefCtrler.selectedIndex = value
            BuildManager:close_timer("city_wall_add_def")
            --在倒计时中 播放倒计时
            if value == 0 then
                self.vm.defBtnColorContorl = "light"
                self:PlayerTimer()
            else --不在倒计时中
                local isMaxDef = self.cityWall:IsMaxDef()
                self.vm.defBtnColorContorl = isMaxDef and "grey" or "light"
            end
        end,
        outFireBtnControl = function(value)
            self.outFireBtn:GetController("c1").selectedPage = value
            self:StopBurningTimer()
            if value == "grey" then
                self.outFireBtn.enabled = false
                self.fireHintTxt.text = lang("UI_CITYWALL_NOT_BURN")
                return
            end
            self.outFireBtn.enabled = true
            self:PlayBurningTimer()
        end
    }
end

function UIWall:InitVM()
    self.cityWall = BuildManager:GetWall()
    self.slider.max = self.cityWall:GetMaxDef()
    self.slider.min = 0

    return {
        outFireBtnControl = "grey",      --灭火按钮控制器
        defBtnColorContorl = "grey",     --增加城防值按钮颜色控制器
        cityDefContorl = 1,              --控制表现

        currDef = self.slider.max,  --城防值
        defIncreasedCD = 0,         --增加城防值CD
        outFireTxt = "",
    }
end

function UIWall:InitEvents()
    self:AddEventListener({_G.EventKey.UPDATE_CITY_WALL}, function(arg)
        if arg then
            self:StopBurningTimer()
            self.vm.currDef = 0
            return
        end
        --刷新界面
        self:SetData()
    end)
end

function UIWall:BindUI()
    self.citydefCtrler = self:GetController("citydef")
    self.slider = self:GetControl("CountProgressBar")
    self.timerTxt = self:GetControl("timerTxt")
    self.fireHintTxt = self:GetControl("outfire_desc1Txt")
    self.outFireBtn = self:GetControl("OutfireBtn")
end

function UIWall:OnDestroy()
    BuildManager:close_timer("city_wall_add_def")
    self:StopBurningTimer()
end



function UIWall:Start()
    self.buildInfo = _G.BuildManager:get_build_info_by_id(self.args.buildID)
    self:SetTitle(lang("ARCHITECTURE_23"))
    self:SetBuildInfo(self.buildInfo.id_)

    self:InitInfoView()
    self:SetData()
end

function UIWall:InitInfoView()
    self:GetControl("InfoTxt").text = lang("UI_CITYWALL_INFO")
end

function UIWall:SetData()
    self.vm.currDef = self.cityWall:GetDef()

    local isBurning = self.cityWall:IsBurning()
    self.vm.outFireBtnControl = isBurning and "light" or "grey"

    local isCooling = self.cityWall:IsCooling()
    self.vm.cityDefContorl = isCooling and 0 or 1
end

function UIWall:PlayerTimer()
    BuildManager:close_timer("city_wall_add_def")
    local endTime = self.cityWall:GetDefRTS()
    local obj = {}
    obj.key = "city_wall_add_def" --倒计时类型
    obj.id = self.buildInfo.id_
    obj.end_time = endTime
    obj.need_scene = "SceneMain"
    obj.on_per_second = function()
        self.timerTxt.text = UIUtil.format_time(endTime - Net.server_time())
    end
    obj.on_complete = function()
        self.vm.cityDefContorl = 1
    end
    BuildManager:register_timer(obj)
end

function UIWall:StopBurningTimer()
    if self.timer then
        LuaTimer.Delete(self.timer)
    end
end

function UIWall:PlayBurningTimer()
    local endTime = self.cityWall:GetBurnEndTime()
    if not endTime then
        return
    end
    self.timer = LuaTimer.Add(0, 1000, function()
        if self.vm.currDef.value <= 0 or
            endTime <= Net.server_time() then
            print("burning time is stop")
            return false
        end
        local time = UIUtil.format_time(endTime - Net.server_time())
        self.fireHintTxt.text = lang("UI_CITYWALL_BURNING", self.cityWall:GetSpeedPerMinute(), time)

        local def = self.cityWall:GetDef()
        --print("curr def = ", self.cityWall:GetDef(), Net.server_time(),endTime)
        self.vm.currDef = def
    end)
end

--灭火
function UIWall:OnOutfireBtnClick()
    Net.send("wall_stop_burning", {}, function(r)
        if r.e == 0 then
            self.cityWall:FireExtinction(r.val)
            self.vm.currDef = r.val
            self.vm.outFireBtnControl = "grey"
        end
    end)
end

--增加城防值
function UIWall:OnCitydefBtnClick()
    Net.send("wall_fix", {}, function(r)
        if r.e == 0 then
            self:SetData()
        end
    end)
end