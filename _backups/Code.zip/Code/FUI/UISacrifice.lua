local UISacrifice = _G.UIController:Get("UISacrifice")
_G.table.mixin(UISacrifice, require("FUI/Patch/TopBannerPatch"))

local lang = _G.lang
local Net = _G.Net
local indexer = _G.Indexer.New()
local Time = _G.Time
local LongPressGesture = _G.LongPressGesture
local ItemManager = _G.ItemManager
local UIController = _G.UIController
local event = _G.event
local EventKey = _G.EventKey
local CommonResTopPlugin = _G.CommonResTopPlugin

local OPEN_ITEM_COUNT = 4
local UNOPEN_ITEM_INDEX = 5
local isLong = false

local PointType = {
	Click     = indexer(-1),
	LongPress = indexer()
}

function UISacrifice:BindUI()
	self.residueTxt = self:GetControl("maxnum")
	self.freeTxt = self:GetControl("freenum")
	self.freeItemBtn = self:GetControl("FreeitemBtn")
end

function UISacrifice:InitBinds()
    return {
    }
end

function UISacrifice:InitVM()
    return {
    }
end

function UISacrifice:OnDestroy()
	CommonResTopPlugin:RecoverAnimation()
end

function UISacrifice:InitEvents()
	self:AddEventListener(EventKey.CITY_FETE_UPDATE, function(args)
        self:RefreshUI()
    end)
end

function UISacrifice:Start()
	self:SetTitle(lang("ARCHITECTURE_16"))
	self.pointerEvent = {}
	self:RefreshUI()
end

function UISacrifice:RefreshUI()
	self.fete = _G.BuildManager:GetFete()
	self:RefreshItems()
	self:RefreshHintTxt()
	self:SetFreeButton()
end

local FreeItemCtrType = {
	Normal = indexer(-1),
	Gray   = indexer(),
}

function UISacrifice:SetFreeButton()
	local basic = self.fete:GetSacBasic()
    local prop = ItemManager:get_item_prop_by_id(basic.free_item)
	local item = ItemManager:get_item_by_id(basic.free_item)
	local cnt = not item and "" or " "..item.count_
	local ctrType = item == nil and FreeItemCtrType.Gray or FreeItemCtrType.Normal
	self.freeItemBtn:GetController("type").selectedIndex = ctrType
	self.freeItemBtn.enabled = item ~= nil
	self.freeItemBtn:GetChild("ItemTxt").text = prop.name..cnt
end

function UISacrifice:RefreshItems()
	for i = 1, OPEN_ITEM_COUNT do
		self:SetItem(i)
	end
	local itemObj = self:GetControl(string.format("item%d", UNOPEN_ITEM_INDEX))
	local itemCtr = itemObj:GetController("type")
	self:SetItemCtrl(itemCtr, nil, UNOPEN_ITEM_INDEX)
	self:SetItemButtonHandle(itemObj, nil, UNOPEN_ITEM_INDEX)
	self:SetItemLongPressHandle(itemObj, UNOPEN_ITEM_INDEX)
end

function UISacrifice:RefreshHintTxt()
	self.residueTxt.text = lang("UI_CITYFETE_TODY_TIME")..self.fete:GetResidueTimes()
    self.freeTxt.text = lang("UI_CITYFETE_FREE_TIME")..self.fete:GetFreeTimes()
end

local ItemCtrType = {
	Normal    = indexer(-1),
	Free      = indexer(),
	NotUnlock = indexer(),
	UnOpen    = indexer()
}

function UISacrifice:SetItemCtrl(itemCtr, itemData, index)
	if index == UNOPEN_ITEM_INDEX then
		itemCtr.selectedIndex = ItemCtrType.UnOpen
		return
	end

	if not itemData.unlock then
		itemCtr.selectedIndex = ItemCtrType.NotUnlock
		return
	end

	if self.fete:GetFreeTimes() > 0 then
		itemCtr.selectedIndex = ItemCtrType.Free
		return
	end
	itemCtr.selectedIndex = ItemCtrType.Normal
end

function UISacrifice:ItemEvent()
    if self.fete:IsFirstTimeGoldFete() then
        local item = self.fete:GetItem(self.itemPos)
        self:SpendGoldNotity(item.price[3], self.itemPos)
        return
    end
    self:SendMessage()
end

function UISacrifice:SetItemButtonHandle(button, itemData, index)
	local function btnclick()
		if isLong then
			isLong = false
			return
		end
		self.pointerHandler = PointType.Click
		if itemData and itemData.unlock then
			local price = self.fete:GetItemPrice(index)

			self.itemCnt = 1
			self.itemPos = index
			self:ItemEvent()
			return
		end

		if index == UNOPEN_ITEM_INDEX then
			MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_MAIN_UNOPEN"))
			return
		end

		if self.fete:GetResidueTimes() <= 0 then
            MsgCenter.send_message(Msg.SHOW_HINT, lang("CITY_FETE_COUNT_USEUP"))
            return
		end

		local hintTxt = self.fete:GetItemHint(index)
        MsgCenter.send_message(Msg.SHOW_HINT, hintTxt)
	end
	--button.onClick:Remove(btnclick)
	button.onClick:Set(btnclick)
end

function UISacrifice:Check(index)
	local price = self.fete:GetItemPrice(index)
	if self.fete:GetFreeTimes() <= 0 and not ItemManager:check_coin(price) then
		self:SendMessage()
		self:NotEnoughNotity()
		return false
	end
	if self.fete:IsFirstTimeGoldFete() then
		local item = self.fete:GetItem(index)
		self:SendMessage()
		self:SpendGoldNotity(item.price[3], index)
		return false
	end
	return true
end

function UISacrifice:SetItemLongPressHandle(button, index)
	if index == UNOPEN_ITEM_INDEX then
		return
	end

	local function start()
		self.itemCnt = self.itemCnt or 0
		self.itemPos = index
	end

	local function callback()
		if not self:Check(index) then
			dump("not check")
			return
		end
		self.itemCnt = self.itemCnt + 1
		print("-----------------------> count = ", self.itemCnt)
		self:PlayAnime(index)
		self.fete:SetFeteCnt(index)
		self:SetItem(index)
		self:RefreshHintTxt()
	end

	local function endCallback()
		CommonResTopPlugin:NoAnimation()
		self.pointerHandler = PointType.LongPress
		self:SendMessage()
	end
	if not self.pointerEvent[index] then
		local event = self:LongPress(button, start, callback, endCallback)
		self.pointerEvent[index] = event
	end
end

function UISacrifice:SetItem(index)
	local itemObj = self:GetControl(string.format("item%d", index))
	local itemCtr = itemObj:GetController("type")
	local itemData = self.fete:GetItem(index)
	local cfg = _G.ItemManager:get_ui_info({itemData.prop[1], itemData.prop[2]})
	if not cfg then
		error("ERROR:not cfg!")
        return
	end
	self:SetItemCtrl(itemCtr, itemData, index)
	self:SetItemButtonHandle(itemObj, itemData, index)
	if itemData.unlock then
		self:SetItemLongPressHandle(itemObj, index)
	end
	itemObj:GetChild("icon").url = "art/"..cfg.icon
	itemObj:GetChild("item_numTxt").text = itemData.prop[3]
	itemObj:GetChild("consumeTxt").text = itemData.price[3]
	itemObj:GetChild("unlockTxt").text = itemData.price
end

function UISacrifice:SendMessage()
    if self.itemCnt == 0 then
        CommonResTopPlugin:RecoverAnimation()
        return
	end

    local req = {
        sacrifice_point = self.itemPos,
        sacrifice_count = self.itemCnt
	}
	dump(req, "req")
    Net.send("sacrifice", req, function(result)
        if result.e == 0 then
            if self.pointerHandler == PointType.Click then
                self.fete:SetFeteCnt(self.itemPos)
                if self.fete:GetFreeTimes() < 0 then
                    self:SetItem(self.itemPos)
                else
                    self:RefreshItems()
                end
            end
            --刷新建筑 title
			local isShow = self.fete:GetFreeTimes() > 0
			event.fire(EventKey.CITY_FETE_UPDATE, isShow)
        end
		CommonResTopPlugin:RecoverAnimation()
		self.pointerHandler = nil
        self.itemPos = nil
        self.itemCnt = 0
    end)
end

function UISacrifice:PlayAnime(index)
    local data = self.fete:GetItem(index)
    local resCnt = ItemManager:get_count_by_prop(data.prop)
    local resData = {
        list = {
            [1] = {
            id = index,
            change = {data.prop[3], 0},
            last = {resCnt + data.prop[3], 0}
			}
        }
	}
	ItemManager:on_resource_change(resData)

    if self.fete:GetFreeTimes() == 0 then
        local goldCnt = ItemManager:get_count_by_prop(data.price)
        local goldData = {
            list = {
                [1] = {
                    id = data.price[1],
                    change = - data.price[3],
                    last = goldCnt - data.price[3]
                },
                --args = "MASTER"
            }
		}
		ItemManager:on_coin_change(goldData)
    end
end

local PopType = {
	SpeedUp = 2,
	NoItem  = 4
}

function UISacrifice:NotEnoughNotity()
	local data = {}
	data.mode = PopType.NoItem
	data.content = lang("ITEM_NOT_ENOUGH")
	UIController:ShowUI("UICommonPop", data)
end

function UISacrifice:SpendGoldNotity(goldCnt, pos)
	local data = {}
	data.mode = PopType.SpeedUp
	data.content = lang("UI_CITYFETE_HINT", goldCnt)
	data.goldCount = goldCnt
	data.callback = function()
		self.itemCnt = 1
		self.itemPos = pos
		self.pointerHandler = PointType.Click
		self:SendMessage()
	end
	UIController:ShowUI("UICommonPop", data)
end

function UISacrifice:LongPress(button, startCallback, longPreeCallback, endCallback)
	local speed = 1
    local accSpend = 10
    local maxSpeed = 100
    local currTime = 0
    local interval = 3
    local OnLongPress =  function()
		speed = speed + accSpend
		if speed > maxSpeed then
			speed = maxSpeed
		end
		currTime = currTime + Time.deltaTime*speed
		if currTime >= interval then
			currTime = 0
			longPreeCallback()
		end
    end
    local OnStart = function()
		isLong = true
		startCallback()
    end

	local OnEnd = function()
		isLong = true
		speed = 1
		currTime = 0
		endCallback()
	end

    local gesture = LongPressGesture(button)
    gesture.once = false
    gesture.trigger = 1
    gesture.interval = 0.2
    gesture.onBegin:Add(OnStart)
    gesture.onEnd:Add(OnEnd)
	gesture.onAction:Add(OnLongPress)
	return gesture
end

function UISacrifice:OnFreeitemBtnClick()
	UIController:ShowUI("UISacrificeExchange")
end