local TopBannerPatch = {}

function TopBannerPatch:OnCloseBtnClick()
    self:Close()
end

function TopBannerPatch:OnBackBtnClick()
    self:Hide()
end

function TopBannerPatch:SetTitle(title)
    self.TopTitleTxt = self:GetControl("BuildIntertitle.TitleTxt")
    self.TopTitleTxt.text = title
end

return TopBannerPatch
