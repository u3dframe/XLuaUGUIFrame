local UIBuildPatch = {}

function UIBuildPatch:SetTopTitle()
    local title = self.BuildInterface:GetChild("")
    title.text = ""
end

function UIBuildPatch:SetBuildInfo(id)
    local build = _G.BuildManager:get_build_info_by_id(id)
    self:SetNameAndLv(build.name_, build.lv_)
    self:SetDesc(build.introduce_)
end

function UIBuildPatch:SetNameAndLv(name, lv)
    local txt = self:GetControl("BuildInterface.BuildTitle")
    txt.text = string.format("%s %s%d", name, _G.lang("UI_BASIC_LV"), lv)
end

function UIBuildPatch:SetDesc(introduceStr)
    local desc = self:GetControl("BuildInterface.BuildDescribe")
    desc.text = introduceStr
end

function UIBuildPatch:OnBackBtnClick()
    self:Hide()
end

function UIBuildPatch:OnCloseBtnClick()
    self:Close()
end

return UIBuildPatch
