--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIHeroList = _G.UIController:Get("UIHeroList")
UIHeroList.url = "ui://6g237b6v113zx1d"

_G.table.mixin(UIHeroList, require("FUI/Patch/TopBannerPatch"))

local HeroManager = _G.HeroManager
local MsgCenter = _G.MsgCenter
local lang = _G.lang

local indexer          = _G.Indexer.New()

local TabType = {
    ALL_TAB     = indexer(), --全部
    LEADER_TAB  = indexer(),--统帅
    SUPPORT_TAB = indexer(),--内政
    WIT_TAB     = indexer(), --智谋
}

function UIHeroList:Awake()
    self.tabIndex = self.args and self.args.heroTab or 1
end

function UIHeroList:InitVM()
    return {
        heroType = 0,
        heroDataList ={},-- self.heroList
    }
end

function UIHeroList:InitBinds()
    return {
        heroDataList = function(value)
            local list = self:GetControl("HeroList")
            --list:RemoveChildrenToPool()
            list.numItems = #value
        end,
        heroType = function(value)
            self.tabIndex = value + 1
            self:UpdateHeroList()
            self.vm.heroDataList = self.heroList
        end
    }
end

function UIHeroList:InitEvents()
    return {
    }
end

function UIHeroList:BindUI()
    
end

function UIHeroList:Start()

    if self.args.type == 1 then
        self:SetTitle("英雄列表")
        self:UpdateHeroList()
        self:InitHeroList()
        self.vm.heroDataList = self.heroList
        self.typeCtrler = self:GetController("LabelRadioGroup")
        local function TypeCtrlerChange()
            self:OnSelectTab(self.typeCtrler.selectedIndex + 1)
        end
        self.typeCtrler.onChanged:Add(TypeCtrlerChange)
    elseif self.args.type == 2 then
        self:InitLookFor()
    end
end

function UIHeroList:UpdateHeroList()
    local ty
    if self.tabIndex ~= TabType.ALL_TAB then
        ty = self.tabIndex - 1
    end
    self.heroList = HeroManager:get_sorted_hero_list(ty)
end
function UIHeroList:GetHeroStar(hero)
    local star = hero:get_star_lv()
    if(star > 5) then
        elog("英雄星级异常，传入的星级为--->"..tostring(hero.star_).."    为避免界面异常，更改为默认星级5" )
        return 5
    else
        return star
    end
end
function UIHeroList:InitHeroList()
    local list =  self:GetControl("HeroList")
    list.itemProvider = function(index)
        return "ui://6g237b6v113zx18"
    end

    list.itemRenderer = function(idx, obj)
        local hero = self.heroList[idx +1]
        obj:GetController("quality").selectedIndex = math.clamp(hero.quality_ -1, 0, 4)
        obj:GetController("star_level").selectedIndex = self:GetHeroStar(hero)
        obj:GetController("Catagorize").selectedIndex = hero.type_ - 1

        obj:GetChild("heroNameTxt").text = hero.name_
        obj:GetChild("IconLoader").url = "art/" .. hero.head_icon_

        local state  = obj:GetController("state")
        if hero.is_active_ then
            state.selectedIndex = 0
            obj:GetChild("levelTxt").text = lang("UI_HERO_LV2", hero.lv_)
            obj:GetController("dynamic_state").selectedIndex = (hero.state_ or 1) - 1
        elseif hero:enable_awake() then
            state.selectedIndex = 3
        else
            state.selectedIndex = 2
            local ProgressBar = obj:GetChild("ProgressBar")
            ProgressBar.value = hero:get_chip_num()
            ProgressBar.max = hero:get_prop().activate[3]
        end
    end

    local function ItemClick(context)
        local item     = context.data
        local childIdx = list:GetChildIndex(item)
        local heroIdx  = list:ChildIndexToItemIndex(childIdx) + 1
        local hero     = self.heroList[heroIdx]
        if hero.is_active_ then
            _G.UIController:ShowUI("UIHeroInfo", { heroList=self.heroList, heroIndex = heroIdx })
        elseif hero:enable_awake() then
            HeroManager:active_hero(hero.id_, function()
                self:UpdateHeroList()
                self.vm.heroDataList = self.heroList
                MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_HERO_ACTIVE_SUCCESS"))
            end)
        else
            MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_HERO_NOT_ACTIVE"))
        end
    end
    list.onClickItem:Add(ItemClick)
    list:SetVirtual()
end

local listType = 1
function UIHeroList:OnSelectTab(index)
    if listType == index then
        return
    end
    listType = index
    self.vm.heroType = index - 1
end




local LookForType = {
    NORMAL = 1,
    high = 2
}
local HeroType = {
    all = 1,--全部
    leader = 2,--统帅
    support = 3,--内政
    wit = 4,--智谋
}

function UIHeroList:InitLookFor()
    self.heroList = self:GetControl("HeroList")
    self.HandbookBtn = self:GetControl("HandbookBtn")
    self.HandbookBtn:GetChild("HandBookTxt").text = lang("UI_BASIC_CONFIRM")
    self.typeCtrler = self:GetController("LabelRadioGroup")
    self:SetTitle("寻访列表")
    self:InitLookForHeroList()
    self:GetLineNum()
    local function TypeCtrlerChange()
            self.activeTitleList = {}
            self.heroTitleList = {}
            self:GetHeroList()
            if #self.activeHeroList > 0 then
                for i = 1, self.lineNum do
                    table.insert(self.activeTitleList,0)
                    table.insert(self.heroTitleList,0)
                end
            else
                self.activeTitleList = {}
                self.heroTitleList = {}
            end
            local lineNum = self.lineNum - (#self.activeHeroList % self.lineNum)
            for i=1,lineNum do
                self:AddHeroList(nil,true)
            end
            self.heroList.numItems = #self.activeTitleList + #self.activeHeroList + #self.heroTitleList + #self.heroDataList
        end

    self.typeCtrler.onChanged:Add(TypeCtrlerChange)

    self.typeCtrler.selectedIndex = 0
    TypeCtrlerChange()

    self.SetBtn = self:GetControl("HandbookBtn")
    self.SetBtn.onClick:Add(function()
        if self.selectHeroId < 0 then
            MsgCenter.send_message(Msg.SHOW_HINT, "请先选中英雄")   
            return
        end
        RecruitManager:set_mark_target(self.args.selectType,self.selectHeroId)
        _G.UIController:CloseUI("UIHeroList")
    end)
    self.SetBtn.title = lang("UI_BASIC_CONFIRM")
end

function UIHeroList:InitLookForHeroList()

    local function ItemProvider(index)
        if index < #self.activeTitleList then
            return "ui://UIHeroList/title"
        elseif index < #self.activeTitleList + #self.activeHeroList then
            return "ui://UIHeroList/ComHeroCard"
        elseif index < #self.activeTitleList + #self.activeHeroList + #self.heroTitleList then
            return "ui://UIHeroList/title"
        end
        return "ui://UIHeroList/ComHeroCard"
    end

    local function ItemRenderer(index,obj)
        if index < #self.activeTitleList then
            obj:GetController("state").selectedIndex = 0
            return
        elseif index < #self.activeTitleList + #self.activeHeroList then
            return self:SetItem(index - #self.activeTitleList + 1,obj,true)
        elseif index < #self.activeTitleList + #self.activeHeroList + #self.heroTitleList then
            obj:GetController("state").selectedIndex = 1
            return
        end
        return self:SetItem(index - (#self.activeTitleList + #self.activeHeroList + #self.heroTitleList) + 1,obj,false)
    end
    self.selectHeroId = -1
    local function ListOnClick()
       self:SetSelectedHerId()
    end

    self.heroList.itemProvider = ItemProvider
    self.heroList.itemRenderer = ItemRenderer
    self.heroList.onClickItem:Add(ListOnClick)
    self.heroList:SetVirtual()
end

function UIHeroList:SetSelectedHerId()
    local item = self.heroList.touchItem
    if not item then
        return
    end
    local childIndex = self.heroList:GetChildIndex(item)
    local listIndex = self.heroList:ChildIndexToItemIndex(childIndex)
    --点中的是第一个title
    if listIndex < #self.activeTitleList then
        return
    elseif listIndex < #self.activeTitleList + #self.activeHeroList then--选中的是激活的
        local data = self.activeHeroList[listIndex - #self.activeTitleList + 1]
        if data.heroId < 0 then
            return
        end
        self.selectHeroId = data.heroId
    elseif listIndex < #self.activeTitleList + #self.activeHeroList + #self.heroTitleList then
        return
    else
        local data = self.heroDataList[listIndex - (#self.activeTitleList + #self.activeHeroList + #self.heroTitleList) + 1]
        if data.heroId < 0 then
            return
        end
        self.selectHeroId = data.heroId
    end
    self.heroList:RefreshVirtualList()
end

function UIHeroList:SetItem(index,obj,type)
    local activeNum = #self.activeHeroList
    local heroId
    if type then
        heroId = self.activeHeroList[index].heroId
    else
        heroId = self.heroDataList[index].heroId
    end
    if heroId < 0 then
        obj.visible = false
        return
    else
        obj.visible = true
    end
    local hero = HeroManager:get_config(heroId)
    obj:GetController("quality").selectedIndex = math.clamp(hero.quality -1, 0, 4)
    if heroId == self.selectHeroId then
        obj:GetController("state").selectedIndex = 5
    else
        obj:GetController("state").selectedIndex = 4
    end
    obj:GetController("Catagorize").selectedIndex = hero.type - 1
    obj:GetChild("heroNameTxt").text = hero.name
    obj:GetChild("IconLoader").url = "art/" .. hero.icon
    obj:GetChild("LookForRateTxt").text = string.format( lang("RECRUIT_RATE"), self.heroDataList[index].up)
end

function UIHeroList:GetHeroList()

    self.heroTypeList = {}

    local recruitBeanList = _G.Database.RecruitConfig.Re_selectData
    for key,value in pairs(recruitBeanList) do
        if value.type == self.args.selectType then
            table.insert( self.heroTypeList,value)
        end
    end

    self:SetHeroList()
end

--设置当前要显示的HeroList
function UIHeroList:SetHeroList()
    self.heroDataList = {}
    self.activeHeroList = {}
    local curType = self.typeCtrler.selectedIndex
    if curType == 0 then
        for key,value in pairs(self.heroTypeList) do
            self:AddHeroList(value,HeroManager:is_hero_active(value.heros))
        end
        self:SortList()
        return
    end
    self:AddTypeHerList(self.typeCtrler.selectedIndex)
    self:SortList()
end

function  UIHeroList:SortList()
    self:SortHeroList(self.heroDataList)
    self:SortHeroList(self.activeHeroList)
end

function UIHeroList:SortHeroList(myTable)
    table.sort( myTable,function(a,b)
        local dataA = HeroManager:get_config(a.heroId)
        local dataB = HeroManager:get_config(b.heroId)
        if dataA.quality == dataB.quality then
             return a.heroId > b.heroId
         end
         return dataA.quality > dataB.quality
     end)
end

function UIHeroList:AddTypeHerList(type)
    for _,value in pairs(self.heroTypeList) do
        local heroData = HeroManager:get_config(value.heros)
        if heroData then
            if heroData.type == type then
                self:AddHeroList(value,HeroManager:is_hero_active(value.heros))
            end
        end
    end
end

function UIHeroList:AddHeroList(value,activate)
    local data = {}
    if value == nil then
        data.heroId = -1
        data.up = 0
    else
        data.heroId = value.heros;
        data.up = value.up
    end
    if activate then
        table.insert( self.activeHeroList,data)
    else
        table.insert(self.heroDataList,data)
    end
end

function UIHeroList:GetLineNum()
    local item = _G.UIPackage.CreateObject("UIHeroList","ComHeroCard")
    local itemWidth = 243
    if not item then
        self.lineNum = 6
        return
    end
    itemWidth = item.width
    item:Dispose()
    self.lineNum = math.floor(self.heroList.width / itemWidth)
end
