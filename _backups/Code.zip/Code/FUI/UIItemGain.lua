--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIItemGain = _G.UIController:Get("UIItemGain")

function UIItemGain:InitBinds()
    return {
    }
end

function UIItemGain:InitVM()
    return {
    }
end

--FIXME:This is automatically generated
--FIXME:If no event to listen, Delete This function
function UIItemGain:InitEvents()
    self:AddEventListener(eventKey or eventKeys, function()

    end)
end

function UIItemGain:BindUI()
	self.gainTxt = self:GetControl("gainTxt")
	self.ItemList = self:GetControl("ItemList")
end

function UIItemGain:Start()

end

