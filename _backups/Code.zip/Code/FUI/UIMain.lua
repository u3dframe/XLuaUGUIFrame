local UIMain = _G.UIController:Get("UIMain")

local BasicConfig = _G.Database.BasicConfig
local MasterManager = _G.MasterManager
local BuildManager = _G.BuildManager
local EventKey = _G.EventKey
local event = _G.event
local UIController = _G.UIController
local lang = _G.lang
local Net = _G.Net
local config = _G.config
local UIUtil = _G.UIUtil
local TimerController = _G.EngineCore.GameController.TimerController
local Screen = _G.Screen
local SceneController = _G.SceneController

function UIMain:InitBinds()
    return {
        HeadProgressBar = function(value)
            self:GetControl("VitProgressBar").value = value
        end,
        MarchQueueList = function(var)
            --dump(var, "march queue list = ", 9)
            self.QueueList.numItems = #var
            local changeHeight = #var * (#var > 0 and self.QueueList:GetChildAt(0).height or 0)
            --dump(changeHeight, "changeHeight")
            self.QueueList.height = changeHeight
        end
    }
end

function UIMain:InitVM()
    return {
        HeadProgressBar = BasicConfig.BasicData.emergy_full[1],
        MarchQueueList = {}
    }
end

function UIMain:InitEvents()
    self:AddEventListener({_G.EventKey.ENERGY_REFRESH}, function()
        self.vm.HeadProgressBar = MasterManager:GetUserEnery()
    end)
    self:AddEventListener({_G.EventKey.CITY_OVER}, function()
        self:OnCityOver()
    end)
    self:AddEventListener({_G.EventKey.CITY_REFRESH_QUEUE}, function()
        self:RefreshQueue()
    end)
    self:AddEventListener({_G.EventKey.CITY_UP_LV_FINISHED}, function()
        self:RefreshQueue()
    end)
    self:AddEventListener({_G.EventKey.CITY_WORLD_MARCH_BAR}, function()
        self:RefreshWorldMarchBar()
    end)
    self:AddEventListener({_G.EventKey.CITY_WORLD_MARCH_END}, function()
        self:RefreshWorldMarchBar()
    end)
    --延迟派发消息
    _G.MessageQueueManager:Dispatch()
end

function UIMain:BindUI()
    self.ReturnCheckBtn = self:GetControl("ReturnCheckBtn")
    self.ReturnToTownBtn = self:GetControl("ReturnToTownBtn")
    self.SearchBtn = self:GetControl("SearchBtn")
    self.ReturnToTownTxt = self.ReturnToTownBtn:GetChild("TrackTxt")
    self.ReturnToTownArrow = self.ReturnToTownBtn:GetChild("TrackArrow")
    self.WorldAxisTxt = self.SearchBtn:GetChild("WorldAxisTxt")
    self.scene = self:GetController("scene")
    self.VitProgreeBar = self:GetControl("VitProgressBar")
    self.MarchQueue = self:GetControl("MarchQueue")
	self.QueueTitleTxt = self:GetControl("MarchQueue.QueueTitleTxt")
    self.QueueList = self:GetControl("MarchQueue.QueueList")
end

function UIMain:Awake()
    self.bar_timer_ = {}
    self.bar_ani_ = {}

    --self.QueueList:SetVirtual()
    self.QueueList.itemRenderer = function(idx, item)
        print("itemRenderer")
        --条目
        --item:SetActive(true)
        local data = _G.WorldManager:GetArmyInfo(idx + 1)
        dump(data, "queue march data", 9)
        local bar_btn = item:GetChild("ItemBtn")
        local btn = item:GetChild("SpeedupBtn")
        local name = item:GetChild("QueueListTitleTxt")
        local bar = item:GetChild("ProgressBar")
        local timer = item:GetChild("QueueTimeTxt")
        local icon = item:GetChild("IconLoader")
        local btn_txt = btn:GetChild("title")

        bar_btn.onClick:Set(function(context)
            if not data then
                return
            end
            self:on_click_army_info(context, data)
        end)
        btn.onClick:Set(function(context)
            if not data then
                return
            end
            self:on_click_army_info_btn(context, data)
        end)
        btn_txt.text = data:get_btn_desc()
        icon.url = "art/"..data:get_icon()
        name.text = data:get_bar_desc() --
        data.is_play_ = true

        local timerName = string.format("marchQueue%d", data.id_)
        TimerController:RemoveTimerEvent(timerName)
        -- 进度条
        local function call()
            bar.value = data:GetCostTime()

            local delta = data:GetLastTime()
            local formatTime = _G.UIUtil.format_time(delta)
            timer.text = formatTime
        end

        local function endCall()
            print("marchQueue className = "..timerName)
            TimerController:RemoveTimerEvent(timerName)
        end

        bar.min = 1;
        bar.max = data:GetAllTime()
        bar.value = data:GetCostTime()
        call()
        self:SetEngineTimer(timerName, call, endCall, data:GetLastTime(), 1, false)
    end
end

function UIMain:Start()
    -- self.n39   = self:GetControl("n39")
    -- self.n39:EnsureBoundsCorrect();
    -- UIManager.top_bar:set_window(self)
    --dump(self.n39)
    self:SwitchSceneState()
    self:InitUserInfo()
    self:RefreshQueue()
    self.ReturnToTownBtn.sortingOrder = 100
end

function UIMain:InitUserInfo()
    self.VitProgreeBar.max = BasicConfig.BasicData.emergy_full[1]
    self.vm.HeadProgressBar = MasterManager:GetUserEnery()
end

function UIMain:PlayQueueTimer(queueId)
    local timerSlider = self:GetControl(string.format("buildtime%dProgressBar", queueId))
    local timeTxt = timerSlider:GetChild("time")
    local buildId = BuildManager:get_build_id_by_queue_id(queueId)
    local build = BuildManager:get_build_info_by_id(buildId)
    local totalTime = build.total_time_
    local remaining = build.end_time_ - Net.server_time()

    timerSlider.min = 0
    timerSlider.max = totalTime
    timerSlider.value = timerSlider.max - remaining
    timeTxt.text = UIUtil.format_time(remaining)
    local function call()
        if not build.end_time_ then
            return
        end
        remaining = build.end_time_ - Net.server_time()
        timeTxt.text = UIUtil.format_time(remaining)
        timerSlider.value = timerSlider.max - remaining
    end

    local function endCall()
        timerSlider.visible = false
    end

    local className = string.format("build_queue_%d", queueId)
    self:SetEngineTimer(className, call, endCall, totalTime, 1, false)
end

function UIMain:StopTimer(queueId)
    local className = string.format("build_queue_%d", queueId)
    TimerController:RemoveTimerEvent(className)
end

function UIMain:RefreshQueue()
    for i = 1, config.BUILDING_QUEUE_MAX do
        local timerSlider = self:GetControl(string.format("buildtime%dProgressBar", i))
        local isUnlock = BuildManager:is_unlock_queue(i)
        if isUnlock then
            if BuildManager:is_busy_queue(i) then
                self:PlayQueueTimer(i)
                timerSlider.visible = true
            else
                self:StopTimer(i)
                timerSlider.visible = false
            end
        else
            self:StopTimer(i)
            timerSlider.visible = false
        end
    end
end

function UIMain:RefreshWorldMarchBar()
    --刷新列表数据（列表会自动刷新ui）
    local armyInfoList = _G.WorldManager:GetArmyInfoList()
    self.vm.MarchQueueList = armyInfoList
    --刷新当前空闲和行军的预览UI
    local curQueueNum = #armyInfoList
    self.QueueTitleTxt.text = lang("UI_MAIN_MARCH_QUEUE", curQueueNum, _G.WorldManager:get_army_num() - curQueueNum)
end

function UIMain:on_click_army_info(event, data)
    local func = function()
        local state = data:get_bar_state()
        print("state.."..state)
        if state == ArmyInfo.SPEED then
            MsgCenter.send_message(Msg.WORLD_JUMP_JOURNEY, data.id_)
        elseif state == ArmyInfo.RETURN then
            if self.world_x_ == data.finish_.x and
                data.finish_.z == self.world_z_ then
                    dump(data.finish_, "data.finish_..")
                    dump(self.world_x_, "self.world_x_..")
                    dump(self.world_z_, "self.world_z_..")
                return
            end
            SceneManager.World_Scene:goto_axis(data.finish_.x, data.finish_.z, true)
        end
    end
    if SceneManager.World_Scene.move_camera_ then
        StartCoroutine(function()
            MsgCenter.send_message(Msg.WORLD_CLEAR_JOURNEY_MENU)
            Yield()
            func()
        end)
    else
        func()
    end
end

local UIMarchSpeedUpMode = 0

function UIMain:on_click_army_info_btn(event, data)
    local state = data:get_bar_state()
    if state == ArmyInfo.SPEED then
        MsgCenter.send_message(Msg.WORLD_CLEAR_JOURNEY_MENU)
        UIController:ShowUI("UIMarchSpeedUp", {mode = UIMarchSpeedUpMode, data = data.id_})
        --UIManager.open_window("ItemJourneySpeedWindow", nil, data.id_)
    elseif state == ArmyInfo.RETURN then
        local msg_ = {}
        msg_.mode=0
        msg_.title = lang("UI_BASIC_HINT")
        msg_.content = lang("UI_FORT_06")
        --msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
        msg_.callback = function() 
           -- if index == 2 then
                local data1 = {}
                data1.id = data.finish_.id
                local obj = WorldManager:get_world_obj(data.finish_.x, data.finish_.z)
                local net_str = obj:get_cancel_msg()
                Net.send(net_str, data1, function(result)
                    if result.e == 0 then
                    end
                end)
          --  end
        end
        
       -- MsgCenter.send_message(Msg.SHOW_NOTIFY,msg_)
        _G.UIController:ShowUI('UICommonPop', msg_)
    end
end

--参数是临时的，大地图场景加入后需要移除
function UIMain:SwitchSceneState(forceWorld)
    if forceWorld then
        self.scene.selectedPage = "world"
        return
    end

    dump(SceneController.currentScene.sceneName, "SceneController.currentScene.sceneName")
    if SceneController.currentScene.sceneName == "SceneMain" then
        --切换controller “scene” 到city
        self.scene.selectedPage = "city"
    else
        --切换controller “scene” 到world
        self.scene.selectedPage = "world"
    end
end

function UIMain:OnReturnCheckBtnClick()
    self:EnterCity()
end

function UIMain:OnGoToWarCheckBtnClick()
    self:EnterWorld()
end

function UIMain:OnActivityBtnClick()
    MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_MAIN_UNOPEN"))
end

function UIMain:OnBuilderBtnClick()
    return {
    }
end

function UIMain:OnHeadBtnClick()
    return {
    }
end

function UIMain:OnHeroBtnClick()
    --type为1表示英雄列表，为2表示寻访列表
    UIController:ShowUI("UIHeroList",{type = 1})
end

function UIMain:OnBagBtnClick()
    UIController:ShowUI("UIItem")
end

function UIMain:OnLeagueBtnClick()
   --MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_MAIN_UNOPEN"))
end

function UIMain:OnMessageBtnClick()
    if _G.FairyGUI then
        _G.UIController:ShowUI("UIReport")
        return
    end
    UIManager.open_window("MailWindow")
end

function UIMain:OnMoreBtnClick()
    local msg_ = {}
    msg_.mode=0
    msg_.title = lang("UI_BASIC_HINT")
    msg_.content = lang("EXPEDITION_41")
   -- msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
    msg_.callback = function()
        --if index == 2 then
            self:Hide()
            StartCoroutine(function ()
                -- Yield(WaitForSeconds(1))
                GameManager:exit_to_clean()
            end)
      --  end
    end
   -- MsgCenter.send_message(Msg.SHOW_NOTIFY,msg_)
    _G.UIController:ShowUI('UICommonPop', msg_)
end

function UIMain:OnQuestBtnClick()
    MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_MAIN_UNOPEN"))
    self:EnterCity()
end

function UIMain:OnShopBtnClick()
    UIController:ShowUI("UIGameTool")
    -- MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_MAIN_UNOPEN"))
    -- self:EnterWorld()
end

function UIMain:OnSwitchBtnClick()
    self:EnterWorld()
end

function UIMain:OnVipBtnClick()
    MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_MAIN_UNOPEN"))
end

function UIMain:OnWelfareBtnClick()
    MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_MAIN_UNOPEN"))
end

function UIMain:OnSearchBtnClick()
    AudioManager.Play("SOUND_BUTTON_COMMON")
    UIManager.open_window("WorldAxisWindow", nil, self.world_x_ or 0, self.world_z_ or 0)
end

function UIMain:OnReturnToTownBtnClick()
    if not SceneManager.World_Scene then
        return
    end
    if SceneManager.World_Scene.move_camera_ then
        StartCoroutine(function()
            MsgCenter.send_message(Msg.WORLD_CLEAR_JOURNEY_MENU)
            Yield()
            SceneManager.World_Scene:goto_axis(WorldManager.main_logic_x_, WorldManager.main_logic_z_)
        end)
    else
        SceneManager.World_Scene:goto_axis(WorldManager.main_logic_x_, WorldManager.main_logic_z_)
    end
end

--暂时兼容老版本场景用这个名字
function UIMain:updata_track_position_ex()
    if not self.ReturnToTownBtn.visible then return end
    if not WorldManager.main_position_ then return end
    local halfWidth = Screen.width / 2
    local halfHeight = Screen.height / 2
    local world_pos = WorldManager.main_position_
    local pos_tmp = Camera.main:ScreenToWorldPoint(Vector3(halfWidth, halfHeight, 30/math.sin(math.rad(30))))
    local pos = Vector3(UIUtil.get_precise_decimal(pos_tmp.x, 2), 
        UIUtil.get_precise_decimal(pos_tmp.y, 2), UIUtil.get_precise_decimal(pos_tmp.z, 2))
    local a = Vector2(0, 1)
    local b = Vector2(world_pos.x - pos.x, world_pos.z - pos.z)
    local vec = math.floor(Vector2.SignedAngle(b.normalized, a.normalized))
    self.ReturnToTownArrow.rotation = vec
    local screen_width = halfWidth - 60
    local screen_hight = halfHeight - 100
    -- WORLD_CAMERA_ANGLE 这里计算了摄像机角度
    local vec_tmp = 1.732
    if math.abs(vec) > 90 then vec_tmp = -1.732 end
    local xx = math.tan(math.rad(vec)) * screen_hight * vec_tmp
    if xx > screen_width then xx = screen_width end
    if xx < -screen_width then xx = -screen_width end
    vec_tmp = 0.577
    if vec > 0 then vec_tmp = -0.577 end
    local zz = math.tan(math.rad(vec+90)) * screen_width * vec_tmp
    if zz > screen_hight then zz = screen_hight end
    if zz < -screen_hight then zz = -screen_hight end
    self.ReturnToTownBtn.xy = Vector2(xx + screen_width, screen_hight- zz)
end

--暂时兼容老版本场景用这个名字
function UIMain:set_axis_value(x, z)
    if not x then return end
    if not z then return end
    self.world_x_ = x
    self.world_z_ = z
    local value = string.format("(%d, %d)", x, z)
    if not value then
        self.WorldAxisTxt.text = ""
        return 
    end
    self.WorldAxisTxt.text = value
    -- 算坐标跟踪箭头
    if self:IsMainCityInScreen() then
        self.ReturnToTownBtn.visible = false
    else
        self.ReturnToTownBtn.visible = true
        local distance = math.floor(math.sqrt(math.pow(WorldManager.main_logic_x_ - x,2) + math.pow(WorldManager.main_logic_z_ - z,2)))
        self.ReturnToTownTxt.text = lang("UI_MONSTERINFO_DISTANE", distance)  
    end
end

function UIMain:IsMainCityInScreen()
    local x, z = WorldManager.main_logic_x_, WorldManager.main_logic_z_
    local build = WorldBuildTmp:get_build(x, z)
    if not build then
        local obj = WorldManager:get_world_obj(x, z)
        -- 如果未加载完成，切距离很近，则表示在屏幕内
        local distance = math.floor(math.sqrt(math.pow(x - self.world_x_,2) + math.pow(z - self.world_z_,2)))
        if distance < 10 then return true end
        return false 
    end
    local world_pos = build.transform.position
    local screen_pos = Camera.main:WorldToScreenPoint(world_pos)
    return screen_pos.x >= -50 and screen_pos.x <= (Screen.width + 50) and 
        screen_pos.y >= 70 and screen_pos.y <= Screen.height
end

function UIMain:EnterWorld()
    SceneController:EnterWorld()
end


function UIMain:EnterCity()
    SceneController:EnterCity()
end

function UIMain:OnCityOver()
    local cityWall = BuildManager:GetWall()
    if cityWall then
        cityWall:Reset()
    end
    event.fire(EventKey.UPDATE_CITY_WALL, true)

    --延迟打开弹窗
    self:SetCallbackTimer("CITY_OVER", function()
        local data = {}
        data.mode = 1
        data.content = lang("UI_CITYWALL_REBUILD_HINT")
        data.callback = function()
            Net.send("wall_city_rebuild", {}, function(result)
                if result.e == 0 then
                    print("wall_city_move is succeed!")
                    self:EnterWorld()
                    UIController:CloseUI("UICommonPop")
                    UIController:CloseUI("UIWall")
                end
            end)
        end
        UIController:ShowUI("UICommonPop", data)
    end, 0.3, true)
end