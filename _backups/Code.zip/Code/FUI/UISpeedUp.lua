local UISpeedUp = _G.UIController:Get("UISpeedUp")

local config = _G.config
local Net = _G.Net
local lang = _G.lang
local BuildManager = _G.BuildManager
local UIUtil = _G.UIUtil
local SoldierManager = _G.SoldierManager
local ItemManager = _G.ItemManager
local event = _G.event
local EventKey = _G.EventKey
local basic = _G.Database.BasicConfig.BasicData
local SPEEDUP_STATE = config.SPEEDUP_STATE
local SpeedUpState

local Can_OverFlow = 5 * 60  -- 5分钟以前的计时器可超出剩余时间
local MinGoldCount = 1
local Slider_MinCount = 1
local partial = _G.partial

local indexer = _G.Indexer.New()

--指定打开某种类型的加速窗口
local SpeedUpType = {
	UPGRAGE = indexer(-1),
	DRILL   = indexer(),
}

function UISpeedUp:BindUI()
	self.stateCtrler = self:GetController("state")

	self.titleTxt = self:GetControl("trainspeed")
	self.countDownTxt = self:GetControl("countdownTxt")
	self.speedupTxt = self:GetControl("TimeTxt")

	self.timerSlider = self:GetControl("ProgressBar")
	self.selectSlider = self:GetControl("progressslider")

	self.blueBtn = self:GetControl("blueBtn")
	self.yellowBtn = self:GetControl("yellowBtn")
	self.yellowBtnGoldTxt = self.yellowBtn:GetChild("CostTxt")

	self.itemList = self:GetControl("ItemList")
end

function UISpeedUp:Awake()
	self.type = self.args.type
	dump(self.type,"type is ")
	self.buildInfo = BuildManager:get_build_info_by_id(self.args.buildID)
	self.buildFreeTime = _G.AttrsManager:get_attrs_value_by_name("free_build_time")
	self.runInfo = self:GetRunInfo()
	self:InitializeList()
end

function UISpeedUp:InitBinds()
    return {
		title = function(value)
			self.titleTxt.text = value
		end,
		remainingTime = function(value)
			value = value < 0 and 0 or value
			local remaining = self:GetRemainingTime()
			self.countDownTxt.text = UIUtil.format_time(remaining)
			self.timerSlider.value = value
			if remaining - self:GetFreeTime() <= 0 then
				 self:Hide()
			end
			local state = SpeedUpState[self.speedupState]
			if state and state.goldCount then
				self.yellowBtnGoldTxt.text = state.goldCount()
			end
		end,
		items = function(value)
			if not next(value) then
				self.stateCtrler.selectedIndex = 1
				return
			end
			self.stateCtrler.selectedIndex = 0
			self.itemList.numItems = #value
		end,
		selected = function(index)
			local item = self.vm.items.value[index]
			self:SetSlider(item)
		end,
		selectCount = function(value)
			value = math.clamp(value, self.selectSlider.min, self.selectSlider.max)
			local item = self.vm.items.value[self.vm.selected.value]
			self.selectSlider.value = value
			self:SetTimerHint(item, value)
		end,
    }
end

function UISpeedUp:InitVM()
    return {
		title = "",
		remainingTime = 0,
		items = {},
		selected = 1,
		selectCount = 0
    }
end

function UISpeedUp:InitEvents()
	self:AddEventListener(EventKey.CITY_SOIDIER_FINISHED, function(arg)
		if self.buildInfo and self.buildInfo.id_ == arg.buildID then
			self:Close()
		end
	end)
	self:AddEventListener(EventKey.CITY_UP_LV_FINISHED, function(arg)
		if self.buildInfo and self.buildInfo.id_ == arg.buildID then
			self:Close()
		end
	end)
	self:AddEventListener(EventKey.CITY_SOLDIER_CURE_FINISHED, function()
		if self.buildInfo and self.buildInfo.build_type_ == config.BUILD_TYPE.HOSPITAL then
			self:Close()
		end
	end)
	self:AddEventListener(EventKey.CITY_BUILD_REMOVED_FINISHED, function(arg)
		if self.buildInfo and self.buildInfo.id_ == arg.buildID then
			self:Close()
		end
	end)
end

function UISpeedUp:Start()
	self:RefreshData()
end

function UISpeedUp:RefreshData()
	self.runInfo = self:GetRunInfo()
	local state = SpeedUpState[self.speedupState]
	if state and state.title then
		self.vm.title = state.title
	end
	self:PlayTimer(self.runInfo)
	local itemsAll = self:GetItems()
	self.vm.selected = self:GetRecommendIdx(itemsAll)
	self.vm.items = itemsAll
	self.vm.selected = self.vm.selected.value
	self.selectSlider.onChanged:Add(function(context)
		self.vm.selectCount = context.sender.value
	end)
end

function UISpeedUp:GetGoldCount()
	local state = SpeedUpState[self.speedupState]
	if state and state.goldCount then
		return state.goldCount()
	end
	return MinGoldCount
end

local SelectType = {
	Unselect = indexer(-1),
	Select = indexer()
}

function UISpeedUp:InitializeList()
	local itemData
	self.itemList.itemRenderer = function(idx, obj)
		itemData =  self.vm.items.value[idx + 1]
		obj:GetController("quality").selectedIndex = math.clamp(itemData.prop_.quality, 0,5)
		obj:GetController("state").selectedIndex = itemData.prop_.label and 3 or 0
		obj:GetChild("5minute").text = itemData.prop_.label or ""
		obj:GetChild("iconloader").url = string.format("art/%s", itemData.prop_.icon)
		obj:GetChild("18Txt").text = itemData.count_
		obj:GetChild("ItemNameTxt").text = itemData.prop_.name
		if idx + 1 == self.vm.selected.value then
			obj:GetController("select").selectedIndex = SelectType.Select
			self.itemList:ScrollToView(idx)
		else
			obj:GetController("select").selectedIndex = SelectType.Unselect
		end
	end

	local function ItemClick(EventContext)
		local currItemObj = EventContext.data
		local index = self.itemList:GetChildIndex(currItemObj)
		local lastItemObj = self.itemList:GetChildAt(self.vm.selected.value - 1)
		if lastItemObj then
			lastItemObj:GetController("select").selectedIndex = SelectType.Unselect
		end
		currItemObj:GetController("select").selectedIndex = SelectType.Select
		self.itemList:ScrollToView(index)
		self.vm.selected = index + 1
	end

	self.itemList.onClickItem:Add(ItemClick)
end

function UISpeedUp:SetSlider(item)
	if not item then
		return
	end

	local max, min
	local remainingTime = self:GetRemainingTime()
	local freeTime = self:GetFreeTime()
	local time = item:get_prop_expedite().time / 1000
	if time <= Can_OverFlow then
		max = math.ceil((remainingTime - freeTime) / time)
	else
		max = math.floor((remainingTime - freeTime) / time)
	end
	max = math.clamp(max, 1, item.count_)
	min = max == 1 and 0 or Slider_MinCount

	self.selectSlider.max = max
	self.selectSlider.min = min
	self.vm.selectCount = max
end

function UISpeedUp:SetTimerHint(item, count)
	if not item then
		self.speedupTxt.text = ""
		return
	end
	local time = item:get_prop_expedite().time / 1000
	local freeTime = ""
	if self:GetFreeTime() > 0 then
		freeTime = lang("UI_SPEEDUP_FREE_TIME", self:GetFreeTime() / 60)
	end
	local str = lang("UI_SPEEDUP_SUB_TIME", UIUtil.format_time(count * time))
	self.speedupTxt.text = str.."  "..freeTime
end

function UISpeedUp:GetRemainingTime()
	if not self.runInfo then
		return 0
	end

	local time = self.runInfo.endTime - Net.server_time()
	time = time < 0 and 0 or time
	return time
end

function UISpeedUp:PlayTimer(runInfo)
	if not runInfo then
		return
	end
	self.timerSlider.min = 0
	self.timerSlider.max = self.runInfo.totalTime
	self.vm.remainingTime = Net.server_time() + self.runInfo.dec - self.runInfo.startTime
	local function call()
		self.vm.remainingTime = Net.server_time() + self.runInfo.dec - self.runInfo.startTime
	end

	local function endCall()
		self:Hide()
	end

	self:SetEngineTimer("city_speedup", call, endCall, self.runInfo.endTime - Net.server_time(), 1, false)
end

function UISpeedUp:GetFreeTime()
	if self.speedupItemType == config.SPEEDUP_ITEM.UP then
		return self.buildFreeTime
	end
	return 0
end

function UISpeedUp:GetItems()
	return ItemManager:GetSpeedupItems(self.speedupItemType, true)
end

function UISpeedUp:FindBestItem(items)
	if not items then
		return
	end

	local lessItem, beyondItem, time
	local remainingTime = self:GetRemainingTime()
	for _, v in ipairs(items) do
		local itemTime = v:get_prop_expedite().time / 1000
		if itemTime <= remainingTime then
			if not lessItem then
				lessItem = v.id_
			end
		else
			beyondItem = v.id_
			time = itemTime
		end
	end
	--道具有可能小于倒计时，或者大于倒计时。
	--lessItem    小于倒计时 的最佳选择
	--beyondItem  大于倒计时 的最佳选择
	--time        道具时间(大于倒计时时候的时间)
	return lessItem, beyondItem, time
end

function UISpeedUp:SetPriority(specialItems, commonItems)
	local aItemId, bItemId, time1 = self:FindBestItem(specialItems)
	local x, y, time2 = self:FindBestItem(commonItems)
	--优先选择单个道具时间小于 计时器剩余时间的
	local itemID = aItemId or x
	if itemID then
		return itemID
	end

	--如果道具时间大于 计时器剩余时间. 优先选择时间接近剩余时间的，其次再选择专用道具
	if bItemId and y then
		return time1 <= time2 and bItemId or y
	end

	return bItemId or y
end

function UISpeedUp:GetRecommendIdx(itemsAll)
	local specialItems, commonItems = {}, {}
	for _, v in ipairs(itemsAll) do
		if v:get_prop_expedite().type == config.SPEEDUP_ITEM.COMMON then
			table.insert(commonItems, v)
		else
			table.insert(specialItems, v)
		end
	end

	local itemId = self:SetPriority(specialItems, commonItems)
	for idx , v in ipairs(itemsAll) do
		if v.id_ == itemId then
			return idx
		end
	end
	return 1
end

function UISpeedUp:GetRunInfo()
	--对特殊情况处理 如果有type则可以指定界面的加速类型 (兵营同一时刻，可以升级、训练)
	if self.type == SpeedUpType.UPGRAGE then
		if not self.buildInfo:is_lvup() then
			return
		end
		self.speedupItemType = config.SPEEDUP_ITEM.UP --道具使用类型
		self.speedupState = SPEEDUP_STATE.UPGRAGE    --当前加速类型
		return self:GetTimeInfo(self.buildInfo)
	end

	if self.type == SpeedUpType.DRILL then
		if not self.buildInfo:is_trainning() then
			return
		end
		local _, _, soldierID = SoldierManager:check_soldier_state(self.buildInfo.build_type_)
		self.soldier = SoldierManager:get_soldier_info_by_id(soldierID)
		self.speedupItemType = config.SPEEDUP_ITEM.DIRLL
		self.speedupState = SPEEDUP_STATE.DRILL
		return self:GetTimeInfo(self.soldier)
	end

	--没有type参数，则根据建筑状态识别界面加速类型

	if self.buildInfo:is_trainning() then
		local _, _, soldierID, soldierClass = SoldierManager:check_soldier_state(self.buildInfo.build_type_)
		local soldier = SoldierManager:get_soldier_info_by_id(soldierID, soldierClass)
		self.soldier = soldier
		self.soldierClass = soldierClass
		if soldier.class_ == config.SOLDIER_CLASS.TRAP then
			self.speedupItemType = config.SPEEDUP_ITEM.TARP
			self.speedupState = SPEEDUP_STATE.TRAP
		else
			self.speedupItemType = config.SPEEDUP_ITEM.DIRLL
			self.speedupState = SPEEDUP_STATE.DRILL
		end
		return self:GetTimeInfo(soldier)
	end

	if self.buildInfo:is_lvup() then
		self.speedupItemType = config.SPEEDUP_ITEM.UP
		self.speedupState = SPEEDUP_STATE.UPGRAGE
		return self:GetTimeInfo(self.buildInfo)
	end

	if self.buildInfo:is_removing() then
		self.speedupItemType = config.SPEEDUP_ITEM.UP
		self.speedupState = SPEEDUP_STATE.DISMANTLE
		return self:GetTimeInfo(self.buildInfo)
	end

	if self.buildInfo:is_curing() then
		local cure = self.buildInfo.cure_timer_
		self.speedupItemType = config.SPEEDUP_ITEM.CURE
		self.speedupState = SPEEDUP_STATE.CURE
		return self:GetTimeInfo(cure)
	end
end

function UISpeedUp:GetTimeInfo(data)
	if not data.start_time_ or not data.end_time_ or not data.total_time_ then
		error("time info is nil！！")
		return
	end
	local t = {}
	t.startTime = data.start_time_
	t.endTime = data.end_time_
	t.totalTime = data.total_time_
	t.dec = data.dec
	return t
end

function UISpeedUp:OnbuttonBtnClick()
	--获取途径按钮 未开发
end

local PopMode = {
	Normal = indexer(-1),
	SpeedUp = indexer(1),
}

function UISpeedUp:SendMessageToServer(reqMsg)
	local state = SpeedUpState[self.speedupState]
	if state and state.callback then
		state.callback(reqMsg)
	end
end

function UISpeedUp:OnblueBtnClick()
	if self.vm.selectCount.value <= 0 then
		return
	end

	local item = self.vm.items.value[self.vm.selected.value]
	local reqMsg = {}
	reqMsg.id = self.buildInfo.id_
	reqMsg.itemid = item.id_
	reqMsg.itemcnt = self.vm.selectCount.value

	local itemTime = item:get_prop_expedite().time / 1000 * self.vm.selectCount.value
	if itemTime <= self:GetRemainingTime() then
		self:SendMessageToServer(reqMsg)
		return
	end

	local data = {}
	data.mode = PopMode.Normal
	data.content = lang("UI_SPEEDUP_HINT3")
	data.callback = function()
		self:SendMessageToServer(reqMsg)
	end
	_G.UIController:ShowUI("UICommonPop", data)
end

function UISpeedUp:OnyellowBtnClick()
	local reqMsg = {
		id = self.buildInfo.id_
	}
	local data = {}
	data.mode = PopMode.SpeedUp
	data.content = lang("UI_SPEEDUP_HINT2")
	data.goldCount = self:GetGoldCount()
	data.callback = function()
		self:SendMessageToServer(reqMsg)
	end
	_G.UIController:ShowUI("UICommonPop", data)
end

function UISpeedUp:OnminusBtnClick()
	local count = self.vm.selectCount.value
	if count <= 1 then
		return
	end
	self.vm.selectCount = count - 1
end

function UISpeedUp:OnRoundAddBtnClick()
	local count = self.vm.selectCount.value
	if count >= self.selectSlider.max then
		return
	end
	self.vm.selectCount = count + 1
end

function UISpeedUp:OnCloseBtnClick()
	self:Hide()
end

function UISpeedUp:SetGoldNum(num)
	if not num then
		return 1
	end
	local integerNum = math.floor(num + 0.5)
	if integerNum <= 0 then
		integerNum = 1
	end
	return integerNum
end

function UISpeedUp:GetBuildingGold()
	local number = basic.build_gold1 * self:GetRemainingTime() ^ basic.build_gold2 - basic.build_gold3
	return self:SetGoldNum(number)
end

function UISpeedUp:GetDrillSoildierGold()
	local number = basic.train_gold1 * self:GetRemainingTime() ^ basic.train_gold2 - basic.train_gold3
	return self:SetGoldNum(number)
end

function UISpeedUp:GetSoldierCureGold()
	local time = self:GetRemainingTime()
	local number = SoldierManager:get_glod_hurts_recover(time)
	return self:SetGoldNum(number)
end

--道具加速

function UISpeedUp:OnLvUpSpeedupHandler(reqMsg)
	Net.send("build_levelup_dectime", reqMsg, function(result)
		if result.e == 3 then
			self:Hide()
		elseif result.e == 0 then
			MsgCenter.send_message(Msg.CITY_UP_LV_UPDATE, self.buildInfo.id_)
			self:RefreshData()
		end
	end)
end

function UISpeedUp:OnDismantleSpeedupHandler(reqMsg)
	Net.send("build_levelup_dectime", reqMsg, function(result)
		--Net.send("build_dismantle_dectime", req_msg, function(result)
		if result.e == 0 then
			MsgCenter.send_message(Msg.CITY_UP_LV_UPDATE, self.buildInfo.id_)
			self:RefreshData()
		elseif result.e == 3 then
			self:Hide()
		end
	end)
end

function UISpeedUp:OnDrillSpeedupHandler(reqMsg)
	Net.send("build_soldier_dectime", reqMsg, function(result)
		if result.e == 3 then
			self:Hide()
		elseif result.e == 0 then
			event.fire(EventKey.CITY_SOIDIER_UPDATE, {buildID = self.buildInfo.id_, soldierID = self.soldier.id_})
			self:RefreshData()
		end
	end)
end

function UISpeedUp:OnTrapSpeedupHandler(reqMsg)
	local data = {
		buildID = self.buildInfo.id_,
		soldierID = self.soldier.id_,
		soldierClass = self.soldierClass
	}
	SoldierManager:ItemSpeedUp(self.buildInfo.id_, self.soldier.id_, reqMsg.itemid, reqMsg.itemcnt, self.soldierClass, function()
		event.fire(EventKey.CITY_SOIDIER_UPDATE, data)
		self:RefreshData()
	end)
end

function UISpeedUp:OnCureSpeedupHandler(reqMsg)
	Net.send("soldier_cure_dectime", reqMsg, function(result)
		if result.e == 3 then
			self:Hide()
		elseif result.e == 0 then
			MsgCenter.send_message(Msg.CITY_SOLDIER_CURE_UPDATE, self.buildInfo.build_type_)
			self:RefreshData()
		end
	end)
end

SpeedUpState = {
	[SPEEDUP_STATE.UPGRAGE] = {
		title = lang("UI_BUILD_UPGRADE"),
		goldCount = partial(UISpeedUp.GetBuildingGold, UISpeedUp),
		callback = partial(UISpeedUp.OnLvUpSpeedupHandler, UISpeedUp)
	},
	[SPEEDUP_STATE.DISMANTLE] = {
		title = lang("UI_SPEEDUP_BUILDING_DISMANTLE"),
		goldCount = partial(UISpeedUp.GetBuildingGold, UISpeedUp),
		callback =  partial(UISpeedUp.OnDismantleSpeedupHandler, UISpeedUp)
	},
	[SPEEDUP_STATE.DRILL] = {
		title = lang("UI_SOLDIER_IN_ARMY_TRAINING"),
		goldCount = partial(UISpeedUp.GetDrillSoildierGold, UISpeedUp),
		callback = partial(UISpeedUp.OnDrillSpeedupHandler, UISpeedUp)
	},
	[SPEEDUP_STATE.CURE] = {
		title = lang("UI_SPEEDUP_CURING"),
		goldCount = partial(UISpeedUp.GetSoldierCureGold, UISpeedUp),
		callback = partial(UISpeedUp.OnCureSpeedupHandler, UISpeedUp)
	},
	[SPEEDUP_STATE.TRAP] = {
		title = lang("UI_SPEED_TRAPING"),
		goldCount = partial(UISpeedUp.GetDrillSoildierGold, UISpeedUp),
		callback = partial(UISpeedUp.OnTrapSpeedupHandler, UISpeedUp)
	}
	-- ...扩展
}