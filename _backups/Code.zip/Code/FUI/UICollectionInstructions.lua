--This is an automatically generated class by FairyGUI. Please do not modify it.

local UICollectionInstructions = _G.UIController:Get("UICollectionInstructions")

local lang = _G.lang
local RespointConfig = _G.Database.RespointConfig

function UICollectionInstructions:BindUI()
	self.OccupyTxt = self:GetControl("OccupyTxt")
	self.OccupyIconLoader = self:GetControl("OccupyIconLoader")
	self.OccupyTitleTxt = self:GetControl("OccupyTitleTxt")
	self.SeizeTxt = self:GetControl("SeizeTxt")
	self.SeizeIconLoader = self:GetControl("SeizeIconLoader")
	self.SeizeTitleTxt = self:GetControl("SeizeTitleTxt")
end

function UICollectionInstructions:Start()
    local obj = self.args.obj
    local prop = RespointConfig.RespointData[obj.id_]
    self.OccupyTitleTxt.text = lang("UI_COLLECT_OCCUPY_"..prop.type)
    self.OccupyTxt.text = lang("UI_COLLECT_OCCUPY_DETAILS_"..prop.type)
    self.OccupyIconLoader.url = "art"..string.sub(prop.model, 8)
    self.SeizeTitleTxt.text = lang("UI_COLLECT_TOROB_"..prop.type)
    self.SeizeTxt.text = lang("UI_COLLECT_TOROB_DETAILS_"..prop.type)
    self.SeizeIconLoader.url = "art"..string.sub(prop.model, 8)
end

--FIXME:Write logic Code here!

function UICollectionInstructions:OnCloseBtnClick()
    self:Hide()
end

