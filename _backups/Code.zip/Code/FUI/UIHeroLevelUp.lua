--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIHeroLevelUp = _G.UIController:Get("UIHeroLevelUp")

local UIUtil = _G.UIUtil
local HeroManager = _G.HeroManager
local SkillManager = _G.SkillManager
local ItemManager = _G.ItemManager

local Mode = {
	Hero = 1,
	Skill = 2,
}

function UIHeroLevelUp:Awake()
	self.mode = self.args.mode or Mode.Hero
	self.hero = self.args.hero
	local itemInfo
	if self.mode == Mode.Hero then
		itemInfo = _G.Database.BasicConfig.BasicData.hero_items
	elseif self.mode == Mode.Skill then
		self.skill = self.hero.skills_[self.args.pos]
		itemInfo = _G.Database.BasicConfig.BasicData.hero_skill_items
	end
	self.itemInfo = {}
	for i, info in ipairs(itemInfo) do
		local cnt = ItemManager:get_count(_G.config.ITEM_ITEM, info[1])
		self.itemInfo[i] = {info[2], cnt, info[1]}
	end
	self.slider.min = self.args.minLv
	self.slider.max = self.args.maxLv
	if self.slider.min == self.slider.max then
		self.slider.min = self.slider.min - 1
		self.slider.touchable = false
	end
	self.slider.onChanged:Set(function(context)
		self.vm.level = context.sender.value
	end)
	self.itemCntTxt = {}
	self.use = {}
	self:InitItemList()
end

function UIHeroLevelUp:OnDestroy()
	self.itemInfo = nil
	self.itemCntTxt = nil
	self.use = nil
end

function UIHeroLevelUp:InitBinds()
    return {
		level = function(value)
			if value < 0 then return end
			local lv, name, totalExp
			if self.mode == Mode.Hero then
				lv = self.hero.lv_
				name = self.hero.name_
				totalExp = self.hero:GetTotalExpToLevel(value)
			elseif self.mode == Mode.Skill then
				lv = self.skill.level
				name = SkillManager:get_config(self.skill.skillid).name
				totalExp = SkillManager:CalcTotalExpToLevel(self.skill, value)
			end
			self.title.text = value - lv
			self.HintText.text = lang("UI_HERO_HINT_LVUP", name, value)
			local _, use = UIUtil.CalcExpItem(totalExp, self.itemInfo)
			self.use = use
			for i, txt in pairs(self.itemCntTxt) do
				txt.text = use[i] or 0
			end
		end
    }
end

function UIHeroLevelUp:InitVM()
    return {
		level = -1,
    }
end

function UIHeroLevelUp:BindUI()
	self.HintText = self:GetControl("HintText")
	self.ItemList = self:GetControl("ItemList")
	self.slider = self:GetControl("slider")
	self.title = self:GetControl("title")
end

function UIHeroLevelUp:Start()
	self.ItemList.numItems = #self.itemInfo
	self.vm.level = self.slider.max
	self.slider.value = self.slider.max
end

function UIHeroLevelUp:InitItemList()
	self.ItemList.itemProvider = function()
		return "ui://UIHeroLevelUp/ComMaterial"
	end
	self.ItemList.itemRenderer = function(idx, obj)
		local index = idx + 1
		local itemInfo = self.itemInfo[index]
		local itemCfg = ItemManager:get_config(itemInfo[3])
		obj:GetChild("iconloader").url = string.format("art/%s", itemCfg.icon)
		obj:GetController("quality").selectedIndex = itemCfg.quality - 1
		obj:GetChild("propname").text = itemCfg.name
		obj:GetController("state").selectedIndex = itemInfo[2] > 0 and 1 or 0
		self.itemCntTxt[index] = obj:GetChild("leveltext")
	end
end

function UIHeroLevelUp:OnCloseBtnClick()
	self:Hide()
end

function UIHeroLevelUp:OnSureBtnClick()
	if not self.use then return end
	local items = {}
	for i, cnt in pairs(self.use) do
		table.insert(items, {self.itemInfo[i][3], cnt})
	end
	if self.mode == Mode.Hero then
		HeroManager:HeroLevelUp(self.hero.id_, items)
	elseif self.mode == Mode.Skill then
		SkillManager:levelup_skill(self.hero.id_, self.args.pos, self.skill.skillid, items)
	end
	self:Hide()
end

function UIHeroLevelUp:OnCancelBtnClick()
	self:Hide()
end

function UIHeroLevelUp:OnAddBtnClick()
	if self.slider.value >= self.args.maxLv then return end
	self.slider.value = self.slider.value + 1
	self.vm.level = self.slider.value
end

function UIHeroLevelUp:OnMinusBtnClick()
	if self.slider.value <= self.args.minLv then return end
	self.slider.value = self.slider.value - 1
	self.vm.level = self.slider.value
end
