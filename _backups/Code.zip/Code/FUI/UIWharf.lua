--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIWharf = _G.UIController:Get("UIWharf")

local lang = _G.lang
local Net = _G.Net

function UIWharf:Awake()
    self.titleTxt.text = lang("UI_CITY_RECEIVE_AWARD")
    self.wharf = _G.BuildManager:GetWharfInfo()
end

function UIWharf:BindUI()
    self.titleTxt = self:GetControl("TitleTxt")
	self.comItem = self:GetControl("ComItem")
	self.itemNameTxt = self:GetControl("ItemNameTxt")
    self.itemDescTxt = self:GetControl("ItemDescTxt")
    self.bgImg = self:GetControl("black_bg")
end

function UIWharf:Start()
    self.bgImg.onClick:Set(function()
        self:Hide()
    end)

    self:SetItem()
end

function UIWharf:SetItem()
    local prop = self.wharf:GetReward()
    local cfg = _G.ItemManager:get_ui_info({prop[1], prop[2]})
    if not cfg then
        return
    end

    self.comItem:GetController("quality").selectedIndex = _G.math.clamp(cfg.quality, 0,5)
    self.comItem:GetChild("iconloader").url = string.format("art/%s", cfg.icon)
    self.comItem:GetChild("18Txt").text = prop[3]
    self.itemNameTxt.text = cfg.name
    self.itemDescTxt.text = cfg.desc
end

function UIWharf:OnConfirmBtnClick()
    local itemData = self.wharf:GetReward()
    Net.send("wharf_get_reward", {}, function(result)
        if result.e == 0 then
            _G.UIManager.open_window("ItemGainRewardWindow", nil, nil, {itemData})
            self:Hide()
        end
    end)
end
