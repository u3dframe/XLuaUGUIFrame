--This is an automatically generated class by FairyGUI. Please do not modify it.

local UISkillAutoBreak = _G.UIController:Get("UISkillAutoBreak")

function UISkillAutoBreak:Awake()
end

function UISkillAutoBreak:InitBinds()
    return {
    }
end

function UISkillAutoBreak:InitVM()
    return {
    }
end

function UISkillAutoBreak:BindUI()
	self.ContainBtn = self:GetControl("ContainBtn")
end

function UISkillAutoBreak:Start()

end

--FIXME:Write logic Code here!

function UISkillAutoBreak:OnConfirmBtnClick()
    _G.SkillManager:onekey_resolve_skill(self.args.type, self.ContainBtn.selected)
    self:Hide()
end

function UISkillAutoBreak:OnCancelBtnClick()
    self:Hide()
end

