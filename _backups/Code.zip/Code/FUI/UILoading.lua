--This is an automatically generated class by FairyGUI. Please do not modify it.

local UILoading = _G.UIController:Get("UILoading")
UILoading.url = "ui://3i4tg8vmwyrzh"

function UILoading:InitBinds()
    return {
        progress = function(value)
            self.ProgressBar.value = value
        end
    }
end

function UILoading:InitVM()
    return {
        progress = 1;
    }
end

function UILoading:BindUI()
    self.ProgressBar = self:GetControl("ProgressBar")
    self.FadeOutGAnim = self:GetTransition("FadeOut")
end

function UILoading:Awake()
    self.ProgressBar.min = 1
    self.ProgressBar.max = 100
end

function UILoading:Start()
    self.mainCom.sortingOrder = 1000
    --假進度，臨時方案
    self.fakeTween = _G.GameTween.To(function(v)
        self:UpdateProcess(v)
    end, 0, 100, 5):SetEase(_G.XEase.Linear)
    --end
end

function UILoading:UpdateProcess(value)
    self.vm.progress = value;
end

function UILoading:FadeOut()
    self.fakeTween:Kill(false)
    if not self:IsLoaded() then
        self:Close()
        return
    end
    self:UpdateProcess(100)
    self.FadeOutGAnim:Play(1, 0.5, function()
        if self:IsLoaded() then
            self:Close()
        end
    end)
end