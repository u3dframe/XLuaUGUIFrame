--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIReport = _G.UIController:Get("UIReport")

_G.table.mixin(UIReport, require("FUI/Patch/TopBannerPatch"))

local lang = _G.lang
local config = _G.config
local UIUtil = _G.UIUtil
local HeroConfig = _G.Database.HeroConfig
local ItemConfig = _G.Database.ItemConfig
local SoldierConfig = _G.Database.SoldierConfig
local MonsterConfig = _G.Database.MonsterConfig
local RespointConfig = _G.Database.RespointConfig
local FortifiedConfig = _G.Database.FortifiedConfig
local MailManager = _G.MailManager
local WorldManager = _G.WorldManager
local HeroManager = _G.HeroManager
local ItemManager = _G.ItemManager

function UIReport:Awake()
	self:SetTitle("信息")
	self.args = self.args or {}
	self:InitReportList()
	self:InitDetectInfoList()
	self:InitDetectSoldierList()
	self:InitResItemList()
end

local selectedReportIDCache = {
	[config.MAIL_MODULE_TYPES.COMMON] = {
		[config.MAIL_TYPES[config.MAIL_MODULE_TYPES.COMMON].SYSTEM] = "",
		[config.MAIL_TYPES[config.MAIL_MODULE_TYPES.COMMON].ACTIVITY] = "",
		[config.MAIL_TYPES[config.MAIL_MODULE_TYPES.COMMON].ALLIANCE] = "",
	},
	[config.MAIL_MODULE_TYPES.REPORT] = {
		[config.MAIL_TYPES[config.MAIL_MODULE_TYPES.REPORT].BATTLE] = "",
		[config.MAIL_TYPES[config.MAIL_MODULE_TYPES.REPORT].RESOURCE] = "",
		[config.MAIL_TYPES[config.MAIL_MODULE_TYPES.REPORT].WILD_BATTLE] = "",
	},
}

local function ResetSelectedReportIDCache()
	for _, v in pairs(selectedReportIDCache) do
		for k, _ in pairs(v) do
			v[k] = ""
		end
	end
end

function UIReport:InitBinds()
    return {
		reports = function(value)
			local mv = self.vm.moduleType.value
			local rv = self.vm.reportType.value
			if mv == "" or rv == -1 then return end
			local selectedID = selectedReportIDCache[mv][rv]
			local selectedIndex = -1
			for i, v in ipairs(value) do
				if v.id_ == selectedID then
					selectedIndex = i
					break
				end
			end
			self.ComReportDetailList.numItems = #value
			self.ReportCtrler.selectedIndex = #value == 0 and 0 or 1
			self.TypeListNoReportCtrler.selectedIndex = #value == 0 and 0 or 1
			if mv == config.MAIL_MODULE_TYPES.REPORT and 
			rv == config.MAIL_TYPES[config.MAIL_MODULE_TYPES.REPORT].BATTLE then
				if MailManager:get_mails_count(mv, rv) > 0 then
					self.ReportCtrler.selectedIndex = 1
					self.TypeListNoReportCtrler.selectedIndex = 1
				end
			end
			if selectedIndex < 0 then
				if selectedID == "" and #value > 0 then	--默认选中第一个
					selectedIndex = 1
					selectedID = value[1].id_
					selectedReportIDCache[mv][rv] = selectedID
				else
					selectedID = ""
				end
			end
			self.vm.selectedReportIndex = selectedIndex
			self.vm.selectedReportID = selectedID
		end,
		reportType = function(value)
			if value < 0 then return end
			self.vm.reports = MailManager:get_sorted_mail_list_by_type(self.vm.moduleType.value, value, self.subType)
		end,
		subType = function(value)
			self:ConvertSubType(value)
			if value < 0 then return end
			self.vm.reports = MailManager:get_sorted_mail_list_by_type(self.vm.moduleType.value, self.vm.reportType.value, self.subType)
		end,
		selectedReportID = function(value)
			if value == "" then
				self.showframeCtrler.selectedIndex = 0
				return
			end
			self:ShowDetail()
		end,
		selectedReportIndex = function(value)
			if value < 0 then return end
			if self.selectedReportIndex and self.selectedReportIndex > 0 and self.selectedReportIndex <= self.ComReportDetailList.numItems then
				local obj = self.ComReportDetailList:GetChildAt(self.selectedReportIndex - 1)
				obj:GetController("state").selectedIndex = 0
			end
			self.selectedReportIndex = value
			local obj = self.ComReportDetailList:GetChildAt(value - 1)
			obj:GetController("state").selectedIndex = 1
		end
    }
end

function UIReport:InitVM()
    return {
		reports = {},
		moduleType = "",
		reportType = -1,
		subType = -1,	--战斗邮件子类型
		selectedReportID = "",
		selectedReportIndex = -1,
    }
end

--FIXME:This is automatically generated
--FIXME:If no event to listen, Delete This function
function UIReport:InitEvents()
    self:AddEventListener(_G.EventKey.MAIL_CHANGE, function()
		self.vm.reportType = self.vm.reportType.value
    end)
end

function UIReport:BindUI()
	self.PoptypeCtrler = self:GetController("Poptype")
	self.PopCtrler = self:GetController("Pop")
	self.showframeCtrler = self:GetController("showframe")
	self.detailshowCtrler = self:GetController("detailshow")
	self.ComReportList = self:GetControl("ComReportList")
	self.ComReportDetailList = self:GetControl("ComReportDetailList")
	self.ComDetectedFail = self:GetControl("ComDetectedFail")
	self.ComResGain = self:GetControl("ComResGain")
	self.ComReportFort = self:GetControl("ComReportFort")
	self.ComBeingDetected = self:GetControl("ComBeingDetected")
	self.ComReportDetail = self:GetControl("ComReportDetail")
	self.ComReportDetect = self:GetControl("ComReportDetect")
	self.ReportCtrler = self:GetController("report")
	self.TypeListNoReportCtrler = self:GetControl("ComReportList"):GetController("noreport")
	self.enemy = self:GetControl("ComReportList.enemy")
	self.resource = self:GetControl("ComReportList.resource")
	self.battle = self:GetControl("ComReportList.battle")
	self.system = self:GetControl("ComReportList.system")
	self.activity = self:GetControl("ComReportList.activity")
	self.ResItemList = self:GetControl("ComResGain.ComItemList")
	self.AttributeLsit = self:GetControl("ComReportDetail.AttributeLsit")
	self.DetailInfoList = self:GetControl("ComReportDetect.DetailInfoList")
	self.FortRewardList = self:GetControl("ComReportFort.RewardList")
end

function UIReport:Start()
	ResetSelectedReportIDCache()
	self.system.selected = true
	self.vm.moduleType = self.args.moduleType or config.MAIL_MODULE_TYPES.COMMON
	self.vm.reportType = self.args.reportType or config.MAIL_TYPES[config.MAIL_MODULE_TYPES.COMMON].SYSTEM
	self.PoptypeCtrler.selectedIndex = 3
end

function UIReport:GetSelectedReport()
	if self.vm.selectedReportIndex.value <= 0 then return end
	return self.vm.reports.value[self.vm.selectedReportIndex.value]
end

function UIReport:ConvertSubType(value)
	local types = config.MAIL_TYPES[config.MAIL_MODULE_TYPES.REPORT]
	if value == 0 then
		self.subType = types.BATTLE
	elseif value == 1 then
		self.subType = types.DETECT
	elseif value == 2 then
		self.subType = types.BATTLE_OTHER
	else
		self.subType = nil
	end
end

function UIReport:InitReportList()
	self.ComReportDetailList.itemProvider = function(idx)
		local index = idx + 1
		if self.vm.moduleType.value == config.MAIL_MODULE_TYPES.REPORT then
			local types = config.MAIL_TYPES[config.MAIL_MODULE_TYPES.REPORT]
			local report = self.vm.reports.value[index]
			if report.type_ == types.DETECT then
				return "ui://UIReport/ComReportLis"
			elseif report.type_ == types.RESOURCE then
				return "ui://UIReport/ComReportLis"
			end
		end
	end
	self.ComReportDetailList.itemRenderer = function(idx, obj)
		local index = self.ComReportDetailList:GetChildIndex(obj) + 1
		local report = self.vm.reports.value[index]
		if report.module_type_ == config.MAIL_MODULE_TYPES.REPORT then
			local types = config.MAIL_TYPES[config.MAIL_MODULE_TYPES.REPORT]
			if report.type_ == types.DETECT then
				self:SetDetectItem(index, obj, report)
			elseif report.type_ == types.RESOURCE then
				self:SetResourceItem(index, obj, report)
			end
		end
	end
	local onClick = function(context)
		local index = self.ComReportDetailList:GetChildIndex(context.data) + 1
		self.vm.selectedReportIndex = index
		local id = self.vm.reports.value[index].id_
		self.vm.selectedReportID = id
		selectedReportIDCache[self.vm.moduleType.value][self.vm.reportType.value] = id
	end
	self.ComReportDetailList.onClickItem:Set(onClick)
	self.ComReportDetailList:SetVirtual()
end

function UIReport:InitDetectInfoList()
	self.DetailInfoList.itemProvider = function(idx)
		return "ui://UIReport/DetailInfo"
	end
	self.DetailInfoList.itemRenderer = function(idx, obj)
		local report = self:GetSelectedReport()
		if idx == 0 then
			obj:GetChild("DetailDesTxt").text = string.format("%s %d", lang("DETECT_DEFEND_AMOUNT"), report:get_defence_soldier_cnt())
		elseif idx == 1 then
			obj:GetChild("DetailDesTxt").text = string.format("%s %d", lang("DETECT_HELP_AMOUNT"), report:get_reinforce_soldier_cnt())
		end
	end
end

local DetectSoldierUIType = {
	HeroTitle = 1,
	HeroHead = 2,
	SoldierTitle = 3,
}
local DetectSoldierUIInfo = {}

function UIReport:InitDetectSoldierList()
	self.AttributeLsit.itemProvider = function(idx)
		local index = idx + 1
		args = self:GetSelectedReport().args_
		local ty = DetectSoldierUIInfo[index]
		if ty == DetectSoldierUIType.HeroTitle then
			return "ui://UIReport/DefHero"
		elseif ty == DetectSoldierUIType.HeroHead then
			return "ui://UIReport/ComHero"
		elseif ty == DetectSoldierUIType.SoldierTitle then
			return "ui://UIReport/TribeDetail"
		end
		return "ui://UIReport/Attribute"
	end
	self.AttributeLsit.itemRenderer = function(idx, obj)
		idx = idx + 1
		local args = self:GetSelectedReport().args_
		local army, def, index, heroCnt
		if idx <= DetectSoldierUIInfo.defenceRows then
			army = args.defence_army
			def = 0
			index = idx
			heroCnt = DetectSoldierUIInfo.defenceHeroCnt
		else
			army = args.reinforce_army
			def = 1
			index = idx - DetectSoldierUIInfo.defenceRows
			heroCnt = DetectSoldierUIInfo.reinforceHeroCnt
		end
		if DetectSoldierUIInfo[idx] == DetectSoldierUIType.HeroTitle then
			obj:GetController("state").selectedIndex = def
			obj:GetChild("LevelTxt").text = heroCnt
		elseif DetectSoldierUIInfo[idx] == DetectSoldierUIType.HeroHead then
			local hs = {}
			for _, v in pairs(army.heroes) do
				hs[v.pos] = v
			end
			local coms = {obj:GetChild("ComHeroHead"), obj:GetChild("ComHeroHead2")}
			for i, com in ipairs(coms) do
				if hs[i] then
					local info = hs[i]
					local heroCfg = HeroConfig.ListData[info.id]
					com:GetController("show").selectedIndex = 1
					com:GetController("locat").selectedIndex = i - 1
					com:GetController("label").selectedIndex = heroCfg.type - 1
					com:GetController("quality").selectedIndex = heroCfg.quality - 1
					com:GetChild("iconloader").url = "art/"..heroCfg.icon
					com:GetChild("NameTxt").text = heroCfg.name
					com:GetChild("LeveTxt").text = lang("UI_HERO_LV2", info.level)
					com:GetChild("HeroHeadStar"):GetController("star_state").selectedIndex = HeroManager:get_star_by_star_level(info.id, info.star) - 1
				else
					com:GetController("show").selectedIndex = 0
				end
			end
		elseif DetectSoldierUIInfo[idx] == DetectSoldierUIType.SoldierTitle then
			obj:GetController("state").selectedIndex = def
			local total = 0
			for _, v in pairs(army.soldiers) do
				total = total + v[2]
			end
			obj:GetChild("TribAmountTxt").text = total
		else
			local id, cnt = unpack(army.soldiers[index - (heroCnt > 0 and 3 or 2)])
			local soldier = SoldierConfig.SoldierData[id]
			obj:GetChild("TypeSoldierTxt").text = lang("UI_SOLDIER_ICON_NAME_LV", soldier.lv, soldier.name)
			obj:GetChild("amountTxt").text = cnt
		end
	end
	self.AttributeLsit:SetVirtual()
end

function UIReport:SetDetectItem(index, obj, report)
	obj:GetChild("DetectedSuccessTxt").text = report.title_
	obj:GetChild("TimeCountTxt").text = UIUtil.time_str_from(report.time_)
	obj:GetController("mailstate").selectedIndex = report:is_read() and 2 or 0
	if index ~= self.vm.selectedReportIndex.value then
		obj:GetController("state").selectedIndex = 0
	end
end

function UIReport:SetResourceItem(index, obj, report)
	obj:GetChild("DetectedSuccessTxt").text = report.title_
	obj:GetChild("TimeCountTxt").text = UIUtil.time_str_from(report.time_)
	obj:GetController("mailstate").selectedIndex = report:is_read() and 2 or 0
	if index ~= self.vm.selectedReportIndex.value then
		obj:GetController("state").selectedIndex = 0
	end
end

function UIReport:ShowDetail()
	local report = self:GetSelectedReport()
	if not report:is_read() then
		MailManager:read_mail(report.module_type_, report.type_, report.id_)
		local obj = self.ComReportDetailList:GetChildAt(self.vm.selectedReportIndex.value - 1)
		obj:GetController("mailstate").selectedIndex = 2
	end
	if report.module_type_ == config.MAIL_MODULE_TYPES.COMMON then
	elseif report.module_type_ == config.MAIL_MODULE_TYPES.REPORT then
		local types = config.MAIL_TYPES[report.module_type_]
		if report.type_ == types.DETECT then
			self:ShowDetectDetail(report)
		elseif report.type_ == types.RESOURCE then
			self:ShowResourceDetail(report)
		end
	end
end

local function deleteSelectedReport()
	local report = UIReport:GetSelectedReport()
	MailManager:delete_mail(report.module_type_, report.type_, report.id_, function()
		UIReport.detailshowCtrler.selectedIndex = 0
		selectedReportIDCache[report.module_type_][UIReport.vm.reportType.value] = ""
	end)
end

function UIReport:ShowDetectDetail(report)
	DetectSoldierUIInfo = {}
	local timeStr = string.format("%s\n(%d,%d)", UIUtil.FormatTimestamp(report.time_), unpack(report.args_.location))
	local timeFrom = UIUtil.time_str_from(report.time_)
	if report.args_.result == 0 then	--侦察成功
		self.showframeCtrler.selectedIndex = 4
		self.ComReportDetect:GetChild("TimeCountDownTxt").text = timeFrom
		self.ComReportDetect:GetChild("PLayerNameTxt").text = report.args_.rname
		self.ComReportDetect:GetChild("TimeCoordinateTxt").text = timeStr
		local id = report:get_most_soldier_id()
		if id then
			local soldier = SoldierConfig.SoldierData[id]
			local str = lang("UI_SOLDIER_ICON_NAME_LV", soldier.lv, soldier.name)
			self.ComReportDetect:GetChild("DescirbeTxt").text = lang("DETECT_SUCCESS_HINT", str)
		else
			self.ComReportDetect:GetChild("DescirbeTxt").text = ""
		end
		self.ComReportDetect:GetChild("CancelBtn").onClick:Set(deleteSelectedReport)
		self.DetailInfoList.numItems = 2
		--详情页
		local defenceArmy = report.args_.defence_army
		local reinforceArmy = report.args_.reinforce_army
		local defenceSoldierCnt = 0
		local reinforceSoldierCnt = 0
		local defPower = WorldManager:CalcTroopPower(defenceArmy.heroes, defenceArmy.soldiers)
		local helpPower = WorldManager:CalcTroopPower(reinforceArmy.heroes, reinforceArmy.soldiers)
		self.ComReportDetail:GetChild("OverallAmountTxt").text = math.floor(defPower + helpPower + 0.5)
		self.ComReportDetail:GetChild("PlayerNameTxt").text = report.args_.rname
		local i = 1
		DetectSoldierUIInfo[i] = DetectSoldierUIType.HeroTitle
		local defenceHeroCnt = table.size(defenceArmy.heroes)
		if defenceHeroCnt > 0 then
			i = i + 1
			DetectSoldierUIInfo[i] = DetectSoldierUIType.HeroHead
		end
		DetectSoldierUIInfo.defenceHeroCnt = defenceHeroCnt
		i = i + 1
		DetectSoldierUIInfo[i] = DetectSoldierUIType.SoldierTitle
		i = i + #defenceArmy.soldiers
		DetectSoldierUIInfo.defenceRows = i
		i = i + 1
		DetectSoldierUIInfo[i] = DetectSoldierUIType.HeroTitle
		local reinforceHeroCnt = table.size(reinforceArmy.heroes)
		DetectSoldierUIInfo.reinforceHeroCnt = reinforceHeroCnt
		if reinforceHeroCnt > 0 then
			i = i + 1
			DetectSoldierUIInfo[i] = DetectSoldierUIType.HeroHead
		end
		i = i + 1
		DetectSoldierUIInfo[i] = DetectSoldierUIType.SoldierTitle
		self.AttributeLsit.numItems = i + #reinforceArmy.soldiers
	elseif report.args_.result == 1 then	--侦察失败
		self.showframeCtrler.selectedIndex = 1
		self.ComDetectedFail:GetChild("timeTxt").text = timeFrom
		self.ComDetectedFail:GetChild("objectnameTxt").text = report.args_.rname
		self.ComDetectedFail:GetChild("timehintTxt").text = timeStr
		self.ComDetectedFail:GetChild("desTxt").text = lang("DETECT_FAIL_HINT")
		local failReason
		if report.args_.failtype == 1 then
			failReason = lang("DETECT_RES_VANISH")
		elseif report.args_.failtype == 2 then
			failReason = lang("DETECT_TRIBE_LEAVE")
		elseif report.args_.failtype == 3 then
			failReason = lang("DETECT_TARGET_UNION")
		end
		self.ComDetectedFail:GetChild("text1Txt").text = failReason
		self.ComDetectedFail:GetChild("yellowBtn").onClick:Set(deleteSelectedReport)
	else
		self.showframeCtrler.selectedIndex = 3	--被侦察
		self.ComBeingDetected:GetChild("TimeCountDownTxt").text = timeFrom
		self.ComBeingDetected:GetChild("PlayerNameTxt").text = report.args_.rname
		self.ComBeingDetected:GetChild("TimeCoordinateTxt").text = timeStr
		self.ComBeingDetected:GetChild("WarrningTxt").text = lang("DETECT_CITY_HIGHER", report.args_.rname)
		self.ComBeingDetected:GetChild("buttonBtn").onClick:Set(deleteSelectedReport)
	end
end

function UIReport:InitResItemList()
	local itemProvider = function()
		return "ui://UIReport/ComItem"
	end
	local itemRenderer = function(idx, obj)
		local index = idx + 1
		local itemInfo = self:GetSelectedReport().args_.rewards[index]
		local cfg = ItemManager:get_ui_info(itemInfo)
		obj:GetController("quality").selectedIndex = cfg.quality - 1
		obj:GetChild("amountTxt").text = itemInfo[3]
		obj:GetChild("iconloader").url = string.format("art/%s", cfg.icon)
	end
	self.ResItemList.itemProvider = itemProvider
	self.ResItemList.itemRenderer = itemRenderer
	self.FortRewardList.itemProvider = itemProvider
	self.FortRewardList.itemRenderer = itemRenderer
end

function UIReport:ShowResourceDetail(report)
	local buildName, lv = report:get_detect_obj_name_lv()
	local timeStr = string.format("%s\n(%d,%d)", UIUtil.FormatTimestamp(report.time_), unpack(report.args_.location))
	local timeFrom = UIUtil.time_str_from(report.time_)
	if report.args_.starttime and report.args_.endtime then
		self.showframeCtrler.selectedIndex = 5
		self.ComReportFort:GetChild("SendTimeTxt").text = timeFrom
		self.ComReportFort:GetChild("FortRepTxt").text = lang("RESPOINT_3", lv, buildName)
		self.ComReportFort:GetChild("CoordinateTxt").text = timeStr
		self.ComReportFort:GetChild("OccupyTxt").text = lang("MAIL_CAPTURE_INFO")
		local st = UIUtil.FormatTimestamp(report.args_.starttime, "%d-%.2d-%.2d %.2d:%.2d:%.2d")
		self.ComReportFort:GetChild("StartTxt").text = string.format("%s: %s", lang("UI_BASE_START_TIME"), st)
		local et = UIUtil.FormatTimestamp(report.args_.endtime, "%d-%.2d-%.2d %.2d:%.2d:%.2d")
		self.ComReportFort:GetChild("OverTxt").text = string.format("%s: %s", lang("UI_BASE_END_TIME"), et)
		local dt = UIUtil.get_format_time_tidy(report.args_.endtime - report.args_.starttime)
		self.ComReportFort:GetChild("OccupyLastTxt").text = string.format("%s: %s", lang("MAIL_CAPTURE_DURATION"), dt)
		self.ComReportFort:GetChild("CancelBtn").onClick:Set(deleteSelectedReport)
		self.FortRewardList.numItems = #report.args_.rewards
	else
		self.showframeCtrler.selectedIndex = 2
		self.ComResGain:GetChild("HINTTxt").text = lang("DETECT_RETREAT", buildName, unpack(report.args_.location))
		self.ComResGain:GetChild("resnameTxt").text = lang("RESPOINT_3", lv, buildName)
		self.ComResGain:GetChild("SendTimeTxt").text = timeFrom
		self.ComResGain:GetChild("TimeTxt").text = timeStr
		self.ResItemList.numItems = #report.args_.rewards
		self.ComResGain:GetChild("buttonBtn").onClick:Set(deleteSelectedReport)
	end
end

function UIReport:OnBlueDetailBtnClick()
end

function UIReport:OnenemyClick()
	local mt = config.MAIL_MODULE_TYPES.REPORT
	self.vm.moduleType = mt
	self.vm.reportType = config.MAIL_TYPES[mt].WILD_BATTLE
end

function UIReport:OnresourceClick()
	local mt = config.MAIL_MODULE_TYPES.REPORT
	self.vm.moduleType = mt
	self.vm.reportType = config.MAIL_TYPES[mt].RESOURCE
end

function UIReport:OnbattleClick()
	local mt = config.MAIL_MODULE_TYPES.REPORT
	self.vm.moduleType = mt
	self.vm.reportType = config.MAIL_TYPES[mt].BATTLE
end

function UIReport:OnsystemClick()
	local mt = config.MAIL_MODULE_TYPES.COMMON
	self.vm.moduleType = mt
	self.vm.reportType = config.MAIL_TYPES[mt].SYSTEM
end

function UIReport:OnactivityClick()
	local mt = config.MAIL_MODULE_TYPES.COMMON
	self.vm.moduleType = mt
	self.vm.reportType = config.MAIL_TYPES[mt].ACTIVITY
end

function UIReport:OnBlue2BtnClick()
	self.PopCtrler.selectedIndex = 1 - self.PopCtrler.selectedIndex
end

function UIReport:OnBlueBtnClick()
	local mt = self.vm.moduleType.value
	local rt = self.vm.reportType.value
	local selectedID = selectedReportIDCache[mt][rt]
	local report = MailManager:get_mail(mt, rt, selectedID)
	MailManager:delete_mails(mt, rt, self.subType, function()
		if report:is_deleted() then
			selectedReportIDCache[mt][rt] = ""
		end
	end)
end

function UIReport:OnyellowBtnClick()
end

function UIReport:OnyellowBtnClick()
end

function UIReport:OnbuttonBtnClick()
end

function UIReport:OnClickSubType()
	self.vm.subType = self.PoptypeCtrler.selectedIndex
	self.PopCtrler.selectedIndex = 0
end

function UIReport:OnBattleBtnClick()
	self:OnClickSubType()
end

function UIReport:OnDetectBtnClick()
	self:OnClickSubType()
end

function UIReport:OnOtherBtnClick()
	self:OnClickSubType()
end

function UIReport:OnAllBtnClick()
	self:OnClickSubType()
end
