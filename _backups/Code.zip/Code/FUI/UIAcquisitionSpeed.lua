--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIAcquisitionSpeed = _G.UIController:Get("UIAcquisitionSpeed")
local BasicConfig = _G.Database.BasicConfig
function UIAcquisitionSpeed:Awake()
	self.armyData=self.args.armyData
	self.count=table.size(BasicConfig.BasicData.respoint)
	self:InitGoodsList()
	self:RefreshTime()
end

function UIAcquisitionSpeed:InitBinds()
    return {
    }
end

function UIAcquisitionSpeed:InitVM()
    return {
    }
end
--FIXME:This is automatically generated
--FIXME:If no event to listen, Delete This function
function UIAcquisitionSpeed:InitEvents()
	self:AddEventListener(
        _G.EventKey.WORLD_RESPOINT_DELETE,
        function(arg)
            if self.armyData.idx_ ~= arg.id then
                return
            end
            self:Hide()
        end
	)
	self:AddEventListener(
        _G.EventKey.WORLD_RESPOINT_REFRESH,
        function(arg)
            if self.armyData.idx_ ~= arg.id then
                return
            end
            self:Hide()
        end
    )
	self:AddEventListener(
        _G.EventKey.RESPOINT_REFRESH,
        function()
			self.GoodsList.numItems=self.count
			self:RefreshTime()
        end
    )
end
function UIAcquisitionSpeed:BindUI()
	self.AddSpeedList = self:GetControl("AddSpeedList")
	self.BackgroundCtrler = self:GetControl("AddSpeedList"):GetController("Background")
	self.AddSpeedTitleTxt = self:GetControl("AddSpeedList.AddSpeedTitleTxt")
	self.AddSpeedTxt = self:GetControl("AddSpeedList.AddSpeedTxt")
	self.CollectionSpeedTxt = self:GetControl("AddSpeedList.CollectionSpeedTxt")
	self.CollectionPlusBar = self:GetControl("AddSpeedList.CollectionPlusBar")
	self.DropDownBtn = self:GetControl("AddSpeedList.DropDownBtn")
	self.GoodsList = self:GetControl("AddSpeedList.GoodsList")
	self.TipsTxt = self:GetControl("TipsTxt")
	self.CloseBtn = self:GetControl("CloseBtn")
	self.ItemIcon = self:GetControl("AddSpeedList.Item")
	self.CollectionTimeTxt = self:GetControl("AddSpeedList.CollectionTimeTxt")
end

function UIAcquisitionSpeed:InitGoodsList()
	local itemHeight=self.GoodsList.height
	self.GoodsList.itemProvider=function()
		return "ui://iq7s70cbqrqpm"
	end
	self.GoodsList.itemRenderer=function(idx,obj)
		local itemId=BasicConfig.BasicData.respoint[idx+1]
		local item=ItemManager:get_item_by_id(itemId)
		local prop
		local num=0
		if item then
			prop=item:get_prop()
			num=item.count_
		else
			prop=ItemManager:get_item_prop_by_id(itemId)
		end
		obj:GetChild("PropNameTxt").text=prop.name
		obj:GetChild("PropDescribeTxt").text=prop.desc
		obj:GetChild("Item").url="art/"..prop.icon
		obj:GetChild("UseBtn").onClick:Set(_G.partial(self.UseBtnClick, self))
		obj:GetChild("PurchaseBtn").onClick:Set(_G.partial(self.BuyBtnClick, self))
		obj:GetChildByPath("PurchaseBtn.GoldCoinTxt").text=prop.quick_buy[3]
		obj:GetController("background").selectedIndex=prop.quality-1
		obj:GetController("paging").selectedIndex=item and 1 or 0
	end
	self.GoodsList.height=itemHeight*self.count
end

function UIAcquisitionSpeed:UseBtnClick(context)
	local Index = self.GoodsList:GetChildIndex(context.sender.parent)
	local itemID=BasicConfig.BasicData.respoint[Index+1]
	local item = ItemManager:get_item_by_id(itemID)
	if not item then return end
	item.use_respoint_gold_ = false
	item:use(function()
		self.GoodsList.numItems=self.count
		self:RefreshTime()
		_G.event.fire(_G.EventKey.RESPOINT_REFRESH_TIME)
	end)
end
function UIAcquisitionSpeed:BuyBtnClick(context)
	local Index = self.GoodsList:GetChildIndex(context.sender.parent)
	local itemID=BasicConfig.BasicData.respoint[Index+1]
	local data = {}
	data.mode = 0
    data.title = lang("UI_BASIC_HINT")
    if WorldManager.respoint_buff_ then
        data.content = lang("RESPOINT_30")
    else
        data.content = lang("RESPOINT_31")
    end
    data.callback = function() 
		ItemManager:quick_buy(itemID, 1,function()
			local item = ItemManager:get_item_by_id(itemID)
			item:confirm_to_use(1,function()
				self.GoodsList.numItems=self.count
				self:RefreshTime()
				_G.event.fire(_G.EventKey.RESPOINT_REFRESH_TIME)
			end)
		end)
    end
	_G.UIController:ShowUI('UICommonPop',data)
end

function UIAcquisitionSpeed:OnItemChange()

end
function UIAcquisitionSpeed:OnItemRefresh()

end

function UIAcquisitionSpeed:RefreshTime()
	local buff = WorldManager.respoint_buff_
	if not buff then
        self.CollectionPlusBar.value = 0
        self.CollectionTimeTxt.text =lang("RESPOINT_27") .. "00:00:00"
        return
	end
	local curConfig
	for _, v in ipairs(BasicConfig.BasicData.respoint) do
		local prop=ItemManager:get_item_prop_by_id(v)
		if prop.usepara[1][1]==buff.val then
			curConfig=prop
			break
		end
	end
	self.ItemIcon.url="art/"..curConfig.icon
	self.BackgroundCtrler.selectedIndex=curConfig.quality-1
	local timeDown=buff.ti - buff.ti_start
	self.CollectionPlusBar.min=0
	self.CollectionPlusBar.max=timeDown
    if self.time_count_ then
        LuaTimer.Delete(self.time_count_)
        self.time_count_ = nil
    end
    self.time_count_ = LuaTimer.Add( 0, 1000, function()
        local time_up = buff.ti - Net.server_time()
        if not buff.ti then
            elog("world respoint buff findn't ti, pls call wanghong check data")
            LuaTimer.Delete(self.time_count_)
            return
		end
        if time_up < 0 then time_up = 0 end
		self.CollectionTimeTxt.text = lang("RESPOINT_27")..UIUtil.format_time(time_up)
        self.CollectionPlusBar.value = time_up 
    end)
end
function UIAcquisitionSpeed:RemoveTimer()
    if self.time_count_ then
        LuaTimer.Delete(self.time_count_)
        self.time_count_ = nil
    end 
end
function UIAcquisitionSpeed:Start()
	self.GoodsList.numItems=self.count
end

function UIAcquisitionSpeed:OnAddSpeedListClick()
end

function UIAcquisitionSpeed:OnCloseBtnClick()
	self:Hide()
	self:RemoveTimer()
end

function UIAcquisitionSpeed:OnCollectionPlusBarClick()
end

function UIAcquisitionSpeed:OnDropDownBtnClick()
	self.GoodsList.visible= not self.GoodsList.visible
end
