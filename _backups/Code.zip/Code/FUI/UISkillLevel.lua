--This is an automatically generated class by FairyGUI. Please do not modify it.

local UISkillLevel = _G.UIController:Get("UISkillLevel")

local lang = _G.lang
local config = _G.config
local BasicConfig = _G.Database.BasicConfig
local HeroManager = _G.HeroManager
local ItemManager = _G.ItemManager
local SkillManager = _G.SkillManager

function UISkillLevel:Awake()
	self.hero = HeroManager:get_hero_by_id(self.args.id)
	self.serverSkill = self.hero.skills_[self.args.pos]
	local skillCfg = SkillManager:get_config(self.serverSkill.skillid)
	self.SkillnameTxt.text = skillCfg.name
	self.skilltypeCtrler.selectedIndex = skillCfg.rare > 0 and 0 or 1
	self.SkillIcon.url = string.format("art/%s", skillCfg.icon)
	self.expItemInfo = BasicConfig.BasicData.hero_skill_items
	self:InitItemList()
end

function UISkillLevel:InitBinds()
    return {
		level = function(value)
			if value < 0 then return end
			self.LevelTxt.text = lang("UI_HERO_LV1", self.serverSkill.level)
			self.SkilldescTxt.text = SkillManager:get_skill_buff_desc(self.serverSkill.skillid, self.serverSkill.level, self.hero.id_)
			self.NextlevelTxt.text = SkillManager:get_skill_desc_next_lv(self.serverSkill.skillid, self.serverSkill.level)
		end,
		exp = function(value)
			if value < 0 then return end
			self.CountProgressBar.value = value
			self.CountProgressBar:GetChild("ExpTxt").text = string.format("%d/%d", value, self.CountProgressBar.max)
		end,
    }
end

function UISkillLevel:InitVM()
    return {
		level = -1,
		exp = -1,
    }
end

function UISkillLevel:InitEvents()
    self:AddEventListener(_G.EventKey.CITY_HERO_SKILL, function()
		self:RefreshSkill()
	end)
	self:AddEventListener(_G.EventKey.ITEM_CHANGE, function()
		self:RefreshItem()
    end)
end

function UISkillLevel:BindUI()
	self.LabletypeCtrler = self:GetController("Labletype")
	self.Comskilldesc = self:GetControl("Comskilldesc")
	self.SkillnameTxt = self:GetControl("Comskilldesc.SkillnameTxt")
	self.SkilldescTxt = self:GetControl("Comskilldesc.SkilldescTxt")
	self.skilltypeCtrler = self:GetControl("Comskilldesc.skill_bg"):GetController("skilltype")
	self.SkillIcon = self:GetControl("Comskilldesc.skill_bg.Skill@icon")
	self.NextlevelTxt = self:GetControl("NextlevelTxt")
	self.CountProgressBar = self:GetControl("CountProgressBar")
	self.LevelTxt = self:GetControl("LevelTxt")
	self.SkillitemList = self:GetControl("SkillitemList")
end

function UISkillLevel:Start()
	self:RefreshSkill()
	self:RefreshItem()
end

function UISkillLevel:RefreshSkill()
	self.serverSkill = self.hero.skills_[self.args.pos]
	if not self.serverSkill then self:Hide() return end
	self.CountProgressBar.min = 0
	self.CountProgressBar.max = SkillManager:get_skill_level_exp(self.serverSkill.skillid, self.serverSkill.level)
	self.vm.level = self.serverSkill.level
	self.vm.exp = self.serverSkill.exp
end

function UISkillLevel:RefreshItem()
	self.SkillitemList.numItems = #self.expItemInfo
end

function UISkillLevel:InitItemList()
	self.SkillitemList.itemProvider = function()
		return "ui://UISkillLevel/ComMaterial"
	end
	self.SkillitemList.itemRenderer = function(idx, obj)
		local index = idx + 1
		local itemInfo = self.expItemInfo[index]
		local itemCfg = ItemManager:get_config(itemInfo[1])
		local cnt = ItemManager:get_count(config.ITEM_ITEM, itemInfo[1])
		obj:GetController("quality").selectedIndex = itemCfg.quality - 1
		obj:GetController("state").selectedIndex = cnt > 0 and 1 or 0
		obj:GetChild("propname").text = itemCfg.name
		obj:GetChild("iconloader").url = string.format("art/%s", itemCfg.icon)
		obj:GetChild("leveltext").text = cnt
	end
	self.SkillitemList.onClickItem:Add(function(context)
		local index = self.SkillitemList:GetChildIndex(context.data) + 1
		local id = self.expItemInfo[index][1]
		local cnt = ItemManager:get_count(config.ITEM_ITEM, id)
		if cnt <= 0 then return end
		SkillManager:levelup_skill(self.hero.id_, self.args.pos, self.serverSkill.skillid, {{id, 1}})
	end)
end

function UISkillLevel:OnBreakBtnClick()
	_G.UIController:ShowUI("UISkillForget", {hero = self.hero, pos = self.args.pos})
end

function UISkillLevel:OnColseBtnClick()
	self:Hide()
end

function UISkillLevel:OnLevelBtnClick()
	local maxLv = SkillManager:CalcMaxLv(self.hero, self.serverSkill)
	local currLv = self.serverSkill.level
	if currLv >= maxLv then return end
	_G.UIController:ShowUI("UIHeroLevelUp",{mode = 2, hero = self.hero, pos = self.args.pos, minLv = currLv + 1, maxLv = maxLv})
end

