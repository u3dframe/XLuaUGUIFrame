--This is an automatically generated class by FairyGUI. Please do not modify it.

    local UIMarchSpeedUp = _G.UIController:Get("UIMarchSpeedUp")

    local BasicConfig = _G.Database.BasicConfig
    local WorldManager = _G.WorldManager
    local ItemManager = _G.ItemManager
    local UIUtil = _G.UIUtil
    local Net = _G.Net
    local lang = _G.lang
    local EventKey = _G.EventKey
    local indexer = _G.Indexer.New()

    local PanelType = {
        Speed = indexer(-1),
        Back  = indexer()
    }

    function UIMarchSpeedUp:InitBinds()
        return {
            remainingTime = function(value)
                value = value < 0 and 0 or value
                self.timerTxt.text = UIUtil.format_time(value)
                self.timerSlider.value = self:GetSilderValue()
            end,
            panelType = function(index)
                self.typeCtrler.selectedIndex = index
                if index == PanelType.Speed then
                    self:RefreshSpeedUI()
                else
                    self:RefreshReturnUI()
                end
            end
        }
    end

    function UIMarchSpeedUp:InitVM()
        return {
            panelType = 0,
            remainingTime = 0,
        }
    end

    function UIMarchSpeedUp:InitEvents()
        self:AddEventListener(EventKey.WORLD_MARCH_DELETE, function(id)
            if self.march.idx_ ~= id then
                return
            end
            self:Hide()
        end)
    end

    function UIMarchSpeedUp:BindUI()
        self.typeCtrler = self:GetController("type")
        self.timerSlider = self:GetControl("TeamProgressBar")
        self.timerTxt = self:GetControl("TeamProgressBar.teamtimeTxt")
        self.speedPrimary = self:GetControl("SpeedPrimary")
        self.speedHigh = self:GetControl("speedHigh")
        self.backItem = self:GetControl("Backteam")
    end

    function UIMarchSpeedUp:Start()
        dump(self.args.mode, "mode = ")
        self.vm.panelType = self.args.mode
    end

    function UIMarchSpeedUp:RefreshSpeedUI()
        self.march = WorldManager:get_march_by_idx(self.args.data)
        local itemObj = {
            self.speedPrimary,
            self.speedHigh
        }
        for i, v in ipairs(BasicConfig.BasicData.armydectime) do
            self:SetItem(itemObj[i], v[1])
            self:SetUseSpeedupItemHandle(itemObj[i], v[1])
        end
        self:PlayTimer()
    end

    function UIMarchSpeedUp:RefreshReturnUI()
        self.backMarch = WorldManager:get_march_by_idx(self.args.data)
        local itemId = BasicConfig.BasicData.armycancel
        self:SetItem(self.backItem, itemId, true)
        self.backItem:GetChild("UseBtn").onClick:Clear()
        self.backItem:GetChild("UseBtn").onClick:Add(function()
            self:SetUseBackItemHandle(itemId)
        end)
    end


    local BtnType = {
        Normal  = indexer(-1),
        Unusual = indexer()
    }
    function UIMarchSpeedUp:SetItem(itemObj, itemId)
        local item = ItemManager:get_item_by_id(itemId)
        local cfg = ItemManager:get_item_prop_by_id(itemId)
        itemObj:GetChild("icon").url = "art/"..cfg.icon
        itemObj:GetChild("ItemnameTxt").text = cfg.name
        itemObj:GetChild("ItemTxt").text = cfg.desc
        itemObj:GetChild("itemnumTxt").text = item and item.count_ or 0
        itemObj:GetController("buttontype").selectedIndex = item and BtnType.Normal or BtnType.Unusual
    end

    function UIMarchSpeedUp:SetUseSpeedupItemHandle(itemObj, itemId)
        local item = ItemManager:get_item_by_id(itemId)
        local function itemClick()
            if not item then
                return
            end
            local data = {}
            data.id = self.march.idx_
            data.itemid = item.id_
            Net.send("army_dectime", data, function(result)
                if result.e == 0 then
                    self:RefreshSpeedUI()
                    MsgCenter.send_message(Msg.SHOW_HINT, lang("EXPEDITION_7"))
                end
            end)
        end
        itemObj:GetChild("UseBtn").onClick:Clear()
        itemObj:GetChild("UseBtn").onClick:Add(itemClick)
    end

    local CommonPop_Normal = 0

    function UIMarchSpeedUp:SetUseBackItemHandle(itemId)
        if not ItemManager:check_item_count(itemId) then
            local prop = ItemManager:get_item_prop_by_id(itemId)
            local str = lang("RESOURCE_BUILDING_3", prop.name)
            MsgCenter.send_message(Msg.SHOW_HINT, str)
            return
        end

        local data = {}
        data.mode = CommonPop_Normal
        data.title = lang("UI_BASIC_HINT")
        data.content = lang("EXPEDITION_8")
        data.callback = function()
            local req = {}
            req.id = self.march.idx_
            print("march_ratio_protect_")
            _G.WorldAniTmp.march_ratio_protect_[self.backMarch.idx_] = 1
            Net.send("army_cancel", req, function(result)
                print("march_ratio_protect_ army_cancel")
                if result.e == 0 then
                    self:Hide()
                end
            end)
        end
        _G.UIController:ShowUI("UICommonPop", data)
    end

    function UIMarchSpeedUp:PlayTimer()
        local runInfo = self.march.runinfo_
        if not runInfo then
            return
        end
        local totleTime = runInfo.ti_end - runInfo.ti_start + runInfo.ti_dec
        local remainingTime = runInfo.ti_end - Net.server_time()
        self.timerSlider.min = 0
        self.timerSlider.max = totleTime
        self.vm.remainingTime = remainingTime
        local function call()
            self.vm.remainingTime = runInfo.ti_end - Net.server_time()
        end

        local function endCall()
            self:Hide()
        end

        self:SetEngineTimer("march_speedup", call, endCall, math.ceil(remainingTime), 1, false)
    end

    function UIMarchSpeedUp:GetSilderValue()
        if not self.march or not self.march.runinfo_ then
            return 0
        end

        local dec = self.march.runinfo_.ti_dec or 0
        return Net.server_time() + dec - self.march.runinfo_.ti_start
    end

    function UIMarchSpeedUp:OnCloseBtnClick()
        self:Hide()
    end