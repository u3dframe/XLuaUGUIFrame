--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIWareTips = _G.UIController:Get("UIWareTips")

function UIWareTips:Awake()
	self.resType=self.args.oneKeyType
	self.itemDatas=self.args.itemDatas
	self:InitInfo()
end

function UIWareTips:InitBinds()
    return {
    }
end

function UIWareTips:InitVM()
    return {
    }
end

--FIXME:This is automatically generated
--FIXME:If no event to listen, Delete This function
function UIWareTips:InitEvents()
    self:AddEventListener(eventKey or eventKeys, function()

    end)
end

function UIWareTips:BindUI()
	self.wall_bg = self:GetControl("wall_bg")
	self.Combg = self:GetControl("Combg")
	self.pop_longwin_title_bg = self:GetControl("Combg.pop_longwin_title_bg")
	self.pop_longwin_top_title = self:GetControl("Combg.pop_longwin_top_title")
	self.pop_win_inside = self:GetControl("pop_win_inside")
	self.TipTxt = self:GetControl("TipTxt")
	self.UseTxt = self:GetControl("UseTxt")
	self.ConfirmBtn = self:GetControl("ConfirmBtn")
	self.icon = self:GetControl("ConfirmBtn.icon")
	self.CancelBtn = self:GetControl("CancelBtn")
	self.UsefoodTxt = self:GetControl("UsefoodTxt")
	self.pop_longwin_title_bg = self:GetControl("Combg.pop_longwin_title_bg")
	self.pop_longwin_top_title = self:GetControl("Combg.pop_longwin_top_title")
	self.icon = self:GetControl("ConfirmBtn.icon")
end
function UIWareTips:InitInfo()
	self.UseTxt.text="主公，是否使用所有的"..lang("ITEM"..self.resType)
	local allNum=0
	for _, v in ipairs(self.itemDatas) do
		allNum=allNum+(v.count_*v.prop_.usepara[1][3])
	end
	allNum=allNum+ItemManager:GetResByType(self.resType)
	self.UsefoodTxt.text="(使用后的)"..lang("ITEM"..self.resType).."总量"..UIUtil.res_num_to_str(allNum)
end
function UIWareTips:Start()

end

--FIXME:Write logic Code here!

function UIWareTips:OnCombgClick()
end

function UIWareTips:OnConfirmBtnClick()
		Net.send('quick_use',{resource_type = self.resType-1},
        function(result)
            if result.e == 0 then
				_G.event.fire(_G.EventKey.ITEM_CHANGE)
				self:Hide()
            end
        end
    )
end

function UIWareTips:OnCancelBtnClick()
	self:Hide()
end

