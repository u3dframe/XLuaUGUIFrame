--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIFragmentExchange = _G.UIController:Get("UIFragmentExchange")

function UIFragmentExchange:Awake()
	self.hero = _G.HeroManager:get_active_hero_by_id(self.args.id)
	local prop = self.hero:get_prop()
	self.generalChip = _G.ItemManager:get_item_by_id(prop.trade_item[2])
	local chipCfg = _G.ItemManager:get_item_prop_by_id(prop.activate[2])
	self.chipNum = self.hero:get_chip_num()

	self.ComFragment:GetChild("icon").url = "art/" .. self.generalChip.prop_.icon
	self.generalChipNumTxt = self.ComFragment:GetChild("899Txt")
	self.ComFragment:GetChild("Fragmenttext").text = self.generalChip.prop_.name
	self.ComFragment:GetController("qua").selectedIndex = self.generalChip.prop_.quality - 1

	self.chipNumTxt = self.ComGeneralFragment:GetChild("100Txt")
	self.ComGeneralFragment:GetChild("icon").url = "art/" .. chipCfg.icon
	self.ComGeneralFragment:GetChild("generalfragName").text = chipCfg.name
	self.ComGeneralFragment:GetController("quality").selectedIndex = chipCfg.quality - 1

	local stageCost = self.hero:get_stage_up_cost()
	local starCost = self.hero:get_star_up_cost()
	self.stageNeed = stageCost - self.chipNum
	self.starNeed = starCost - self.chipNum
	if self.stageNeed <= 0 then
		self.stageNeed = stageCost
	end
	if self.starNeed <= 0 then
		self.starNeed = starCost
	end
	self.stepuptext.text = lang("UI_HERO_CHIP_EXCHANGE_UP_STAGE", self.stageNeed)
	self.staruptext.text = lang("UI_HERO_CHIP_EXCHANGE_UP_STAR", self.starNeed)
end

function UIFragmentExchange:InitBinds()
    return {
		selectedCount = function(value)
			self.FragmentAmount.text = value
			self.generalChipNumTxt.text = self.generalChip.count_ - value
			self.chipNumTxt.text = value
			if value < self.stageNeed then
				self.StepBtn.selected = false
			end
			if value < self.starNeed then
				self.StarBtn.selected = false
			end
		end,
    }
end

function UIFragmentExchange:InitVM()
    return {
		selectedCount = 1,
    }
end

function UIFragmentExchange:BindUI()
	self.ComFragment = self:GetControl("ComFragment")
	self.ComGeneralFragment = self:GetControl("ComGeneralFragment")
	self.FragmentAmount = self:GetControl("FragmentAmount")
	self.stepuptext = self:GetControl("1stepuptext")
	self.staruptext = self:GetControl("1staruptext")
	self.StepBtn = self:GetControl("StepBtn")
	self.StarBtn = self:GetControl("StarBtn")
end

function UIFragmentExchange:Start()

end

function UIFragmentExchange:CanStageUp()
	return self.stageNeed <= self.generalChip.count_
end

function UIFragmentExchange:CanStarUp()
	return self.starNeed <= self.generalChip.count_
end

function UIFragmentExchange:OnCloseBtnClick()
	self:Hide()
end

function UIFragmentExchange:OnExchangeBtnClick()
	_G.HeroManager:HeroChipExchange(self.hero.id_, self.vm.selectedCount.value)
	self:Hide()
end

function UIFragmentExchange:OnMinusBtnClick()
	local cnt = self.vm.selectedCount.value
	if cnt <= 1 then return end
	self.vm.selectedCount = cnt - 1
end

function UIFragmentExchange:OnAddBtnClick()
	local cnt = self.vm.selectedCount.value
	if cnt >= self.generalChip.count_ then return end
	self.vm.selectedCount = cnt + 1
end

function UIFragmentExchange:OnPlus10Click()
	local cnt = self.vm.selectedCount.value
	local rest = self.generalChip.count_ - cnt
	local add = math.min(rest, 10)
	self.vm.selectedCount = cnt + add
end

function UIFragmentExchange:OnRedMaxClick()
	self.vm.selectedCount = self.generalChip.count_
end

function UIFragmentExchange:OnStepBtnClick()
	if self:CanStageUp() then
		self.StarBtn.selected = false
		self.vm.selectedCount = self.stageNeed
	else
		self.StepBtn.selected = false
	end
end

function UIFragmentExchange:OnStarBtnClick()
	if self:CanStarUp() then
		self.StepBtn.selected =false
		self.vm.selectedCount = self.starNeed
	else
		self.StarBtn.selected = false
	end
end
