local UIGameTool = _G.UIController:Get("UIGameTool")

local Net = _G.Net
local MsgCenter = _G.MsgCenter
local Msg = _G.Msg
local ItemConfig = _G.Database.ItemConfig

local resList = {
	"木材",
	"粮食",
	"石材",
	"铁锭",
	"宝石",
	"贵族经验",
	"金币",
	"兵",
	"体力",
}

function UIGameTool:InitBinds()
    return {
		list = function(value)
			self.chooseList.items = value
		end,
		selectIndex = function(value)
			self.chooseList.selectedIndex = value
		end,
    }
end

local resourceDefaultValue = 100000
local itemDefaultValue = 100

function UIGameTool:InitVM()
    return {
		list = {},
		selectIndex = 0,
    }
end

function UIGameTool:BindUI()
	self.resAmountTxt = self:GetControl("ResAmountTxt")
	self.itemIdTxt = self:GetControl("ItemIdTxt")
	self.itemAmountTxt = self:GetControl("ItemAmountTxt")
	self.gmOrderTxt = self:GetControl("GmOrderTxt")
	self.chooseList = self:GetControl("ChooseList")
end

function UIGameTool:Start()
	self.vm.list = resList
end

function UIGameTool:OnResAddBtnClick()
	local selectIndex = _G.math.clamp(self.chooseList.selectedIndex + 1, 1, #resList)
	local count = self.resAmountTxt.text
	if not tonumber(count) then
		return
	end

	local chat = {}
	chat.channel = 1
	if selectIndex < 8 then
		chat.content = string.format("lua@item(%d,0,%s)", selectIndex, count)
	elseif selectIndex == 8 then
        chat.content = string.format("lua@soldier(%d,%s)", 1, count)
	elseif selectIndex == 9 then
		chat.content = string.format("item(12,0,%d)", count)
	end
	Net.send("chat_chating", chat, function(res)
        if res.e == 0 then
            MsgCenter.send_message(Msg.SHOW_HINT, "已经添加成功！")
        end
    end)
end

local ITEM_MAX_COUNT = 9999999

function UIGameTool:OnItemAddBtnClick()
	local id = tonumber(self.itemIdTxt.text)
	local count = tonumber(self.itemAmountTxt.text)
	if not id or not count then
		return
	end
	local cfg = ItemConfig.ItemData[tonumber(id)]
	if not cfg then
		MsgCenter.send_message(Msg.SHOW_HINT, "物品不存在！")
        return
	end

	if count < 1 or count > ITEM_MAX_COUNT then
		MsgCenter.send_message(Msg.SHOW_HINT, "物品数量必须在1到9999999之间！")
        return
	end

	local reqMsg = {
		content = string.format("lua@item(10,%d,%d)", id, count)
	}
	Net.send("chat_chating", reqMsg, function(res)
        if res.e == 0 then
            MsgCenter.send_message(Msg.SHOW_HINT, "已经添加成功！")
        end
    end)
end

function UIGameTool:OnSendGmBtnClick()
	local gmCommand = self.gmOrderTxt.text
	if not gmCommand or gmCommand == "" then
		return
	end

	local cmd = string.lower(gmCommand)
	if string.sub(cmd, 1, 4) ~= "lua@" then
		cmd = "lua@"..cmd
	end
	Net.send("chat_chating", {content = cmd}, function(res)
        if res.e == 0 then
            if string.match(cmd, "time") then
                Net.send("ping", {any = 0}, function(result)
                    Net:UpdateServerTime(result)
                end)
            end
            MsgCenter.send_message(Msg.SHOW_HINT, "执行成功！")
        end
    end)
end

function UIGameTool:OnCloseBtnClick()
	self:Hide()
end
