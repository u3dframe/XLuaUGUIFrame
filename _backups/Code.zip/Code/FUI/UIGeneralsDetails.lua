--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIGeneralsDetails = _G.UIController:Get("UIGeneralsDetails")

function UIGeneralsDetails:Awake()
	self.hero=self.args.hero
	self:InitHeroInfo()
	self:InitSkillInfo()
end

function UIGeneralsDetails:InitBinds()
    return {
    }
end

function UIGeneralsDetails:InitVM()
    return {
    }
end

--FIXME:This is automatically generated
--FIXME:If no event to listen, Delete This function
function UIGeneralsDetails:InitEvents()
    self:AddEventListener(eventKey or eventKeys, function()

    end)
end

function UIGeneralsDetails:BindUI()
	self.CloseBtn = self:GetControl("CloseBtn")
	self.PowerTxt = self:GetControl("PowerTxt")
	self.LeaderTxt = self:GetControl("LeaderTxt")
	self.IntelligenceTxt = self:GetControl("IntelligenceTxt")
	self.PoliticsTxt = self:GetControl("PoliticsTxt")
	self.ComHerohead = self:GetControl("ComHerohead")
	self.PoliticsBar = self:GetControl("PoliticsBar")
	self.IntelligenceBar = self:GetControl("IntelligenceBar")
	self.LeaderBar = self:GetControl("LeaderBar")
	self.GeneralsSkillList = self:GetControl("GeneralsSkillList")
	self.ArtOfWarList = self:GetControl("ArtOfWarList")
	self.ComStar = self:GetControl("ComStar")
end

function UIGeneralsDetails:Start()
	 self.GeneralsSkillList.numItems=table.size(self.hero.skills_)
	-- self.ArtOfWarList.numItems=table.size(self.hero.)
end

--FIXME:Write logic Code here!

function UIGeneralsDetails:InitHeroInfo()
	UIUtil.SetHeroHead(self.ComHerohead, self.hero, self.hero.pos_-1)
	self.PowerTxt.text=self.hero:get_power()
end

function UIGeneralsDetails:InitSkillInfo()
	self.GeneralsSkillList.itemProvider=function()
		return "ui://im6ncqp6fedmx"
	end
	self.GeneralsSkillList.itemRenderer=function(idx,obj)
		-- local skill=self.hero.skills_[idx+1]
		-- obj:GetChild("SkillLevelTxt").text=skill.level
		--obj:GetChild("SkillIcon").url="art/"..
	end
end
function UIGeneralsDetails:InitBookInfo()

end


function UIGeneralsDetails:OnCloseBtnClick()
	self:Hide()
end
function UIGeneralsDetails:OnComHeroheadClick()
end

function UIGeneralsDetails:OnPoliticsBarClick()
end

function UIGeneralsDetails:OnIntelligenceBarClick()
end

function UIGeneralsDetails:OnLeaderBarClick()
end

function UIGeneralsDetails:OnComStarClick()
end

