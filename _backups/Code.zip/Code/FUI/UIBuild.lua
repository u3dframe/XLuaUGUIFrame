--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIBuild = _G.UIController:Get("UIBuild")

_G.table.mixin(UIBuild, require("FUI/Patch/UIBuildPatch"))

local SceneManager = _G.SceneManager
local BuildManager = _G.BuildManager
local lang = _G.lang

function UIBuild:InitBinds()
    return {
    }
end

function UIBuild:InitVM()
    return {
    }
end

--FIXME:This is automatically generated
--FIXME:If no event to listen, Delete This function
function UIBuild:InitEvents()
end

function UIBuild:BindUI()
	self.BuildInterface = self:GetControl("BuildInterface")
	self.Building = self:GetControl("Building")
	self.BuildBtn = self:GetControl("Building.BuildBtn")
	self.Build = self:GetControl("Building.Build")
	self.UICommonResTop = self:GetControl("UICommonResTop")
	self.Buildlist = self:GetControl("Building.BuildList01")
	self.BuildTitle = self:GetControl("BuildInterface.BuildTitle")
	self.BuildDescribe = self:GetControl("BuildInterface.BuildDescribe")
end

function UIBuild:Start()
	self.isShow = false
    self:AddEventListener(_G.EventKey.CITY_BUILDING_SUCCEED, function()
        self.isShow = true
    end)
	self.spaceClass = self.args.space
	self.spaceInfo = BuildManager:get_space_info_by_id(self.spaceClass.id_)
	self:InitBuildList()
	self:GetControl("BuildIntertitle.TitleTxt").text = lang("UI_BUILDSPEND_BUILD")
	self:ShowBuildImage();
end


function UIBuild:SetSelectedItem()
	local list = UIBuild.Buildlist
	local item = list.touchItem
	local buildType = UIBuild.spaceInfo.allow_build_[UIBuild.curTouchIndex + 1]
	local buildData = BuildManager:get_build_data(buildType)
	local upInfo = buildData:get_update_info_by_level(1)
	local unlock = BuildManager:unlock_proviso_meet(buildData, 1)
	UIBuild.BuildTitle.text = buildData.name_
	UIBuild.BuildDescribe.text = buildData.introduce_
	UIBuild.touchIndex = UIBuild.curTouchIndex
	UIBuild.BuildBtn:GetChild("build_time@title").text = _G.UIUtil.format_time(upInfo.uplong / 1000)
	if unlock then
		item:GetController("build").selectedIndex = 1
		UIBuild.BuildBtn:GetChildAt(0).grayed = false
	else
		item:GetController("build").selectedIndex = 3
		UIBuild.BuildBtn:GetChildAt(0).grayed = true
	end
	self.spaceClass:show_img_by_path(upInfo.path)
end

function UIBuild:ShowBuildImage()
	local buildType = UIBuild.spaceInfo.allow_build_[1]
	local buildData = BuildManager:get_build_data(buildType)
	local upInfo = buildData:get_update_info_by_level(1)
	self.spaceClass:show_img_by_path(upInfo.path)
end

function UIBuild:ListOnClick()
	local list = UIBuild.Buildlist
	local item = list.touchItem
	UIBuild.curTouchIndex = list:GetChildIndex(item)
	if UIBuild.curTouchIndex == UIBuild.touchIndex then
		return
	end
	for i = 1,list.numItems do
		local obj = list:GetChildAt(i - 1)
		local buildType = UIBuild.spaceInfo.allow_build_[i]
		local buildData = BuildManager:get_build_data(buildType)
		local unlock = BuildManager:unlock_proviso_meet(buildData, 1)
		if unlock then
			obj:GetController("build").selectedIndex = 0
		else
			obj:GetController("build").selectedIndex = 2
		end
	end
	self:SetSelectedItem()
end
local function ItemRenderer(idx,obj)
	local buildType = UIBuild.spaceInfo.allow_build_[idx + 1]
	local buildData = BuildManager:get_build_data(buildType)
	local unlock, dependName, minLevel = BuildManager:unlock_proviso_meet(buildData, 1)
	local upInfo = buildData:get_update_info_by_level(1)
	local isAllowBuild, currCount, totalCount = BuildManager:check_build_limit(buildData)
	obj:GetChild("BuildUnlock").text = buildData.name_
	if unlock then
		obj:GetChild("BuildNum").text = string.format( "%d/%d",currCount,totalCount )
		obj:GetController("build").selectedIndex = 0
	else
		obj:GetChild("BuildCondition").text = lang("UI_CONSTRUCTION_BUILD",dependName,minLevel)--留空的是字符串表的key,待配置
		obj:GetController("build").selectedIndex = 2
	end
	obj:GetChild("BuildIcon").url = "art/"..upInfo.path
end
local function ItemProvider(index)
	return "ui://UIBuild/Buildunlock"
end
function UIBuild:InitBuildList()
	local list = self.Buildlist
	list.itemProvider = ItemProvider
	list.itemRenderer = ItemRenderer
	list.onClickItem:Add(function()
		self:ListOnClick()
	end)
	list.numItems = #self.spaceInfo.allow_build_
	self:SetFirstEnter()
end
function UIBuild:SetFirstEnter()
	local list = self.Buildlist
	local item = list:GetChildAt(0)
	local touchIndex = list:GetChildIndex(item)
	local buildType = UIBuild.spaceInfo.allow_build_[touchIndex + 1]
	local buildData = BuildManager:get_build_data(buildType)
	item:GetController("build").selectedIndex = 1
	UIBuild.BuildTitle.text = buildData.name_
	UIBuild.BuildDescribe.text = buildData.introduce_
	local upInfo = buildData:get_update_info_by_level(1)
	UIBuild.BuildBtn:GetChild("build_time@title").text = _G.UIUtil.format_time(upInfo.uplong / 1000)
	self.touchIndex = 0
end

function UIBuild:OnCloseBtnClick()
	if not self.isShow then
        self.spaceClass:hide_build_img()
    end
	_G.SceneController.currentScene:GetCameraController():FocusBack()
	self:Close()
end

function UIBuild:OnBackBtnClick()
	if not self.isShow then
        self.spaceClass:hide_build_img()
    end
	_G.SceneController.currentScene:GetCameraController():FocusBack()
	self:Hide()
end

function UIBuild:OnBuildBtnClick()
	local touchIndex = self.touchIndex
	local buildType = self.spaceInfo.allow_build_[touchIndex + 1]
	local buildData = BuildManager:get_build_data(buildType)
	local unlock = BuildManager:unlock_proviso_meet(buildData, 1)
	if not unlock then
		return
	end
	local buildLevel = 0
	local buildData = BuildManager:get_build_data(buildType)
	local isAllowBuild, currCount, totalCount = BuildManager:check_build_limit(buildData)
	if(currCount < totalCount) then
		_G.UIController:ShowUI("UIBuildUpdate",{space=self.spaceClass,buildType=buildType,level=buildLevel})
	else
		MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_HERO_FULL_LV"))
	end
end

