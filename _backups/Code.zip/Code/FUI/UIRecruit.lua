local UIRecruit = _G.UIController:Get("UIRecruit")
_G.table.mixin(UIRecruit,require("FUI/Patch/TopBannerPatch"))

local Msg = _G.Msg
local lang = _G.lang
local UIUtil = _G.UIUtil
local GameUtil = _G.GameUtil
local ItemManager = _G.ItemManager
local BuildManager = _G.BuildManager
local RecruitManager = _G.RecruitManager
local High = _G.config.RECRUIT_TYPES.HIGH
local Normal = _G.config.RECRUIT_TYPES.COMMON
local RecruitConfig = _G.Database.RecruitConfig

local colorRed = _G.UnityEngine.Color.red

function UIRecruit:Awake()
	self.couponNumColor = self.ItemNum1Txt.color
	self:SetHeroMarkIcon()
	self.LookforNor.onClick:Add(function() self:OpenLockForWind(Normal) end)
	self.LookforHig.onClick:Add(function() self:OpenLockForWind(High) end)
	self.LookforNorReplaceBtn.onClick:Set(function()
		RecruitManager:set_mark_target(Normal)
	end)
	self.LookforHigReplaceBtn.onClick:Set(function()
		RecruitManager:set_mark_target(High)
	end)
end

function UIRecruit:InitBinds()
    return {
    }
end

function UIRecruit:InitVM()
    return {
    }
end

function UIRecruit:InitEvents()
	self:AddEventListener({_G.EventKey.ITEM_CHANGE}, function()
		self:SetNormalRecruitData()
		self:SetHighRecruitData()
		self:SetNormalLookforState()
		self:SetHighLookForState()
	end)
	self:AddEventListener({_G.EventKey.RECRUIT_SET_MARK},function()
		self:SetNormalLookforState()
		self:SetHighLookForState()
	end)
end

function UIRecruit:BindUI()
	self.RecruitListCtrler = self:GetController("RecruitList")
	self.typeCtrler = self:GetController("type")
	self.BuildIntertitle1 = self:GetControl("BuildIntertitle1")
	self.InfoBtn = self:GetControl("InfoBtn")
	self.NumTxt = self:GetControl("NumTxt")
	self.RemainHintHigTxt = self:GetControl("RemainHintHigTxt")
	self.BuyNumHigTxt = self:GetControl("BuyNumHigTxt")
	self.item_numTxt = self:GetControl("item_numTxt")
	self.item_icon = self:GetControl("item_icon")
	self.item_num3Txt = self:GetControl("item_num3Txt")
	self.item_icon2 = self:GetControl("item_icon2")
	self.Recruit10NorBtn = self:GetControl("Recruit10NorBtn")
	self.FreeRecruitBtn = self:GetControl("FreeRecruitBtn")
	self.Recruit1NorBtn = self:GetControl("Recruit1NorBtn")
	self.BlueNumTxt = self:GetControl("BlueNumTxt")
	self.AddBtn = self:GetControl("AddBtn")
	self.ItemNum1Txt = self:GetControl("ItemNum1Txt")
	self.ItemIcom = self:GetControl("ItemIcom")
	self.ItemNum2Txt = self:GetControl("ItemNum2Txt")
	self.Item2Icom = self:GetControl("Item2Icom")
	self.RemainHintNorTxt = self:GetControl("RemainHintNorTxt")
	self.RemainNumNorTxt = self:GetControl("RemainNumNorTxt")
	self.FreetimeTxt = self:GetControl("FreetimeTxt")
	self.LookforNor = self:GetControl("LookforNor")
	self.LookforNorlockCtrler = self:GetControl("LookforNor"):GetController("lock")
	self.LookforNorBgTxt = self:GetControl("LookforNor.BgTxt")
	self.LookforNornumTxt = self:GetControl("LookforNor.numTxt")
	self.LookforNoricon = self:GetControl("LookforNor.icon")
	self.LookforNorReplaceBtn = self:GetControl("LookforNor.ReplaceBtn")
	self.LookforNorLookForTxt = self:GetControl("LookforNor.LookForTxt")
	self.LookforNorChosseHintTxt = self:GetControl("LookforNor.ChosseHintTxt")
	self.LookforNorChangeHintTxt = self:GetControl("LookforNor.ChangeHintTxt")
	self.PreviewHigBtn = self:GetControl("PreviewHigBtn")
	self.PreviewNorBtn = self:GetControl("PreviewNorBtn")
	self.Recruit1HigBtn = self:GetControl("Recruit1HigBtn")
	self.Recruit10HigBtn = self:GetControl("Recruit10HigBtn")
	self.LookforHig = self:GetControl("LookforHig")
	self.LookforHiglockCtrler = self:GetControl("LookforHig"):GetController("lock")
	self.LookforHigBgTxt = self:GetControl("LookforHig.BgTxt")
	self.LookforHignumTxt = self:GetControl("LookforHig.numTxt")
	self.LookforHigicon = self:GetControl("LookforHig.icon")
	self.LookforHigReplaceBtn = self:GetControl("LookforHig.ReplaceBtn")
	self.LookforHigLookForTxt = self:GetControl("LookforHig.LookForTxt")
	self.LookforHigChosseHintTxt = self:GetControl("LookforHig.ChosseHintTxt")
	self.LookforHigChangeHintTxt = self:GetControl("LookforHig.ChangeHintTxt")
	self.UISkillRecruit = self:GetControl("UISkillRecruit")
	self.stateCtrler = self:GetControl("UISkillRecruit"):GetController("state")
	self.PreviewSkillHigBtn = self:GetControl("UISkillRecruit.PreviewSkillHigBtn")
	self.RecruitFree = self:GetControl("UISkillRecruit.RecruitFree")
	self.Recruit10Btn = self:GetControl("UISkillRecruit.Recruit10Btn")
	self.RemFreeTxt = self:GetControl("UISkillRecruit.RemFreeTxt")
	self.RemFreeTimeTxt = self:GetControl("UISkillRecruit.RemFreeTimeTxt")
	self.SkillBookTxt = self:GetControl("UISkillRecruit.SkillBookTxt")
	self.SkillAmountTxt = self:GetControl("UISkillRecruit.SkillAmountTxt")
	self.CountdownTxt = self:GetControl("UISkillRecruit.CountdownTxt")
	self.CountdownTimeTxt = self:GetControl("UISkillRecruit.CountdownTimeTxt")
	self.ComCountdown = self:GetControl("UISkillRecruit.ComCountdown")
	self.Recruit1Btn = self:GetControl("UISkillRecruit.Recruit1Btn")
	self.Recruit1CostItemTxt = self:GetControl("UISkillRecruit.Recruit1CostItemTxt")
	self.Recruit1CostAmountTxt = self:GetControl("UISkillRecruit.Recruit1CostAmountTxt")
	self.Recruit1CostTxt = self:GetControl("UISkillRecruit.Recruit1CostTxt")
end

function UIRecruit:Start()
	--self:SetTitle("招募")
	self:RefreshData()
end

function UIRecruit:RefreshData()
	self:SetNormalRecruitData()
	self:SetHighRecruitData()

	self:SetNormalLookforState()
	self:SetHighLookForState()
	
	self:SetNormalFreeBtnState()
end
--设置普通招募的数据
function UIRecruit:SetNormalRecruitData()
	local costProp = RecruitManager.costProp[Normal].onePrice
	--普通招募令总数量
	self.BlueNumTxt.text = ItemManager:get_count_by_prop(costProp)
	--剩余招募次数
	self.RemainNumNorTxt.text = RecruitManager:get_unused_buy_count(Normal)
	--十连抽招募令花费
	self.ItemNum1Txt.text = RecruitManager.costProp[Normal].tenPrice[3]

	local cnt = ItemManager:get_count_by_prop(costProp)
	if cnt < RecruitManager.costProp[Normal].tenPrice[3] then
		self.ItemNum1Txt.color = UnityEngine.Color.red
	else
		self.ItemNum1Txt.color = self.couponNumColor
	end

	if cnt < costProp[3] then
		self.ItemNum2Txt.color = UnityEngine.Color.red
	else
		self.ItemNum2Txt.color = self.couponNumColor
	end
	self:SetNormalLookforState()
end
function UIRecruit:SetHighRecruitData()
	local costProp = RecruitManager.costProp[High].onePrice
	local curNum = ItemManager:get_count_by_prop(costProp)
	self.NumTxt.text = curNum
	self.BuyNumHigTxt.text = RecruitManager:get_unused_buy_count(High)
	if curNum < RecruitManager.costProp[High].tenPrice[3] then
		self.item_num3Txt.color = UnityEngine.Color.red
	else
		self.item_num3Txt.color = self.couponNumColor
	end
	if curNum < costProp[3] then
		self.item_numTxt.color = UnityEngine.Color.red
	else
		self.item_numTxt.color = self.couponNumColor
	end
end
--设置普通寻访功能的显示
function UIRecruit:SetNormalLookforState()
	local restNum = RecruitManager:get_rest_mark_count(Normal)--剩余多少次数可寻访
	if restNum > 0 then
		self.LookforNorlockCtrler.selectedIndex = 0
		self.LookforNorLookForTxt.text = lang("RECRUIT_FIND_UNLOCK", RecruitManager:get_rest_mark_count(Normal))
		self.LookforNornumTxt.text = _G.string.format( "%d/%d",RecruitConfig.Re_listData[Normal].find_time,
			RecruitManager:get_total_count(Normal))
		return
	end
	if RecruitManager:get_mark_hero_id(Normal) then
		self.LookforNorlockCtrler.selectedIndex = 2
		self:SetHeroMarkIcon()
	else
		self.LookforNorlockCtrler.selectedIndex = 1
	end
end
--设置高级招募寻访显示状态
function UIRecruit:SetHighLookForState()
	local restNum = RecruitManager:get_rest_mark_count(High)
	if restNum > 0 then
		self.LookforHiglockCtrler.selectedIndex = 0
		self.LookforHigLookForTxt.text = lang("RECRUIT_FIND_UNLOCK", RecruitManager:get_rest_mark_count(High))
		self.LookforHignumTxt.text = _G.string.format( "%d/%d",RecruitConfig.Re_listData[High].find_time,
		RecruitManager:get_total_count(High))
		return
	end
	
	if RecruitManager:get_mark_hero_id(High) then
		self.LookforHiglockCtrler.selectedIndex = 2
		self:SetHeroMarkIcon()
	else
		self.LookforHiglockCtrler.selectedIndex = 1
	end
end
--设置寻访功能的英雄头像
function UIRecruit:SetHeroMarkIcon()
	local normalMark = RecruitManager:get_mark_hero_id(Normal)
	if normalMark then
		local hero = _G.HeroManager:get_config(normalMark)
		self.LookforNoricon.url = "art/"..hero.icon
	end
	local highMark = RecruitManager:get_mark_hero_id(High)
	if highMark then
		local hero = _G.HeroManager:get_config(highMark)
		self.LookforHigicon.url = "art/"..hero.icon
	end
end
--设置普通招募免费按钮状态
function UIRecruit:SetNormalFreeBtnState()
	local freeCd = RecruitManager:get_free_cooldown(Normal)
	local ufc = RecruitManager:get_unused_free_count(Normal)
	if freeCd > 0 then--cd中
		self.typeCtrler.selectedIndex = 1
		local TimeEndCall = function()
			self:SetNormalFreeBtnState()
		end
		local TimeCall = function()
			local cd = RecruitManager:get_free_cooldown(Normal)
			--self.FreetimeTxt.text = lang("RECRUIT_FREE_COUNTDOWN", UIUtil.format_time(cd))
			self.FreetimeTxt.text = UIUtil.format_time(cd)
		end
		self:SetEngineTimer("HeroRecuitFreeCD",TimeCall,TimeEndCall,RecruitManager:get_free_cooldown(Normal),1,true)
		return
	end
	if ufc > 0 then--还有免费次数
		self.typeCtrler.selectedIndex = 0
		self.FreeRecruitBtn:GetChild("RemainTimeTxt").text =
			string.format( "(%d/%d)",ufc,RecruitConfig.Re_listData[Normal].daily_free)
		return
	end
	self.typeCtrler.selectedIndex = 2
end

function UIRecruit:OnInfoBtnClick()
end
local function OpenRewardWnd(type, num, items)
	UIRecruit:OpenRewardWnd(type, num, items)
end
--免费招募
function UIRecruit:OnFreeRecruitBtnClick()
	RecruitManager:recruit_free(Normal,OpenRewardWnd)
end
--付费普通招募一次
function UIRecruit:OnRecruit1NorBtnClick()
	RecruitManager:recruit_one(Normal,OpenRewardWnd)
end
--付费普通招募十次
function UIRecruit:OnRecruit10NorBtnClick()
	RecruitManager:recruit_ten(Normal,OpenRewardWnd)
end
	--付费高级招募一次
function UIRecruit:OnRecruit1HigBtnClick()
	RecruitManager:recruit_one(High,OpenRewardWnd)
end
--付费高级招募10次
function UIRecruit:OnRecruit10HigBtnClick()
	RecruitManager:recruit_ten(High,OpenRewardWnd)
end
--打开奖励获得弹窗
function UIRecruit:OpenRewardWnd(type, num, items)
	self:SetNormalRecruitData()
	self:SetHighRecruitData()

	self:SetNormalLookforState()
	self:SetHighLookForState()
	if num == 1 then
		self:SetNormalFreeBtnState()
	end
	_G.UIController:ShowUI("UIFinalGainPop",{drawType = type,drawNum = num,itemList = items})
end

--增加普通招募令
function UIRecruit:OnAddBtnClick()
end
--高级招募预览
function UIRecruit:OnPreviewHigBtnClick()
	_G.UIController:ShowUI("UIPreviewPop",{type = 2})
end
--普通招募预览
function UIRecruit:OnPreviewNorBtnClick()
	_G.UIController:ShowUI("UIPreviewPop",{type = 1})
end
--技能招募预览
function UIRecruit:OnPreviewSkillHigBtnClick()
	_G.UIController:ShowUI("UIPreviewPop",{type = 3})
end
--寻访功能按钮
function UIRecruit:OpenLockForWind(type)
	if RecruitManager:is_mark_available(type) then
		--UIManager.open_window("RecruitFindWindow", nil, type)
		_G.UIController:ShowUI("UIHeroList",{type = 2,selectType = type})
	else
		MsgCenter.send_message(Msg.SHOW_NOTIFY, {
			title = "",
			content = lang("RECRUIT_HINT"),
			buttons = {lang("UI_BASIC_SURE")},
		})
	end
end

function UIRecruit:OnPreviewTipsClick()
end

function UIRecruit:OnRewad10Click()
end

function UIRecruit:OnReward1Click()
end
function UIRecruit:OnBuyAgainBtnClick()
end

function UIRecruit:OnBuyagainBtnClick()
end

function UIRecruit:OnRecruitFreeClick()
end

function UIRecruit:OnRecruit10BtnClick()
end

function UIRecruit:OnRecruit1BtnClick()
end