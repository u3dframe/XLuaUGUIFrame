--This is an automatically generated class by FairyGUI. Please do not modify it.

local UITrainDetail = _G.UIController:Get('UITrainDetail')
Attribute = config.SOLDIER_ATTR
local AttributeConfig = _G.Database.AttributeConfig
local ExistPath = {
	[1] = 4,
	[2] = 3,
	[3] = 4,
	[4] = 4,
	[5] = 4,
	[6] = 4,
	[7] = 5,
	[8] = 5,
}

function UITrainDetail:Awake()
    self.soldierId = self.args.soldierLv
    self.buildID = self.args.buildID
    self.buildInfo = BuildManager:get_build_info_by_id(self.buildID)
    self.soldierAllInfo = SoldierManager:get_soldier_info_by_build_type(self.buildInfo.build_type_)
    self.soldierInfo = self:FindSoldierByLv(self.soldierId)
    self:SelectSoldier()
    self:InitAttribute()
end

function UITrainDetail:GetUnlockSoldier()
    self.unlockSoldier = {}
    for k, v in pairs(self.soldierAllInfo) do
        local isMeet, buildInfo = self:IsUnlock(v)
        if isMeet then
            table.insert(self.unlockSoldier, v)
        end
    end
    table.sort(
        self.unlockSoldier,
        function(x, y)
            return x.lv_ > y.lv_
        end
    )
end

function UITrainDetail:SelectSoldier()
    if not self.soldierInfo then
        return
    end
    local leftShow = self.soldierInfo.id_ > self.soldierAllInfo[1].id_
    local rightShow = self.soldierInfo.id_ < self.soldierAllInfo[#self.soldierAllInfo].id_
    self.ArrowLeftBtn.visible = leftShow
    self.ArrowRightBtn.visible = rightShow
    self:GetUnlockSoldier()
    self:SetContent()
end

function UITrainDetail:SetSoldierSpine()
    self.isSpineLoading = {}
local assetPath = self:GetSpinePath(self.soldierInfo)
_G.GameController.spineController:CreateSkeletonAnimObj(assetPath, function(obj)
    if _G.Slua.IsNull(obj) then
        self.isSpineLoading[self.soldierInfo.id_] = false
        return
    end
    if not _G.Slua.IsNull(self.SoldierIcon) and not _G.Slua.IsNull(self.SoldierIcon.displayObject.gameObject) then
        print("IconGraph.displayObject.name = "..self.SoldierIcon.displayObject.gameObject.name)
        if self.SoldierIcon.displayObject.gameObject.name == "GoWrapper" then
            self.SoldierIcon.displayObject.parent:RemoveChild(self.SoldierIcon.displayObject, true)
        end
    end
    local rect_data = self.soldierInfo.prop_.scale
    local uiSpineScale = self:GetUISpineScale()
    local soliderScale = 0.4
    obj.transform.localScale =  _G.Vector3(uiSpineScale.x*rect_data[1] * soliderScale, uiSpineScale.y*rect_data[1]* soliderScale, 1)
    local goWrapper = _G.UIController:LoadGameObjectToUI(self.SoldierIcon, obj)
    goWrapper.supportStencil = true
    _G.GameController.spineController:PlayAnimation(obj, "animation" , 0 , true, nil)
    if not _G.Slua.IsNull(self.SoldierIcon) then
        self.SoldierIcon.visible = true
    end
    self.isSpineLoading[self.soldierInfo.id_] = false
end)
end


function UITrainDetail:GetSpinePath(soldier)
	local soldierType = soldier.soldier_type_
	local lv = soldier.lv_
	local exist = false
	local existLv = ExistPath[soldierType]
	if existLv == lv then
		exist = true
	end
	local localPath = string.format("Model/Soldier/soldier_type_%d/lv_%d/siji_SkeletonData", soldierType, exist and lv or existLv)
	return localPath
end
function UITrainDetail:SetContent()
    --self.SoldierIcon.url = 'art/' .. self.soldierInfo.half_icon_path_
    self:SetSoldierSpine()
	self.levelTxt.text = lang('UI_SOLDIER_NAME_LV', self.soldierInfo.lv_)
	self.TimerTxt.text=self.soldierInfo:get_drill_max_count()
    self.ComSoldier:GetController('type').selectedIndex = (self.soldierInfo.soldier_type_ - 1)   
    self:SetSkillInfo()
    local isUnlock = SoldierManager:is_unlock(self.soldierInfo)
    if isUnlock then
        self.LeftAmountTxt.visible = true
        self.LeftAmountTxt.text = lang('UI_SOLDIERDES_NUMBER', self.soldierInfo.number_)
    else
        self.LeftAmountTxt.visible = false
    end
    local hasCount = self.soldierInfo.number_ > 0 --功能不一样
    --如果是最大等级
    local length = table.size(self.soldierAllInfo)
    local MaxLv = self.soldierInfo.lv_ >= self.soldierAllInfo[length-1].lv_
    if MaxLv then
        self.HintTxt.text = lang('UI_BASIC_COLOR', config.FONT_COLOR.YELLOW, lang('UI_SOLDIERDES_HINT1'))
        self:GetController('state').selectedIndex = 1
        return
    end
    --如果不能晋升
    local noPromote = self.unlockSoldier[1].lv_ - 1 <= self.soldierInfo.lv_
    if noPromote then
        self.HintTxt.text = lang('UI_BASIC_COLOR', config.FONT_COLOR.GREEN, self:ShowHintNotLock())
        self:GetController('state').selectedIndex = 1
        return
    end
    --如果数量为0
    if self.soldierInfo.number_ <= 0 then
        self.HintTxt.text = lang('UI_BASIC_COLOR', config.FONT_COLOR.RED, lang('UI_SOLDIERDES_HINT2'))
        self:GetController('state').selectedIndex = 1
        return
    end
    --是否在训练中
    local timerExis = SoldierManager:check_soldier_state(self.buildInfo.build_type_)
    if timerExis then
        local txt = lang('UI_SOLDIERs_Hint3', self.buildInfo.name_)
        self.HintTxt.text = lang('UI_BASIC_COLOR', config.FONT_COLOR.RED, txt)
        self:GetController('state').selectedIndex = 1
        return
    end
    --如果可以晋升--------------------------------------------------------------------------TODO 按钮状态转换
    self:GetController('state').selectedIndex = 0
end

function UITrainDetail:InitAttribute()
    self.AttributeList.itemProvider = function()
        return 'ui://eqd07itilsg7d'
    end
    self.AttributeList.itemRenderer = function(idx, obj)
        local attr = self.soldierInfo.attribute_
        obj:GetChild('AttrNameTxt').text = AttributeConfig.AttributeData[idx + 1].name_c
        obj:GetChild('AmountTxt').text = attr[config.SOLDIER_ATTR[idx + 1]]
    end
end

function UITrainDetail:SetSkillInfo()
    if not self.soldierInfo then
        return
    end
    local index = table.size(self.soldierInfo.skill_info_)
    self:GetController('skill').selectedIndex = index - 1
    for i = 1, config.SOLDIER_SKILL_MAX do
        local frontSoldierInfo
        if self.soldierId > 1 then
            frontSoldierInfo = self:FindSoldierByLv(self.soldierId - 1)
        end
        if self.soldierInfo.skill_info_[i] then
            if i == 1 then
                if not frontSoldierInfo or (frontSoldierInfo and not frontSoldierInfo.skill_info_[i]) then
                    self.ComSkillDetail1:GetChild('SkillNameTxt').text = self.soldierInfo.skill_info_[i].name_
                    self.ComSkillDetail1:GetChild('SkillDescriptionTxt').text = self.soldierInfo.skill_info_[i].des_
					self.ComSkillDetail1:GetChild('SkillLevelTxt').text = lang('SKILL_UNLOCK', self.soldierInfo.lv_)
					self.skillIcon1.url="art/"..self.soldierInfo.skill_info_[i].path_
                end
            end
            if i == 2 then
                if not frontSoldierInfo or (frontSoldierInfo and not frontSoldierInfo.skill_info_[i]) then
                    self.ComSkillDetail2:GetChild('SkillNameTxt').text = self.soldierInfo.skill_info_[i].name_
                    self.ComSkillDetail2:GetChild('SkillDescriptionTxt').text = self.soldierInfo.skill_info_[i].des_
					self.ComSkillDetail2:GetChild('SkillLevelTxt').text = lang('SKILL_UNLOCK', self.soldierInfo.lv_)
					self.skillIcon2.url="art/"..self.soldierInfo.skill_info_[i].path_
                end
            end
            if i == 3 then
                if not frontSoldierInfo or (frontSoldierInfo and not frontSoldierInfo.skill_info_[i]) then
                    self.ComSkillDetail3:GetChild('SkillNameTxt').text = self.soldierInfo.skill_info_[i].name_
                    self.ComSkillDetail3:GetChild('SkillDescriptionTxt').text = self.soldierInfo.skill_info_[i].des_
					self.ComSkillDetail3:GetChild('SkillLevelTxt').text = lang('SKILL_UNLOCK', self.soldierInfo.lv_)
					self.skillIcon3.url="art/"..self.soldierInfo.skill_info_[i].path_
                end
            end
        end
    end
end

function UITrainDetail:ShowHintNotLock()
    local soldier = SoldierManager:get_soldier_info_by_id(self.soldierInfo.id_ + 2)
    if soldier then
        local buildType = soldier.build_type_
        local lv = soldier.unlock_
        local build = BuildManager:get_build_info_by_build_type(buildType)
        local str = lang('UI_SOLDIER_PROMOTE_HINT', build.name_, lv, soldier.lv_, soldier.name_)
        return str
    end
end
function UITrainDetail:FindSoldierByLv(lv)
    if not self.soldierAllInfo then
        return
    end
    local obj
    for _, v in pairs(self.soldierAllInfo) do
        if v.lv_ == lv then
            obj = v
            break
        end
    end
    if not obj then
        elog('not found value in table. lv = %s', lv)
    end
    return obj
end

function UITrainDetail:IsUnlock(soldierInfo)
    local buildType = soldierInfo.build_type_
    local buildInfo = BuildManager:get_build_info_by_build_type(buildType)
    if not buildInfo then
        buildInfo = BuildManager:get_build_data(buildType)
        return false, buildInfo
    end
    local dependLv = soldierInfo.unlock_
    return dependLv <= buildInfo.lv_, buildInfo
end
function UITrainDetail:InitBinds()
    return {}
end

function UITrainDetail:InitVM()
    return {}
end

--FIXME:This is automatically generated
--FIXME:If no event to listen, Delete This function
function UITrainDetail:InitEvents()
    self:AddEventListener(
        eventKey or eventKeys,
        function()
        end
    )
end

function UITrainDetail:BindUI()
    self.skillCtrler = self:GetController('skill')
    self.stateCtrler = self:GetController('state')
    self.DetailTop = self:GetControl('DetailTop')
    self.LeftAmountTxt = self:GetControl('LeftAmountTxt')
    self.HintTxt = self:GetControl('HintTxt')
	self.PromoteBtn = self:GetControl('PromoteBtn')
	self.TimerTxt=self:GetControl('PromoteBtn.TimerTxt')
    self.ArrowRightBtn = self:GetControl('ArrowRightBtn')
    self.ArrowLeftBtn = self:GetControl('ArrowLeftBtn')
    self.ComSoldier = self:GetControl('ComSoldier')
    self.character_shadow = self:GetControl('ComSoldier.character_shadow')
    self.SoldierIcon = self:GetControl('ComSoldier.IconGraph')
    self.levelTxt = self:GetControl('ComSoldier.levelTxt')
    self.CloseBtn = self:GetControl('CloseBtn')
    self.AttributeList = self:GetControl('AttributeList')
    self.ComSkillDetail1 = self:GetControl('ComSkillDetail1')
    self.skillIcon1 = self:GetControl('ComSkillDetail1.icon')
    self.SkillDescriptionTxt1 = self:GetControl('ComSkillDetail1.SkillDescriptionTxt')
    self.SkillNameTxt1 = self:GetControl('ComSkillDetail1.SkillNameTxt')
    self.SkillLevelTxt1 = self:GetControl('ComSkillDetail1.SkillLevelTxt')
    self.ComSkillDetail2 = self:GetControl('ComSkillDetail2')
    self.skillIcon2 = self:GetControl('ComSkillDetail2.icon')
    self.SkillDescriptionTxt2 = self:GetControl('ComSkillDetail2.SkillDescriptionTxt')
    self.SkillNameTxt2 = self:GetControl('ComSkillDetail2.SkillNameTxt')
    self.SkillLevelTxt2 = self:GetControl('ComSkillDetail2.SkillLevelTxt')
    self.ComSkillDetail3 = self:GetControl('ComSkillDetail3')
    self.skillIcon3 = self:GetControl('ComSkillDetail3.icon')
    self.SkillDescriptionTxt3 = self:GetControl('ComSkillDetail3.SkillDescriptionTxt')
    self.SkillNameTxt3 = self:GetControl('ComSkillDetail3.SkillNameTxt')
    self.SkillLevelTxt3 = self:GetControl('ComSkillDetail3.SkillLevelTxt')
    self.ComSkillDetailLsit = self:GetControl('ComSkillDetailLsit')
    self.SoldierType = self:GetControl('ComSoldier.n4')
end

function UITrainDetail:Start()
    self.AttributeList.numItems = table.size(self.soldierInfo.attribute_)
end

--FIXME:Write logic Code here!

function UITrainDetail:OnArrowRightBtnClick()
    self.soldierId = self.soldierId + 1
    self.soldierInfo = self:FindSoldierByLv(self.soldierId)
    self.AttributeList.numItems = table.size(self.soldierInfo.attribute_)
    self:SelectSoldier()
end

function UITrainDetail:OnArrowLeftBtnClick()
    self.soldierId = self.soldierId - 1
    self.soldierInfo = self:FindSoldierByLv(self.soldierId)
    self.AttributeList.numItems = table.size(self.soldierInfo.attribute_)
    self:SelectSoldier()
end

function UITrainDetail:OnComSoldierClick()
end

function UITrainDetail:OnPromoteBtnClick()
    if self.soldierInfo and self.buildInfo then
        --士兵id，将要晋升的士兵id，晋升最大数量，建造id
        local next_soldier_id = self:getNextSoldierId()
        _G.UIController:ShowUI(
            'UITrainPromot',
            {
                currSoldierID = self.soldierInfo.id_,
                nextSoldierID = next_soldier_id,
                soldierMaxCnt = self.soldierInfo:get_drill_max_count(),
                buildID = self.buildID
            }
        )
    end
end

function UITrainDetail:getNextSoldierId()
    local next_soldier
    for k, v in ipairs(self.unlockSoldier) do
        if v.soldier_type_ == self.soldierInfo.soldier_type_ then
            next_soldier = v
            break
        end
    end
    return next_soldier.id_
end
function UITrainDetail:OnCloseBtnClick()
    self:Hide()
end

function UITrainDetail:OnComSkillDetail1Click()
end

function UITrainDetail:OnComSkillDetail2Click()
end

function UITrainDetail:OnComSkillDetail3Click()
end
