--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIWareUseItem = _G.UIController:Get("UIWareUseItem")

function UIWareUseItem:Awake()
    self.useType=self.args.useType
    self.ItemID=self.args.ItemID    
    self.ResType=self.args.ResType
    self:InitInfo()
    self:InitSlider()
end
function UIWareUseItem:InitInfo()
	self.itemData=ItemManager:get_item_by_id(self.ItemID)
	self.itemConfig=ItemManager:get_item_prop_by_id(self.ItemID)
    self.icon.url="art/"..self.itemConfig.icon   
    local str=self.itemConfig.usepara[1][3]..self.itemConfig.name
    self.UseTxt.text=lang("Wareroom_1",str)
end

function UIWareUseItem:InitSlider()
    self.ButtonTypeCtrler.selectedIndex=self.useType
    if self.ButtonTypeCtrler.selectedIndex==0 then
        self.maxValue=100
    else
        self.maxValue=self.itemData.count_
        self.ItemNumTxt.text=self.maxValue
    end
    self.useslider.min=1
    self.useslider.max=self.maxValue
    self.useslider.value=self.maxValue
    self.useslider:CheckSlider()
    self:OnSliderChanged()
    local function onSliderChanged()
        self:OnSliderChanged()
    end
    self.useslider.onChanged:Add(onSliderChanged)  
end
function UIWareUseItem:OnSliderChanged()
    if self.ButtonTypeCtrler.selectedIndex==1 then
    local value = self.useslider.value    
    local addCount = UIUtil.res_num_to_str(value*self.itemConfig.usepara[1][3]+ItemManager:GetResByType(self.ResType))
    self.ConfirmTxt.text=lang("Wareroom_2",self.itemConfig.name,addCount)
    self.ItemNumTxt.text=self.maxValue
    else
        self.Buyitem:GetChild("PriceTxt").text=self.itemConfig.quick_buy[3]*self.useslider.value
        self.ItemnameTxt.text=self.itemConfig.usepara[1][3]..self.itemConfig.name
    end
    self.SliderTxt.text= string.strfmt("{1}/{2}",  self.useslider.value, self.maxValue)
end
function UIWareUseItem:InitBinds()
    return {
    }
end

function UIWareUseItem:InitVM()
    return {
    }
end

--FIXME:This is automatically generated
--FIXME:If no event to listen, Delete This function
function UIWareUseItem:InitEvents()
    self:AddEventListener(eventKey or eventKeys, function()

    end)
end

function UIWareUseItem:BindUI()
	self.ButtonTypeCtrler = self:GetController("ButtonType")
	self.HitZoneBtn = self:GetControl("HitZoneBtn")
	self.icon = self:GetControl("ComIcon.icon")
    self.SliderTxt = self:GetControl("ComNum.ItemNumTxt")
	self.Comusenum2 = self:GetControl("Comusenum2")
	self.BuyitemTxt = self:GetControl("BuyitemTxt")
    self.useitemTxt = self:GetControl("useitemTxt")    
	self.CloseBtn = self:GetControl("CloseBtn")
	self.Less = self:GetControl("Less")
	self.PlusBtn = self:GetControl("PlusBtn")
	self.useslider = self:GetControl("useslider")
	self.UseBtn = self:GetControl("UseBtn")
	self.Buyitem = self:GetControl("Buyitem")
	self.ItemNumTxt = self:GetControl("ItemNumTxt")
	self.UseTxt = self:GetControl("UseTxt")
    self.ConfirmTxt = self:GetControl("ConfirmTxt")
	self.ItemnameTxt = self:GetControl("ItemnameTxt")
	self.SafeitemTxt = self:GetControl("SafeitemTxt")
end

function UIWareUseItem:Start()
end

--FIXME:Write logic Code here!
function UIWareUseItem:OnCloseBtnClick()
    self:Hide()
end

function UIWareUseItem:OnLessClick()
    if self.useslider.value > 1 then
        self.useslider.value = self.useslider.value - 1
        self:OnSliderChanged()
    end  
end

function UIWareUseItem:OnPlusBtnClick()
    if self.useslider.value < self.useslider.max then
        self.useslider.value = self.useslider.value + 1
        self:OnSliderChanged()
    end
end
function UIWareUseItem:OnHitZoneBtnClick()
    self:Hide()
end
function UIWareUseItem:OnUseBtnClick()
    local item = ItemManager:get_item_by_id(self.ItemID)
    item:confirm_to_use(self.useslider.value,1)
    self:Hide()
end

function UIWareUseItem:OnBuyitemClick()
   ItemManager:quick_buy(self.ItemID, self.useslider.value)
   self:Hide()
end

