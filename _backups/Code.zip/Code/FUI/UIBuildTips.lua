--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIBuildTips = _G.UIController:Get("UIBuildTips")

function UIBuildTips:InitBinds()
    return {
    }
end

function UIBuildTips:InitVM()
    return {
    }
end

--FIXME:This is automatically generated
--FIXME:If no event to listen, Delete This function
function UIBuildTips:InitEvents()
    self:AddEventListener(eventKey or eventKeys, function()

    end)
end

function UIBuildTips:BindUI()
	self.BuildNoLongerTips1Btn = self:GetControl("BuildNoLongerTips1Btn")
	self.BuildCancelBtn = self:GetControl("BuildCancelBtn")
	self.BuildDetermineBtn = self:GetControl("BuildDetermineBtn")
end

function UIBuildTips:Start()

end

function UIBuildTips:OnBuildNoLongerTips1BtnClick()
end

function UIBuildTips:OnBuildCancelBtnClick()
end

function UIBuildTips:OnBuildDetermineBtnClick()
end

