--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIFinalGainPop = _G.UIController:Get("UIFinalGainPop")

local Config = config
local ItemManager = _G.ItemManager
local HeroManager = _G.HeroManager
local RecruitManager = _G.RecruitManager

function UIFinalGainPop:Awake()
end

function UIFinalGainPop:InitBinds()
    return {
    }
end

function UIFinalGainPop:InitVM()
    return {
    }
end

--FIXME:This is automatically generated
--FIXME:If no event to listen, Delete This function
function UIFinalGainPop:InitEvents()
    -- self:AddEventListener(eventKey or eventKeys, function()

    -- end)
end

function UIFinalGainPop:BindUI()
	self.stateCtrler = self:GetController("state")
	self.RewardAmountCtrler = self:GetController("RewardAmount")
	self.titleTxt = self:GetControl("titleTxt")
	self.BuyagainBtn = self:GetControl("BuyagainBtn")
	self.SureBtn = self:GetControl("SureBtn")
	self.Icon = self:GetControl("Icon")
	self.ItmeNumTxt = self:GetControl("ItmeNumTxt")
	self.buyitem = self:GetControl("buyitem")
	self.itemlist = self:GetControl("itemlist")
end

function UIFinalGainPop:Start()
	self:SetShowType()
	self:SetRewardList()
	self:SetOnceMoreText()
end
--设置再次购买的图标和价格
function UIFinalGainPop:SetOnceMoreText()
	 local prop
	 if self.args.drawNum == 1 then
		prop = RecruitManager.costProp[self.args.drawType].onePrice
	 else
		prop = RecruitManager.costProp[self.args.drawType].tenPrice
	 end
	 _G.dump(prop,"prop")
	 local itemConfig = ItemManager:get_ui_info(prop)
	 _G.dump(itemConfig,"itemConfig")
	 if not itemConfig then
		return
	 end
	 if itemConfig then
		self.Icon.url = string.format("art/%s",itemConfig.icon)
	 end
	 self.ItmeNumTxt.text = prop[3]
end
function UIFinalGainPop:SetShowType()
	if self.args.drawNum == 1 then
		self.RewardAmountCtrler.selectedIndex = 0
	else
		self.RewardAmountCtrler.selectedIndex = 1
	end
end
function UIFinalGainPop:SetRewardList()
	local isfirst = self.itemlist.numItems == 0
	local itemInfoList = self.args.itemList
	local itemNum = #itemInfoList
	dump(itemInfoList,"itemList")
	if itemNum <= 10 then
		self.itemlist.scrollPane.touchEffect = false
	end
	for i = 1,itemNum do
		local item = nil
		if isfirst then
			item = _G.UIPackage.CreateObject("UIRecruit","Item")
		else
			item = self.itemlist:GetChildAt(i - 1)
		end
		if not item then
			elog("奖励列表创建道具item失败")
			return
		end
		self:SetItem(item,itemInfoList[i])
		self.itemlist:AddChild(item)
	end
end
--设置item数据   item为FGUI对象，itemInfo是服务器下发数据
function UIFinalGainPop:SetItem(item,itemInfo)
	local cfg
	if itemInfo[1] == Config.ITEM_ITEM then
		cfg = ItemManager:get_config(itemInfo[2])
	elseif itemInfo[1] == Config.ITEM_HERO then
		cfg = HeroManager:get_config(itemInfo[2])
	end
	if not cfg then
		elog("表数据有误，获得的道具类型--->"..item[1].."    id为---->"..item[2])
		return
	end
	item:GetChild("itemnameTxt").text = cfg.name
	item:GetController("Color").selectedIndex = cfg.quality
	local itemObj = item:GetChild("Item")
	itemObj:GetChild("iconloader").url = string.format( "art/%s",cfg.icon)
	itemObj:GetController("quality").selectedIndex = cfg.quality
	itemObj:GetChild("18Txt").text = item[3]
end
--FIXME:Write logic Code here!
local function DrawCallBack(type, num, items)
	UIFinalGainPop.args.itemList = {}
	UIFinalGainPop.args.itemList = items
	UIFinalGainPop:SetRewardList()
end
function UIFinalGainPop:OnBuyagainBtnClick()
	if self.args.drawNum == 1 then
		RecruitManager:recruit_one(self.args.drawType,DrawCallBack)
	else
		RecruitManager:recruit_ten(self.args.drawType,DrawCallBack)
	end
end

function UIFinalGainPop:OnSureBtnClick()
	_G.UIController:CloseUI("UIFinalGainPop")
end