--This is an automatically generated class by FairyGUI. Please do not modify it.

local UISkillku = _G.UIController:Get("UISkillku")

local SkillManager = _G.SkillManager
local ItemManager = _G.ItemManager

local SelectedType = {
	Skill = 1,
	Frag = 2,
}

function UISkillku:Awake()
	if self.args and self.args.id then
		self.hero = _G.HeroManager:get_active_hero_by_id(self.args.id)
	end
	self.ButtontypeCtrler.selectedIndex = self.hero and 0 or 1
	self.selectedType = {}
	self.selectedID = {}
	self.fragIDs = {}
	self:InitSkillList()
end

function UISkillku:OnDestroy()
	self.hero = nil
	self.selectedType = nil
	self.selectedID = nil
	self.fragIDs = nil
end

function UISkillku:InitBinds()
    return {
		currPage = function(value)
			if value < 0 then return end
			self.vm.skillList = SkillManager:get_sorted_skill_list_by_type(value)
		end,
		selectedIndex = function(value)
			if value < 0 then return end
			if self.selectedType[self.vm.currPage.value] == SelectedType.Skill then
				self.breaktypeCtrler.selectedIndex = 0
				local skill = self.vm.skillList.value[self.vm.selectedIndex.value]
				self.SkillnameTxt.text = skill.cfg_.name
				local desc = skill.cfg_.desc
				if self.hero then
					local sk = self.hero:get_skill_by_pos(self.args.pos)
					desc = SkillManager:get_skill_buff_desc(skill.id_, sk and sk.level or 1, self.hero.id_)
				end
				self.SkilldescTxt.text = desc
				self.skilltypeCtrler.selectedIndex = skill.cfg_.rare > 0 and 0 or 1
				self.SkillIcon.url = string.format("art/%s", skill.cfg_.icon)
			else
				self.breaktypeCtrler.selectedIndex = 1
				local fragID = self.fragIDs[self.vm.currPage.value][self.vm.selectedIndex.value]
				local fragCfg = ItemManager:get_config(fragID)
				local skillCfg, _, _ = SkillManager:get_skill_cfg_by_frag_id(fragID)
				self.skilltypeCtrler.selectedIndex = skillCfg.rare > 0 and 0 or 1
				self.SkillnameTxt.text = fragCfg.name
				self.SkilldescTxt.text = fragCfg.desc
				self.SkillIcon.url = string.format("art/%s", fragCfg.icon)
			end
		end,
		skillList = function(value)
			local ty = self.vm.currPage.value
			if ty < 0 then return end
			if not self.fragIDs[ty] then
				self.fragIDs[ty] = SkillManager:GetSortedSkillFragmentsIDByType(ty)
			end
			local selectedID = self.selectedID[ty]
			local selectedIndex = -1
			if self.selectedType[ty] == SelectedType.SKill then
				for i, v in ipairs(value) do
					if v.id_ == selectedID then
						selectedIndex = i
						break
					end
				end
			elseif self.selectedType[ty] == SelectedType.Frag then
				for i, v in ipairs(self.fragIDs[ty]) do
					if v == selectedID then
						selectedIndex = i
						break
					end
				end
			end
			if selectedIndex < 0 then
				selectedIndex = 1
				if #value > 0 then
					self.selectedType[ty] = SelectedType.Skill
					self.selectedID[ty] = value[1].id_
				else
					self.selectedType[ty] = SelectedType.Frag
					self.selectedID[ty] = self.fragIDs[ty][1]
				end
			end
			self.Skilllist.numItems = #value + #self.fragIDs[ty] + 2
			self.vm.selectedIndex = selectedIndex
		end
    }
end

function UISkillku:InitVM()
    return {
		currPage = -1,
		selectedIndex = -1,
		skillList = {},
    }
end

function UISkillku:InitEvents()
	self:AddEventListener(_G.EventKey.SKILL_BAG, function()
		local args = self.args
		self:Hide()
		_G.UIController:ShowUI("UISkillku", args)
	end)
end

function UISkillku:BindUI()
	self.LabletypeCtrler = self:GetController("Labletype")
	self.ButtontypeCtrler = self:GetController("Buttontype")
	self.breaktypeCtrler = self:GetController("breaktype")
	self.SkillConsiderBtn = self:GetControl("SkillConsiderBtn")
	self.ResolveBtn = self:GetControl("ResolveBtn")
	self.BreakBtn = self:GetControl("BreakBtn")
	self.Comskilldesc = self:GetControl("Comskilldesc")
	self.SkillnameTxt = self:GetControl("Comskilldesc.SkillnameTxt")
	self.SkilldescTxt = self:GetControl("Comskilldesc.SkilldescTxt")
	self.skill_bg = self:GetControl("Comskilldesc.skill_bg")
	self.Skilllist = self:GetControl("Skilllist")
	self.SkillnameTxt = self:GetControl("Comskilldesc.SkillnameTxt")
	self.SkilldescTxt = self:GetControl("Comskilldesc.SkilldescTxt")
	self.skilltypeCtrler = self.skill_bg:GetController("skilltype")
	self.SkillIcon = self:GetControl("Comskilldesc.skill_bg.Skill@icon")
end

function UISkillku:Start()
	self.vm.currPage = self.hero and self.hero.type_ or 1
end

function UISkillku:InitSkillList()
	self.Skilllist.itemProvider = function(idx)
		local index = idx + 1
		if index == 1 or index == #self.vm.skillList.value + 2 then
			return "ui://UISkillku/Comtitlebg"
		end
		return "ui://UISkillku/ComSkillinfo2"
	end
	self.Skilllist.itemRenderer = function(idx, obj)
		local index = idx + 1
		local x = #self.vm.skillList.value + 2
		local selectedType = self.selectedType[self.vm.currPage.value]
		local selectedID = self.selectedID[self.vm.currPage.value]
		if index == 1 then
			obj:GetController("txttype").selectedIndex = 0
		elseif index == x then
			obj:GetController("txttype").selectedIndex = 1
		elseif index < x then
			local skill = self.vm.skillList.value[index - 1]
			obj:GetController("skilltype").selectedIndex = skill:is_rare() and 0 or 1
			obj:GetController("iconcolor").selectedIndex = 0
			obj:GetChild("SkillnameTxt").text = skill.cfg_.name
			obj:GetChild("SkilllevelTxt").text = skill.count_
			obj:GetChild("Skill@icon").url = string.format("art/%s", skill.cfg_.icon)
			local selected = selectedType == SelectedType.Skill and selectedID == skill.id_
			obj:GetController("Selected").selectedIndex = selected and 0 or 1
		else
			local fragID = self.fragIDs[self.vm.currPage.value][index - x]
			local fragCfg = ItemManager:get_config(fragID)
			local cnt = ItemManager:get_count(config.ITEM_ITEM, fragID)
			local skillCfg, _, need = SkillManager:get_skill_cfg_by_frag_id(fragID)
			obj:GetController("skilltype").selectedIndex = skillCfg.rare > 0 and 0 or 1
			obj:GetController("iconcolor").selectedIndex = cnt > 0 and 0 or 1
			obj:GetChild("SkillnameTxt").text = fragCfg.name
			obj:GetChild("SkilllevelTxt").text = string.format("%d/%d", cnt, need)
			obj:GetChild("Skill@icon").url = string.format("art/%s", fragCfg.icon)
			local selected = selectedType == SelectedType.Frag and selectedID == fragID
			obj:GetController("Selected").selectedIndex = selected and 0 or 1
		end
	end
	self.Skilllist.onClickItem:Add(function(context)
		local index = self.Skilllist:GetChildIndex(context.data) + 1
		local skillList = self.vm.skillList.value
		if index == 1 or index == #skillList + 2 then return end
		local ty = self.vm.currPage.value
		if index <= #skillList + 1 then
			self.selectedType[ty] = SelectedType.Skill
			self.selectedID[ty] = skillList[index - 1].id_
			self.vm.selectedIndex = index - 1
		else
			index = index - #skillList - 2
			self.selectedType[ty] = SelectedType.Frag
			self.selectedID[ty] = self.fragIDs[ty][index]
			self.vm.selectedIndex = index
		end
		self.Skilllist.numItems = #self.vm.skillList.value + #self.fragIDs[ty] + 2
	end)
end

function UISkillku:OnSkillConsiderBtnClick()
end

function UISkillku:OnResolveBtnClick()
	_G.UIController:ShowUI("UISkillAutoBreak", {type = self.vm.currPage.value})
end

function UISkillku:OnBreakBtnClick()
	if self.selectedType[self.vm.currPage.value] == SelectedType.Frag then return end
	_G.UIController:ShowUI("UISkillBreak", {id = self.selectedID[self.vm.currPage.value]})
end

function UISkillku:OnColseBtnClick()
	self:Hide()
end

function UISkillku:OnLeaderBtnClick()
	self.vm.currPage = 1
end

function UISkillku:OnIQBtnClick()
	self.vm.currPage = 3
end

function UISkillku:OnGovBtnClick()
	self.vm.currPage = 2
end

function UISkillku:OnSkillStudyBtnClick()
	if self.selectedType[self.vm.currPage.value] == SelectedType.Frag then return end
	local id = self.selectedID[self.vm.currPage.value]
	SkillManager:learn_skill(self.hero.id_, self.args.pos, id)
	self:Hide()
end

