--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIHeroStarUpSuccess = _G.UIController:Get("UIHeroStarUpSuccess")

function UIHeroStarUpSuccess:Awake()
	self.hero = _G.HeroManager:get_active_hero_by_id(self.args.id)
	local starLv, starStage = self.hero:get_star_and_stage()
	self.newData = {
		power = self.hero:get_power(),
		attrs = self.hero:get_attr(),
		maxLv = self.hero:get_max_lv(),
		maxSkillLv = _G.HeroManager:get_hero_skill_max_lv(self.hero.id_, self.hero.star_),
		starLv = starLv,
		starStage = starStage,
	}
	local attrsSnapshot = self.hero:get_attrs_snapshot()
	self.oldData = {
		power = attrsSnapshot.power_,
		attrs = attrsSnapshot.attrs_value_,
		maxLv = attrsSnapshot.max_lv_,
		maxSkillLv = attrsSnapshot.max_skill_lv_,
		starLv = attrsSnapshot.star_lv_,
		starStage = attrsSnapshot.star_stage_,
	}
	self.isStarLvUp = self.oldData.starLv ~= self.newData.starLv
end

function UIHeroStarUpSuccess:InitBinds()
    return {
    }
end

function UIHeroStarUpSuccess:InitVM()
    return {
    }
end

function UIHeroStarUpSuccess:BindUI()
	self.sateCtrler = self:GetController("sate")
	self.ComGeneral_before = self:GetControl("ComGeneral_before")
	self.ComGeneral_after = self:GetControl("ComGeneral_after")
	self.ComData = self:GetControl("ComData")
	self.ComNewData = self:GetControl("ComNewData")
end

function UIHeroStarUpSuccess:Start()
	self.sateCtrler.selectedIndex = self.isStarLvUp and 1 or 0
	self:SetCard(self.ComGeneral_before, self.oldData)
	self:SetCard(self.ComGeneral_after, self.newData)
	self:SetAttrs(self.ComData, self.oldData)
	self:SetAttrs(self.ComNewData, self.newData)
end

function UIHeroStarUpSuccess:SetCard(obj, data)
	obj:GetController("quality").selectedIndex = self.hero.quality_ - 1
	obj:GetController("label").selectedIndex = self.hero.type_ - 1
	obj:GetController("step").selectedIndex = data.starStage
	obj:GetChild("ComStarUp"):GetController("c1").selectedIndex = data.starLv - 1
	obj:GetChild("level").text = lang("UI_HERO_LV2", self.hero.lv_)
	obj:GetChild("Name").text = self.hero.name_
	local str
	if data.starStage == 0 then
        str = lang("UI_HERO_STAR", data.starLv)
    else
        str = lang("UI_HERO_STAR", data.starLv)..lang("UI_HERO_STAGE", data.starStage)
    end
	obj:GetChild("StarStep").text = str
end

function UIHeroStarUpSuccess:SetAttrs(obj, data)
	obj:GetController("sate").selectedIndex = self.isStarLvUp and 1 or 0
	obj:GetChild("overalldata").text = data.power
	local attrTxts = {
		obj:GetChild("leaderdata"),
		obj:GetChild("governdata"),
		obj:GetChild("intelldata"),
	}
	for i, v in ipairs(attrTxts) do
		v.text = data.attrs[i]
	end
	if self.isStarLvUp then
		obj:GetChild("heroilevellimit").text = data.maxLv
		obj:GetChild("skillilevellimit").text = data.maxSkillLv
	end
end

function UIHeroStarUpSuccess:OnCloseBtnClick()
	self:Hide()
end

function UIHeroStarUpSuccess:OnDestroy()
	self.hero = nil
	self.newData = nil
	self.oldData = nil
end
