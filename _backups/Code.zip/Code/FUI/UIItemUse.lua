--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIItemUse = _G.UIController:Get("UIItemUse")

local ItemManager = _G.ItemManager
local lang = _G.lang

function UIItemUse:InitBinds()
    return {
    }
end

function UIItemUse:InitVM()
    return {
    }
end

function UIItemUse:BindUI()
	self.descriptionTxt = self:GetControl("descriptionTxt")
	self.amount = self:GetControl("amount")
	self.SliderBar = self:GetControl("SliderBar")
	self.qualityCtrler = self:GetControl("n8"):GetController("quality")
	self.icon = self:GetControl("n8.icon")
	self.Name = self:GetControl("n8.Name")
end

function UIItemUse:Start()
	self:InitItemInfo()
	self:RefreshUseTxt()
	self:InitSlider()
end

function UIItemUse:InitItemInfo()
	local item = self.args.item
	self.useCount = item.count_
	self.Name.text = item.prop_.name
	self.qualityCtrler.selectedIndex = item.prop_.quality - 1
	self.icon.url = "art/"..item.prop_.icon

	self.inherentRewards = {}
	self.randomRewards = {}
	if not item.prop_.usepara then return end
	if item.prop_.usetype == config.ITEM_USE_TYPES.GAIN_ALL then
		self.inherentRewards = item.prop_.usepara
	elseif item.prop_.usetype == config.ITEM_USE_TYPES.GAIN_RANDOM then
		self.randomRewards = item.prop_.usepara
	elseif item.prop_.usetype == config.ITEM_USE_TYPES.DROP then
		local dropid = item.prop_.usepara[1]
		self.randomRewards = ItemManager:get_drop_data(dropid)
		for i = 2, #item.prop_.usepara do
			table.insert(self.inherentRewards, item.prop_.usepara[i])
		end
	end
end

function UIItemUse:InitSlider()
	local item = self.args.item
	self.amount.text = string.format("%d/%d", self.useCount, item.count_)
	self.SliderBar.min = 1
	self.SliderBar.max = item.count_
	self.SliderBar.value = self.useCount
	local function onSliderChanged()
		self.useCount = self.SliderBar.value
		self.amount.text = string.format("%d/%d", self.useCount, item.count_)
		self:RefreshUseTxt()
	end
	self.SliderBar.onChanged:Add(onSliderChanged)
end

function UIItemUse:RefreshUseTxt()
	local ir = {}
	for _, reward in pairs(self.inherentRewards) do
		local cfg = ItemManager:get_ui_info(reward)
		table.insert(ir, string.format("%s*%s", cfg.name, UIUtil.res_num_to_str(reward[3] * self.useCount)))
	end
	local rr = {}
	for _, reward in pairs(self.randomRewards) do
		local cfg = ItemManager:get_ui_info(reward)
		table.insert(rr, string.format("%s*%s", cfg.name, UIUtil.res_num_to_str(reward[3] * self.useCount)))
	end
	local str1 = lang("ITEM_CONFIRM_TO_USE", self.args.item.prop_.name)
	local str2 = #ir > 0 and string.format("%s %s", lang("ITEM_USE_TO_GAIN"), table.concat(ir, ",")) or ""
	local sep = (#ir > 0 and #rr > 0) and "\n" or ""
	local str3 = #rr > 0 and string.format("%s %s", lang("ITEM_USE_TO_GAIN_RANDOM"), table.concat(rr, ",")) or ""
	self.descriptionTxt.text = string.format("%s\n%s%s%s", str1, str2, sep, str3)
end

function UIItemUse:OnCloseBtnClick()
	self:Hide()
end

function UIItemUse:OnConfirmBtnClick()
	self.args.item:confirm_to_use(self.useCount, self.args.on_success)
	self:Hide()
end

function UIItemUse:OnMinusBtnClick()
	if self.useCount <= 1 then return end
	self.useCount = self.useCount - 1
	self.SliderBar.value = self.useCount
	self.amount.text = string.format("%d/%d", self.useCount, self.args.item.count_)
	self:RefreshUseTxt()
end

function UIItemUse:OnRoundAddBtnClick()
	if self.useCount >= self.args.item.count_ then return end
	self.useCount = self.useCount + 1
	self.SliderBar.value = self.useCount
	self.amount.text = string.format("%d/%d", self.useCount, self.args.item.count_)
	self:RefreshUseTxt()
end
