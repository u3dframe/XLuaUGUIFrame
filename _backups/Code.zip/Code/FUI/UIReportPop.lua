--This is an automatically generated class by FairyGUI. Please do not modify it.

local UIReportPop = _G.UIController:Get("UIReportPop")

local WorldManager = _G.WorldManager

function UIReportPop:Awake()
end

function UIReportPop:InitBinds()
    return {
    }
end

function UIReportPop:InitVM()
    return {
    }
end

function UIReportPop:BindUI()
	self.qualityCtrler = self:GetController("quality")
	self.TopText = self:GetControl("TopText")
	self.yellowBtn = self:GetControl("yellowBtn")
	self.iconloader = self:GetControl("iconloader")
	self.UnionNameTxt = self:GetControl("UnionNameTxt")
	self.PlayerNameTxt = self:GetControl("PlayerNameTxt")
	self.DetectCost = self:GetControl("DetectCost")
	self.CostTxt = self:GetControl("CostTxt")
end

function UIReportPop:Start()
	local obj = self.args.obj
	local cost = WorldManager:GetDetectCost(obj)
	local time = WorldManager:GetDetectTime(obj)
	self.CostTxt.text = string.format("%d\n%s", cost, _G.UIUtil.FormatDuration(time))
	self.PlayerNameTxt.text = string.format("%s\n(%d,%d)", obj.name_, obj.x_, obj.z_)
end

--FIXME:Write logic Code here!

function UIReportPop:OnyellowBtnClick()
	if not WorldManager:enable_battle() then
        MsgCenter.send_message(Msg.SHOW_HINT, lang("EXPEDITION_31"))
        return
    end
	WorldManager:DetectObj(self.args.obj)
	self:Hide()
end

function UIReportPop:OnCloseBtnClick()
	self:Hide()
end
