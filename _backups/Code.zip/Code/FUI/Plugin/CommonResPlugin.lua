local CommonResTopPlugin = {
    __name = "CommonResTopPlugin"
}

_G.CommonResTopPlugin = CommonResTopPlugin

function CommonResTopPlugin:OnInit()
    dump("CommonResTopPlugin:OnInit")
end

function CommonResTopPlugin:OnAfterInitVM(ui, vm)
    if not ui:GetControl("CommonResTop", true) then
        return
    end

    local config = _G.config

    vm.ResInfo = {
        WOOD  = _G.ItemManager:GetResByType(config.ITEM_WOOD ),
        FOOD  = _G.ItemManager:GetResByType(config.ITEM_FOOD),
        STONE = _G.ItemManager:GetResByType(config.ITEM_STONE),
        IRON  = _G.ItemManager:GetResByType(config.ITEM_IRON),

        GOLD  = _G.ItemManager:GetResByType(config.ITEM_GOLD),
        GEM  = _G.ItemManager:GetResByType(config.ITEM_GEM),
    }
    -- self:AssetsChangeAni(ui,config.ITEM_STONE,1000)
end

local animationSwitch = true

function CommonResTopPlugin:OnAfterInitBinds(ui)
    if not ui:GetControl("CommonResTop", true) and true then
        return
    end
    ui.AddMoneyBtn       = ui:GetControl("CommonResTop.AddMoneyBtn")
    ui.AddGoldBtn        = ui:GetControl("CommonResTop.AddGoldBtn")

    ui.MoneyBtn          = ui:GetControl("CommonResTop.MoneyBtn")
    ui.GoldBtn           = ui:GetControl("CommonResTop.GoldBtn")
    ui.IronBtn           = ui:GetControl("CommonResTop.IronBtn")
    ui.StoneBtn          = ui:GetControl("CommonResTop.StoneBtn")
    ui.WoodBtn           = ui:GetControl("CommonResTop.WoodBtn")
    ui.FoodBtn           = ui:GetControl("CommonResTop.FoodBtn")

    ui.vm.ResInfo.WOOD.rx:subscribe(function(value)
        ui.WoodBtn.title = _G.UIUtil.res_num_to_str(value)
    end)

    ui.vm.ResInfo.FOOD.rx:subscribe(function(value)
        ui.FoodBtn.title = _G.UIUtil.res_num_to_str(value)
    end)

    ui.vm.ResInfo.STONE.rx:subscribe(function(value)
        ui.StoneBtn.title = _G.UIUtil.res_num_to_str(value)
    end)

    ui.vm.ResInfo.IRON.rx:subscribe(function(value)
        ui.IronBtn.title = _G.UIUtil.res_num_to_str(value)
    end)

    ui.vm.ResInfo.GOLD.rx:subscribe(function(value)
        ui.MoneyBtn.title = _G.UIUtil.res_num_to_str(value)
    end)

    ui.vm.ResInfo.GEM.rx:subscribe(function(value)
        ui.GoldBtn.title = _G.UIUtil.res_num_to_str(value)
    end)

    ui:AddEventListener(_G.EventKey.RESOURCE_CHANGE, function(changeData)
        if not animationSwitch then
            return
        end
        self:OnAfterInitVM(ui, ui.vm)
        self:ResoureChange(ui,changeData)

        if type(ui.OnResouceChange) == "function" then
            ui.OnResouceChange(ui, changeData)
        end
    end)

    function ui:OnWoodBtnClick()
        _G.UIController:ShowUI('UIWareroom',{jumpIndex=0})
    end

    function ui:OnFoodBtnClick()
        _G.UIController:ShowUI('UIWareroom',{jumpIndex=1})
    end

    function ui:OnStoneBtnClick()
        _G.UIController:ShowUI('UIWareroom',{jumpIndex=2})
    end

    function ui:OnIronBtnClick()
        _G.UIController:ShowUI('UIWareroom',{jumpIndex=3})
    end

    function ui:OnMoneyBtnClick()
        print("OnMoneyBtnClick")
    end

    function ui:OnGoldBtnClick()
        print("OnGoldBtnClick")
    end
end


function CommonResTopPlugin:NoAnimation()
    animationSwitch = false
end

function CommonResTopPlugin:RecoverAnimation()
    animationSwitch = true
end

function CommonResTopPlugin:ResoureChange(ui,changeData)
    local list = changeData.changeData
    for _, value in ipairs(list) do
        local id = value.id
        local changeNum = type(value.change) == "table" and value.change[2] or value.change
        self:AssetsChangeAni(ui, id, changeNum)
    end
end
--资源变化调用动画
local function SetPlayAni(aniItem,playAniItem,num)--调用动画，aniIten的位置是playAniItam要移动到的位置
    local aniTime = 1.5
    local slidingDistance = 50
    local aniItemY = aniItem.y
    if num > 0 then
        playAniItem:SetXY(aniItem.x,aniItemY + slidingDistance)
        playAniItem:TweenMoveY(aniItemY,aniTime)
    else
        playAniItem:SetXY(aniItem.x,aniItem.y)
        playAniItem:TweenMoveY(aniItem.y + slidingDistance,aniTime)
    end
    StartCoroutine(function ()
        Yield(WaitForSeconds(aniTime))
        playAniItem:Dispose()
        playAniItem = nil
    end)
end
--type 调用类型，num，数量
function CommonResTopPlugin:AssetsChangeAni(ui,itemType,num)
    local config = _G.config
    local aniItem = nil
    local itemName = ""
    if itemType == config.ITEM_WOOD then
        aniItem = ui.WoodBtn
        itemName = "WoodBtn"
    elseif itemType == config.ITEM_FOOD then
        aniItem = ui.FoodBtn
        itemName = "FoodBtn"
    elseif itemType == config.ITEM_STONE then
        aniItem = ui.StoneBtn
        itemName = "StoneBtn"
    elseif itemType == config.ITEM_IRON then
        aniItem = ui.IronBtn
        itemName = "IronBtn"
    elseif itemType == config.ITEM_GEM then
        aniItem = ui.GoldBtn
        itemName = "GoldBtn"
    elseif itemType == config.ITEM_GOLD then
        aniItem = ui.MoneyBtn
        itemName = "MoneyBtn"
    end
    local playAniItem = _G.UIPackage.CreateObject("CommonButton",itemName)
    if not playAniItem then
        dump("CommonResTopPlugin:AssetsChangeAni:创建移动的item失败") return
    end
    ui:GetControl("CommonResTop"):AddChild(playAniItem)
    if num > 0 then
        playAniItem.title = string.format( "+%d", num)
    else
        playAniItem.title = num
    end
    if num > 0 then
        playAniItem:GetChild("title").color = UnityEngine.Color.green
    else
        local result,color = UnityEngine.ColorUtility.TryParseHtmlString("#DCC689")
        playAniItem:GetChild("title").color = color
    end
    SetPlayAni(aniItem,playAniItem,num)
end
return CommonResTopPlugin