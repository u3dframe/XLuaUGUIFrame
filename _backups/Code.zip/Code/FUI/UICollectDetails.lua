--This is an automatically generated class by FairyGUI. Please do not modify it.

    local UICollectDetails = _G.UIController:Get('UICollectDetails')

    function UICollectDetails:Awake()
        self.obj = self.args.obj
        self.soldierList = self.args.soldierList
        self.HeroList = self.args.HeroList
        self:InitCollectInfo()
        self:InitSoldierInfo()
        self:InitHeroInfo()
    end
    
    function UICollectDetails:InitBinds()
        return {}
    end
    
    function UICollectDetails:InitVM()
        return {}
    end
    function UICollectDetails:InitCollectInfo()
        local prop = self.obj:get_prop()
        local path = string.gsub(prop.model, 'Sprites/', '')
        self.ResourceField.url = 'art/' .. path
        self.CollectNameTxt.text = self.obj:get_name()
        self.CollectLvTxt.text = lang('UI_HERO_LV2', prop.level)
        self.CoordinateTxt.text = lang('EXPEDITION_1') .. self.obj.x_ .. ',' .. self.obj.z_
        self.AddBtn.visible = true
        if WorldManager.respoint_buff_ then
            local time = WorldManager.respoint_buff_.ti - Net.server_time()
            if time < 0 then
                time = 0
            end
            self.AddTimeTxt.text = lang('RESPOINT_8') .. UIUtil.format_time(time)
            if prop.type == config.ITEM_GOLD then
                self.AddBtn.visible = false
                self.AddTimeTxt.text = lang('RESPOINT_24')
            else
                self.AddTimeTxt.text = lang('RESPOINT_8') .. UIUtil.format_time(time)
            end
        else
            self.AddTimeTxt.text = lang('RESPOINT_8') .. '00:00:00'
        end
        local server_speed = self.obj.speed_ * 3600
        local base_speed = self.obj:get_prop().speed * 3600
        local delta = server_speed - base_speed
        local str1 = lang('RESPOINT_6') .. lang('RESPOINT_2', base_speed)
        local str2 = lang('UI_COLLECT_ADD', delta)
        self.CollectionSpeedTxt.text = str1
        self.AddSpeedTxt.text = str2
        self:AddTimer()
        self.PlayerNameTxt.text = self.obj.name_
        local count = 0
        for _, v in ipairs(self.soldierList) do
            count = count + v[2]
        end
        self.PlayerInforTxt.text = lang('UI_COLLECT_NUMBER', count)
    end
    
    --刷新时间
    function UICollectDetails:AddTimer()
        if self.time_count_ then
            LuaTimer.Delete(self.time_count_)
            self.time_count_ = nil
        end
        self.time_count_ =
            LuaTimer.Add(
            0,
            100,
            function()
                local num = self.obj:get_res_num()
                self.TotalTxt.text = lang('RESPOINT_5') .. num
                self.CollectAmountTxt.text = lang('UI_COLLECT_AMOUNT', math.floor(self.obj.all_cnt_ - num))
                if WorldManager.respoint_buff_ then
                    local time = WorldManager.respoint_buff_.ti - Net.server_time()
                    if time < 0 then
                        time = 0
                    end
                    self.AddTimeTxt.text = lang('RESPOINT_8') .. UIUtil.format_time(time)
                end
            end
        )
    end
    function UICollectDetails:InitSoldierInfo()
        self.CollectDetailsList.itemProvider = function()
            return 'ui://igzs501ofedm10'
        end
        self.CollectDetailsList.itemRenderer = function(idx, obj)
            local soldier = self.soldierList[idx + 1]
            local prop = SoldierManager:get_soldier_prop_by_id(soldier[1])
            obj:GetChild('TroopsTxt').text = lang('RESPOINT_3', prop.lv, prop.name)
            obj:GetChild('SurvivalTxt').text = lang('UI_FORT_02') .. soldier[2]
        end
    end
    function UICollectDetails:InitHeroInfo()
        local heroList = self.HeroList
        UIUtil.SetHeroHead(self.ComHeroheadMain,nil,nil,true)
        UIUtil.SetHeroHead(self.ComHeroheadVice,nil,nil,true)
        table.sort(
            heroList,
            function(x, y)
                return x.pos_ < y.pos_
            end
        )
        if heroList and #heroList > 0 then
            for _, v in ipairs(heroList) do
                if v.pos_ == 1 then
                    UIUtil.SetHeroHead(self.ComHeroheadMain, v, 0)
                    self:SetHeroInfo(self.ComHeroheadMain, v)
                else
                    UIUtil.SetHeroHead(self.ComHeroheadVice, v, 1)
                    self:SetHeroInfo(self.ComHeroheadVice, v)
                end
            end
        end
    end
    
    function UICollectDetails:SetHeroInfo(component, hero)
        component.onClick:Set(
            function()
                _G.UIController:ShowUI('UIGeneralsDetails', {hero = hero})
            end
        )
    end
    function UICollectDetails:InitEvents()
        self:AddEventListener(
            _G.EventKey.WORLD_RESPOINT_DELETE,
            function()
                self:ReceiveChange()
            end
        )
        self:AddEventListener(
            _G.EventKey.WORLD_RESPOINT_REFRESH,
            function()
                self:ReceiveChange()
            end
        )
        self:AddEventListener(
            _G.EventKey.RESPOINT_REFRESH_TIME,
            function()
                self:InitCollectInfo()
            end
        )
    end
    function UICollectDetails:ReceiveChange(arg)
        if self.obj.idx_ ~= arg.id then
            return
        end
        self:Hide()
    end
    function UICollectDetails:OnDestroy()
        self:RemoveEventListener()
        self:CloseTimer()
    end
    function UICollectDetails:CloseTimer()
        if self.time_count_ then
            LuaTimer.Delete(self.time_count_)
            self.time_count_ = nil
        end
    end
    function UICollectDetails:BindUI()
        self.CloseBtn = self:GetControl('CloseBtn')
        self.CollectNameTxt = self:GetControl('CollectName')
        self.CollectLvTxt = self:GetControl('CollectLv')
        self.TotalTxt = self:GetControl('TotalTxt')
        self.ResourceField = self:GetControl('ResourceField')
        self.CoordinateTxt = self:GetControl('CoordinateTxt')
        self.PlayerInforTxt = self:GetControl('PlayerInforTxt')
        self.ComHeroheadMain = self:GetControl('ComHeroheadMain')
        self.ComHeroheadVice = self:GetControl('ComHeroheadVice')
        self.ComStarMain = self:GetControl('ComStarMain')
        self.ComStarVice = self:GetControl('ComStarVice')
        self.CollectDetailsList = self:GetControl('CollectDetailsList')
        self.CollectionSpeedTxt = self:GetControl('CollectionSpeedTxt')
        self.AddSpeedTxt = self:GetControl('AddSpeedTxt')
        self.CollectAmountTxt = self:GetControl('CollectAmountTxt')
        self.AddTimeTxt = self:GetControl('AddTimeTxt')
        self.AddBtn = self:GetControl('AddBtn')
        self.PlayerNameTxt = self:GetControl('PlayerNameTxt')
    end
    function UICollectDetails:Start()
        self.CollectDetailsList.numItems = table.size(self.soldierList)
    end
    --FIXME:Write logic Code here!
    
    function UICollectDetails:OnCloseBtnClick()
        self:Hide()
    end
    
    function UICollectDetails:OnAddBtnClick()
        _G.UIController:ShowUI('UIAcquisitionSpeed', {armyData = self.obj})
    end
    