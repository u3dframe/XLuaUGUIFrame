--This is an automatically generated class by FairyGUI. Please do not modify it.

    local UIWareroom = _G.UIController:Get('UIWareroom')
    local BasicConfig = _G.Database.BasicConfig
    local resType = {
        [0] = BasicConfig.BasicData.woodsort,
        [1] = BasicConfig.BasicData.foodsort,
        [2] = BasicConfig.BasicData.stonesort,
        [3] = BasicConfig.BasicData.ironsort
    }
    _G.table.mixin(UIWareroom, require('FUI/Patch/TopBannerPatch'))
    function UIWareroom:Awake()
        self.buildInfo = BuildManager:get_build_info_by_build_type(config.BUILD_TYPE.WAREROOM)
        self.oneKeyType = 1
        self.protecedInfo = self.buildInfo:get_update_info_by_level(self.buildInfo.lv_)
        self:SetTitle(self:GetBuildName())
        self:InitResList()
        local jumpIndex=self.args.jumpIndex
        if jumpIndex then
            self:OnResClick(jumpIndex)
        end
    end
    function UIWareroom:GetBuildName()
        return self.buildInfo and self.buildInfo.name_
    end
    function UIWareroom:InitBinds()
        return {}
    end
    
    function UIWareroom:InitVM()
        return {}
    end
    
    --FIXME:This is automatically generated
    --FIXME:If no event to listen, Delete This function
    function UIWareroom:InitEvents()
        self:AddEventListener(
            _G.EventKey.ITEM_CHANGE,
            function()
                self.ResourceList.numItems = table.size(resType[self.ButtontypeCtrler.selectedIndex])
                self:SetResInfo()
                self:RefreshUseBtn()
            end
        )
    end
    function UIWareroom:OnDestroy()
        self:RemoveEventListener()
    end
    function UIWareroom:InitResList()
        self:SetResInfo()
        self:RefreshUseBtn()
        self.ResourceList.itemProvider = function(index)
            return 'ui://7xo94zu0c7fxp'
        end
        self.ResourceList.itemRenderer = function(idx, obj)
            local itemID = resType[self.ButtontypeCtrler.selectedIndex][idx + 1]
            local itemData = ItemManager:get_item_by_id(itemID)
            local itemConfig = ItemManager:get_item_prop_by_id(itemID)
            obj:GetChild('icon').url = 'art/' .. itemConfig.icon
            obj:GetChild('WoodNumTxt').text = itemData and itemData.count_ or 0
            obj:GetChild('WoodNameTxt').text = itemConfig.name .. itemConfig.label
            obj:GetChild('n3').text = itemConfig.desc
            obj:GetController('status').selectedIndex = itemData and 0 or 1
            if not itemData then
                obj:GetChildByPath('n7.PriceTxt').text = itemConfig.quick_buy[3]
                obj:GetChild('n7').onClick:Set(_G.partial(self.UseBtnClick, self))
            else
                obj:GetChild('UseBtn').onClick:Set(_G.partial(self.UseBtnClick, self))
            end
        end
    end
    function UIWareroom:UseBtnClick(context)
        local resIndex = self.ResourceList:GetChildIndex(context.sender.parent)
        local itemID = resType[self.ButtontypeCtrler.selectedIndex][resIndex + 1]
        local args = {}
        local itemData = ItemManager:get_item_by_id(itemID)
        args.useType = itemData and 1 or 0
        args.ItemID = itemID
        args.ResType= self.oneKeyType
        _G.UIController:ShowUI('UIWareUseItem', args)
    end
    function UIWareroom:BindUI()
        self.ButtontypeCtrler = self:GetController('Buttontype')
        self.WaretypeCtrler = self:GetController('Waretype')
        self.UseBtn = self:GetControl('UseBtn')
        self.ResourcesTxt = self:GetControl('ResourcesTxt')
        self.NoSafeTxt = self:GetControl('NoSafeTxt')
        self.SafeTxt = self:GetControl('SafeTxt')
        self.icon = self:GetControl('ComBox.icon')
        self.ResourceList = self:GetControl('ResourceList')
        self.InfoBtn = self:GetControl('InfoBtn')
        self.Wood = self:GetControl('Wood')
        self.Food = self:GetControl('Food')
        self.Stone = self:GetControl('Stone')
        self.Iron = self:GetControl('Iron')
        self.Close1Btn = self:GetControl('Close1Btn')
        self.ProtectionTxt = self:GetControl('ProtectionTxt')
        self.ProtectionDesc = self:GetControl('ProtectionDesc')
        self.WareTxt = self:GetControl('WareTxt')
        self.WareDesc = self:GetControl('WareDesc')
        self.NoProtectTxt = self:GetControl('NoProtectTxt')
        self.NoProtectDesc = self:GetControl('NoProtectDesc')
        self.ComWareType = self:GetControl('ComWareType')
    end
    
    function UIWareroom:SetResInfo()
        local itemID = resType[self.ButtontypeCtrler.selectedIndex][1]
        self.icon.url = 'art/' .. ItemManager:get_item_prop_by_id(itemID).icon
        local unSafeRes = ItemManager:GetUnSafeResByType(self.ButtontypeCtrler.selectedIndex + 1)
        local protectedMax = tonumber(self.protecedInfo.moredetails[self.oneKeyType + 2]) --最大保护量
        local protectedRes = unSafeRes <= protectedMax and unSafeRes or protectedMax
        local unSafeNum = (unSafeRes - protectedMax) <= 0 and 0 or unSafeRes - protectedMax
        self.ResourcesTxt.text =lang("Wareroom_3",
         UIUtil.res_num_to_str(ItemManager:GetResByType(self.ButtontypeCtrler.selectedIndex + 1)))
        self.NoSafeTxt.text = lang("Wareroom_4",UIUtil.res_num_to_str(unSafeNum))
        self.SafeTxt.text = lang("Wareroom_5",UIUtil.res_num_to_str(protectedRes) .. '/' .. UIUtil.res_num_to_str(protectedMax))
    end
    function UIWareroom:InitResProtected()
        local unSafeRes = ItemManager:GetUnSafeResByType(self.ButtontypeCtrler.selectedIndex + 1)
        local protectedMax = tonumber(self.protecedInfo.moredetails[self.oneKeyType + 2]) --前两位暂时没用
        local protectedRes = unSafeRes <= protectedMax and unSafeRes or protectedMax
        self.ProtectionTxt.text = lang("Wareroom_6",
        UIUtil.res_num_to_str(ItemManager:GetSafeResByType(self.ButtontypeCtrler.selectedIndex + 1))) 
        self.WareTxt.text = lang("Wareroom_5",UIUtil.res_num_to_str(protectedRes) .. '/' .. UIUtil.res_num_to_str(protectedMax))
        local unSafeNum = (unSafeRes - protectedMax) <= 0 and 0 or unSafeRes - protectedMax
        self.NoProtectTxt.text =lang("Wareroom_4",UIUtil.res_num_to_str(unSafeNum))
    end
    function UIWareroom:Start()
        self.WaretypeCtrler.selectedIndex = 1
        self.ResourceList.numItems = table.size(resType[self.ButtontypeCtrler.selectedIndex])
    end
    
    function UIWareroom:RefreshUseBtn()
        local useDatas = self:GetUseDatas()
        self.UseBtn.visible= #useDatas>0 or false
    end
    --FIXME:Write logic Code here!
    function UIWareroom:OnUseBtnClick()
        local useDatas = self:GetUseDatas()
        if #useDatas > 0 then
            _G.UIController:ShowUI('UIWareTips', {oneKeyType = self.oneKeyType, itemDatas = useDatas})
        else
            MsgCenter.send_message(Msg.SHOW_HINT, lang('UI_MAIN_UNOPEN'))
        end
    end
    
    function UIWareroom:GetUseDatas()
        local useDatas = {}
        for _, v in ipairs(resType[self.ButtontypeCtrler.selectedIndex]) do
            local itemData = ItemManager:get_item_by_id(v)
            if itemData then
                table.insert(useDatas, itemData)
            end
        end
        return useDatas
    end
    function UIWareroom:OnWoodClick()
        if self.currentType ~= 0 then
            self:OnResClick(0)
        end
    end
    function UIWareroom:OnFoodClick()
        if self.currentType ~= 1 then
            self:OnResClick(1)
        end
    end
    function UIWareroom:OnStoneClick()
        if self.currentType ~= 2 then
            self:OnResClick(2)
        end
    end
    
    function UIWareroom:OnIronClick()
        if self.currentType ~= 3 then
          self:OnResClick(3)
        end
    end
    function UIWareroom:OnResClick(index)
        self.ButtontypeCtrler.selectedIndex = index
        self.oneKeyType = index + 1
        self:SetResInfo()
        self:RefreshUseBtn()
        self.ResourceList.numItems = table.size(resType[self.ButtontypeCtrler.selectedIndex])
    end
    function UIWareroom:OnInfoBtnClick()
        self.WaretypeCtrler.selectedIndex = 0
        self:InitResProtected()
    end
    function UIWareroom:OnClose1BtnClick()
        self.WaretypeCtrler.selectedIndex = 1
    end
    