local UIRandomShop = _G.UIController:Get("UIRandomShop")
_G.table.mixin(UIRandomShop, require("FUI/Patch/TopBannerPatch"))

local lang = _G.lang
local UIUtil = _G.UIUtil
local Net = _G.Net
local ItemManager = _G.ItemManager
local UIController = _G.UIController
local indexer = _G.Indexer.New()
local EventKey = _G.EventKey

local ITEM_GROUP_COUNT = 4
local ITEM_LIST_COUNT  = 4
local basic

function UIRandomShop:Awake()
	self.randomShop = _G.BuildManager:GetRandomShop()
	basic = self.randomShop:GetBasic()
end

local SliderSetting = {
	Min = 21,
	Max = 79
}

local Total = SliderSetting.Max - SliderSetting.Min

function UIRandomShop:InitBinds()
    return {
		intimacy = function(value)
			local str = self:StrFormat(value, basic.intimacy_limit, lang("UI_RANDOMSHOP_INTIMACY"))
			self.intimacyTxt.text = str
			local mapValue = value/self.hertSlider.max*Total + SliderSetting.Min
			self.hertSlider.value = mapValue
		end,
		todayCost = function(value)
			local str = self:StrFormat(value, basic.cost_limit, lang("UI_RANDOMSHOP_CONSUME"))
			self.todayCostTxt.text = str
		end,
		todayRefresh = function(value)
			local str = self:StrFormat(value, basic.refresh_limit, lang("UI_RANDOMSHOP_REFRESH_TIMES"))
			self.todayRefreshTxt.text = str
		end,
		openTime = function(value)
			local str = self:StrFormat(value, basic.times, lang("UI_RANDOMSHOP_TODYGOODS"))
			self.openTimeTxt.text = str
		end,
		remainingTime = function(value)
			self.remainTimeTxt.text = UIUtil.format_time(value)
		end,
		panelType = function(panelType)
			self.panelCtrler.selectedIndex = panelType
			self:SetPanel(panelType)
		end,
    }
end

local DEFAULT_INTERGET = 0
local PanelType = {
	Normal  = indexer(-1),
	NoGoods = indexer()
}

function UIRandomShop:InitVM()
    return {
		intimacy  = DEFAULT_INTERGET,
		todayCost = DEFAULT_INTERGET,
		todayRefresh = DEFAULT_INTERGET,
		openTime = DEFAULT_INTERGET,
		remainingTime = DEFAULT_INTERGET,
		panelType = PanelType.NoGoods,
    }
end
function UIRandomShop:InitEvents()
    self:AddEventListener(EventKey.CITY_RANDOM_SHOP_UPDATE, function(isClose)
		if isClose == 1 then
			self:Close()
			return
		end
		self:RefreshUI()
    end)
end

function UIRandomShop:BindUI()
	self.panelCtrler = self:GetController("state")
	self.todayGoodsCount = self:GetControl("ComNoGoods.TimeCountTxt")

	self.intimacyTxt = self:GetControl("ComMain.IntimacyTxt")
	self.todayCostTxt = self:GetControl("ComMain.TodayCostTxt")
	self.remainTimeTxt = self:GetControl("ComMain.RemainTimeTxt")
	self.todayRefreshTxt = self:GetControl("ComMain.TodayRefreshTxt")
	self.openTimeTxt = self:GetControl("ComMain.OpenTimeTxt")
	self.hertSlider = self:GetControl("ComMain.RewardBtn.ProgressBar")
	self.sureBtn = self:GetControl("ComMain.SureBtn")
end

function UIRandomShop:Start()
	self:SetTitle(lang("EXPLAIN_18"))
	self:RefreshUI()
end

function UIRandomShop:RefreshUI()
	if not self.randomShop then
        return
	end
	local isOpen = self.randomShop:IsOpen()
	self.vm.panelType = isOpen and PanelType.Normal or PanelType.NoGoods
end

function UIRandomShop:SetPanel(panelType)
	if panelType == PanelType.NoGoods then
		self.todayGoodsCount.text = self:StrFormat(self.randomShop.currTimes, basic.times, "今日已上货：")
		return
	end
	self.hertSlider.min = 0
	self.hertSlider.max = basic.intimacy_limit
	self:RefreshBtn()
	self:SetSomeTxt()
	self:RefreshItems()
end

local RefreshBtnType = {
	Free  = indexer(-1),
	Cost  = indexer(),
	Limit = indexer()
}

function UIRandomShop:RefreshBtn()
	local stateCtrl = self.sureBtn:GetController("state")
	local canRefresh = self.randomShop:EnableRefresh()
	if not canRefresh then
		stateCtrl.selectedIndex = RefreshBtnType.Limit
		self.sureBtn.enabled = false
		return
	end

	self.sureBtn.enabled = true
	local price = self.randomShop:GetRefreshPrice()
	local isFree = self.randomShop:IsFreeRefresh()
	if isFree then
		self.sureBtn:GetChild("FreeTxt").text = price
		stateCtrl.selectedIndex = RefreshBtnType.Free
		return
	end

	self.sureBtn:GetChild("CostTxt").text = price
	stateCtrl.selectedIndex = RefreshBtnType.Cost
end

function UIRandomShop:SetSomeTxt()
	self.vm.todayCost = self.randomShop.currConsume
	self.vm.openTime = self.randomShop.currTimes
	self:RefreshIntimacy()
	self:RefreshTimes()
	self:PlayTimer()
end

function UIRandomShop:RefreshTimes()
	self.vm.todayRefresh = self.randomShop.currRefresh
end

function UIRandomShop:RefreshIntimacy()
	self.vm.intimacy = self.randomShop.currIntimacy
end

local ItemType = {
	Normal  = indexer(-1),
	Soldout = indexer()
}

function UIRandomShop:RefreshItems()
	local list = self.randomShop:GetPropList()
    if not list then
		dump(list, "callback can not nil")
		return
	end
	local labels = self.randomShop:GetItemdLabel()
	for groupIndex = 1, ITEM_GROUP_COUNT do
		local itemGroup = self:GetControl(string.format("ComMain.ComList%d", groupIndex))
		itemGroup:GetChild("Text").text = labels[groupIndex]
		for i = 1, ITEM_LIST_COUNT do
			local itemData = list[groupIndex][i]
			local itemObj = itemGroup:GetChild(string.format("ComItem%d", i))
			self:SetItem(itemData, itemObj)
		end
	end
end

function UIRandomShop:SetItem(itemData, itemObj)
	local prop = itemData.prop
	local items = itemData.prop.items
	local cfg = ItemManager:get_ui_info({items[1], items[2]})
	local soldstate = itemObj:GetController("soldstate")
	soldstate.selectedIndex = itemData.enable and ItemType.Normal or ItemType.Soldout
	itemObj:GetController("quality").selectedIndex = math.clamp(cfg.quality, 0, 5)
	itemObj:GetChild("iconloader").url = "art/"..cfg.icon
	itemObj:GetChild("DisTxt").text = string.format("%d%s", prop.discount, lang("UI_BASIC_REBATE"))
	itemObj:GetChild("AmountTxt").text = items[3]
	itemObj:GetChildByPath("PriceBtn.CostTxt").text = prop.price[3]
	itemObj:GetChildByPath("PriceBtn.iconloader").url = "art/UI/Common/ItemSmall/"..prop.price[1]
	local function ItemClick()
		local req = {}
		req.type = prop.type
		req.pos = itemData.pos
		self:SetButtonEvent(req, soldstate)
	end
	itemObj:GetChild("PriceBtn").onClick:Set(ItemClick)
end

function UIRandomShop:SetButtonEvent(req, soldstate)
	Net.send("merchant_buy", req, function(result)
        if result.e == 0 then
            if result.favorability then
                self.randomShop:SetIntimacy(result.favorability)
                self.vm.intimacy = self.randomShop.currIntimacy
            end
            soldstate.selectedIndex = ItemType.Soldout
            self.randomShop:SetItemEnable({req.type, req.pos})
			self.randomShop:SetCost(result.expense)
			self.vm.todayCost = self.randomShop.currConsume
        end
    end)
end

function UIRandomShop:PlayTimer()
	local timeObj = self.randomShop:GetTimeStamp()
	local remainTime = timeObj.totalTime - (Net.server_time() - timeObj.startTime)
	self.vm.remainingTime = remainTime
	local function call()
		remainTime = timeObj.totalTime - (Net.server_time() - timeObj.startTime)
		self.vm.remainingTime = remainTime
	end

	local function endCall()
		self:Hide()
	end

	self:SetEngineTimer("city_speedup", call, endCall, timeObj.totalTime, 1, false)
end

function UIRandomShop:StrFormat(num1, num2, str)
	-- if num1 > num2 then
    --     num1 = num2
    -- end
	return string.format("%s%d/%d", str, num1, num2)
end

function UIRandomShop:OnSureBtnClick()
	if not self.randomShop:EnableRefresh() then
        return
    end
    Net.send("merchant_refresh", {}, function(result)
        if result.e == 0 then
			self:RefreshTimes()
            self:RefreshItems()
            self:RefreshBtn()
        end
    end)
end


local PopMode = 5
function UIRandomShop:OnInfoBtnClick()
	local titleStr = lang("UI_RANDOMSHOP_INFO_TITLE")
	local rules = lang("UI_RANDOMSHOP_INFO_HINT")
	local data = {
		mode = PopMode,
		title = titleStr,
		rule = rules
	}
	UIController:ShowUI("UICommonPop", data)
end

local RewardPopMode = 2
function UIRandomShop:OnRewardBtnClick()
	print("OnProgressBarClick")
	if not self.randomShop:EnableReward() then
		local rewardItems = self.randomShop:GetPreviewReward()
		UIController:ShowUI("UIPreviewPop", {mode = RewardPopMode, items = rewardItems})
		return
	end
	Net.send("merchant_get", {}, function(result)
        if result.e == 0 then
            if result.favorability then
                self.randomShop:SetIntimacy(result.favorability)
                self:RefreshIntimacy()
            end
            --show reward window
            if result.items then
                local itemData = {}
                for _, v in ipairs(result.items) do
                    table.insert(itemData, v.array)
                end
                UIManager.open_window("ItemGainRewardWindow", nil, nil, itemData)
            end
        end
    end)
end

