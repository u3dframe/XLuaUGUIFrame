module("resmng", package.seeall)

--通用
add_config("common/define")
add_config("common/tools")

--prop
-- add_config("client/prop_monster")
-- add_config("client/prop_city")
-- add_config("client/prop_soldier")
-- add_config("client/prop_soldierskill")
-- add_config("client/prop_language")
-- add_config("client/prop_popupwindow")
-- add_config("client/prop_topbanner")
-- add_config("client/prop_item")
-- add_config("client/prop_drop")
-- add_config("client/prop_basic")
-- add_config("client/prop_attribute")
-- add_config("client/prop_energy")
-- add_config("client/prop_audio")
-- add_config("client/prop_fortified")
-- add_config("client/prop_respoint")
-- add_config("client/prop_money")
-- add_config("client/prop_hero")
-- add_config("client/prop_merchant")
-- add_config("client/prop_recruit")

local AudioConfig = _G.Database.AudioConfig
local LanguageConfig = _G.Database.LanguageConfig


function propLanguageByKey(id, ...)
    local arg = {...}
    if #arg == 0 then
        return LanguageConfig.CnData[id] or id or "undefine"
    else
        return format_ex(LanguageConfig.CnData[id], unpack(arg))
    end
end

function process_audio_config()
    local register = AudioManager.RegisterConfig 
    for id, prop in pairs(AudioConfig.AudioData) do
        register(prop.id, prop.respath, prop.cache==1)
    end
end


function process_config_data()
    process_audio_config()
end