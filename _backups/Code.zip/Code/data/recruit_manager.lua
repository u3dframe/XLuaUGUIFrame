module("RecruitManager", package.seeall)


local RecruitConfig = _G.Database.RecruitConfig


function initialize(self)
    self.data = {}
    self.costProp = {}
    self.findConfig = {}
    for _, ty in pairs(config.RECRUIT_TYPES) do
        self.findConfig[ty] = {}
        self.data[ty] = {
            freeCDStart = 0,
            freeCount = 0,
            buyCount = 0,
            totalCount = 0,
        }
        self.costProp[ty] = {
            onePrice = RecruitConfig.Re_listData[ty].one_price,
            tenPrice = RecruitConfig.Re_listData[ty].ten_price,
        }
    end
    self:initFindConfig()
    
    Net.register(self, "recruit_freeinfo", on_recruit_freeinfo)
end

--初始化寻访配置
function initFindConfig(self)
    for _, ty in pairs(config.RECRUIT_TYPES) do
        local t = self.findConfig[ty]
        for _, v in pairs(RecruitConfig.Re_selectData) do
            if v.type == ty then
                t[v.heros] = v.mark
            end
        end
    end
end

function HeroID2Mark(self, ty, heroID)
    return self.findConfig[ty][heroID]
end

function Mark2HeroID(self, ty, mark)
    for k, v in pairs(self.findConfig[ty]) do
        if v == mark then
            return k
        end
    end
end

function on_recruit_freeinfo(self, data)
    local tbl = self.data[data.type]
    if not tbl then
        elog("error arg")
        return
    end
    tbl.freeCDStart = data.free_time
    tbl.freeCount = data.free_count or 0
    tbl.buyCount = data.buy_count or 0
    tbl.totalCount = data.count or 0
    tbl.mark = data.mark
    MsgCenter.send_message(Msg.RECRUIT_INFO_ALL)
end

function get_free_cooldown(self, _type)
    local tbl = self.data[_type]
    if not tbl.freeCDStart then return 0 end
    if not tbl then return end
    local cd = RecruitConfig.Re_listData[_type].free_time - (Net.server_time() - tbl.freeCDStart)
    if cd < 0 then cd = 0 end
    return cd
end

function is_free_cd_completed(self, _type)
    return self:get_free_cooldown(_type) <= 0
end

function get_used_free_count(self, _type)
    return self.data[_type].freeCount
end

function get_unused_free_count(self, _type)
    return RecruitConfig.Re_listData[_type].daily_free - self:get_used_free_count(_type)
end

function get_used_buy_count(self, _type)
    return self.data[_type].buyCount
end

function get_unused_buy_count(self, _type)
    return RecruitConfig.Re_listData[_type].daily_limit - self:get_used_buy_count(_type)
end

function get_total_count(self, _type)
    return self.data[_type].totalCount
end

function get_rest_mark_count(self, _type)
    return RecruitConfig.Re_listData[_type].find_time - self:get_total_count(_type)
end

function is_mark_available(self, _type)
    return self:get_rest_mark_count(_type) <= 0
end

function get_mark_hero_id(self, _type)
    return self:Mark2HeroID(_type, self.data[_type].mark)
end

function no_free(self, _type)
    local cfg = RecruitConfig.Re_listData[_type]
    return not cfg.daily_free or cfg.daily_free <= 0
end

function recruit_free(self, _type, SuccessCallBack)
    if self:get_unused_free_count(_type) < 1 then return false end
    if not self:is_free_cd_completed(_type) then return false end
    Net.send("recruit_free", {type = _type}, function(res)
        if res.e == 0 then
            self.data[_type].freeCDStart = Net.server_time()
            self.data[_type].freeCount = self.data[_type].freeCount + 1
            self.data[_type].totalCount = self.data[_type].totalCount + 1
            local items = {}
            for _, info in ipairs(res.items) do
                table.insert(items, info.array)
            end
            SuccessCallBack(_type, 1, items)
            --MsgCenter.send_message(Msg.RECRUIT_FREE_SUCCESS, _type)
            --UIManager.open_window("RecruitGainRewardWindow", nil, _type, 1, items)
        end
    end)
    return true
end

function recruit_one(self, _type,SuccessCallBack)
    local prop = self.costProp[_type].onePrice
    local has = ItemManager:get_count_by_prop(prop)
    if has < prop[3] then
        ItemManager:quick_buy(prop[2], prop[3] - has)
        return false
    end
    if self:get_unused_buy_count(_type) < 1 then return false end
    Net.send("recruit_one", {type = _type}, function(res)
        if res.e == 0 then
            self.data[_type].buyCount = self.data[_type].buyCount + 1
            self.data[_type].totalCount = self.data[_type].totalCount + 1
            local items = {}
            for _, info in ipairs(res.items) do
                table.insert(items, info.array)
            end
            -- MsgCenter.send_message(Msg.RECRUIT_ONE_SUCCESS, _type)
            -- UIManager.open_window("RecruitGainRewardWindow", nil, _type, 1, items)
            SuccessCallBack(_type, 1, items)
        end
    end)
    return true
end

function recruit_ten(self, _type,SuccessCallBack)
    local prop = self.costProp[_type].tenPrice
    local has = ItemManager:get_count_by_prop(prop)
    if has < prop[3] then
        ItemManager:quick_buy(prop[2], prop[3] - has)
        return false
    end
    if self:get_unused_buy_count(_type) < 10 then return false end
    Net.send("recruit_ten", {type = _type}, function(res)
        if res.e == 0 then
            self.data[_type].buyCount = self.data[_type].buyCount + 10
            self.data[_type].totalCount = self.data[_type].totalCount + 10
            local items = {}
            for _, info in ipairs(res.items) do
                table.insert(items, info.array)
            end
            -- MsgCenter.send_message(Msg.RECRUIT_TEN_SUCCESS, _type)
            -- UIManager.open_window("RecruitGainRewardWindow", nil, _type, 10, items)
            SuccessCallBack(_type, 10, items)
        end
    end)
    return true
end

function set_mark_target(self, _type, hero_id)
    if hero_id == self:get_mark_hero_id(_type) then return end
    if not self:is_mark_available(_type) then return end
    local mark = self:HeroID2Mark(_type, hero_id)
    Net.send("set_mark_target", {type = _type, mark = mark}, function(res)
        if res.e == 0 then
            self.data[_type].mark = mark
            MsgCenter.send_message(Msg.RECRUIT_SET_MARK, _type)
            _G.event.fire(_G.EventKey.RECRUIT_SET_MARK)
        end
    end)
end
