module("BuildManager", package.seeall)

local RandomShop = require("data/object/RandomShop")
local CityFete = require("data/object/city_fete_t")
local CityWharf = require("data/object/city_wharf_t")
local CityWall = require("data/object/CityWall")

local BasicConfig = _G.Database.BasicConfig
local CityConfig = _G.Database.CityConfig
local BuildopenConfig = _G.Database.BuildopenConfig
local Net = _G.Net
local config = _G.config

--队列状态
Queue_State = {
    NOT_UNLOCK = -1, --未解锁
    FREE = 0,        --空闲
    BUSY = 1         --使用中
}

--init data
function initialize(self)
    self.build_space_ = {}  --空地
    self.build_info_ = {}   --建筑
    self.build_res_unlock_ = {}     --资源配置
    self.spaceid_to_buildid_ = {}
    self.timer_ = {}

    -- 初始化队列
    self.queue_map_ = {}

    for k, v in ipairs(CityConfig.SpaceData) do
        local value = CityBuildSpace(k)
        table.insert(self.build_space_, value)
    end
    for k, v in ipairs(CityConfig.UnlockData) do
        table.insert(self.build_res_unlock_, v)
    end

    Net.register(self, "city_build_all", on_city_build_all)
    Net.register(self, "city_build", on_city_build)
    Net.register(self, "soldier_cure_info", on_soldier_cure_info)
    Net.register(self, "mainqueue_info", on_queue_info)
    Net.register(self, "city_dismantle", on_city_dismantle)
    Net.register(self, "merchant_info", OnMerchantInfo)
    Net.register(self, "wall_info", OnWallInfo)
    Net.register(self, "sacrifice_info", OnFeteIndo)
    Net.register(self, "wharf_reward_time", OnWharfInfo)
    self:init_queue()
end

function on_city_build_all(self, data)
    --elog("on_city_build_all = "..dumpTab(data))
    if data == nil then return end
    -- 暂时服务器写法，后面统一
    Net:UpdateServerTime(data)
    self.spaceid_to_buildid_ = {}
    for _, v in pairs(data.list) do
	    v.mark = config.BUILD_MARK.NORMAL
        local build = CityBuild(v)
        build:update_server(v)
        self.build_info_[v.id] = build
        self.spaceid_to_buildid_[build.space_id_] = v.id
    end

    --加载不可升级建筑
    local noLvBuild = BuildopenConfig.BuildopenData
    for _, v in pairs(noLvBuild) do
        v.mark = config.BUILD_MARK.NOLV
        local build = CityBuild(v)
        build.id = "NoLv"..v.buildtype

        self.build_info_[build.id] = build
        self.spaceid_to_buildid_[build.space_id_] = build.id
    end
    log("sapce = "..dumpTab(self.spaceid_to_buildid_))
end

function OnFnOpenBuild(self, data)
    dump(data, "")
    if not data then
        return
    end
end

function on_city_build(self, data)
    dump(data, "-------------------------------- > on_city_build")
    local build = self.build_info_[data.id]
    if not build then
        data.mark = config.BUILD_MARK.NORMAL
        build = CityBuild(data)
        self.build_info_[data.id] = build
        self.spaceid_to_buildid_[build.space_id_] = data.id
    end
    local old_lv = build.lv_

    build:update_server(data)
    --服务器主动推送，城外需要显示升级完成提示。
    if not data.runinfo then
        self:remove_queuq(data.id)
        --新建医馆获取医馆倒计时
        if data.level == 1 then
            local timer, count = self:get_hurts_cure_timer()
            build:set_soldier_cure_info(timer, count)
        end

        --升级完成 or 取消升级
        if data.level and data.level > 0 then
            if _G.FairyGUI then
                _G.event.fire(_G.EventKey.CITY_UP_LV_FINISHED, data.id)
            else
                MsgCenter.send_message(Msg.CITY_UP_LV_FINISHED, data.id)
			end
        end

        if type(old_lv) == "number" and old_lv == data.level then return end
        --升级完成提示
        MsgCenter.send_message(Msg.SHOW_BUILD_LV_UP, data.id)
    end
end

function on_city_dismantle(self, data)
    log("city_dismantle = "..dumpTab(data))
    if not data then return end
    --采集
    local collect = CollectManager:get_collect(data.id)
    if data.id and self.build_info_[data.id] then
        self:remove_queuq(data.id)       --从队列中清除
        self.build_info_[data.id] = nil  --清除build
        if collect then
            local collect_obj = {}
            collect_obj.buff = nil
            collect_obj.start_time = nil
            collect:refresh_data(collect_obj)--清除采集信息
        end

        local arg
        for space_id, build_id in pairs(self.spaceid_to_buildid_) do
            if build_id == data.id then
                arg = space_id
                self.spaceid_to_buildid_[space_id] = nil
            end
        end
        MsgCenter.send_message(Msg.CITY_BUILD_REMOVED_FINISHED, arg, data.id)
        if _G.event then
            _G.event.fire(_G.EventKey.CITY_BUILD_REMOVED_FINISHED, {spaceID = arg, buildID = data.id})
        end
    end
end

function on_soldier_cure_info(self, data)
    log("soldier_cure_info = "..dumpTab(data))
    if not data then return end
    local hospitals = self:get_all_builds_by_type(config.BUILD_TYPE.HOSPITAL)
    if not hospitals then return end
    for _, v in pairs(hospitals) do
        v:update_soldier_cure_server(data)
    end
    if data.finish then
        MsgCenter.send_message(Msg.CITY_SOLDIER_CURE_FINISHED)
        if _G.event then
            _G.event.fire(_G.EventKey.CITY_SOLDIER_CURE_FINISHED)
        end
    end
end

function OnMerchantInfo(self, data)
    log("------------------------------> merchant_info"..dumpTab(data))
    if not data then
        return
    end
    if not self.randomBuild then
        self.randomBuild = RandomShop:New(data)
    else
        self.randomBuild:RefreshData(data)
    end

    local isClose
    if self.randomBuild:IsClose() then
        isClose = 1 --是否是关闭商店
    elseif self.randomBuild:IsInitiativeGoods() then
        self.showTitle = true
        isClose = 2 --是否是主动上货
    end
    if EventKey then
        event.fire(EventKey.CITY_RANDOM_SHOP_UPDATE, isClose)
        return
    end
    --刷新界面 (随机商店和title)
    MsgCenter.send_message(Msg.CITY_RANDOM_SHOP_UPDATE, isClose)
end

function OnFeteIndo(self, data)
    if not self.feteBuild then
        self.feteBuild = CityFete:New(data)
    else
        self.feteBuild:RefreshData(data)
    end
    local isShow = self.feteBuild:GetFreeTimes() > 0
    if EventKey then
        event.fire(EventKey.CITY_FETE_UPDATE, isShow)
        return
    end
    MsgCenter.send_message(Msg.CITY_FETE_UPDATE, isShow)
end

function OnWharfInfo(self, data)
    if not data then
        return
    end
    if not self.wharf then
        self.wharf = CityWharf:New(data)
    else
        self.wharf:RefreshData(data)
    end
    if EventKey then
        event.fire(EventKey.CITY_WHARF_UPDATE, isShow)
        return
    end
    --刷新市舶司
    MsgCenter.send_message(Msg.CITY_WHARF_UPDATE)
end

function OnWallInfo(self, data)
    if not data then
        return
    end
    if not self.wall then
        self.wall = CityWall:New(data)
    else
        self.wall:RefreshData(data)
    end
    if EventKey then
        event.fire(EventKey.UPDATE_CITY_WALL)
    end
end

function GetWall(self)
    return self.wall
end

function GetWharfInfo(self)
    return self.wharf
end


function GetFete(self)
    return self.feteBuild
end

function GetRandomShop(self)
    return self.randomBuild
end

-- 获取主城的等级
function get_main_lv(self)
    local build = self:get_build_info_by_build_type(config.BUILD_TYPE.KING)
    return build.lv_ or 1
end

--获取伤兵恢复时间
function get_hurts_cure_timer(self)
    local hospitals = self:get_all_builds_by_type(config.BUILD_TYPE.HOSPITAL)
    if not hospitals then return end
    for _, v in pairs(hospitals) do
        if v.cure_timer_ and v.cure_total_ then
            return v.cure_timer_, v.cure_total_
        end
    end
end

function get_builds_all(self)
    return self.build_info_
end

function GetNormalBuild(self)
    if not self.build_info_ then
        return
    end
    local builds = {}
    for _, v in pairs(self.build_info_) do
        if v.buildMark == config.BUILD_MARK.NORMAL then
            table.insert(builds, v)
        end
    end
    return builds
end

--get space info
function get_space_info_by_id(self, space_id)
    return self.build_space_[space_id]
end

--get build info
function get_build_info_by_space_id(self, space_id)
    return self.build_info_[self.spaceid_to_buildid_[space_id]]
end

--根据建筑ID 获取空地ID
function get_sapce_id_by_build_id(self, build_id)
    if not build_id  then return end
        for k, v in pairs(self.spaceid_to_buildid_ or {}) do
            if v == build_id then
                return k
            end
        end
end

function get_build_info_by_build_type(self, build_type)
    local obj = {}
    for k, v in pairs(self.build_info_) do
        if v.build_type_ == build_type then
            table.insert(obj, v)
        end
    end
    --只返回一个建筑
    if #obj == 1 then return obj[1] end
    --return obj
end

function get_all_builds_by_type(self, build_type)
    local ret = {}
    for k, v in pairs(self.build_info_) do
        if v.build_type_ == build_type then
            ret[k] = v
        end
    end
    return ret
end
--返回所有资源建筑
function get_all_res_builds_by_type(self)
    local ret = {
        [config.BUILD_TYPE.FARM] = {},
        [config.BUILD_TYPE.LOGGING_CAMP] = {},
        [config.BUILD_TYPE.STONE_PIT] = {},
        [config.BUILD_TYPE.SMELTER] = {}
    }
    for k, v in pairs(self.build_info_) do
        if
            v.build_type_ == config.BUILD_TYPE.FARM or 
            v.build_type_ == config.BUILD_TYPE.LOGGING_CAMP or
            v.build_type_ == config.BUILD_TYPE.STONE_PIT or
            v.build_type_ == config.BUILD_TYPE.SMELTER
         then
            if v.lv_>0 then
                table.insert(ret[v.build_type_], v)                
            end
        end
    end
    return ret
end
function get_build_info_by_id(self, id)
    if not id then return end
    return self.build_info_[id]
end

--获取配置中的建筑data
function get_build_data(self, build_type)
    local build_data = CityConfig.BuildData[build_type]
    build_data.mark = config.BUILD_MARK.NORMAL
    local build = CityBuild(build_data)
    if not build then 
        log("build data is nil, pls check method :[get_build_data]")
        return
    end
    return build
end

--交换位置
--build1_id 主动交换的建筑。 build2_id 目标建筑（可能为nil），sapce_id 空地id
function change_build_pos(self, build1_id, build2_id, space_id)
    log("change_build_pos.  parameters is build1_id = %s, build2_id = %s, space_id = %s", build1_id, build2_id, space_id)
    local build1 = self:get_build_info_by_id(build1_id)
    local build2 = self:get_build_info_by_id(build2_id)
    if not build1 or not space_id then return end
    --如果目标建筑存在
    if build2 then
        --替换位置信息
        self.spaceid_to_buildid_[build1.space_id_], self.spaceid_to_buildid_[build2.space_id_] = 
        self.spaceid_to_buildid_[build2.space_id_], self.spaceid_to_buildid_[build1.space_id_]
        build1.space_id_, build2.space_id_ = build2.space_id_, build1.space_id_
        build1.pos_, build2.pos_ = build2.pos_, build1.pos_
    else
        for k, v in pairs(self.spaceid_to_buildid_) do
            if v == build1_id then
                self.spaceid_to_buildid_[k] = nil
                break
            end
        end
        self.spaceid_to_buildid_[space_id] = build1_id
        build1.space_id_ = space_id
    end
end

-- 是否满足解锁/升级条件
-- index 升级条件可能有多个
function unlock_proviso_meet(self, build_data, index)
    if build_data == nil then
        elog("build_data is nil")
    end
    --获取下一等级info
    local build_info = build_data:get_update_info_by_level(build_data.lv_ + 1)
    --如果没有限制条件返回true
    if not build_info.precondition or #build_info.precondition <= 0 then
        return true
    end

    local depend_build_type = build_info.precondition[index][1]
    local min_level = build_info.precondition[index][2]

    local target_build = self:get_build_info_by_build_type(depend_build_type)
    --这里是当获取配置中的模板(有可能建筑还没建造出来)
    if not target_build then
        target_build = self:get_build_data(depend_build_type)
    end
    local target_name = target_build.name_
    local is_full = target_build.lv_ >=  min_level
    --是否满足  依赖建筑的名称 满足需要的等级
    return is_full, target_name, min_level, target_build
end

--检查建筑可建造的数量
function check_build_limit(self, build)
    if not build then return end
    local curr_count = 0
    local total_count = 0
    local is_allow_build

    for _, v in pairs(self.build_info_) do
        if v.build_type_ == build.build_type_ and v.lv_ >= 0 then
            curr_count = curr_count + 1
        end
    end
    if not build:is_outside_build() then
        total_count = 1
    else
        for _, v in pairs(build.max_count_) do
            if self:get_main_lv() >= v[2] then
                total_count = v[1]
            end
        end
    end
    if curr_count >= total_count then
            is_allow_build = false
        else
            is_allow_build = true
        end
    return is_allow_build, curr_count, total_count
end

-- 根据时间获取金币数量（队列相关）
-- time 建造建筑还需要多少时间
function get_glod_count_by_time(self, time)
    local queue_info = BasicConfig.BasicData.goldcoin_queue
    local num = math.ceil(time / queue_info[2])
    return num * queue_info[1]
end

-- 根据金币获取需要的天数（队列相关）
function get_days_by_gold(self, gold_count)
    if not gold_count then return end
    local queue_info = BasicConfig.BasicData.goldcoin_queue
    -- queue_info[2] 单位是秒
    return math.ceil(gold_count / queue_info[1] * (queue_info[2] / 60 / 60 / 24))
end

-- 根据优先级获取资源
function get_build_by_priority(self)
    -- 选择资源足够的建筑
    -- 等级最低的建筑
    -- id由大到小
    local obj = {}
    for _, v in pairs(self.build_info_) do
        if v:is_enough_res_all() and not v:is_building() and not v:is_lvup() then
            table.insert(obj, v)
        end
    end
    if #obj <= 0 then
        local obj2 = {}
        for _, v in pairs(self.build_info_) do
            if not v:is_building() and not v:is_lvup() then
                table.insert(obj2, v)
            end
        end
        table.sort(obj2, function(x, y)
            if x.lv_ == y.lv_ then
                return x.id_ < y.id_
            end
            return x.lv_ < y.lv_
        end)
        return obj2[1]
    end
    table.sort(obj, function(x, y)
        if x.lv_ == y.lv_ then
            return x.id_ < y.id_
        end
        return x.lv_ < y.lv_
    end)
    return obj[1]
end

---------------------------------------building queue--------------------------------------------
--初始化队列
function init_queue(self)
    for i = 1, config.BUILDING_QUEUE_MAX do
        local obj = {}
        obj.state = Queue_State.NOT_UNLOCK
        obj.time = nil
        if i == 1 then
            --默认第一条队列是解锁的
            obj.state = Queue_State.FREE
        end
        obj.value = nil
        self.queue_map_[i] = obj
    end
end

function on_queue_info(self, data)
    log("mainqueue_info = "..dumpTab(data))
    --记录第二队列的结束时间
    self.queue_map_[config.BUILDING_QUEUE_SECOND].time = data.ti_end or 0
    --第二队列如果解锁
    if data.ti_end and Net.server_time() < data.ti_end then
        self.queue_map_[config.BUILDING_QUEUE_SECOND].state = Queue_State.FREE
        if data.purchase then
            self.queue_map_[config.BUILDING_QUEUE_SECOND].state = Queue_State.BUSY
            self.queue_map_[config.BUILDING_QUEUE_SECOND].value = data.purchase
        end
        local remaining_time = self:get_queue2_time()
        log("queue remaining_time = %s", remaining_time)
        if self.lua_timer_ then
            LuaTimer.Delete(self.lua_timer_)
        end
        if remaining_time and remaining_time > 0 then
            self.lua_timer_ = LuaTimer.Add(remaining_time * 1000, 1000, function()
                self.queue_map_[config.BUILDING_QUEUE_SECOND].state = Queue_State.NOT_UNLOCK
                self.queue_map_[config.BUILDING_QUEUE_SECOND].value = nil
                MsgCenter.send_message(Msg.CITY_QUEUE_UPDATE)
                return false
            end)
        end
    else
        self.queue_map_[config.BUILDING_QUEUE_SECOND].state = Queue_State.NOT_UNLOCK
    end
    --第1队列
    if data.main then
        self.queue_map_[config.BUILDING_QUEUE_FIRST].state = Queue_State.BUSY
        self.queue_map_[config.BUILDING_QUEUE_FIRST].value = data.main
    end
    MsgCenter.send_message(Msg.CITY_QUEUE_UPDATE)
end


--建筑添加到队列
--方式1：顺序添加
--方式2：指定队列id添加
function append_queue(self, build_id, queuq_id)
    if queuq_id then
        if self.queue_map_[queuq_id].state == Queue_State.FREE then
            self.queue_map_[queuq_id].state = Queue_State.BUSY
            self.queue_map_[queuq_id].value = build_id
            log("build %s  add to building queuq %s.", build_id, queuq_id)
        end
        return
    end
    local queue = self:get_queue()
    for _, v in pairs(queue) do
        if v.value == build_id then
            log("%s already existed in queuq", build_id)
            return
        end
    end
    for i = 1, config.BUILDING_QUEUE_MAX do
        if self.queue_map_[i].state == Queue_State.FREE then
            self.queue_map_[i].state = Queue_State.BUSY
            self.queue_map_[i].value = build_id
            log("build %s  add to building queuq %s.", build_id, i)
            break
        end
    end
end

--将建筑移除队列
function remove_queuq(self, build_id)
    if not build_id then return end
    for _, v in pairs(self.queue_map_) do
        if v.value == build_id then
            v.state = Queue_State.FREE
            v.value = nil
            log("build %s  remove for build queue", build_id)
        end
    end
end

--是否有空闲队列
function check_queue(self)
    for _, v in pairs(self.queue_map_) do
        if v.state == Queue_State.FREE then
            return true
        end
    end
    return false
end

--获取正在使用的队列
function get_queue(self)
    local queue_info = {}
    for _, v in pairs(self.queue_map_) do
        if v.state == Queue_State.BUSY then
            table.insert(queue_info, v)
        end
    end
    return queue_info
end

-- 通过建筑id 获取队列id
function get_queue_id(self, build_id)
    if not build_id then return end
    local queue_id
    for k, v in pairs(self.queue_map_) do
        if v.value == build_id then
            queue_id = k
            break
        end
    end
    return queue_id
end

function get_build_id_by_queue_id(self, queue_id)
    if not queue_id then return end
    if not self.queue_map_[queue_id] or not self.queue_map_[queue_id].value then return end
    return self.queue_map_[queue_id].value
end

--是否是空闲队列
function is_free_queue(self, queue_id)
    if self.queue_map_[queue_id].state and self.queue_map_[queue_id].state == Queue_State.FREE then
        return true
    end
    return false
end

--是否是使用中的队列
function is_busy_queue(self, queue_id)
    if self.queue_map_[queue_id].state and self.queue_map_[queue_id].state == Queue_State.BUSY then
        return true
    end
    return false
end

--是否是解锁了的队列
function is_unlock_queue(self, queue_id)
    if self.queue_map_[queue_id].state and self.queue_map_[queue_id].state ~= Queue_State.NOT_UNLOCK then
        return true
    end
    return false
end


-- 是否需要申请解锁队列
function is_have_unlock_queue(self)
    for i = 1, config.BUILDING_QUEUE_MAX do
        --有空闲队列就不需要申请解锁
        if self:is_free_queue(i) then
            return false
        end
    end

    for i = 1, config.BUILDING_QUEUE_MAX do
        --如果有未解锁的才可以申请解锁
        if self.queue_map_[i].state == Queue_State.NOT_UNLOCK then
            return true
        end
    end
    return false
end

--是否要雇佣第二个队列(第一个队列在使用中，只能使用第二个队列)
function is_hire_sencond_queue(self, uplv_time)
    -- 第一个队列在使用 and (第二个队列未解锁 or 第二个队列时间不够)
    local busy = self:is_busy_queue(config.BUILDING_QUEUE_FIRST)
    local is_unlock = self:is_unlock_queue(config.BUILDING_QUEUE_SECOND)
    if busy and (not is_unlock or self:get_queue2_time() < uplv_time / 1000) then
        return true
    end
    return false
end

-- 队列是否已满 （俩条队列都在建造）
function is_full_queue(self)
    for i = 1, config.BUILDING_QUEUE_MAX do
        --如果没有建造 说明没满
        if not self:is_busy_queue(i) then
            return false
        end
    end
    return true
end

-- 获取队列2的剩余时间
function get_queue2_time(self)
    if self.queue_map_[config.BUILDING_QUEUE_SECOND].time then
        if self.queue_map_[config.BUILDING_QUEUE_SECOND].time <= 0 then return 0 end
        return self.queue_map_[config.BUILDING_QUEUE_SECOND].time - Net.server_time()
    end
end

-------------------------------------------------------------------------------------

-----------------------------------------------timer------------------------------------------------

-- key 键
-- end_time      结束时间
-- on_per_second 每秒回调
-- on_complete   结束回调
-- need_scene    依赖场景

function register_timer(self, obj)
    if not obj or not obj.key or not obj.end_time then return end

    self.timer_[obj.key] = self.timer_[obj.key] or {}
    self.timer_[obj.key].end_time = obj.end_time
    self.timer_[obj.key].need_scene = obj.need_scene

    self.timer_[obj.key].on_per_second = self.timer_[obj.key].on_per_second or {}
    self.timer_[obj.key].on_complete = self.timer_[obj.key].on_complete or {}
    --在回调里面注册 接收回调的方法 以及id作为唯一标识

    local on_per_second_obj = {
        callback = obj.on_per_second,
        id = obj.id
    }

    local on_complete_obj = {
        callback = obj.on_complete,
        id = obj.id
    }

    --如果已经存在
    self:unregister_timer(obj.key, obj.id)

    table.insert(self.timer_[obj.key].on_per_second, on_per_second_obj)
    table.insert(self.timer_[obj.key].on_complete, on_complete_obj)

    self:play_timer(obj.key)
end

--取消注册
function unregister_timer(self, key, id)
    log("--------------------> key = %s, id = %s", key, id)
    if (not key) or (not id) then
        return
    end
    local timer = self.timer_[key]
    if timer then
        --取消on_per_second注册
        if timer.on_per_second then
            for k, v in pairs(timer.on_per_second) do
                if v.id == id then
                    log("on_per_second delete is ok")
                    timer.on_per_second[k] = nil
                end
            end
        end
        --取消on_complete注册
        if timer.on_complete then
            for k, v in pairs(timer.on_complete) do
                if v.id == id then
                    log("on_complete delete is ok")
                    timer.on_complete[k] = nil
                end
            end
        end
    end
end


function play_timer(self, key)
    if not key then
        return
    end
    --已经有的LuaTimer不需要重新创建
    if self.timer_[key] and self.timer_[key].timer then
        return
    end
    local timer = LuaTimer.Add(0, 1000, function()
        -- 检查依赖
        if not self:check_state(key) then
            self:close_timer(key)
            return false
        end
        if self.timer_[key] then
            -- 结束回调
            if self.timer_[key].end_time and Net.server_time() >= self.timer_[key].end_time then
                if type(self.timer_[key].on_complete) == "table" then
                    for k, v in pairs(self.timer_[key].on_complete) do
                        v.callback()
                     end
                    self:close_timer(key)
                    return false
                end
            end
            -- 每秒回调
            if type(self.timer_[key].on_per_second) == "table" then
                for _, v in pairs(self.timer_[key].on_per_second) do
                    v.callback()
                end
            end
        end
    end)
    self.timer_[key].timer = self.timer_[key].timer or {}
    table.insert(self.timer_[key].timer, timer)
end

-- 每秒都要判断 性能不好 可能需要优化
function check_state(self, key)
     -- 判断依赖条件：依赖场景、依赖UI、依赖功能
    if self.timer_[key] and self.timer_[key].need_scene then
        local scene_name = GameUtil:GetActiveScene()
        if scene_name ~= self.timer_[key].need_scene then
            return false
        end
    end
    return true
end

function close_timer(self, key)
    if self.timer_[key] and self.timer_[key].timer then
        for _, v in pairs(self.timer_[key].timer) do
            LuaTimer.Delete(v)
        end
        self.timer_[key] = nil
    end 
end



