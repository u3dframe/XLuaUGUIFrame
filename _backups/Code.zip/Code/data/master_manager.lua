module("MasterManager", package.seeall)


local BasicConfig = _G.Database.BasicConfig
local EnergyConfig = _G.Database.EnergyConfig
local event = _G.event
local EventKey = _G.EventKey

function initialize(self)
    self.user_ = {}
    self.user_.energy_ = 0
    self.user_.energy_buytime_ = 0
    Net.register(self, "role_object", init_basic_info)
    Net.register(self, "energy_info", on_energy_info)
    Net.register(self, "energy_change", on_energy_change)
    Net.register(self, "energy_change_one", on_energy_change_one)

    --FIXME:Temp regesit
    Net.register(self, "fnopen_list", on_fnopen_list)
    Net.register(self, "fnopen_new", on_fnopen_new)

    --[[
    --]]
end

function on_fnopen_new()
end

function on_fnopen_list()
end

function init_basic_info(self, data)
    self.user_.name_ = data.rname or self.user_.name_
    self.user_.rid_ = data.rid or self.user_.rid_           -- 角色ID
    MsgCenter.send_message(Msg.REFRESH_MASTER_USER, data)
end

function get_energy_percent(self)
    local percent = self.user_.energy_ / BasicConfig.BasicData.emergy_full[1]
    return percent > 1 and 1 or percent
end

function on_energy_info(self, data)
    self.user_.energy_ = data.cnt or self.user_.energy_
    self.user_.energy_buytime_ = data.buycnt or self.user_.energy_buytime_
    MsgCenter.send_message(Msg.ENERGY_REFRESH)
    if EventKey then
        event.fire(EventKey.ENERGY_REFRESH)
    end
end

function on_energy_change(self, data)
    for i,v in ipairs(data.list) do
        MsgCenter.send_message(Msg.ENERGY_CHANGE, v.change)
        tmp_energy = v.last
    end
    self.user_.energy_ = tmp_energy
    MsgCenter.send_message(Msg.ENERGY_REFRESH)
    if EventKey then
        event.fire(EventKey.ENERGY_REFRESH)
    end
end

function on_energy_change_one(self, data)
    self.user_.energy_ = data.last
    MsgCenter.send_message(Msg.ENERGY_CHANGE, data.change)
    MsgCenter.send_message(Msg.ENERGY_REFRESH)
    if EventKey then
        event.fire(EventKey.ENERGY_REFRESH)
    end
end

function is_master(self, owner)
    if not owner then return false end
    if owner == self.user_.rid_ then
        return true
    end
    return false
end

function buy_energy(self)
    if self.user_.energy_ > BasicConfig.BasicData.emergy_full[2] then
        MsgCenter.send_message(Msg.SHOW_HINT, lang("EXPEDITION_37"))
        return false
    end
    
    --先使用道具在使用金币噶
    local item_data
    for i,v in ipairs(BasicConfig.BasicData.energy) do
        if ItemManager:check_item_count(v[1]) then
            item_data = v
        end
    end
    -- 使用道具
    
    -- 使用金币
    local time = self.user_.energy_buytime_+1
    local prop = EnergyConfig.EnergyData[time]
    if not prop then
        MsgCenter.send_message(Msg.SHOW_HINT, lang("EXPEDITION_38"))
        return false
    end
    if not ItemManager:check(prop.gold) then
        MsgCenter.send_message(Msg.SHOW_HINT, lang("RESOURCE_BUILDING_6"))
        return false
    end
    
    local str = lang("EXPEDITION_39", prop.gold[3], prop.energy[3])
    local msg_ = {}
    msg_.mode=0
    msg_.title = lang("UI_BASIC_HINT")
    msg_.content = str
  --  msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
    msg_.callback = function() 
     --   if index == 2 then
            Net.send("energy_buy",{buycnt = time}, function(result)
                if result.e == 0 then
                    self.user_.energy_buytime_ = self.user_.energy_buytime_ + 1
                    MsgCenter.send_message(Msg.SHOW_HINT, lang("EXPEDITION_40"))
                end
            end)
    --    end
    end
    --MsgCenter.send_message(Msg.SHOW_NOTIFY,msg_)
    _G.UIController:ShowUI('UICommonPop', msg_)
    return true
end

function GetUserEnery(self)
    return self.user_.energy_
end
