module("HeroManager", package.seeall)


local BasicConfig = _G.Database.BasicConfig
local HeroConfig = _G.Database.HeroConfig


function initialize(self)
    self.hero_cards_ = {}
    self:init_hero_cards()
    self:init_hero_stardata()
    self.messager_ = Messager:new(self)
    
    Net.register(self, "hero_info", on_hero_info)
end

function init_hero_cards(self)
    for id, v in pairs(HeroConfig.ListData) do
        if v.isshow == 1 then
            self.hero_cards_[id] = Hero(id)
        end
    end
end

function get_config(self, heroid)
    local cfg = HeroConfig.ListData[heroid]
    if not cfg then elog("Can't find config of hero id: "..tostring(heroid)) end
    return cfg
end

function active_hero(self, id, on_success)
    local hero = self:get_hero_by_id(id)
    if not hero or not hero:enable_awake() then return end
    Net.send("hero_active", {id = id}, function(res)
        if res.e == 0 then
            if type(on_success) == "function" then
                on_success()
            end
        end
    end)
end

function get_sorted_hero_list(self, _type)
    local heroes = {}
    -- 转为有序table -- 
    for k,v in pairs(self.hero_cards_) do
        if not _type or v.type_ == _type then
            table.insert(heroes, v)
        end
    end
    local ret = {}
    -- 需要召唤的 --
    table.sort(heroes, function(a, b) return b.quality_ < a.quality_ end)
    for k,v in ipairs(heroes) do        
        if v:enable_awake() then
            table.insert(ret, v)
        end
    end
    
    -- 已经激活的 --
    for k,v in ipairs(heroes) do
        if v.is_active_ then
            table.insert(ret, v)
        end
    end
    
    -- 未激活且不能激活的 --
    for k,v in ipairs(heroes) do
        if not v.is_active_ and not v:enable_awake() then
            table.insert(ret, v)
        end
    end

    return ret
end

-- 获取可出征的英雄（至多2个）
function get_heroes_troop(self)
    local heroes_tmp = self:get_heroes()
    local heroes = {}
    local num = 0
    for i=1, #heroes_tmp do
        if heroes_tmp[i].state_ == Hero.ST_HOME then
            table.insert(heroes, heroes_tmp[i])
            if #heroes == 2 then break end
        end
    end
    return heroes
end

function get_heroes(self)
    local heroes = {}
    
    for i, v in pairs(self.hero_cards_) do
        if v.is_active_ then
            table.insert(heroes, v)            
        end
    end
    table.sort(heroes, function(a, b) return b.quality_ < a.quality_ end)
    return heroes
end


function get_active_hero_by_id(self, id)
    if not id then return end
    local hero = self.hero_cards_[id]
    if not hero.is_active_ then return end
    return hero
end


function get_hero_by_id(self, id)
    if not id then return end
    return self.hero_cards_[id]
end

function is_hero_active(self, id)
    local hero = self:get_hero_by_id(id)
    if not hero then return false end
    return hero.is_active_
end

function on_hero_info(self, data)
    if not data then return end
    if not data.list then return end
    for k,v in pairs(data.list) do
        if self.hero_cards_[v.id] then
            self.hero_cards_[v.id]:update_server_data(v)
        else
            -- 暂时注释掉
            --self.hero_cards_[v.id] = Hero(v.id)
            --self.hero_cards_[v.id]:update_server_data(v)
        end
    end
    MsgCenter.send_message(Msg.UI_HERO_INFO, data.list)
end

function init_hero_stardata(self)
    self.star_prop_map_ = {}
    for k,v in pairs(HeroConfig.StarData) do
        local key = v.hero*100 + v.star_level
        self.star_prop_map_[key] = v
    end
end

function calc_hero_troop_power(self, id, level, star_level)
    local starCfg = self.star_prop_map_[id * 100 + star_level]
    local attr = HeroConfig.PropertyData[level].leader  --出征用军事属性计算
    local quality = HeroConfig.ListData[id].quality
    return attr / BasicConfig.BasicData.march_hero_attrs_c[1] * (BasicConfig.BasicData.march_hero_power_c[quality] or 0)
end

function get_star_by_star_level(self, id, star_level)
    return self:get_hero_star_prop(id, star_level).star
end

function get_hero_skill_max_lv(self, hero_id, star_lv)
    local data = self:get_hero_star_prop(hero_id, star_lv)
    if data then return data.skill_level end
end

function get_hero_star_prop(self, hero_id, star_lv)
    return self.star_prop_map_[hero_id * 100 + star_lv]
end

function get_hero_max_lv(self, hero_id, star_lv)
    return self:get_hero_star_prop(hero_id, star_lv).maxlevel
end

function show_hero_star_comp(self, star_group, star)
    if not star_group then return end
    star = star or 0
    for i=1,5 do
        local star_go = star_group:Find("star"..i):GetComponent(Image)
        if i <= star then
            UIUtil.set_sprite("UI/Common/HerCard/star1_yellow", star_go)
        else
            UIUtil.set_sprite("UI/Common/HerCard/star1_gray", star_go)
        end
    end
end

--根据经验，获取所能升到的等级，以及最后一级的当前经验
function get_lv_by_exp(self, id, exp)
    if not exp or not id then return end
    local hero_data = self:get_active_hero_by_id(id)
    local curr_lv = hero_data.lv_
    local max_lv = hero_data:get_max_lv()
    local exist_exp = hero_data.cur_exp_
    local sum_exp = 0
    for i = curr_lv, max_lv do
        --当前等级需要的经验
        --elog("-------------------------> i = %s", i)
        local curr_lv_exp = hero_data:get_exp(i)
        if curr_lv_exp then
            sum_exp = sum_exp + curr_lv_exp
            --道具 + 已有的经验  < 总共的经验
            if exp + exist_exp < sum_exp then
                local cur_exp = curr_lv_exp - (sum_exp - exp - exist_exp)
                if i >= hero_data:get_max_hero_lv() then
                    cur_exp = 0
                end
                return i, cur_exp
            end
            --如果道具经验 超过当前最高等级 
            if i == max_lv and exp + exist_exp >= sum_exp then

                --------------------------->暂时定为0
                return i, 0
            end
        end
    end
end

function GetExpOfLevel(self, heroID, level, starLevel)
    return HeroConfig.PropertyData[level].exp * self:get_hero_star_prop(heroID, starLevel).exp_para
end

--items: {{id, cnt}, ...}
function HeroLevelUp(self, heroID, items)
    local data = {id = heroID, cost = {}}
    for _, v in pairs(items) do
        local id, cnt = unpack(v)
        if cnt > 0 then
            table.insert(data.cost, {array = {config.ITEM_ITEM, id, cnt}})
        end
    end
    Net.send("hero_levelup", data, function(res)
        if res.e == 0 then
            local hero = self:get_hero_by_id(heroID)
            hero.lv_ = res.level or hero.lv_
            hero.cur_exp_ = res.exp or hero.cur_exp_
            hero.max_exp_ = hero:get_exp()
            _G.event.fire(_G.EventKey.CITY_HERO_LVUP, {id = hero.id_})
        end
    end)
end

function HeroStarUp(self, heroID, targetStar)
    local data = {
        id = heroID,
        tar_star = targetStar,
    }
    Net.send("hero_starup", data, function(result)
        if result.e == 0 then
            local hero = self:get_hero_by_id(heroID)
            hero.star_ = result.hero.star or hero.star_
            hero.lv_ = result.hero.level or hero.lv_
            hero.cur_exp_ = result.hero.level_exp or hero.cur_exp_
            _G.event.fire(_G.EventKey.CITY_HERO_STARUP, {id = hero.id_})
        end
    end)
end

function HeroChipExchange(self, heroID, count)
    Net.send("hero_chip_conversion", {id = heroID, cnt = count}, function(result)
        if result.e == 0 then
            MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_HINT_CHIP_EXCHANGE_SUCCEED"))
            _G.event.fire(_G.EventKey.CHIP_EXCHANGE_SUCCESS, {id = heroID})
		end
	end)
end
