module("AttrsManager", package.seeall)


local AttributeConfig = _G.Database.AttributeConfig


function initialize(self)
    self.attrs_ = {}
    self.attrs_map_ = {}
    for k, v in pairs(AttributeConfig.AttributeData) do
        self.attrs_[k] = Attrs(k)
        local str = self.attrs_[k]:get_prop().name
        self.attrs_map_[str] = k
    end
    
    Net.register(self, "role_attrs", on_role_attrs)
    Net.register(self, "role_attrs_change", on_role_attrs_change)
end

function on_role_attrs(self, data)
    for i,v in ipairs(data.ids) do
        if not self.attrs_[v] then
            error(string.format("Not found in AttributeConfig. key is %d", v))
        end
        self.attrs_[v]:update_data(data.vals[i])
    end
end

function on_role_attrs_change(self,data)
    for i,v in ipairs(data.ids) do
        self.attrs_[v]:update_data(data.vals[i])
    end
end


function get_attrs_value(self, key)
    if not self.attrs_[key] then return end
    return self.attrs_[key].value_ or 0
end

function get_attrs_value_by_name(self, name)
    if not name then return end
    local key = self.attrs_map_[name]
    return self:get_attrs_value(key)
end

function get_attrs(self, key)
    if not self.attrs_[key] then return end
    return self.attrs_[key]
end

function get_attrs_by_name(self, name)
    if not name then return end
    local key = self.attrs_map_[name]
    return self:get_attrs(key)
end