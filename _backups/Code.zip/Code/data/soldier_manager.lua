module("SoldierManager", package.seeall)

local AttrsManager = _G.AttrsManager
local BasicConfig = _G.Database.BasicConfig
local SoldierConfig = _G.Database.SoldierConfig
local TrapConfig = _G.Database.TrapConfig
local config = _G.config


function initialize(self)
	self.soldier_info_ = {} --所有士兵
	self.soldier_lvup_ = {} --士兵晋升
	for k, v in pairs(SoldierConfig.SoldierData) do
		self.soldier_info_[k] = CitySoldier(k)
	end
	self.traps = {}
	for k, v in pairs(TrapConfig.TrapData) do
		self.traps[k] = CitySoldier(k, config.SOLDIER_CLASS.TRAP)
	end

	for k, v in pairs(SoldierConfig.PromotionData) do
		self.soldier_lvup_[k] = v
	end
	self:sort_soldier_by_type()
	self:sort_soldier_lvup_by_id()

	Net.register(self, "buildsoldier_all", on_soldier_all)
	Net.register(self, "buildsoldier", on_soldier)
	Net.register(self, "soldier_info", on_soldier_info)
	Net.register(self, "trap_info", on_trap_info_all)
	Net.register(self, "build_trap_info", on_build_trap_info)
	Net.register(self, "trap_updata", on_trap_updata)
end


----------------------------------- interface---------------

--获取士兵(得到一个副本)
function get_soldier(self)
	local list = {}
	for k, v in pairs(self.soldier_info_) do
		table.insert(list, v)
	end
	return list
end

--通过ID 得到士兵
function get_soldier_info_by_id(self, id, soldier_class)
	soldier_class = soldier_class or config.SOLDIER_CLASS.COMMON
	local data
	if soldier_class == config.SOLDIER_CLASS.COMMON then
		data = self.soldier_info_
	elseif soldier_class == config.SOLDIER_CLASS.TRAP then
		data = self.traps
	end
	return data[id]
end

function get_trap_total_count(self)
	local cnt = 0
	for _, v in pairs(self.traps) do
		cnt = cnt + v.number_
	end
	return cnt
end

function get_trap_capacity(self)
	return AttrsManager:get_attrs_value_by_name("trap_capa")
end

function get_trap_train_max_cnt(self)
	local numOnce = AttrsManager:get_attrs_value_by_name("train_num_trap")
	local numLimit = self:get_trap_capacity() - self:get_trap_total_count()
	return numLimit > numOnce and numOnce or numLimit
end

-- 【排序】等级优先
function get_soldier_by_level_priority(self)
	local soldiers = self:get_soldier_number_than_zero()
	if not soldiers then return end
	table.sort(soldiers, function(x, y)
		if x.lv_ == y.lv_ then
			return x.id_ < y.id_
		end
		return x.lv_ > y.lv_
	end)
	return soldiers
end
-- 【排序】负重优先
function get_soldier_by_weight_priority(self)
	local soldiers = self:get_soldier_number_than_zero()
	if not soldiers then return end
	table.sort(soldiers, function(x, y)
		if x.attribute_.weight_ == y.attribute_.weight_ then
			return x.id_ < y.id_
		end
		return x.attribute_.weight_ > y.attribute_.weight_
	end)
	return soldiers
end

-- 【排序】速度优先
function get_soldier_by_speed_priority(self)
	local soldiers = self:get_soldier_number_than_zero()
	if not soldiers then return end
	table.sort(soldiers, function(x, y)
		if x.attribute_.speed_ == y.attribute_.speed_ then
			return x.id_ < y.id_
		end
		return x.attribute_.speed_ > y.attribute_.speed_
	end)
	return soldiers
end

-- 【排序】搭配优先 20%盾兵  80%其他士兵
function get_soldier_by_collocation_priority(self)
	local soldiers = self:get_soldier_number_than_zero()
	if not soldiers then return end
	local count = math.floor(#soldiers * 0.2)
	if count == 0 then count = 1 end
	table.sort(soldiers, function(x, y)
		if x.lv_ == y.lv_ then
			return x.id_ < y.id_
		end
		return x.lv_ > y.lv_
	end)
	local list = {} --盾兵表
	for k, v in pairs(soldiers) do
		if v.soldier_type_ == config.SOLDIER_TYPE.TYPE_2 then
			if #list >= count then break end
			table.insert(list, v)
			soldiers[k] = nil
		end
	end
	local new_soldiers = {}
	if #list > 0 then
		for i = #list, 1, -1 do
			table.insert(new_soldiers, 1, list[i])
		end
	end
	for k, v in pairs(soldiers) do
		table.insert(new_soldiers, v)
	end
	return new_soldiers
end

--获取数量大于0的士兵
function get_soldier_number_than_zero(self, soldier_class)
	soldier_class = soldier_class or config.SOLDIER_CLASS.COMMON
	local data
	if soldier_class == config.SOLDIER_CLASS.COMMON then
		data = self.soldier_info_
	elseif soldier_class == config.SOLDIER_CLASS.TRAP then
		data = self.traps
	end
	local list = {}
	for _, v in pairs(data) do
		if v.number_ and v.number_ > 0 then
			table.insert(list, v)
		end
	end
	return list
end

--是否解锁
function is_unlock(self, soldier_info)
	local build_type = soldier_info.build_type_
	local build_info = BuildManager:get_build_info_by_build_type(build_type)
	if not build_info then
		build_info = BuildManager:get_build_data(build_type)
		return false, build_info
	end
	local depend_lv = soldier_info.unlock_
	return depend_lv <= build_info.lv_, build_info
end

--获取所有的伤兵
function get_hurts_all(self)
	if not self.soldier_info_ then return end
	local hurts = {} 
	for k, v in pairs(self.soldier_info_) do
		if v.hurts_number_ > 0 then
			table.insert(hurts, v)
		end
  	end
  	--按等级排序
  	table.sort(hurts, function(x, y)
  		if x.lv_ == y.lv_ then
  			return x.soldier_type_ < y.soldier_type_
  		end
  		return x.lv_ > y.lv_
  	end)
  	return hurts
end

function GetHurtsCountAll(self)
	local hurts_all = self:get_hurts_all()
	local sum_cnt = 0
	for _, v in pairs(hurts_all) do
		sum_cnt = sum_cnt + v.hurts_number_
	end
	return sum_cnt
end

--治疗时间
function get_hurts_uplog(self, time, hurts_count)
	if not time or not hurts_count then return end
	--治疗时间=单兵时间*数量/(1+医馆治疗速度)
	local speed = AttrsManager:get_attrs_value_by_name("cure_speed")
	local hurts_tiem = time * hurts_count / (1 + speed)
	return hurts_tiem / 1000
end

--获取金币数量
function get_gold_drill_number(self, remaining_time)
	if not remaining_time then return end
	-- 金币=系数1*（训练时间）^系数2-系数3.   结果四舍五入,最小值为1
	local basic = BasicConfig.BasicData
	local number = basic.train_gold1 * remaining_time ^ basic.train_gold2 - basic.train_gold3
	local integer_num = math.floor(number + 0.5)
	if integer_num <= 0 then integer_num = 1 end
	return integer_num
end


--获取伤兵立即治疗需要的金币数量
function get_glod_hurts_recover(self, cure_time)
	if not cure_time then return end
	if cure_time == 0 then return 0 end
	--立即治疗金币=系数1*（治疗时间）^系数2-系数3
	local basic = BasicConfig.BasicData
	local number = basic.cure_gold1 * cure_time ^ basic.cure_gold2 - basic.cure_gold3
	if not number then elog("get_glod_hurts_recover is nil") number = 1 end
	local integer_num = math.floor(number + 0.5)
	if integer_num <= 0 then integer_num = 1 end
	return integer_num
end
----------------------------------------------------------------

function on_soldier_all(self, data)
	if not data then return end
	for k, v in pairs(data.list) do
		--获取当前正在训练的小兵ID
		local build = BuildManager:get_build_info_by_id(v.id)
		if build then
			build.soldier_id_ = v.soldier
		end

		--更新数据
		local soldier = self.soldier_info_[v.soldier]
		soldier:update_server(v)
	end
end

function on_soldier(self, data)
	log("[server] solider info"..dumpTab(data))
	if not data then return end
	--建筑获取小兵id
	local build = BuildManager:get_build_info_by_id(data.id)
	if data.soldier and build then build.soldier_id_ = data.soldier end

	--更新数值
	local soldier_id = data.soldier and build.soldier_id_ or build.soldier_id_
	if not soldier_id then elog("error: soldier_id is nil, check it !") return end
 	local soldier = self.soldier_info_[soldier_id]
 	soldier:update_server(data)
 	--发送通知
	if not data.runinfo then
		if data.soldier and data.soldiercnt then
			-- 训练完成 服务器主动通知
			if _G.event then
				_G.event.fire(_G.EventKey.CITY_SOIDIER_FINISHED, {buildID = data.id, soldierID = data.soldier})
				return
			end
			MsgCenter.send_message(Msg.CITY_SOIDIER_FINISHED, data.id, data.soldier)
		end
	end
end

function on_soldier_info(self, data)
	if not data then return end
	if data.soldiers then
		for k, v in pairs(data.soldiers) do
			local index = v.array[1]
			self.soldier_info_[index].number_ = v.array[2] or 0
		end
	end

	if not data.hurts then return end
	for k, v in pairs(data.hurts) do
		local index = v.array[1]
		self.soldier_info_[index].hurts_number_ = v.array[2] or 0
	end
end

function on_trap_info_all(self, data)
	if not data then return end
	local all_trap = data.all_trap
	for _, v in pairs(self.traps) do
		v.number_ = 0
	end
	for i, v in pairs(all_trap.arr1) do
		self.traps[v].number_ = all_trap.arr2[i]
	end
	_G.event.fire(_G.EventKey.CITY_TRAP_CHANGE)
end

function on_build_trap_info(self, data)
	if not data or not next(data) then return end
	if not data.trap_id then
		local buildType = BuildManager:get_build_info_by_id(data.id).build_type_
		local _, _, trap_id, _ = self:check_soldier_state(buildType)
		data.trap_id = trap_id
	end
	local soldier = self.traps[data.trap_id]
	if not soldier then return end
	soldier:update_server({
		id = data.id,
		runinfo = data.runinfo,
		soldier = data.trap_id,
		soldiercnt = data.trap_cnt,
	})
	if not data.runinfo and soldier.select_count_ and soldier.select_count_ > 0 then
		if _G.event then
			_G.event.fire(_G.EventKey.CITY_SOIDIER_FINISHED, {buildID = data.id, soldierID = soldier.id_, soldierClass = soldier.class_})
			return
		end
		MsgCenter.send_message(Msg.CITY_SOIDIER_FINISHED, data.id, soldier.id_, soldier.class_)
	end
end

function on_trap_updata(self, data)
	if not data then return end
	local trap = self.traps[data.trap_id]
	if not trap then return end
	trap.number_ = data.trap_cnt
	_G.event.fire(_G.EventKey.CITY_TRAP_CHANGE)
end


--对士兵进行有序排列(根据不同建筑分类)
function sort_soldier_by_type(self)
	if not self.soldier_info_ then return end
	self.orderly_soldier_info_ = {}
	for k, v in pairs(self.soldier_info_) do
		self.orderly_soldier_info_[v.build_type_] = self.orderly_soldier_info_[v.build_type_] or {}
		table.insert(self.orderly_soldier_info_[v.build_type_], v)
	end
	self.orderly_trap_info_ = {}
	for k, v in pairs(self.traps) do
		self.orderly_trap_info_[v.build_type_] = self.orderly_trap_info_[v.build_type_] or {}
		table.insert(self.orderly_trap_info_[v.build_type_], v)
	end
	for _, t in pairs(self.orderly_trap_info_) do
		table.sort(t, function(a, b)
			if a.lv_ ~= b.lv_ then return a.lv_ < b.lv_ end
			return a.soldier_type_ < b.soldier_type_
		end)
	end
end

--对晋升信息排序
function sort_soldier_lvup_by_id(self)
	if not self.soldier_lvup_ then return end
	self.orderly_soldier_lvup_ = {}
	for k, v in pairs(self.soldier_lvup_) do
		self.orderly_soldier_lvup_[v.soldier] = self.orderly_soldier_lvup_[v.soldier] or {}
		table.insert(self.orderly_soldier_lvup_[v.soldier], v)
	end
end

--晋升信息(根据当前soldier_id, 取出升级target_id的 升级信息)
function get_lvup_info_by_lv(self, soldier_id, target_id)
	if not soldier_id then return end
	if not self.orderly_soldier_lvup_[soldier_id] then return end
	local up_info
	for k, v in pairs(self.orderly_soldier_lvup_[soldier_id]) do
		if v.target == target_id then
			up_info = v
			break
		end
	end
	if not up_info then elog("not found up_info. soldier_id = %s, target_id = %s", soldier_id, target_id) end
	return up_info
end

function get_soldier_info_by_build_type(self, build_type)
	local data = self:get_orderly_soldier_info(build_type)
	if not data[build_type] then 
		elog("the key not found in table, key = %s", build_type)
		return 
	end
	return data[build_type]
end

function get_orderly_soldier_info(self, build_type)
	if build_type == config.BUILD_TYPE.TRAP then
		return self.orderly_trap_info_
	end
	return self.orderly_soldier_info_
end

--检查该建筑士兵状态（是否正在训练，是否有未收取的小兵）
function check_soldier_state(self, build_type)
	if not build_type then return end
	local soldiers = self:get_orderly_soldier_info(build_type)[build_type]
	if not soldiers then return end
	local timer_exis, finish_train, soldier
	for _, v in pairs(soldiers) do
		if v.end_time_ or v.select_count_ then
			soldier = v
			break
		end
	end
	
	if not soldier then return end
	timer_exis = soldier:is_counting()
	--没有倒计时，但是有count 说明。训练完成
	if not timer_exis and soldier.select_count_ then
		finish_train = true
	end
	return timer_exis, finish_train, soldier.id_, soldier.class_
end

function get_soldier_prop_by_id(self, id, soldier_class)
	soldier_class = soldier_class or config.SOLDIER_CLASS.COMMON
	local data
	if soldier_class == config.SOLDIER_CLASS.COMMON then
		data = SoldierConfig.SoldierData
	elseif soldier_class == config.SOLDIER_CLASS.TRAP then
		data = TrapConfig.TrapData
	end
    return data[id]
end

function IsResEnough(self, soldierID, soldierCnt, index, soldierClass)
	local prop = self:get_soldier_prop_by_id(soldierID, soldierClass).upcost[index]
	if not prop then return true end
	local cost = prop[3] * soldierCnt
	local had = ItemManager:get_resource(prop[1]) or 0
	return had >= cost
end

function PromoteSoldier(self, buildID, soldierID, onSuccess)
	--TODO
end

function TrainSoldier(self, buildID, soldierID, soldierCnt, soldierClass, useGold, onSuccess)
	if not soldierCnt or soldierCnt ~= soldierCnt or soldierCnt <= 0 then
		MsgCenter.send_message(Msg.SHOW_HINT, string.format("Invalid soldier count: %s", soldierCnt))
		return
	end
	soldierClass = soldierClass or config.SOLDIER_CLASS.COMMON
	local buildType = BuildManager:get_build_info_by_id(buildID).build_type_
	local _, _, soldier, _ = self:check_soldier_state(buildType)
	if soldier then
		MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_SOLDIER_IN_ARMY_TRAINING"))
		return
	end
	if useGold then
		local soldier = self:get_soldier_info_by_id(soldierID, soldierClass)
		local need = soldier:get_gold_drill_number(soldierCnt)
		local has = ItemManager:get_count(config.ITEM_GOLD)
		if has < need then
			_G.MsgCenter.send_message(Msg.SHOW_HINT, lang("BUILD_SOLDIER_FINISH7"))
			return
		end
	end
	for i = 1, #self:get_soldier_prop_by_id(soldierID, soldierClass).upcost do
		if not self:IsResEnough(soldierID, soldierCnt, i, soldierClass) then
			_G.MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_SOLDIER_PROPS_NOT_ENOUGH"))
			return
		end
	end

	local cb = function()
		if type(onSuccess) == "function" then
			onSuccess()
		end
		if _G.EventKey then
			_G.event.fire(_G.EventKey.CITY_SOIDIER_UPDATE, {buildID = buildID, soldierID = soldierID, soldierClass = soldierClass})
			return
		end
		_G.MsgCenter.send_message(Msg.CITY_SOIDIER_UPDATE, buildID, soldierID, soldierClass)
	end

	local msg, data
	if soldierClass == config.SOLDIER_CLASS.COMMON then
		msg = useGold and "build_soldier_finish" or "build_soldier"
		data = {
			id = buildID,
			soldier = soldierID,
			soldiercnt = soldierCnt,
		}
	elseif soldierClass == config.SOLDIER_CLASS.TRAP then
		msg = useGold and "create_trap_finish" or "create_trap"
		data = {
			trap_id = soldierID,
			create_cnt = soldierCnt,
			build_id = buildID,
		}
	end
	local send = function()
		Net.send(msg, data, function(result)
			if result.e == 0 then cb() end
		end)
	end
	if useGold then
		_G.UIController:ShowUI("UICommonPop", {
			mode = 0,
			content = lang("UI_SOLDIER_FINISH"),
			callback = send,
		})
	else
		send()
	end
end

function GoldSpeedUp(self, buildID, soldierID, soldierClass, onSuccess)
	soldierClass = soldierClass or config.SOLDIER_CLASS.COMMON
	local callback = function()
		local soldier = self:get_soldier_info_by_id(soldierID, soldierClass)
		local need = soldier:get_gold_drill_number(soldierCnt)
		local has = ItemManager:get_count(config.ITEM_GOLD)
		if has < need then
			_G.MsgCenter.send_message(Msg.SHOW_HINT, lang("BUILD_SOLDIER_FINISH7"))
			return
		end
		local msg, data
		if soldierClass == config.SOLDIER_CLASS.COMMON then
			msg = "build_soldier_dectime"
			data = {id = buildID}
		elseif soldierClass == config.SOLDIER_CLASS.TRAP then
			msg = "create_trap_dectime"
			data = {build_id = buildID}
		end
		Net.send(msg, data, function(result)
			if result.e == 0 and type(onSuccess) == "function" then
				onSuccess()
			end
		end)
    end
	_G.UIController:ShowUI("UICommonPop", {
		mode = 0,
		content = lang("UI_SOLDIER_FINISH"),
		callback = callback,
	})
end

function ItemSpeedUp(self, buildID, soldierID, itemID, itemCnt, soldierClass, onSuccess)
	soldierClass = soldierClass or config.SOLDIER_CLASS.COMMON
	local msg, data
	if soldierClass == config.SOLDIER_CLASS.COMMON then
		msg = "build_soldier_dectime"
		data = {id = buildID, itemid = itemID, itemcnt = itemCnt}
	elseif soldierClass == config.SOLDIER_CLASS.TRAP then
		msg = "create_trap_dectime"
		data = {build_id = buildID, item_id = itemID, item_cnt = itemCnt}
	end
	Net.send(msg, data, function(result)
		if result.e == 0 and type(onSuccess) == "function" then
			onSuccess()
		end
	end)
end

function CancelTrain(self, buildID, soldierID, soldierClass, onSuccess)
	soldierClass = soldierClass or config.SOLDIER_CLASS.COMMON
	local callback = function()
		local msg, data
		if soldierClass == config.SOLDIER_CLASS.COMMON then
			msg = "build_soldier_cancel"
			data = {id = buildID}
		elseif soldierClass == config.SOLDIER_CLASS.TRAP then
			msg = "create_trap_cancel"
			data = {trap_id = soldierID, build_id = buildID}
		end
		Net.send(msg, data, function(result)
			if result.e == 0 and type(onSuccess) == "function" then
				onSuccess()
			end
		end)
	end
	local rebate = self:get_soldier_prop_by_id(soldierID, soldierClass).rebate
	_G.UIController:ShowUI("UICommonPop", {
		mode = 0,
		content = lang("UI_SOLDIER_REBATE", rebate),
		callback = callback,
	})
end

function PickTrained(self, buildID, soldierID, soldierClass, onSuccess)
	local msg, data
	if soldierClass == config.SOLDIER_CLASS.COMMON then
		msg = "build_soldier_pick"
		data = {id = buildID}
	elseif soldierClass == config.SOLDIER_CLASS.TRAP then
		msg = "create_trap_pick"
		data = {build_id = buildID}
	end
	Net.send(msg, data, function(result)
		if result.e == 0 and type(onSuccess) == "function" then
	        onSuccess()
	    end
	end)
end

function RemoveTrap(self, soldierID, soldierCnt, onSuccess)
	Net.send("removed_trap", {trap_id = soldierID, removed_cnt = soldierCnt}, function(result)
		if result.e == 0 and type(onSuccess) == "function" then
			onSuccess()
		end
	end)
end
