module("CollectManager", package.seeall)

function initialize(self)
	self.collect_data_ = {}
    self.collect_unlock_ = {}

    Net.register(self, "build_produce_all", on_build_collect_all)
    Net.register(self, "build_produce", on_build_collect)
    Net.register(self, "cityunlock_info", on_city_unlock_info)
end

function on_build_collect_all(self, data)
    if not data then return end
    for i,v in ipairs(data.list) do
        self.collect_data_[v.id] = CityCollect(v.id)
        self.collect_data_[v.id]:refresh_data(v)
    end
end

function on_build_collect(self, data)
    if not data then return end
    if not self.collect_data_[data.id] then 
        self.collect_data_[data.id] = CityCollect(data.id)
    end
    self.collect_data_[data.id]:refresh_data(data)
     _G.event.fire(_G.EventKey.PRODUCE_UPDATE)  
end

function on_city_unlock_info(self, data)
    if not data then return end
    for i,v in ipairs(data.list) do
        self.collect_unlock_[v] = v 
    end
end

function get_attrs_buff(self, id, value)
    if not id then return end
    if not self.collect_data_[id] then return end
    return self.collect_data_[id]:get_attrs_buff(value)
end

function get_collect(self, id)
    if not id then return end
    return self.collect_data_[id]
end

function get_same_collect_list(self, buildType)
    local list = {}
    for k,v in pairs(self.collect_data_) do
        if v.type_ == buildType then
            table.insert(list, v)
        end
    end
    return list
end
