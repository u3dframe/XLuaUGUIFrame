module("TimerManager", package.seeall)


function initialize(self)
    self:dispose()
    self.delta_time_ = Net.server_time()
    local function update_timer()
        self.delta_time_ = Net.server_time() - self.delta_time_
        for k,v in pairs(self.listeners_) do
            local timer = v[1]
            if timer and timer:get_active_state() then
                timer:play(self.delta_time_)
                if timer:check() then
                    v[2](unpack(v[3]))
                    timer:close_state()
                end
            end
        end
        self.delta_time_ = Net.server_time()
    end
    self.timer_ = LuaTimer.Add( 0, 1000, update_timer)
end

function add_listener(self, timer, callback, ...)
    if not timer then
        return
    end
    local key = timer.key_
    if key and callback then
        local args = {...}
        timer:active_state()
        self.listeners_[key] = {}
        self.listeners_[key][1] = timer
        self.listeners_[key][2] = callback
        self.listeners_[key][3] = args
    end
end

function dispose(self)
    self.listeners_ = {}
    if self.timer_ then
        LuaTimer.Delete(self.timer_)
        self.timer_ = nil
    end  
end