module("MailManager", package.seeall)


local EventKey = _G.EventKey
local event = _G.event


function initialize(self)
    self.mails_ = {}
    self.mail_count_ = {}
    self.unread_mail_count_ = {}
    for _, mt in pairs(config.MAIL_MODULE_TYPES) do
        self.mails_[mt] = {}
        self.mail_count_[mt] = {}
        self.unread_mail_count_[mt] = {}
        for _, v in pairs(config.MAIL_TYPES[mt]) do
            self.mails_[mt][v] = {}
            self.mail_count_[mt][v] = 0
            self.unread_mail_count_[mt][v] = 0
        end
    end

    Net.register(self, "email_info", on_get_common)
    Net.register(self, "email_expire_del", on_delete_expire_common)
    Net.register(self, "report_wild", on_get_report)
    Net.register(self, "report_expire_del", on_delete_expire_report)
    Net.register(self, "report_resource", on_get_report)
    Net.register(self, "report_fight", on_get_report)
    Net.register(self, "report_detect", on_get_report)
    Net.register(self, "battleresult_log", _battle_data_for_test)
end

local cache = {}
function _battle_data_for_test(self, data)
    local text = data.text
    if text then
        table.insert(cache, text)
    else
        local ttext = table.concat(cache)
        cache = {}
        UIManager.open_window("TestBattleDataWindow", nil, ttext)
    end
end

function _add_mail(self, mail)
    if mail:is_deleted() then return end
    local mt = self.mails_[mail.module_type_]
    if mt then
        if mt[mail.type_] then
            mt[mail.type_][mail.id_] = mail
            local cnts = self.mail_count_[mail.module_type_]
            cnts[mail.type_] = cnts[mail.type_] + 1
            if not mail:is_read() then
                local ucnts = self.unread_mail_count_[mail.module_type_]
                ucnts[mail.type_] = ucnts[mail.type_] + 1
            end
        end
    end
end

function _delete_mail(self, mail)
    local mt = self.mails_[mail.module_type_]
    if mt then
        if mt[mail.type_] then
            mt[mail.type_][mail.id_] = nil
            mail:on_delete()
            local cnts = self.mail_count_[mail.module_type_]
            cnts[mail.type_] = cnts[mail.type_] - 1
            if not mail:is_read() then
                local ucnts = self.unread_mail_count_[mail.module_type_]
                ucnts[mail.type_] = ucnts[mail.type_] - 1
            end
        end
    end
end

--------------------------------↓服务器协议回调函数↓--------------------------------

function on_get_common(self, data)
    local module_type = config.MAIL_MODULE_TYPES.COMMON
    for _, info in pairs(data.emails) do
        local mail = Mail(module_type, info)
        self:_add_mail(mail)
    end
    if EventKey then
        event.fire(EventKey.MAIL_CHANGE)
    end
end

function on_delete_expire_common(self, data)
    local module_type = config.MAIL_MODULE_TYPES.COMMON
    local mt = self.mails_[module_type]
    for _, id in pairs(data.ids) do
        local mail, ty = self:find_mail(module_type, id)
        if mail then
            self:_delete_mail(mail)
        end
    end
    if EventKey then
        event.fire(EventKey.MAIL_CHANGE)
    end
end

function on_get_report(self, data)
    --暂时屏蔽战斗报告
    local module_type = config.MAIL_MODULE_TYPES.REPORT
    for _, info in pairs(data.list) do
        local mail = Mail(module_type, info)
        if mail.type_ ~= config.MAIL_TYPES[module_type].BATTLE then
            self:_add_mail(mail)
        end
    end
    if EventKey then
        event.fire(EventKey.MAIL_CHANGE)
    end
end

function on_delete_expire_report(self, data)
    local mt = self.mails_[config.MAIL_MODULE_TYPES.REPORT]
    if mt[data.type] and mt[data.type][data.id] then
        mail = mt[data.type][data.id]
        self:_delete_mail(mail)
        if EventKey then
            event.fire(EventKey.MAIL_CHANGE)
        end
    end
end

--------------------------------↑服务器协议回调函数↑--------------------------------


function get_read_msg(self, module_type, onekey)
    local ok = onekey and "_onekey" or ""
    if module_type == config.MAIL_MODULE_TYPES.COMMON then
        return string.format("email%s_read", ok)
    elseif module_type == config.MAIL_MODULE_TYPES.REPORT then
        return string.format("report%s_read", ok)
    end
    elog("No read msg of module type "..tostring(module_type))
end

function get_pick_msg(self, module_type)
    if module_type == config.MAIL_MODULE_TYPES.COMMON then
        return "email_pick"
    elseif module_type == config.MAIL_MODULE_TYPES.REPORT then
        return "report_pick"
    end
    elog("No pick msg of module type "..tostring(module_type))
end

function get_delete_msg(self, module_type, onekey)
    local ok = onekey and "_onekey" or ""
    if module_type == config.MAIL_MODULE_TYPES.COMMON then
        return string.format("email%s_delete", ok)
    elseif module_type == config.MAIL_MODULE_TYPES.REPORT then
        return string.format("report%s_delete", ok)
    end
    elog("No delete msg of module type "..tostring(module_type))
end

local SubTypes = {
    [config.MAIL_MODULE_TYPES.REPORT] = {
        [config.MAIL_TYPES[config.MAIL_MODULE_TYPES.REPORT].BATTLE] = {
            config.MAIL_TYPES[config.MAIL_MODULE_TYPES.REPORT].BATTLE,
            config.MAIL_TYPES[config.MAIL_MODULE_TYPES.REPORT].DETECT,
            --config.MAIL_TYPES[config.MAIL_MODULE_TYPES.REPORT].BATTLE_OTHER,
        }
    }
}

function is_subtype(self, module_type, parent, sub)
    if parent == sub then return true end
    local mt = SubTypes[module_type]
    if not mt or not mt[parent] then return false end
    for _, t in pairs(mt[parent]) do
        if t == sub then return true end
    end
    return false
end

function get_all_subtypes(self, module_type, mail_type)
    local mt = SubTypes[module_type]
    if mt then
        if mt[mail_type] then return mt[mail_type] end
    end
    return {mail_type}
end

function get_given_subtypes(self, module_type, mail_type, subtype)
    if subtype then return {subtype} end
    return self:get_all_subtypes(module_type, mail_type)
end

function get_mails_by_type(self, module_type, mail_type)
    local mails
    local mt = self.mails_[module_type]
    if mt then
        mails = mt[mail_type]
        if not mails then
            elog(string.format("The mail type '%s' does not exist", mail_type))
        end
    else
        elog(string.format("The mail modul type '%s' does not exist", module_type))
    end
    return mails or {}
end

function mail_comparator(a, b)
    return a.time_ > b.time_
end

function get_mail_list_by_type(self, module_type, mail_type, subtype)
    local list = {}
    local types = self:get_given_subtypes(module_type, mail_type, subtype)
    for _, ty in pairs(types) do
        for _, mail in pairs(self:get_mails_by_type(module_type, ty)) do
            table.insert(list, mail)
        end
    end
    return list
end

function get_sorted_mail_list_by_type(self, module_type, mail_type, subtype)
    local list = self:get_mail_list_by_type(module_type, mail_type, subtype)
    table.sort(list, mail_comparator)
    return list
end

function get_mails_count(self, module_type, mail_type)
    local cnt = 0
    local mt = self.mail_count_[module_type]
    if mt then
        for _, ty in pairs(self:get_all_subtypes(module_type, mail_type)) do
            cnt = cnt + (mt[ty] or 0)
        end
    end
    return cnt
end

function get_unread_mails_count(self, module_type, mail_type)
    local cnt = 0
    local mt = self.unread_mail_count_[module_type]
    if mt then
        for _, ty in pairs(self:get_all_subtypes(module_type, mail_type)) do
            cnt = cnt + (mt[ty] or 0)
        end
    end
    return cnt
end

function get_mail(self, module_type, mail_type, mail_id)
    local mt = self.mails_[module_type]
    if mt then
        local t = mt[mail_type]
        if t and t[mail_id] then return t[mail_id], mail_type end
        for _, ty in pairs(self:get_all_subtypes(module_type, mail_type)) do
            if mt[ty][mail_id] then
                return mt[ty][mail_id], ty
            end
        end
    end
end

function find_mail(self, module_type, mail_id)
    local mt = self.mails_[module_type]
    if mt then
        for ty, mails in pairs(mt) do
            if mails[mail_id] then
                return mails[mail_id], ty
            end
        end
    end
end

function on_read_mail_successfully(self, module_type, mail_type, mails, read_time)
    read_time = read_time or os.time()
    for _, mail in pairs(mails) do
        local em = self:get_mail(module_type, mail.type_, mail.id_)
        if em and not em:is_read() then
            em:on_read(read_time)
            local mt = self.unread_mail_count_[module_type]
            mt[em.type_] = mt[em.type_] - 1
        end
    end
    -- if EventKey then
    --     event.fire(EventKey.MAIL_CHANGE)
    --     return
    -- end
end

function send_read_msg(self, module_type, mail_type, subtypes, mails)
    local msg = self:get_read_msg(module_type)
    if msg then
        local data = {}
        if module_type == config.MAIL_MODULE_TYPES.REPORT then
            data.types = subtypes
        end
        if #mails == 1 then
            data.id = mails[1].id_
        end
        Net.send(msg, data, function(res)
            if res.e == 0 then
                self:on_read_mail_successfully(module_type, mail_type, mails, res.readtime)
            end
        end)
    end
end

function send_onekey_read_msg(self, module_type, mail_type, subtypes, to_read, to_gain)
    local msg = self:get_read_msg(module_type, true)
    if msg then
        local data = {
            types = #subtypes == 1 and subtypes[1] or subtypes
        }
        Net.send(msg, data, function(res)
            if res.e == 0 then
                --readtime和picktime的数值对客户端无意义，随便采用一个非空值即可
                local time = os.time()
                if #to_read > 0 then
                    self:on_read_mail_successfully(module_type, mail_type, to_read, time)
                end
                if #to_gain > 0 then
                    self:on_pick_mail_successfully(module_type, mail_type, to_gain, time)
                end
            end
        end)
    end
end

function read_mail(self, module_type, mail_type, mail_id)
    local mail, ty = self:get_mail(module_type, mail_type, mail_id)
    if mail and not mail:is_read() then
        self:send_read_msg(module_type, mail_type, {ty}, {mail})
    end
end

--批量读邮件，会同时领取奖励
function read_mails(self, module_type, mail_type, subtype)
    local to_read = {}
    local to_gain = {}
    local types = self:get_given_subtypes(module_type, mail_type, subtype)
    for _, ty in pairs(types) do
        for _, mail in pairs(self:get_mails_by_type(module_type, ty)) do
            if not mail:is_read() then
                table.insert(to_read, mail)
            end
            if mail:has_ungained_rewards() then
                table.insert(to_gain, mail)
            end
        end
    end
    if module_type == config.MAIL_MODULE_TYPES.REPORT and #to_read > 0 then
        self:send_read_msg(module_type, mail_type, types, to_read)
    elseif module_type == config.MAIL_MODULE_TYPES.COMMON and (#to_read > 0 or #to_gain > 0) then
        self:send_onekey_read_msg(module_type, mail_type, types, to_read, to_gain)
    end
end

function has_ungained_rewards_by_type(self, module_type, mail_type)
    local types = self:get_all_subtypes(module_type, mail_type)
    for _, ty in pairs(types) do
        for _, mail in pairs(self:get_mails_by_type(module_type, ty)) do
            if mail:has_ungained_rewards() then
                return true
            end
        end
    end
    return false
end

function has_ungained_rewards_by_id(self, module_type, mail_type, mail_id)
    local mail = self:get_mail(module_type, mail_type, mail_id)
    if mail then return mail:has_ungained_rewards() end
    return false
end

function on_pick_mail_successfully(self, module_type, mail_type, mails, pick_time)
    local rewards = {}
    for _, mail in pairs(mails) do
        local em = self:get_mail(module_type, mail.type_, mail.id_)
        if em and em:has_ungained_rewards() then
            em:on_gain_rewards(pick_time)
            for _, r in pairs(em.rewards_) do
                table.insert(rewards, r)
            end
        end
    end
    MsgCenter.send_message(Msg.TOP_BANNER_REWARDS_ANI, rewards)
    if EventKey then
        event.fire(EventKey.MAIL_CHANGE)
    end
end

function send_pick_msg(self, module_type, mail_type, mail)
    local msg = self:get_pick_msg(mail.module_type_)
    if msg then
        Net.send(msg, {id = mail.id_}, function(res)
            if res.e == 0 then
                self:on_pick_mail_successfully(module_type, mail_type, {mail}, res.picktime)
                self:on_read_mail_successfully(module_type, mail_type, {mail}, res.readtime)
            end
        end)
    end
end

function gain_rewards_by_id(self, module_type, mail_type, mail_id)
    local mail, ty = self:get_mail(module_type, mail_type, mail_id)
    if mail and mail:has_ungained_rewards() then
        self:send_pick_msg(module_type, mail_type, mail)
    end
end

function delete_mail(self, module_type, mail_type, mail_id, on_success)
    local msg = self:get_delete_msg(module_type)
    if not msg then return end
    local mail, ty = self:get_mail(module_type, mail_type, mail_id)
    if not mail then return end
    if mail:has_ungained_rewards() or not mail:is_read() then
        MsgCenter.send_message(Msg.SHOW_HINT, lang("MAIL_MUST_GAIN_BEFORE_DELETE"))
        return
    end
    _G.UIController:ShowUI("UICommonPop", {
        mode = 0,
        content = lang("MAIL_DELETE_CONFIRM"),
        callback = function()
            Net.send(msg, {id = mail.id_, types = {mail_type}}, function(res)
                if res.e ~= 0 then return end
                if mail:is_deleted() then return end
                self:_delete_mail(mail)
                if type(on_success) == "function" then
                    on_success()
                end
                if EventKey then
                    event.fire(EventKey.MAIL_CHANGE)
                end
            end)
        end,
    })
end

function delete_mails(self, module_type, mail_type, subtype, on_success)
    --普通邮件的一键删除用email_onekey_delete消息，战报的一键删除用report_delete消息
    local msg = self:get_delete_msg(module_type, module_type == config.MAIL_MODULE_TYPES.COMMON)
    if not msg then return end
    local callback = function()
        local to_del = {}
        local types = self:get_given_subtypes(module_type, mail_type, subtype)
        local total = 0
        for _, ty in pairs(types) do
            for _, mail in pairs(self:get_mails_by_type(module_type, ty)) do
                total = total + 1
                if mail:is_read() and not mail:has_ungained_rewards() then
                    table.insert(to_del, mail)
                end
            end
        end
        local func = function()
            if #to_del == 0 then return end
            local data = {}
            if module_type == config.MAIL_MODULE_TYPES.COMMON then
                data.type = types[1]
            elseif module_type == config.MAIL_MODULE_TYPES.REPORT then
                data.types = types
            end
            Net.send(msg, data, function(res)
                if res.e == 0 then
                    if res.list then    --如果有list字段，用其更新邮件，否则用客户端本地数据更新
                        for ty, info in pairs(res.list) do
                            for _, id in pairs(info.ids) do
                                local mail = self:get_mail(config.MAIL_MODULE_TYPES.REPORT, ty, id)
                                if mail and not mail:is_deleted() then
                                    self:_delete_mail(mail)
                                end
                            end
                        end
                    else
                        for _, mail in pairs(to_del) do
                            if not mail:is_deleted() then
                                self:_delete_mail(mail)
                            end
                        end
                    end
                    if type(on_success) == "function" then
                        on_success()
                    end
                    if EventKey then
                        event.fire(EventKey.MAIL_CHANGE)
                        return
                    end
                end
            end)
        end
        if #to_del ~= total then
            _G.UIController:ShowUI("UICommonPop", {
                mode = 0,
                content = lang("MAIL_DELETE_FINAL_CONFIRM"),
                callback = func,
            })
        else
            func()
        end
    end
    _G.UIController:ShowUI("UICommonPop", {
        mode = 0,
        content = lang("MAIL_DELETE_CONFIRM"),
        callback = callback,
    })
end
