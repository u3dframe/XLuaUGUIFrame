module("SkillManager", package.seeall)


--技能加成类型
SkillBuffTypes = {
    Percent = 1,       --百分比
    Value = 2,      --数值
}

local SkillBuffUnit = 100


local ItemConfig = _G.Database.ItemConfig
local HeroConfig = _G.Database.HeroConfig
local ItemManager = _G.ItemManager
local HeroManager = _G.HeroManager


function initialize(self)
    self.skills_ = {}
    for _, v in pairs(config.SKILL_TYPES) do
        self.skills_[v] = {}
    end

    Net.register(self, "bagskill_all", on_bagskill_all)
    Net.register(self, "bagskill_change", on_bagskill_change)
end

--------------------------------↓服务器协议回调函数↓--------------------------------

function on_bagskill_all(self, data)
    if not data then return end
    for i, id in pairs(data.ids) do
        local cnt = data.cnts[i] or 0
        if cnt > 0 then
            local cfg = HeroConfig.SkillData[id]
            if cfg and self.skills_[cfg.type] then
                self.skills_[cfg.type][id] = Skill(id, cnt)
            end
        end
    end
end

function on_bagskill_change(self, data)
    if not data then return end
    for _, v in pairs(data.list) do
        local id = v.id
        local cfg = HeroConfig.SkillData[id]
        if cfg and self.skills_[cfg.type] then
            local last = v.last or 0
            local t = self.skills_[cfg.type]
            if last > 0 then    
                if not t[id] then
                    t[id] = Skill(id, last)
                else
                    t[id].count_ = last
                end
            elseif t[id] then
                t[id].count_ = 0
                t[id] = nil
            end
        end
    end

    MsgCenter.send_message(Msg.SKILL_CHANGE, data.list)
end

function get_config(self, id)
    return HeroConfig.SkillData[id]
end

function skill_comparator(a, b)
    return skill_cfg_comparator(a.cfg_, a.id_, b.cfg_, b.id_)
end

function skill_cfg_comparator(cfg1, id1, cfg2, id2)
    if cfg1.rare ~= cfg2.rare then return cfg1.rare > 0 end
    return id1 < id2
end

function get_skill_list_by_type(self, _type)
    local list = {}
    for _, skill in pairs(self.skills_[_type] or {}) do
        table.insert(list, skill)
    end
    return list
end

function get_sorted_skill_list_by_type(self, _type)
    local list = self:get_skill_list_by_type(_type)
    table.sort(list, skill_comparator)
    return list
end

function get_skill_by_id(self, id)
    local cfg = HeroConfig.SkillData[id]
    if not cfg then return end
    local data = self.skills_[cfg.type]
    return data and data[id]
end

function get_skill_cfg_by_frag_id(self, frag_id)
    local data = ItemConfig.Auto_combineData[frag_id]
    if not data then return end
    local id = data.combine[2]
    return HeroConfig.SkillData[id], id, data.num
end

function GetSortedSkillFragmentsIDByType(self, ty)
    local ret = {}
    for id, _ in pairs(ItemManager:get_all_item_cfg_of_showpoint(config.ITEM_SHOW_POINT.SKILL_BAG)) do
        local sk = self:get_skill_cfg_by_frag_id(id)
        if sk and sk.type == ty then
            table.insert(ret, id)
        end
    end
    table.sort(ret, function(a, b)
        local sk1, id1, _ = self:get_skill_cfg_by_frag_id(a)
        local sk2, id2, _ = self:get_skill_cfg_by_frag_id(b)
        return self.skill_cfg_comparator(sk1, id1, sk2, id2)
    end)
    return ret
end

function get_skill_buff_desc(self, skill_id, level, hero_id)
    local skillCfg = HeroConfig.SkillData[skill_id]
    if skillCfg then
        local hero = HeroManager:get_hero_by_id(hero_id)
        if hero then
            local attr = hero:get_attr(skillCfg.type) / SkillBuffUnit
            local total_data = {}
            local update_data = {}
            for i, params in ipairs(skillCfg.desc_para) do
                local buff = params[2] + params[3] * (level - 1)
                if params[1] == SkillBuffTypes.Percent then
                    total_data[i] = UIUtil.get_precise_decimal(buff * attr * 100, 2).."%"
                    update_data[i] = UIUtil.get_precise_decimal(buff * 100, 2).."%"
                else
                    total_data[i] = UIUtil.get_precise_decimal(buff * attr, 2)
                    update_data[i] = UIUtil.get_precise_decimal(buff, 2)
                end
            end
            local desc_total = GameUtil.StringFormat(skillCfg.desc_total, unpack(total_data))
            local desc_update = GameUtil.StringFormat(skillCfg.desc_update, unpack(update_data))
            local desc = string.format("%s\n(%s)", desc_total, desc_update)
            return desc
        end
    end
    return ""
end

function get_skill_desc_next_lv(self, skill_id, curr_lv)
    local skillCfg = HeroConfig.SkillData[skill_id]
    if skillCfg then
        local update_data = {}
        for i, params in ipairs(skillCfg.desc_para) do
            local buff = params[2] + params[3] * curr_lv
            if params[1] == SkillBuffTypes.Percent then
                update_data[i] = UIUtil.get_precise_decimal(buff * 100, 2).."%"
            else
                update_data[i] = UIUtil.get_precise_decimal(buff, 2)
            end
        end
        local desc_update = GameUtil.StringFormat(skillCfg.desc_update, unpack(update_data))
        local desc = string.format("%s (%s)", lang("SKILL_NEXT"), desc_update)
        return desc
    end
    return ""
end

function get_skill_level_exp(self, skillid, level)
    local sk = HeroConfig.SkillData[skillid]
    if not sk then return end
    local exp = HeroConfig.Skill_upData[level]
    if not exp then return end
    return exp.exp * sk.exp_para
end

--技能等级是否达到最高（与武将星级无关）
function is_skill_lv_max(self, lv)
    if type(lv) ~= "number" then return true end
    return HeroConfig.Skill_upData[lv] == nil
end

function is_skill_lv_max_by_star(self, skill_lv, hero_id, hero_star)
    return skill_lv >= HeroManager:get_hero_skill_max_lv(hero_id, hero_star)
end

function CalcTotalExpToLevel(self, serverSkill, level)
    local exp = self:get_skill_level_exp(serverSkill.skillid, serverSkill.level) - serverSkill.exp
    for lv = serverSkill.level + 1, level - 1 do
        exp = exp + self:get_skill_level_exp(serverSkill.skillid, lv)
    end
    return exp
end

function CalcMaxLv(self, hero, serverSkill)
    local maxLvByStar = HeroManager:get_hero_skill_max_lv(hero.id_, hero.star_)
    if serverSkill.level >= maxLvByStar then return serverSkill.level end
    local totalExpOfItems = 0
    for i, info in ipairs(_G.Database.BasicConfig.BasicData.hero_skill_items) do
        local cnt = ItemManager:get_count(config.ITEM_ITEM, info[1])
        totalExpOfItems = totalExpOfItems + info[2] * cnt
    end
    local maxLv = serverSkill.level
    local currExp = serverSkill.exp
    while maxLv < maxLvByStar and totalExpOfItems > 0 do
        local total = self:get_skill_level_exp(serverSkill.skillid, maxLv)
        if not total then break end
        local addExp = math.min(totalExpOfItems, total - currExp)
        totalExpOfItems = totalExpOfItems - addExp
        currExp = currExp + addExp
        if currExp >= total then
            maxLv = maxLv + 1
            currExp = currExp - total
        end
    end
    return maxLv
end

function CalcAllExpOfSkill(self, serverSkill)
    local exp = 0
    for lv = 1, serverSkill.level - 1 do
        exp = exp + self:get_skill_level_exp(serverSkill.skillid, lv)
    end
    return exp + serverSkill.exp
end

function learn_skill(self, hero_id, pos, skill_id)
    Net.send("heroskill_learn", {
        id = hero_id,
        pos = pos,
        skillid = skill_id,
    }, function(res)
        if res.e == 0 then
            local hero = HeroManager:get_hero_by_id(hero_id)
            hero:learn_skill_on_lient(pos, skill_id)
            _G.event.fire(_G.EventKey.CITY_HERO_SKILL, {id = hero.id_})
        end
    end)
end

function levelup_skill(self, hero_id, pos, skill_id, item_infos)
    local hero = HeroManager:get_hero_by_id(hero_id)
    if not hero then return end
    local skill = hero:get_skill_by_pos(pos)
    if not skill then return end
    if self:is_skill_lv_max(skill.level) then return end
    if self:is_skill_lv_max_by_star(skill.level, hero_id, hero.star_) then return end
    local cost = {}
    for _, info in ipairs(item_infos) do
        if info[2] > 0 then
            table.insert(cost, {array = {config.ITEM_ITEM, info[1], info[2]}})
        end
    end
    if not next(cost) then return end
    Net.send("heroskill_levelup", {
        id = hero_id,
        pos = pos,
        skillid = skill_id,
        cost = cost,
    }, function(res)
        if res.e == 0 then
            hero:levelup_skill_on_client(pos, skill_id, res.level, res.exp)
            _G.event.fire(_G.EventKey.CITY_HERO_SKILL, {id = hero.id_})
        end
    end)
end

function forget_skill(self, hero_id, pos, skill_id)
    Net.send("heroskill_forget", {
        id = hero_id,
        pos = pos,
        skillid = skill_id,
    }, function(res)
        if res.e == 0 then
            local hero = HeroManager:get_hero_by_id(hero_id)
            hero:forget_skill_on_client(pos, skill_id)
            _G.event.fire(_G.EventKey.CITY_HERO_SKILL, {id = hero.id_})
        end
    end)
end

function resolve_skill(self, skillid, cnt)
    Net.send("bagskill_resolve", {
        skillid = skillid,
        cnt = cnt,
    }, function(res)
        if res.e == 0 then
            _G.event.fire(_G.EventKey.SKILL_BAG)
        end
    end)
end

function onekey_resolve_skill(self, _type, rare)
    Net.send("bagskill_resolve_onekey", {
        type = _type,
        rare = rare,
    }, function(res)
        if res.e == 0 then
            _G.event.fire(_G.EventKey.SKILL_BAG)
        end
    end)
end
