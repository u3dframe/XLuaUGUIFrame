module("WorldManager", package.seeall)


local AttrsManager = _G.AttrsManager
local config = _G.config
local lang = _G.lang
local SoldierConfig = _G.Database.SoldierConfig
local HeroConfig = _G.Database.HeroConfig
local BasicConfig = _G.Database.BasicConfig

local ObjTypeServer2Client = {
    [1] = config.WORLD_MAIN,
    [2] = config.WORLD_MONSTER,
    [3] = config.WORLD_MARCH,
    [4] = config.WORLD_FORT,
    [5] = config.WORLD_RESPOINT,
}


function initialize(self)
    self:on_dispose()
    -- 战斗队列(不需要每次都释放)
    self.battle_queue_ = {}
    self.battleQueueList = {}
    self.messager_ = Messager:new(self)
    self.messager_:add_listener(Msg.SCENE_UPDATE, on_update_scene)
    self.messager_:add_listener(Msg.WORLD_ENABLE_WATCH, on_refresh_watch) 
    self.messager_:add_listener(Msg.WORLD_ENABLE_WATCH2, on_refresh_watch2) 
    
    self.march_id_ = 0
    Net.register(self, "map_monster", on_map_monster)
    Net.register(self, "map_city", on_map_city)
    Net.register(self, "map_army", on_map_army)
    Net.register(self, "map_delete", on_map_delete)
    Net.register(self, "map_fortified", on_map_fortified)
    Net.register(self, "map_respoint", on_map_respoint)
    
    Net.register(self, "army_info", on_army_info) --行军队列
    Net.register(self, "army_return", on_army_return)
    Net.register(self, "respoint_buff", on_respoint_buff)
    Net.register(self, "monster_battle_lv", on_monster_battle_lv)
end

function on_dispose(self)
    self.worldDelayReturnCityMarch = {}
    self.world_monster_ = {}
    self.world_main_ = {}
    self.world_march_queue_ = {}  
    self.world_fort_ = {}
    self.world_respoint_ = {}
    -- 类型映射表
    self.world_type_ = {}
end

function get_client_obj_type_by_server(self, server_type)
    return ObjTypeServer2Client[server_type]
end

function on_map_city(self, data)
    --Debug.LogError(MasterManager.user_.name_.."--------map_city------>"..data.name)
    if MasterManager.user_.name_ == data.name then
        self.main_logic_x_ = data.x
        self.main_logic_z_ = data.y
    end
    local x = data.x
    local z = data.y
    local is_exist = false
    if self.world_main_[x] and self.world_main_[x][z] and
        self.world_main_[x][z].idx_ == data.id then
        is_exist = true
    end
    if is_exist then return end
    if not self.world_main_[x+1] then
        self.world_main_[x+1] = {}
    end    
    self.world_main_[x+1][z+1] = WorldMainJump(x+1, z+1, x, z)
    self.world_main_[x+1][z] = WorldMainJump(x+1, z, x, z)
    if not self.world_main_[x] then
        self.world_main_[x] = {}
    end
    self.world_main_[x][z] = WorldMain(x, z, data)
    self.world_main_[x][z+1] = WorldMainJump(x, z+1, x, z)
    self.world_type_[data.id] = self.world_main_[x][z].obj_type_
    MsgCenter.send_message(Msg.WORLD_REFRESH_OBJ, data.id)
end

function on_map_monster(self, data)
    local x = data.x
    local z = data.y
    if not self.world_monster_[x] then
        self.world_monster_[x] = {}
    end
    --log("--on_map_monster------------>"..dumpTab(data))
    local is_exist = false
    if self.world_monster_[x][z] then
        if self.world_monster_[x][z].idx_ == data.id then
            is_exist = true
        end
    end
    if is_exist then return end
    self.world_monster_[x][z] = WorldMonster(x, z, data.defid, data.id)
    self.world_type_[data.id] = self.world_monster_[x][z].obj_type_
    MsgCenter.send_message(Msg.WORLD_REFRESH_OBJ, data.id)
end


function on_map_army(self, data)
    if not data then return end
    log("--on_map_army------------>"..dumpTab(data))
    self.march_id_ = data.id
    local march = self.world_march_queue_[self.march_id_]
    local tmp_march = WorldMarch(data)
    local oldMarchType = march and march.army_type_
    local oldId = march and march.idx_
    local oldIsPlaying = march and march.is_play_
    local oldEndTime = march and march.runinfo_.ti_end
    self.world_march_queue_[self.march_id_] = tmp_march

    if oldMarchType and
        (oldMarchType == ArmyInfo.TO_MONSTER or
        oldMarchType == ArmyInfo.TO_FORTIFIED) and
        data.armytype == ArmyInfo.RET_CITY and
        data.id == oldId and
        oldIsPlaying and
        Net.server_time() - oldEndTime >= 0 and
        not self.worldDelayReturnCityMarch[data.id] then
            self.worldDelayReturnCityMarch[data.id] = _G.LuaTimer.Add( _G.config.BATTLE_COST_TIME * 1000,
            function()
                if SceneManager.World_Scene and SceneManager.World_Scene.is_complete_ then
                    MsgCenter.send_message(Msg.WORLD_MARCH_START, data.id)
                end
                self.worldDelayReturnCityMarch[data.id] = nil
            end)
    else
        dump(Net.server_time(), "Net.server_time()")
        dump(oldEndTime, "oldEndTime")
        if self.worldDelayReturnCityMarch[data.id] then
            return
        end
        if SceneManager.World_Scene and SceneManager.World_Scene.is_complete_ then
            MsgCenter.send_message(Msg.WORLD_MARCH_START, data.id)
        end
    end

    -- dump(oldMarchType, "oldMarchType = ")
    -- dump(data.armytype, "data.armytype = ")

    self.world_type_[data.id] = self.world_march_queue_[self.march_id_].obj_type_
end

function on_army_info(self, data)
    print("-on_army_info------------->")
    if not data then return end
    if not next(data) then return end
    --空队列也需要推送，让界面刷新
    --if not next(data.list) then return end
    dump(data.list, "-on_army_info------------->", 9)
    self.battleQueueList = {}
    self.battle_queue_ = {}
    for k,v in pairs(data.list) do
        local army_info = ArmyInfo(v)
        --local time = v.runinfo.ti_end - v.runinfo.ti_start 
        --elog(time.."--on_army_info------------>"..dumpTab(v))
        self.battle_queue_[v.id] = army_info
        _G.table.insert(self.battleQueueList, army_info)
        MsgCenter.send_message(Msg.WORLD_MARCH_BAR, v.id)
    end
    if _G.EventKey then
        _G.event.fire(_G.EventKey.CITY_WORLD_MARCH_BAR)
    end
end

function on_army_return(self, data)
    log("-on_army_return------------->"..dumpTab(data))
    MsgCenter.send_message(Msg.WORLD_MARCH_END)
    if _G.EventKey then
        _G.event.fire(_G.EventKey.CITY_WORLD_MARCH_END)
    end
end

function on_map_fortified(self, data)
    if not data then return end
    log("--on_map_fortified------------>"..dumpTab(data))
    local x = data.x
    local z = data.y
    if not self.world_fort_[x] then
        self.world_fort_[x] = {}
    end
    local is_exist = false
    if self.world_fort_[x][z] then
        if self.world_fort_[x][z].idx_ == data.id then
            is_exist = true
        end
    end
    if is_exist then
        self.world_fort_[x][z]:refresh_data(data)
        return 
    end
    self.world_fort_[x][z] = WorldFort(x, z, data)
    self.world_type_[data.id] = self.world_fort_[x][z].obj_type_
    MsgCenter.send_message(Msg.WORLD_REFRESH_OBJ, data.id)
end

function on_map_respoint(self, data)
    --log("--on_map_respoint------------>"..dumpTab(data))
    if not data then return end
    local x = data.x
    local z = data.y
    if not self.world_respoint_[x] then
        self.world_respoint_[x] = {}
    end
    local is_exist = false
    if self.world_respoint_[x][z] then
        if self.world_respoint_[x][z].idx_ == data.id then
            is_exist = true
        end
    end
    if is_exist then
        self.world_respoint_[x][z]:refresh_data(data)
        return 
    end
    self.world_respoint_[x][z] = WorldRespoint(x, z, data)
    self.world_type_[data.id] = self.world_respoint_[x][z].obj_type_
    MsgCenter.send_message(Msg.WORLD_REFRESH_OBJ, data.id)
end

function on_monster_battle_lv(self, data)
    self.monster_battle_lv_ = data.level
end

function on_respoint_buff(self, data)
    if data.ti == 0 then
        self.respoint_buff_ = nil
    else
        self.respoint_buff_ = data
    end
   -- MsgCenter.send_message(Msg.RESPOINT_REFRESH)
   _G.event.fire(_G.EventKey.RESPOINT_REFRESH)
end

function on_map_delete(self, data)
    local typp = 0
    if self.world_type_[data.id] then
        typp = self.world_type_[data.id]
    end
    log("--on_map_delete------------>"..dumpTab(data))
    if not data then return end
    local obj = self:get_world_obj_by_id(data.id)
    if not obj then
        local world_type = self.world_type_[data.id]
        elog(string.format("map delete failed, id = %d, type = %s", data.id, tostring(world_type)))
        return
    end
    if self:hasBattleQueue(data.id) then
        _G.LuaTimer.Add( _G.config.BATTLE_COST_TIME * 1000, function() obj:delete_self() end)
        return
    end

    obj:delete_self()
end

function on_update_scene(self)
    WorldAniTmp:on_update_scene()
end

function init_watch_pos(self)
    self.watch_x_ = self.main_logic_x_
    self.watch_z_ = self.main_logic_z_
end

function on_refresh_watch(self, name, logic)
    if not name then return end
    if not logic then return end
    local x, z = UIUtil.get_world_axis(name, logic)
    local data = {}
    data.x = x
    data.y = z
    Net.send("map_watch", data, function(result)
        if result.e == 0 then
            MsgCenter.send_message(Msg.WORLD_ENABLE_WATCH_CB, x, z)
        end
    end)
end

function on_refresh_watch2(self, x, z)
    if not x then return end
    if not z then return end
    local data = {}
    data.x = x
    data.y = z
    Net.send("map_watch", data, function(result)
        if result.e == 0 then
            MsgCenter.send_message(Msg.WORLD_ENABLE_WATCH_CB, x, z)
        end
    end)
end

-- @@
function build_world_obj(self)
    for k,v in pairs(self.battle_queue_) do
        if not v.is_play_ then
            MsgCenter.send_message(Msg.WORLD_MARCH_BAR, v.id_)
        end
    end
    if _G.EventKey then
        _G.event.fire(_G.EventKey.CITY_WORLD_MARCH_BAR)
    end
    for k,v in pairs(self.world_march_queue_) do
        if not v.is_play_ then
            MsgCenter.send_message(Msg.WORLD_MARCH_START, v.idx_)
        end
    end
    for k,v in pairs(self.world_monster_) do
        for _k,_v in pairs(v) do
            if not _v.is_load_ then
                MsgCenter.send_message(Msg.WORLD_REFRESH_OBJ, _v.idx_)
            end
        end
    end
    for k,v in pairs(self.world_fort_) do
        for _k,_v in pairs(v) do
            if not _v.is_load_ then
                MsgCenter.send_message(Msg.WORLD_REFRESH_OBJ, _v.idx_)
            end
        end
    end
    for k,v in pairs(self.world_respoint_) do
        for _k,_v in pairs(v) do
            if not _v.is_load_ then
                MsgCenter.send_message(Msg.WORLD_REFRESH_OBJ, _v.idx_)
            end
        end
    end
    for k,v in pairs(self.world_main_) do
        for _k,_v in pairs(v) do
            if _v.obj_type_ == config.WORLD_MAIN and not _v.is_load_ then
                MsgCenter.send_message(Msg.WORLD_REFRESH_OBJ, _v.idx_)
            end
        end
    end
end


function get_army_info(self, id)
    return self.battle_queue_[id]
end

function GetArmyInfo(self, idx)
    if not next(self.battleQueueList or {}) then
        return
    end

    return self.battleQueueList[idx]
end

function GetArmyInfoList(self)
    dump(self.battleQueueList, "self.battleQueueList", 9)
    if not next(self.battleQueueList or {}) then
        return {}
    end

    return self.battleQueueList
end

-- @@
function get_world_obj_by_id(self, id)
    local world_type = self.world_type_[id]
    if not world_type then
        elog("world objs findn't world type, id = "..id)
        return
    end
    if world_type == config.WORLD_MONSTER then
        for k,v in pairs(self.world_monster_) do
            for _k,_v in pairs(v) do
                if _v.idx_ == id then
                    return _v
                end
            end
        end
    elseif world_type == config.WORLD_MAIN then
        for k,v in pairs(self.world_main_) do
            for _k,_v in pairs(v) do
                if _v.idx_ == id then
                    return _v
                end
            end
        end
    elseif world_type == config.WORLD_FORT then
        for k,v in pairs(self.world_fort_) do
            for _k,_v in pairs(v) do
                if _v.idx_ == id then
                    return _v
                end
            end
        end
    elseif world_type == config.WORLD_RESPOINT then
        for k,v in pairs(self.world_respoint_) do
            for _k,_v in pairs(v) do
                if _v.idx_ == id then
                    return _v
                end
            end
        end
    elseif world_type == config.WORLD_MARCH then
        return self.world_march_queue_[id]
    end
    return
end

-- @@
function get_world_obj(self, x, z)
    if not x or not z then return end  
    if self.world_main_ then
        if self.world_main_[x] and self.world_main_[x][z] then
            return self.world_main_[x][z]
        end
    end    
    if self.world_monster_ then
        if self.world_monster_[x] and self.world_monster_[x][z] then
            return self.world_monster_[x][z]
        end
    end
    if self.world_fort_ then
        if self.world_fort_[x] and self.world_fort_[x][z] then
            return self.world_fort_[x][z]
        end
    end
    if self.world_respoint_ then
        if self.world_respoint_[x] and self.world_respoint_[x][z] then
            return self.world_respoint_[x][z]
        end
    end
    return    
end

function get_world_monster(self)
    local data = {}
    for k,v in pairs(self.world_monster_) do
        for _k,_v in pairs(v) do
            table.insert(data, _v)
        end
    end
    return data
end

function get_my_build(self)
    local data = {}
    for k,v in pairs(self.world_main_) do
        for _k,_v in pairs(v) do
            table.insert(data, _v)
        end
    end
    return data
end

-- 获取当前主城的逻辑坐标
function get_my_build_logic_axis(self)
    return self.main_logic_x_, self.main_logic_z_
end

function get_march_queue_num(self)
    if not next(self.battle_queue_) then return 0 end
    local count = 0
    for k,v in pairs(self.battle_queue_) do
        count = count + 1
    end
    return count
end

function hasBattleQueue(self, targetId)
    -- local count = 0
    -- for k,v in pairs(self.world_march_queue_) do
    --     count = count + 1
    -- end
    -- print("self.world_march_queue_ count = "..count)
    for k,v in pairs(self.world_march_queue_) do
        print(string.format("world_march_queue_ index = %d, value = %s", k, v))
        if (v.army_type_ == ArmyInfo.TO_MONSTER or
            v.army_type_ == ArmyInfo.TO_FORTIFIED) and
            v.finish_.id == targetId then
            return true
        end
    end
    return false
end

function get_march_by_str(self, strID)
    for k,v in pairs(self.world_march_queue_) do
        local str = tostring(k)
        if strID == str then
            return v
        end
    end
    return
end

function get_march_by_idx(self, idx)
    return self.world_march_queue_[idx]
end

function get_army_num(self)
    local num = AttrsManager:get_attrs_value_by_name("army_num")
    return num or 0
end

function enable_battle(self)
    if self:get_march_queue_num() >= self:get_army_num() then
        return false
    end
    return true
end

function GetTroops(self, worldObj, callback)
    local troops = {}
    --ai驻军
    if not worldObj:has_troop() then
        --设置士兵
        troops.soldiers = worldObj:get_prop().sttr

        --设置武将
        troops.heroes = {}
        local prop = worldObj:get_prop()
        for i,v in ipairs(prop.general) do
            local hero = Hero(v[1])
            hero.lv_ = v[2]
            hero.star_ = v[3]
            hero.pos_ = i
            table.insert(troops.heroes, hero)
        end

        if callback then
            callback(troops)
        end
        return
    end

    --玩家驻军
    _G.Net.send("view_army", {id = worldObj.idx_}, function(result)
        if result.e == 0 then
            --设置武将
            troops.heroes = {}
            for _,v in pairs(result.heroes) do
                local hero = _G.Hero(v.id)
                hero:update_server_data(v)
                table.insert(troops.heroes, hero)
            end

            --设置士兵
            dump(result.soldiers.arr1, "result.soldiers.arr1")
            local count = table.size(result.soldiers.arr1 or {})
            if count <= 0 or count ~= table.size(result.soldiers.arr2 or {}) then
                return
            end

            troops.soldiers = {}
            for i = 1, count do
                -- body
                local data = {}
                data[1] = result.soldiers.arr1[i]
                data[2] = result.soldiers.arr2[i]
                table.insert(troops.soldiers, data)
            end
        end

        if callback then
            callback(troops)
        end
    end)
end

function DetectObj(self, obj)
    if type(obj.get_detect_msg) ~= "function" then return end
    local msg = obj:get_detect_msg()
    if not msg then return end
    Net.send(msg, {
        target = obj.idx_,
        soldiers = {arr1 = {}, arr2 = {}},
        heroes = {},
    }, function(res)
        if res.e == 0 then
        end
    end)
end

function GetDetectTime(self, obj)
    local distance = self:GetLogicDistanceFromHome(obj)
    local speed = BasicConfig.BasicData.detect_speed or 1
    local attsSpeed = self:GetSpeedAttrValue(obj) or 0
    local a = BasicConfig.BasicData.detect_a
    local b = BasicConfig.BasicData.detect_b
    local c = BasicConfig.BasicData.detect_c    
    -- 侦察行军时间 =(-a*距离^2+b*距离+c) /(速度*(1+加成))
    local time = (-a * math.pow(distance, 2) + b * distance + c) / (speed *(1 + attsSpeed))
    return time
end

function GetDetectCost(self, obj)
    local args = BasicConfig.BasicData.detect_consume
    return args[1] + args[2] * (obj.mainlevel_ or 1) - args[3]
end

function GetLogicDistanceFromHome(self, target)
    local formX, fromZ = self:get_my_build_logic_axis()
    local deltaX = target.x_ - formX
    local deltaZ = target.z_ - fromZ
    return math.sqrt(deltaX * deltaX + deltaZ * deltaZ)
end

function GetSpeedAttrValue(self, target)
    local speedAdd = AttrsManager:get_attrs_value_by_name("speedAdd") or 0
    local attrSpeed = speedAdd
    if target.obj_type_ == config.WORLD_MONSTER then
        local speedMadd = AttrsManager:get_attrs_value_by_name("speed_madd") or 0
        attrSpeed = speedAdd + speedMadd
    end
    return attrSpeed
end

function CalcTroopPower(self, heroes, soldierIDCntList)
    local soldierPower = 0
    for _, v in pairs(soldierIDCntList) do
        local cfg = SoldierConfig.SoldierData[v[1]]
        soldierPower = soldierPower + cfg.power / 100 * v[2]
    end
    local heroPower = 0
    for _, v in pairs(heroes) do
        heroPower = heroPower + HeroManager:calc_hero_troop_power(v.id, v.level, v.star)
    end
    return 100 + heroPower * soldierPower + soldierPower
end

function StartBattle(self, target, heroes, soldierIDList, soldierCntList, onSuccess)
    local cnt = 0
    for _, v in pairs(soldierCntList) do
        cnt = cnt + v
    end
    if cnt == 0 then
        _G.MsgCenter.send_message(Msg.SHOW_HINT, lang("EXPEDITION_30"))
        return
    end
    if not self:enable_battle() then
        _G.MsgCenter.send_message(Msg.SHOW_HINT, lang("EXPEDITION_31"))
        return
    end
    if target.obj_type_ == config.WORLD_MONSTER then
        if target.lv_ > (self.monster_battle_lv_ + 1) then
            local str = lang("RESPOINT_25", (self.monster_battle_lv_ + 1))
            _G.MsgCenter.send_message(Msg.SHOW_HINT, str)
            return
        end
    end
    --如果只有主将，没有副将，哪需要将主将的id补0
    local heroIdList = {0,0,0}
    for k,v in pairs(heroes) do
        heroIdList[k] = v.id_
    end
    local data = {
        heroes = heroIdList,
        soldiers = {arr1 = soldierIDList, arr2 = soldierCntList},
        target = target.idx_,
    }

    local msg = target:get_battle_msg()
    Net.send(msg, data, function(result)
        if result.e == 0 and type(onSuccess) == "function" then
            onSuccess()
        end
    end)
end
