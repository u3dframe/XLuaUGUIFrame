local BgmManager  = {}
local XEase       = _G.XEase
local GameTween   = _G.GameTween
local GameRes     = _G.GameRes
local GameObject  = _G.GameObject
local AudioClip   = _G.AudioClip
local UnityEngine = _G.UnityEngine

_G.BgmManager = BgmManager

local audioSource = nil
local now_playing = ""
local global_volume = 0.5
local enabled = true

function BgmManager:initialize()
    -- audioSource = GameObject.Find("Initializer"):GetComponent(UnityEngine.AudioSource)
    if GameController then
        audioSource = _G.GameController.Instance:GetComponent(UnityEngine.AudioSource)
    else
        audioSource = GameObject.Find("Initializer"):GetComponent(UnityEngine.AudioSource)
    end
    audioSource.volume = 0
    now_playing = ""
    global_volume = 0.5
    enabled = true
    self:SetEnable(enabled)
    self:SetVolume()
end

function BgmManager.Play(bgm, loop, time, ease)
    if not enabled then return end
    if bgm == nil then return end
    if bgm == now_playing then
        return
    else
        if ease == nil then ease = XEase.OutCubic end
        if time == nil then time = 2 end
        if now_playing ~= "" then
            GameTween.Kill(audioSource, false)
            GameTween.To(function(v)
                audioSource.volume = v
            end,
            audioSource.volume, 0, time):SetEase(ease):OnComplete(function()
                BgmManager:loadBgm(bgm, audioSource, loop, time, ease)
            end)
        else
            BgmManager:loadBgm(bgm, audioSource, loop, time, ease)
        end
        now_playing = bgm
    end
end

function BgmManager:GetNowPlaying()
    return now_playing
end

function BgmManager:loadBgm(bgm, audioSource, loop, time, ease)
    if loop == nil then loop = true end
    if bgm ~= now_playing and now_playing ~= "" then return end
    ResourcesManager.LoadObjectAsync(bgm, function(clip)
        if now_playing == bgm then
            if clip then
                audioSource.clip = clip
                audioSource.loop = loop
                GameTween.Kill(audioSource, false)
                GameTween.To(function(v) audioSource.volume = v end, 0, global_volume, time):SetEase(ease)
                audioSource:Play()
            else
                audioSource:Stop()
            end
        end
    end)
end

function BgmManager:SetVolume(value)
    if not value then
        value =  global_volume
    end
    audioSource.volume = value
end

function BgmManager:GetVolume()
    return audioSource.volume
end

function BgmManager:SetEnable(enable)
    if not enable then
        now_playing = ""
    end
    enabled = enable

    audioSource.enabled = enable
end

function BgmManager:IsEnable()
    return enabled
end

return BgmManager
