module('ItemManager', package.seeall)

local ItemConfig = _G.Database.ItemConfig
local DropConfig = _G.Database.DropConfig
local BasicConfig = _G.Database.BasicConfig
local MoneyConfig = _G.Database.MoneyConfig

function initialize(self)
    self.items_ = {}
    for _, v in pairs(config.ITEM_TYPES) do
        self.items_[v] = {}
    end
    self.items_uuid_map_ = {}
    self.new_item_tags_ = {}

    self.resources_ = {}
    self.coins_ = {}

    self:init_drop_data()

    Net.register(self, 'bagm_all', on_bagm_all)
    Net.register(self, 'bagm_change', on_bagm_change)
    Net.register(self, 'money_all', on_coin_all)
    Net.register(self, 'money_change', on_coin_change)
    Net.register(self, 'resource_all', on_resource_all)
    Net.register(self, 'resource_change', on_resource_change)
end

function clear_up_items(self)
    for _, v in pairs(config.ITEM_TYPES) do
        self.items_[v] = {}
    end
    self.items_uuid_map_ = {}
end

function clear_up_resources(self)
    self.resources_ = {}
end

function clear_up_coins(self)
    self.coins_ = {}
end

-- 初始化随机掉落表
function init_drop_data(self)
    self.drop_data_ = {}
    local renders = {}
    for _, info in pairs(DropConfig.RenderData) do
        renders[info.render] = renders[info.render] or {}
        for _, item in pairs(info.items) do
            table.insert(renders[info.render], item)
        end
    end
    for drop_id, drop_info in pairs(DropConfig.DropData) do
        self.drop_data_[drop_id] = {}
        for _, render in pairs(drop_info.render) do
            for _, item in pairs(renders[render[1]] or {}) do
                table.insert(self.drop_data_[drop_id], item)
            end
        end
    end
end

--------------------------------↓服务器协议回调函数↓--------------------------------

function on_bagm_all(self, data)
    if not data then
        return
    end
    self:clear_up_items()
    for i, id in pairs(data.ids) do
        local cnt = data.cnts[i] or 0
        if cnt > 0 then
            local cfg = ItemConfig.ItemData[id]
            if cfg then
                self.items_[cfg.type][id] = Item(id, cnt)
            end
        end
    end
end

function on_bagm_change(self, data)
    for _, v in pairs(data.list or {}) do
        local id = v.id
        local cfg = ItemConfig.ItemData[id]
        if cfg and self.items_[cfg.type] then
            local last = v.last or 0
            local t = self.items_[cfg.type]
            if last > 0 then
                if not t[id] then
                    t[id] = Item(id, last)
                    self.new_item_tags_[id] = true
                else
                    t[id].count_ = last
                end
            elseif t[id] then
                t[id].count_ = 0
                t[id] = nil
            end
        end
    end

    MsgCenter.send_message(Msg.ITEM_CHANGE, data.list)
    if _G.FairyGUI then
        _G.event.fire(_G.EventKey.ITEM_CHANGE, data.list)
    end
end

function on_resource_all(self, data)
    self:clear_up_resources()
    for k, v in pairs(data.list) do
        local d = v.cnt
        self.resources_[v.id] = d and {d[1] or 0, d[2] or 0} or {0, 0}
    end
end

function on_resource_change(self, data)
    if not data or not data.list then
        return
    end
    for k, v in pairs(data.list) do
        local last = v.last
        self.resources_[v.id] = last and {last[1] or 0, last[2] or 0} or {0, 0}
    end
    MsgCenter.send_message(Msg.RESOURCE_OR_COIN_CHANGE, data.list)
    if _G.EventKey then
        _G.event.fire(_G.EventKey.RESOURCE_CHANGE, {changeData = data.list})
    end
end

function on_coin_all(self, data)
    self:clear_up_coins()
    if data and data.ids then
        for i = 1, #data.ids do
            self.coins_[data.ids[i]] = data.cnts[i]
        end
    end
end

function on_coin_change(self, data)
    if not data or not data.list then
        return
    end
    for k, v in pairs(data.list) do
        self.coins_[v.id] = self.coins_[v.id] + v.change
    end
    MsgCenter.send_message(Msg.RESOURCE_OR_COIN_CHANGE, data.list)

    if _G.FairyGUI then
        _G.event.fire(_G.EventKey.RESOURCE_CHANGE, {changeData = data.list})
    end
end

--------------------------------↑服务器协议回调函数↑--------------------------------

function get_config(self, itemid)
    local cfg = ItemConfig.ItemData[itemid]
    if not cfg then
        elog("Can't find config of item id: " .. tostring(itemid))
    end
    return cfg
end

function get_drop_data(self, drop_id)
    return self.drop_data_[drop_id] or {}
end

-- 获取数量
function get_count_by_prop(self, prop)
    return self:get_count(prop[1], prop[2])
end

--根据物品类型和ID获取物品余量
function get_count(self, _type, id)
    if self.is_item_type(_type) then
        local item = self:get_item_by_id(id)
        if not item then
            return 0
        end
        return item.count_
    elseif self.is_resource_type(_type) then
        return self:get_resource(_type, id)
    elseif self.is_coin_type(_type) then
        return self:get_coin(_type, id)
    end
    elog('The given type does not exist')
end

function get_coin(self, coinType, id)
    if not coinType then
        return
    end
    return self.coins_[coinType]
end

function get_resource(self, resType, id)
    if not resType then
        return
    end
    local v = self.resources_[resType]
    if type(v) == 'table' then
        return v[1] + v[2]
    end
    return v
end

function ItemManager:GetResByType(resType)
    local v = self.resources_[resType]
    if type(v) == 'table' then
        return v[1] + v[2]
    end
    return self.coins_[resType]
end
--获取道具安全资源
function ItemManager:GetSafeResByType(resType)
    local v = self.resources_[resType]
    return v[2]
end
--获取仓库和非保护资源资源
function ItemManager:GetUnSafeResByType(resType)
    local v = self.resources_[resType]
    return v[1]
end
-- function add_items_map(item)
--     if self.items_[item.propid] == nil then
--         self.items_[item.propid] = {}
--     end
--     self.items_[item.idx] = Item(item.propid, item.num, item.uuid)
-- end

function is_item_type(_type)
    return _type == config.ITEM_ITEM
end

function is_resource_type(_type)
    for _, t in pairs(config.RES_ITEMS) do
        if _type == t then
            return true
        end
    end
    return false
end

function is_coin_type(_type)
    for _, t in pairs(config.RES_COINS) do
        if _type == t then
            return true
        end
    end
    return false
end

function is_energy_type(_type)
    return _type == config.ITEM_ENERGY
end

function check_energy(self, prop)
    local energy = prop[3] or 0
    return MasterManager.user_.energy_ >= energy
end

function check_item(self, prop)
    local item = self:get_item_by_id(prop[2])
    if not item then
        return false
    end
    return item.count_ >= prop[3]
end

function check_item_count(self, id, count)
    count = count or 1
    local item = self:get_item_by_id(id)
    local has = item and item.count_ or 0
    return has >= count
end

function check_coin(self, prop)
    local coin = self:get_coin(prop[1])
    if not coin then
        return false
    end
    return coin >= prop[3]
end

function check_resource(self, prop)
    local res = self:get_resource(prop[1])
    if not res then
        return false
    end
    return res >= prop[3]
end

-- prop = {物品类型, 对应ID, 数量}
function check(self, prop, cb, isGuide)
    local ty = prop[1]
    if self.is_item_type(ty) then
        return self:check_item(prop)
    elseif self.is_resource_type(ty) then
        return self:check_resource(prop)
    elseif self.is_coin_type(ty) then
        return self:check_coin(prop)
    elseif self.is_energy_type(ty) then
        return self:check_energy(prop)
    end
    return false
end

function check_group(self, prop)
    if not prop then
        return true
    end
    for k, v in pairs(prop) do
        local result = self:check(v)
        if not result then
            return false
        end
    end
    return true
end

function item_comparator(a, b)
    if a.prop_.order ~= b.prop_.order then
        return a.prop_.order > b.prop_.order
    end
    if a.prop_.type ~= b.prop_.type then
        return a.prop_.type < b.prop_.type
    end
    return a.id_ < b.id_
end

function get_item_prop_by_id(self, id)
    local cfg = ItemConfig.ItemData[id]
    return cfg
end

function get_item_by_id(self, id)
    local cfg = ItemConfig.ItemData[id]
    if not cfg then
        return
    end
    return self.items_[cfg.type][id]
end

function use_item(self, id, count, ...)
    local item = self:get_item_by_id(id)
    if not item then
        MsgCenter.send_message(Msg.SHOW_HINT, lang('ITEM_NOT_ENOUGH'))
        return
    end
    item:use(count, ...)
end

--返回指定类型的item table{id: Item}
--itemType为nil时返回所有item
function get_items(self, itemType)
    local ret
    if itemType then
        ret = self.items_[itemType]
        if not ret then
            elog(string.format('Item type %s does not exist', itemType))
            return {}
        end
    else
        ret = {}
        for _, tbl in pairs(self.items_) do
            for id, v in pairs(tbl) do
                ret[id] = v
            end
        end
    end
    return ret
end

--返回指定类型的item list
--itemType为nil时返回所有item
function get_item_list(self, itemType)
    local itemlist = {}
    if itemType then
        local tbl = self.items_[itemType]
        if not tbl then
            elog(string.format('Item type %s does not exist', itemType))
        else
            for _, v in pairs(tbl) do
                itemlist[#itemlist + 1] = v
            end
        end
    else
        for _, tbl in pairs(self.items_) do
            for _, v in pairs(tbl) do
                itemlist[#itemlist + 1] = v
            end
        end
    end
    return itemlist
end

--返回排序后的指定类型的item list
--itemType为nil时返回所有item
function get_sorted_item_list(self, itemType)
    local itemlist = self:get_item_list(itemType)
    table.sort(itemlist, item_comparator)
    return itemlist
end

function get_sorted_item_list_of_showpoint(self, item_type, show_point)
    local list = {}
    for _, item in ipairs(self:get_item_list(item_type)) do
        if item.prop_.show_point == show_point then
            table.insert(list, item)
        end
    end
    table.sort(list, item_comparator)
    return list
end

function get_all_item_cfg_of_showpoint(self, show_point)
    local ret = {}
    for id, cfg in pairs(ItemConfig.ItemData) do
        if cfg.show_point == show_point then
            ret[id] = cfg
        end
    end
    return ret
end

function GetSpeedupItems(self, speedupType, needSort)
    local itemlist = self:get_item_list(config.ITEM_TYPES.EXPEDITE)

    local items = {}
    for _, v in pairs(itemlist) do
        local propExpedite = v:get_prop_expedite()
        if propExpedite and propExpedite.type == speedupType then
            table.insert(items, v)
        end

        if propExpedite and propExpedite.type == config.SPEEDUP_ITEM.COMMON then
            table.insert(items, v)
        end
    end

    if needSort then
        --排序 专用>通用 时间长的>时间短的
        table.sort(
            items,
            function(a, b)
                local aConfig = a:get_prop_expedite()
                local bConfig = b:get_prop_expedite()
                if aConfig.type == bConfig.type then
                    return aConfig.time > bConfig.time
                else
                    return aConfig.type > bConfig.type
                end
            end
        )
    end
    return items
end

--获取所有队列卷
function get_queue_item(self)
    local queue_item_id = BasicConfig.BasicData.queue_item
    local itemlist = self:get_item_by_id(queue_item_id)
    return itemlist
end

function is_item_new(self, itemid)
    return self.new_item_tags_[itemid]
end

function clear_new_tag(self, itemid)
    self.new_item_tags_[itemid] = nil
end

--获取奖励物品配置
function get_reward_cfg(self, prop)
    local id
    if self.is_resource_type(prop[1]) or self.is_coin_type(prop[1]) then
        id = prop[4]
    else
        id = prop[2]
    end
    return ItemConfig.ItemData[id]
end

--获取物品的UI属性，如icon,name,quality等
function get_ui_info(self, prop)
    if not prop then
        return {}
    end
    local cfg
    if self.is_item_type(prop[1]) then
        cfg = ItemConfig.ItemData[prop[2]]
    else
        cfg = MoneyConfig.MoneyData[prop[1]]
    end
    if not cfg then
        elog(string.format("Can't find config of prop: %s,%s,%s", unpack(prop)))
    end
    return cfg or {}
end

-- 获取武将升级道具
function get_hero_exp_item(self)
    --升级书道具id
    local basic = BasicConfig.BasicData
    if not basic or not basic.hero_items then
        return
    end
    local exp = {}
    for i, v in ipairs(basic.hero_items) do
        local obj = self:get_item_by_id(v[1])
        if obj then
            obj.exp = v[2]
        end
        table.insert(exp, obj)
    end
    return exp
end

function is_skill_fragment(self, item_id)
    local cfg = ItemConfig.ItemData[item_id]
    if not cfg then
        return false
    end
    return cfg.show_point == config.ITEM_SHOW_POINT.SKILL_BAG
end

-- 获取武将技能升级道具
function get_hero_skill_exp_items(self)
    local basic = BasicConfig.BasicData
    if not basic or not basic.hero_skill_items then
        return
    end
    local ret = {}
    for i, v in ipairs(basic.hero_skill_items) do
        ret[v[1]] = self:get_item_by_id(v[1])
    end
    return ret
end

--快捷购买
function quick_buy(self, itemid, count, on_success)
    local itemCfg = self:get_config(itemid)
    if not itemCfg then
        return
    end
    local cost = itemCfg.quick_buy
    if not cost then
        elog("Can't find quick buy info")
        return
    end
    local costCnt = cost[3] * count
    local costCfg = self:get_ui_info(cost)
    local data = {
        mode = 0,
        title = lang('UI_BASE_QUICK_BUY_TITLE'),
        content = GameUtil.StringFormat(lang('UI_BASE_QUICK_BUY_INFO'), itemCfg.name, count, costCfg.name, costCnt),
        --  buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")},
        callback = function()
            if not self:check({cost[1], cost[2], costCnt}) then
                _G.UIController:ShowUI(
                    'UICommonPop',
                    {
                        mode = 0,
                        title = '',
                        content = lang('UI_BASE_QUICK_BUY_INFO_2', costCfg.name),
                        buttons = {lang('UI_BASIC_CANCEL'), lang('UI_BASIC_SURE')},
                        callback = function()
                            _G.UIController:ShowUI('UICommonPop', {mode = 0, content = lang('UI_MAIN_UNOPEN')})
                        end
                    }
                )
                return
            end
            Net.send(
                'quick_buy',
                {itemid = itemid, num = count},
                function(result)
                    if result.e == 0 then
                        if type(on_success) == 'function' then
                            on_success()
                        end
                    end
                end
            )
        end
    }
    _G.UIController:ShowUI('UICommonPop', data)
    -- MsgCenter.send_message(Msg.SHOW_NOTIFY, data)
end
