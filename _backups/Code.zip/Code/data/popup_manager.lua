module("PopupManager", package.seeall)


function initialize(self)
    self.popup_logic_ = {}
    self.messager_ = Messager:new(self)
    self.messager_:add_listener(Msg.POPUP_WINDOW, on_popup_window)
end

function on_popup_window(self, key, data)
    if not key then return end
    if not self:get_popup_prop(key) then
        elog("popupwindow findn't the config, key = "..key)
        return 
    end
    local popup_data = {}
    popup_data.data = data
    popup_data.key = key
    table.insert(self.popup_logic_, popup_data)
    self:next_window()
end


function next_window(self, localTag)
    if #self.popup_logic_ == 0 then return end
    local win = UIManager.get_window("PopupWindow")
    if win then return end
    UIManager.open_window("PopupWindow", function()
            table.remove(self.popup_logic_, 1)
        end, self.popup_logic_[1].key, self.popup_logic_[1].data)
end

function get_popup_prop(self, key)
    return resmng.propPopupwindowData[key]
end