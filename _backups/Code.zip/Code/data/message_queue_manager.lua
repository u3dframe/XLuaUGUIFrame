--消息队列Manager
--
local MessageQueueManager = {}
_G.MessageQueueManager = MessageQueueManager

local Net = _G.Net
local EventKey = _G.EventKey

local msgs
if EventKey then
    msgs = {
        --格式 [服务器push消息 / 客户端接收消息]
        {"wall_over", EventKey.CITY_OVER},
    }
end

function MessageQueueManager:Initialize()
    self.first = 0 --首部索引
    self.last = -1 --尾部索引
    self.list = {}

    if not EventKey then
        return
    end
    local UIMain = _G.UIController:Get("UIMain")
    for i, v in pairs(msgs) do
        Net.register(self, v[1], function(data)
            --添加到队列
            self:Push{i, data}
            if UIMain:IsLoaded() then
                self:Dispatch()
            end
        end)
    end
    --测试
    --self:Push{1}
end

function MessageQueueManager:Dispatch()
    print("Dispatch")
    for _ = 1, self:GetCount() do
        local data = self:Pop()
        if data then
            local key = data[1]
            local msg = msgs[key][2]
            print("----------------------------> send msg = ", msg)
            --MsgCenter.send_message(msg, data[2])
            _G.event.fire(msg, data[2])
        end
    end
end

function MessageQueueManager:Push(value)
    local last = self.last + 1
    self.last = last
    self.list[last] = value
end

function MessageQueueManager:Pop()
    local first = self.first
    if first > self.last then
        error("list is empty!")
        return
    end
    local value = self.list[first]
    self.list[first] = nil
    self.first = first + 1
    return value
end

function MessageQueueManager:GetCount()
    if not next(self.list or {}) then
        return 0
    end
    local len = 0
    for _ in pairs(self.list) do
        len = len + 1
    end
    return len
end

return MessageQueueManager