--城墙功能
local CityWall = {}

local Net = _G.Net
local BasicData = _G.Database.BasicConfig.BasicData
local config = _G.config


local wallObj --城墙建筑对象

function CityWall:New(data)
    local obj = setmetatable({}, {__index = self})
    wallObj = _G.BuildManager:get_build_info_by_build_type(config.BUILD_TYPE.WALL)
    if not wallObj then
        error("wall build is nil!")
    end
    obj:RefreshData(data)
    return obj
end

function CityWall:RefreshData(data)
    self.cityDef = data.val               --城防值
    self.startTime = data.start_ti        --燃烧的开始时间
    self.endTime = data.stop_ti           --燃烧的结束时间
    self.cityDefBurning = data.start_val  --开始燃烧时候的城防值
    self.areaType = data.area             --区域类型
    self.repairTime = data.fix_ti         --修复的开始时间
end

--灭火
function CityWall:FireExtinction(def)
    self.cityDef = def
    self.endTime = nil
    self.startTime = nil
    self.cityDefBurning = nil
end

--重置（城池重建）
function CityWall:Reset()
    self.cityDef = 0
end

--是否在燃烧
function CityWall:IsBurning()
    if self.endTime and self.endTime > Net.server_time() then
        return true
    end
    return false
end

--增加城防值是否在冷却中
function CityWall:IsCooling()
    if self:GetDefRTS() and self:GetDefRTS() > Net.server_time() then
        return true
    end
    return false
end

--是否是满城防值
function CityWall:IsMaxDef()
    if self:GetDef() >= self:GetMaxDef() then
        return true
    end
    return false
end

function CityWall:GetDef()
    if self:IsBurning() then
        --计算当前的城防值
        local pastTime = Net.server_time() - self.startTime
        local speed = self:GetSpeed()
        if self.areaType == config.AREA_TYPE.FIELD then
            local stage = math.floor(pastTime / speed[2]) --当前阶段
            if stage == 0 then
                return self.cityDefBurning - pastTime / speed[1]
            end

            --前几个阶段的城防值
            local sum = 0
            for i = 1, stage do
               local value = speed[2] / (speed[1] / i)
               sum = sum + value
            end
            --加上当前阶段损失的城防值
            local currStage = stage + 1
            sum = sum + (pastTime % speed[2]) / (speed[1] / currStage)
            return self.cityDefBurning - sum
        end
        return self.cityDefBurning - pastTime / speed[1]
    end
    return self.cityDef
end

function CityWall:GetBurnEndTime()
    return self.endTime
end

--获取增加城防值的结束时间
function CityWall:GetDefRTS()
    if not self.repairTime then
        return
    end
    return self.repairTime + BasicData.wall_cd
end

--获取燃烧的结束时间
function CityWall:GetBurningRTS()
    return self.endTime
end


--获取最大城防值
function CityWall:GetMaxDef()
    --从配置里面读取
    return _G.AttrsManager:get_attrs_value_by_name("city_def")
end

--获取增加城防值提示
function CityWall:GetAddDefHint()
    return _G.lang("UI_CITYWALL_ADD_DEF", BasicData.wall_cd / 60, BasicData.wall_val)
end

--速度（每分钟失去多少城防值）
function CityWall:GetSpeedPerMinute()
    local data = self:GetSpeed()
    if not data[2] then
        return math.floor(60 / data[1])
    end
    local stage = math.floor((Net.server_time() - self.startTime) / data[2])
    local initValue = math.floor(60 / data[1])
    return initValue + initValue * stage
end

--速度（损失每点城防值需要的时间）
function CityWall:GetSpeed()
    return BasicData.wall_burning[self.areaType]
end

return CityWall

