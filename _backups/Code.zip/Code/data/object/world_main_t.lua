module("WorldMain", package.seeall)
deriveClass(WorldMain, WorldObj) 


function init(self, x, z, data)
    WorldObj.init(self, x, z)
    self.obj_type_ = config.WORLD_MAIN
    self.name_ = data.name
    
    self.idx_ = data.id
    self.is_load_ = false
end

function get_name(self)
    if MasterManager.user_.name_ == self.name_ then
        return "我的主城"
    end
    return self.name_
end

function get_offset_pos(self, fieldOfView, p)
    local ratio_x = p.x / Screen.width
    local weight_x = 1.9
    local result_x = fieldOfView * ratio_x * weight_x    
    --num_min和num_max是比例，x轴
    --min和max是值，y轴
    local num_min = -0.7
    local num_max = 0.6
    local step = 0.02
    local max = 100
    local min = -120
    local ratio_y = p.y / Screen.height
    local weight_y = max
    local delta = max - min
    for i=num_min,num_max,step do
        local percent = (i-num_min)/(num_max-num_min)
        if ratio_y <= i then
            weight_y = min + percent*delta
            break
        end        
    end
    --设置fieldOfView情况
    local field_value_min = WorldScene.FIELDOFVIEW_MIN
    local field_value_max = WorldScene.FIELDOFVIEW_MAX
    local field_value_step = 1
    local field_min = -100
    local field_max = 0
    local field_value = field_value_max
    local field_delta = field_max - field_min
    for i=field_value_min,field_value_max,field_value_step do
        local percent = (i-field_value_min)/(field_value_max-field_value_min)
        if fieldOfView <= i then
            field_value = field_min + percent*field_delta
            break
        end        
    end
    local result_y = fieldOfView * ratio_y + weight_y + field_value
    return result_x, result_y
end

function set_city_text_mesh(self, textMesh)
    local name = UIUtil.get_first_char(self.name_)
    textMesh.text = name
    local render = textMesh.transform:GetComponent(MeshRenderer)
    render.sortingOrder = 1
end