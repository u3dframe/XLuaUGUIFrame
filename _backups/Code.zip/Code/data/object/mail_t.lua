module("Mail", mkcall)

--资源报告的产生源类型，与服务器定义一致
ResObjType = {
    fortified = 4,
    respoint = 5,
}


local MonsterConfig = _G.Database.MonsterConfig
local FortifiedConfig = _G.Database.FortifiedConfig
local RespointConfig = _G.Database.RespointConfig
local SoldierConfig = _G.Database.SoldierConfig
local lang = _G.lang


function new(module_type, info)
    local obj = {}
    setmetatable(obj, {__index = Mail})
    obj:init(module_type, info)
    return obj
end

function init(self, module_type, info)
    self.id_ = info.id
    self.type_ = info.type
    self.time_ = info.time
    self.rewards_ = {}
    self.read_time_ = info.readtime
    self.pick_time_ = info.picktime
    self.deleted_ = false
    if module_type == config.MAIL_MODULE_TYPES.COMMON then
        self:_init_common(info)
    elseif module_type == config.MAIL_MODULE_TYPES.REPORT then
        self:_init_report(info)
    else
        self.deleted_ = true
        elog("Fail to init mail. Invalid module type: "..tostring(module_type))
    end
end

function _init_common(self, info)
    self.module_type_ = config.MAIL_MODULE_TYPES.COMMON
    self.title_ = info.theme or ""
    self.content_ = info.content or ""
    if info.items then
        for _, item in pairs(info.items) do
            table.insert(self.rewards_, item.array)
        end
    end
end

function _init_report(self, info)
    self.module_type_ = config.MAIL_MODULE_TYPES.REPORT
    self.title_ = info.title or ""
    self.content_ = info.content or ""
    local types = config.MAIL_TYPES[self.module_type_]
    if info.type == types.WILD_BATTLE then
        self.args_ = {
            monsterid = info.monsterid,
            result = info.result,
            rewards = {},
            pos = info.point,
            lose_power = info.lose_power,
            hurt = info.hurt,
            live = info.live,
            all = info.all,
        }
        --战报奖励不在邮件领取，只做显示
        if info.reward then
            for _, r in pairs(info.reward) do
                table.insert(self.args_.rewards, r.array)
            end
        end
        if info.new then
            local monster = MonsterConfig.MonsterData[self.args_.monsterid]
            if monster then
                self:send_report_msg({
                    result = self.args_.result,
                    target_lv = monster.lv,
                    target_name = monster.name,
                    rewards = self.args_.rewards,
                })
            else
                elog("Can't find monster id: "..tostring(self.args_.monsterid))
            end
        end
    elseif info.type == types.RESOURCE then
        if info.objtype ~= ResObjType.fortified and info.objtype ~= ResObjType.respoint then
            return elog("Invalid resource obj type: "..tostring(info.objtype))
        end
        self.args_ = {
            rewards = {},
            objtype = info.objtype,
            defid = info.defid,
            location = info.location,
        }
        if info.starttime then
            self.args_.starttime = math.floor(info.starttime)
        end
        if info.endtime then
            self.args_.endtime = math.floor(info.endtime)
        end
        if info.award then
            for _, r in pairs(info.award) do
                table.insert(self.args_.rewards, r.array)
            end
        end
    elseif info.type == types.BATTLE then
        self.args_ = {
            result = info.result,
            rewards = {},
            attacker = info.attack,
            defender = info.defence,
        }
        if info.award then
            for _, r in pairs(info.award) do
                table.insert(self.args_.rewards, r.array)
            end
        end
        if info.new then
            local name, lv
            local detail = self.args_.defender
            if detail.defid then
                local cfg = FortifiedConfig.FortifiedData[detail.defid]
                if cfg then
                    name = lang("UI_FORT_07")
                    lv = cfg.level
                else
                    elog("Can't find fortified id: "..tostring(detail.defid))
                end
            else
                name = detail.rname
            end
            self:send_report_msg({
                result = self.args_.result,
                target_lv = lv,
                target_name = name,
                rewards = self.args_.rewards,
            })
        end
    elseif info.type == types.DETECT then
        local objType = WorldManager:get_client_obj_type_by_server(info.objtype)
        if not objType then
            self.deleted_ = true
            elog("Invalid world obj server type: "..tostring(info.objtype))
            return
        end
        self.args_ = {
            rname = info.rname,
            location = info.location,
            failtype = info.failtype,   -- 1资源点消失 2军队已撤离 3友军
            defid = info.defid,
            result = info.result,   -- 0成功 1失败 2被侦查
            heroes = info.heroes,
            objtype = objType,
        }
        local soldierComparator = function(a, b)
            if a[2] ~= b[2] then return a[2] > b[2] end
            local cfg1 = SoldierConfig.SoldierData[a[1]]
            local cfg2 = SoldierConfig.SoldierData[b[1]]
            if cfg1.type ~= cfg2.type then return cfg1.type < cfg2.type end
            return cfg1.lv > cfg2.lv
        end
        if info.defence_army then
            self.args_.defence_army = {heroes = info.defence_army.heroes or {}, soldiers = {}}
            for i, v in ipairs(info.defence_army.soldiers.arr1) do
                table.insert(self.args_.defence_army.soldiers, {v, info.defence_army.soldiers.arr2[i]})
            end
            table.sort(self.args_.defence_army.soldiers, soldierComparator)
        else
            self.args_.defence_army = {heroes = {}, soldiers = {}}
        end
        if info.reinforce_army then
            self.args_.reinforce_army = {heroes = info.reinforce_army.heroes or {}, soldiers = {}}
            for i, v in ipairs(info.reinforce_army.soldiers.arr1) do
                table.insert(self.args_.reinforce_army.soldiers, {v, info.reinforce_army.soldiers.arr2[i]})
            end
            table.sort(self.args_.reinforce_army.soldiers, soldierComparator)
        else
            self.args_.reinforce_army = {heroes = {}, soldiers = {}}
        end
        if info.new then
            local result
            if info.result == 0 then
                result = 1
            elseif info.result == 1 then
                result = 2
            end
            local name, lv
            if objType == config.WORLD_MAIN then
                --TODO
            elseif objType == config.WORLD_FORT then
                name = lang("UI_FORT_07")
                lv = FortifiedConfig.FortifiedData[info.defid].level
            elseif objType == config.WORLD_RESPOINT then
                local cfg = RespointConfig.RespointData[info.defid]
                name = lang(cfg.name)
                lv = cfg.level
            elseif objType == config.WORLD_MONSTER then
                local cfg = MonsterConfig.MonsterData[info.defid]
                name = cfg.name
                lv = cfg.lv
            end
            if info.result ~= 2 then    --被侦察不发
                self:send_report_msg({
                    text = lang("EXPEDITION_43", lv, name),
                    result = result,
                    target_lv = lv,
                    target_name = name,
                    rewards = {},
                })
            end
        end
    else
        self.deleted_ = true
        elog("Invalid mail type: "..tostring(info.type))
    end
end

function is_read(self)
    return self.read_time_ ~= nil
end

function on_read(self, read_time)
    self.read_time_ = read_time
end

function has_rewards(self)
    return #self.rewards_ > 0
end

function has_ungained_rewards(self)
    return self:has_rewards() and not self.pick_time_
end

function on_gain_rewards(self, pick_time)
    self.pick_time_ = pick_time
end

function is_deleted(self)
    return self.deleted_
end

function on_delete(self)
    self.deleted_ = true
end

function send_report_msg(self, data)
    --0是目标消失1是成功 2是失败
    -- if data.result == 0 then
    --     local key
    --     if self.type_ == 1 then
    --         key = "DETECT_RES_VANISH"
    --     elseif self.type_ == 2 then
    --         key = "UI_FORT_03"
    --     end
    --     MsgCenter.send_message(Msg.SHOW_HINT, lang(key))
    -- else
        data.module_type = self.module_type_
        data.type = self.type_
        MsgCenter.send_message(Msg.WORLD_MARCH_RESULT, data)
    -- end
end

function get_attacker_name(self)
    if self.module_type_ ~= config.MAIL_MODULE_TYPES.REPORT then return end
    if self.type_ ~= config.MAIL_TYPES[self.module_type_].BATTLE then return end
    local info = self.args_.attacker
    if info.rname then return info.rname end
    --从配置ID获取
end

function get_defence_soldier_cnt(self)
    if not self.args_.defenceSoldierCnt then
        local cnt = 0
        for _, v in pairs(self.args_.defence_army.soldiers) do
            cnt = cnt + v[2]
        end
        self.args_.defenceSoldierCnt = cnt
    end
    return self.args_.defenceSoldierCnt
end

function get_reinforce_soldier_cnt(self)
    if not self.args_.reinforceSoldierCnt then
        local cnt = 0
        for _, v in pairs(self.args_.reinforce_army.soldiers) do
            cnt = cnt + v[2]
        end
        self.args_.reinforceSoldierCnt = cnt
    end
    return self.args_.reinforceSoldierCnt
end

function get_most_soldier_id(self)
    if not self.args_.mostSoldierIDFlag then
        local cnt = {}
        for _, v in pairs(self.args_.defence_army.soldiers) do
            cnt[v[1]] = v[2]
        end
        for _, v in pairs(self.args_.reinforce_army.soldiers) do
            cnt[v[1]] = (cnt[v[1]] or 0) + v[2]
        end
        local id
        local max = -1
        for k, v in pairs(cnt) do
            if v > max then
                id = k
                max = v
            end
        end
        self.args_.mostSoldierID = id
        self.args_.mostSoldierIDFlag = true
    end
    return self.args_.mostSoldierID
end

function get_detect_obj_name_lv(self)
    local buildName, lv
    if self.args_.objtype == ResObjType.fortified then
        buildName = lang("UI_FORT_07")
        local cfg = FortifiedConfig.FortifiedData[self.args_.defid]
        if cfg then lv = cfg.level end
    else
        local cfg = RespointConfig.RespointData[self.args_.defid]
        if cfg then
            lv = cfg.level
            buildName = lang(cfg.name)
        end
    end
    return buildName, lv
end
