module("CityBuildSpace", mkcall)

local CityConfig = _G.Database.CityConfig


function new(id)
	local obj = {}
	setmetatable(obj, {__index = CityBuildSpace})
	obj:init(id)
	return obj
end

function init(self, id)
	self.id_ = id
	self.prop_ = self:get_prop()
	self.allow_build_ = self.prop_.allowbuild
end

function get_prop(self)
	return CityConfig.SpaceData[self.id_]
end

function init_allow_build(self)
	local obj = {}
	for k, v in ipairs(self.prop_.allowbuild) do
		table.insert(obj, v)
	end
	return obj
end

--空地是否解锁
function is_unlock(self)
	local unlock_data = CityConfig.UnlockData
	for i, v in ipairs(unlock_data) do
		-- 加5 是因为配置表配的都是城外的空地。 城内的空地没算在内
		if self.id_ >= v.start + 5 and self.id_ <= v.stop + 5 then
			local lv = BuildManager:get_main_lv()
			if lv >= v.unlock then
				return true
			end
		end
	end
	return false
end

--指定建筑是否可以移动到该空地
function is_movable_by_build_id(self, build_id)
	if not self:is_unlock() then return end
	local build = BuildManager:get_build_info_by_id(build_id)
	if build and self.allow_build_ then
		for i, v in ipairs(self.allow_build_) do
			if build.build_type_ == v then
				return true
			end
		end
	end
	return false
end

--是否是城外空地
function isOutSideSpace(self)
	if self.id_ >= 6 and self.id_ <= 40 then
		return true
	end
	return false
end
