module("Timer", mkcall)

ACTIVE_STATE = 1        -- 激活状态
WAIT_STATE = 2          -- 等待状态
CLOSE_STATE = 3         -- 关闭状态


function new(key, duration)
	local obj = {}
    setmetatable(obj, {__index = Timer})
    obj:init(key, duration)
    return obj
end

function init(self, key, duration)	
    self.key_ = key
    self.state_ = CLOSE_STATE
    self.duration_ = duration
    self.timer_ = 0
    self.need_scene_ = nil
end

function active_state(self)
    self.timer_ = self.duration_
    self.state_ = ACTIVE_STATE
end

function get_active_state(self)
    return self.state_ ~= CLOSE_STATE
end

function close_state(self)
    self.timer_ = 0
    self.state_ = CLOSE_STATE
end

function play(self, delta)
    self.timer_ = self.timer_ - delta
    if self.timer_ < 0 then
        self.state_ = WAIT_STATE
    end
end

function check(self)
    -- 判断依赖条件：依赖场景、依赖UI、依赖功能
    if self.need_scene_ then
        local scene_name = GameUtil:GetActiveScene()
        if scene_name ~= self.need_scene_ then
            return false
        end        
    end
    
    
    
    if self.state_ == WAIT_STATE then
        return true
    end
    return false
end
