module("Attrs", mkcall)

local AttributeConfig = _G.Database.AttributeConfig


function new(id)
    local obj = {}
    setmetatable(obj, {__index = Attrs})
    obj:init(id)
    return obj
end

function init(self, id)
    self.id_ = id
end

function get_prop(self)
    return AttributeConfig.AttributeData[self.id_]
end

function update_data(self, value)
    self.value_ = value
end