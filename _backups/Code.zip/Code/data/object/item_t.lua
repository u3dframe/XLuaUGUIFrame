module("Item", mkcall)

local ItemConfig = _G.Database.ItemConfig
local BasicConfig = _G.Database.BasicConfig


function new(id, count, uuid)
    local obj = {}
    setmetatable(obj, {__index = Item})
    obj:init(id,count, uuid)
    return obj
end

function init(self, id, count, uuid)
    self.id_ = id   --propid
    self.uuid_ = uuid --serverid
    self.count_ = count
    
    self.prop_ = self:get_prop()
end

function get_prop_expedite(self)
    local cfg = ItemConfig.ExpediteData[self.id_]
    if not cfg then
        elog("propExpediteData Can't find config of item id "..self.id_)
    end
    return cfg or {}
end

function get_prop(self)
    local cfg = ItemConfig.ItemData[self.id_]
    if not cfg then
        elog("propItemData Can't find config of item id "..self.id_)
    end
    return cfg or {}
end

function can_use(self)
    return self.prop_.usetype > config.ITEM_USE_TYPES.NO_USE
end

function is_use_one(self)
    return self.prop_.useone and self.prop_.useone > 0
end

function can_show_rewards(self)
    return self.prop_.usetype == config.ITEM_USE_TYPES.SELECT_ONE
end

function show_rewards(self)
    if self.prop_.usetype == config.ITEM_USE_TYPES.SELECT_ONE then
        _G.UIController:ShowUI("UIItemChoose", {item=self, usable=false, on_success=on_success})
    end
end

function confirm_to_use(self, count, on_success, ...)
    count = count or 1
    local use_args = {...}
    local use_func = function(ex_args)
        if count > self.count_ then
            MsgCenter.send_message(Msg.SHOW_HINT, lang("ITEM_NOT_ENOUGH"))
            return
        end
        local send_data = {
            id = self.id_,
            cnt = count,
        }
        if ex_args then
            
            local args = {}
            for k, v in pairs(ex_args) do
                args[k] = v
            end
            send_data.args = GameUtil.TableToJson(args)
        elseif self.prop_.usetype == config.ITEM_USE_TYPES.SELECT_ONE then
            send_data.args = tostring(use_args[1])
        end
        Net.send("bagm_item_use", send_data, function(res)
            if res.e == 0 then
                if type(on_success) == "function" then
                    on_success()
                end
                self:on_use_successfully(count, send_data, GameUtil.JsonToTable(res.args))
            end
        end)
    end
    --重复提示
    -- if CallbackBeforeUse[self.prop_.usetype] and CallbackBeforeUse[self.prop_.usetype][1] then
    --     CallbackBeforeUse[self.prop_.usetype][1](self, use_func)
    -- else
        use_func()
    --end
end

function use(self, on_success)
    if self.prop_.usetype == config.ITEM_USE_TYPES.SELECT_ONE then
        _G.UIController:ShowUI("UIItemChoose", {item=self, usable=true, on_success=on_success})
    elseif not self:is_use_one() and self.count_ > 1 then
        _G.UIController:ShowUI("UIItemUse", {item=self, on_success=on_success})
    elseif self.prop_.usetype == config.ITEM_USE_TYPES.COLLECTION or 
        self.prop_.usetype == config.ITEM_USE_TYPES.PRODUCTION then
        self:confirm_to_use(1, on_success)
    else
        local msg = {
            mode=0,
            title = "",
            content = lang("ITEM_CONFIRM_TO_USE", self.prop_.name),
            callback = function(index)
                if index == 2 then
                    self:confirm_to_use(1, on_success)
                end
            end
        }
        _G.UIController:ShowUI('UICommonPop', msg)
    end
end

--成功使用后回调
function on_use_successfully(self, count, send_data, server_args)
    if CallbackBeforeUse[self.prop_.usetype] and CallbackBeforeUse[self.prop_.usetype][2] then
        CallbackBeforeUse[self.prop_.usetype][2](self)
    end
    if not server_args or #server_args == 0 then return end
    local inherent_rewards, random_rewards
    if self.prop_.usetype == config.ITEM_USE_TYPES.DROP then
        inherent_rewards = server_args[1] or {}
        random_rewards = server_args[2] or {}
    elseif self.prop_.usetype == config.ITEM_USE_TYPES.GAIN_RANDOM then
        inherent_rewards = {}
        random_rewards = server_args
    elseif self.prop_.usetype == config.ITEM_USE_TYPES.SELECT_ONE then
        inherent_rewards = {server_args}
        random_rewards = {}
    else
        inherent_rewards = server_args
        random_rewards = {}
    end
    if #inherent_rewards == 0 and #random_rewards == 0 then return end
    _G.event.fire(_G.EventKey.ITEM_CHANGE)
    UIManager.open_window("ItemGainRewardWindow", nil, inherent_rewards, random_rewards)
end
-------------------------------------------------------- ↓ COMMON ↓ ----------------------------------------------------------------------------
function use_common_successfully(self)
    MsgCenter.send_message(Msg.SHOW_HINT, lang("INCREASE_01"))
end
-------------------------------------------------------- ↓ COLLECTION ↓ ----------------------------------------------------------------------------
-- 大世界资源采集加速
function use_respoint_speed(self, use_func)
    local msg_ = {}
    msg_.mode=0
    msg_.title = lang("UI_BASIC_HINT")
    if WorldManager.respoint_buff_ then
        msg_.content = lang("RESPOINT_30")
    else
        msg_.content = lang("RESPOINT_31")
    end
   -- msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
    msg_.callback = function() 
        if self.use_respoint_gold_ then
            use_func({usemoney=true})
        else
            use_func()
        end
    end
    _G.UIController:ShowUI('UICommonPop', msg_)
   -- MsgCenter.send_message(Msg.SHOW_NOTIFY,msg_)  
end

-------------------------------------------------------- ↓ PRODUCTION ↓ ----------------------------------------------------------------------------
-- 主城池资源增产
function use_collect_add(self)
    if self.use_build_id_ then
        local msg_ = {}
        msg_.mode=0
        msg_.title = lang("UI_BASIC_HINT")
        msg_.content = lang("RESOURCE_BUILDING_4")
      --  msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
        msg_.callback = function() 
           -- if index == 2 then
                local func = function()
                    local data = {}
                    data.id = self.use_build_id_
                    Net.send("produce_buffadd", data, function(result)
                        if result.e == 0 then
                            MsgCenter.send_message(Msg.CITY_COLLECT_REFRESH, self.use_build_id_)
                        end
                        self.use_build_id_ = nil
                        self.use_collect_ = nil
                    end)
                end
                if not self.use_collect_:has_buff() then
                    func()
                    return
                end
                local msg_1 = {}
                msg_1.mode=0
                msg_1.title = lang("UI_BASIC_HINT")
                local str = lang("RESOURCE_BUILDING_5", self.use_collect_.name_, self.use_collect_:get_buff_time())
                msg_1.content = str
               -- msg_1.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
                msg_1.callback = function() 
                    --if index == 2 then
                        func()
                   -- end                
                end
               -- MsgCenter.send_message(Msg.SHOW_NOTIFY,msg_1)
                _G.UIController:ShowUI('UICommonPop', msg_1)                
          --  end
        end
       -- MsgCenter.send_message(Msg.SHOW_NOTIFY,msg_)
        _G.UIController:ShowUI('UICommonPop', msg_)
    else
        local build_type
        for i,v in ipairs(BasicConfig.BasicData.resouce_buildtpye) do
            local tmp_build_type
            for _i,_v in ipairs(v) do
                if _i == 1 then 
                    tmp_build_type = _v 
                else
                    if self.id_ == _v then
                        build_type = tmp_build_type
                    end
                end
            end
        end
        local list = CollectManager:get_same_collect_list(build_type)
        if #list == 0 then
            local msg_ = {}
            msg_.mode=0
            msg_.title = lang("UI_BASIC_HINT")
            msg_.content = lang("RESOURCE_BUILDING_11")
           -- msg_.buttons = {lang("UI_BASIC_SURE")}
           -- MsgCenter.send_message(Msg.SHOW_NOTIFY,msg_)
            _G.UIController:ShowUI('UICommonPop', msg_)
            return
        end
        if #list > 1 then
            table.sort(list, function(x, y)
                local build1 = BuildManager:get_build_info_by_id(x.build_id_)
                local build2 = BuildManager:get_build_info_by_id(y.build_id_)
                return build1.lv_ > build2.lv_
            end)
        end
        local enable_collect
        local build_name
        local build_lv
        for i,v in ipairs(list) do
            local build = BuildManager:get_build_info_by_id(v.build_id_)
            build_name = build.name_
            if not v:has_buff() then
                enable_collect = v
                build_lv = build.lv_
                break
            end
        end
        local msg_ = {}
        msg_.mode=0
        msg_.title = lang("UI_BASIC_HINT")
        msg_.content = lang("INCREASE_02", self.prop_.name)
        msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
        msg_.callback = function() 
            if enable_collect then
                local msg_ = {}
                msg_.mode=0
                msg_.title = lang("UI_BASIC_HINT")
                msg_.content = lang("INCREASE_03", build_lv, build_name)
                msg_.callback = function()
                    local data = {}
                    data.id = enable_collect.build_id_
                    Net.send("produce_buffadd", data, function(result)
                        if result.e == 0 then
                            MsgCenter.send_message(Msg.CITY_COLLECT_REFRESH, enable_collect.build_id_)
                        end
                    end)
                end
                _G.UIController:ShowUI('UICommonPop', msg_)
            else
                local msg_ = {}
                msg_.mode=0
                msg_.title = lang("UI_BASIC_HINT")
                msg_.content = lang("INCREASE_04", build_name, build_name)
                msg_.callback = function() end
                _G.UIController:ShowUI('UICommonPop', msg_)
            end
        end
        _G.UIController:ShowUI('UICommonPop', msg_)
    end
end

------------------------------------------------------------------------------------------------------------------------------------------------
--物品使用类型 到 *使用前回调函数* 的映射
--*使用前回调函数* 接收 *物品使用函数*，在物品确定使用后、向服务器发送消息前调用
--*物品使用函数* 可接收使用参数table，调用后向服务器发送使用消息
CallbackBeforeUse = {
    [config.ITEM_USE_TYPES.COLLECTION] = {use_respoint_speed, use_common_successfully},
    [config.ITEM_USE_TYPES.PRODUCTION] = {use_collect_add, use_common_successfully},
}
