module("WorldRespoint", package.seeall)
deriveClass(WorldRespoint, WorldObj) 


local BasicConfig = _G.Database.BasicConfig
local RespointConfig = _G.Database.RespointConfig


function init(self, x, z, data)
    WorldObj.init(self, x, z)
    self.idx_ = data.id
    self.id_ = data.defid
    self.obj_type_ = config.WORLD_RESPOINT
    self.is_load_ = false
    self.mainlevel_ = data.mainlevel
    
    self.name_ = data.name
    self.owner_ = data.owner
    self.collent_time_ = data.ti_collect
    self.speed_ = data.speed or 1
    self.cnt_ = data.cnt or 0
    self.all_cnt_ = data.cntall
end

function get_prop(self)
    local prop = RespointConfig.RespointData[self.id_]
    if not prop then
        elog("world_respoint_t findn't prop in propRespointData, id = "..tostring(self.id_))
    end    
    return RespointConfig.RespointData[self.id_]
end

function get_name(self)
    local prop = self:get_prop()
    return lang(prop.name)
end

-- 出征界面，野怪
function get_troop_type_name(self)
    return lang("RESPOINT_17")
end

function get_battle_msg(self)
    return "respoint_battle"
end

function get_detect_msg(self)
    return "respoint_detect"
end

function get_cancel_msg(self)
    return "respoint_cancel"
end

--重新加载，初始化
function prepare_reload(self)
    self.is_load_ = false
    self.is_load_icon_ = false
end

-- 是否有军队
function has_troop(self)
    return self.owner_ and self.owner_ > 0
end

function refresh_data(self, data)
    local is_push = true
    if self.owner_ == data.owner then
        is_push = false
    end

    self.name_ = data.name
    self.collent_time_ = data.ti_collect
    self.owner_ = data.owner
    self.mainlevel_ = data.mainlevel
    self.speed_ = data.speed or 1
    self.cnt_ = data.cnt or 0
    self.all_cnt_ = data.cntall
    -- 等数据更新了再推消息
    if is_push then
        --MsgCenter.send_message(Msg.WORLD_RESPOINT_REFRESH, self.idx_)
        _G.event.fire(_G.EventKey.WORLD_RESPOINT_REFRESH,self.idx_)
    end
end

function get_res_num(self)
    local has_num = self.all_cnt_ - self.cnt_
    if self:has_troop() then
        local delta = Net.server_time() - self.collent_time_
        has_num = math.floor(has_num - delta*self.speed_)
        has_num = has_num < 0 and 0 or has_num
    end
    return math.floor(has_num)
end

function get_detect_cost(self)
    local args = BasicConfig.BasicData.detect_consume
    return args[1] + args[2] * self.mainlevel_ - args[3]
end

function make_component(self, tran)
    local lv_txt = tran.transform:Find("lv/Text"):GetComponent(TextMesh)
    local icon = tran.transform:Find("respoint"):GetComponent(SpriteRenderer)
    local box_go = tran.transform:Find("box").gameObject
    
    local prop = self:get_prop()
    if not prop then return end
    if self:has_troop() then
        box_go:SetActive(true)
        lv_txt.text = string.format("<color=green>%d</color>", prop.level)
    else
        box_go:SetActive(false)
        lv_txt.text = prop.level
    end 
    if not self.is_load_icon_ then
        ResourcesManager.LoadSpriteAsync(prop.model, function(sprite) 
            if not Slua.IsNull(sprite) and not Slua.IsNull(icon) then
                icon.sprite = sprite
            end
        end)
        self.is_load_icon_ = true
    end
end

function delete_self(self)
    MsgCenter.send_message(Msg.WORLD_DELETE_OBJ, self.idx_)
    MsgCenter.send_message(Msg.WORLD_CLEAR_MENU)
    _G.event.fire(_G.EventKey.WORLD_RESPOINT_DELETE, self.idx_)
    --MsgCenter.send_message(Msg.WORLD_RESPOINT_DELETE, self.idx_)
    LuaTimer.Add( 0, function()
        if WorldManager.world_fort_[self.x_] then
            WorldManager.world_fort_[self.x_][self.z_] = nil
        end
        MsgCenter.send_message(Msg.WORLD_DELETE_OBJ_BUILD, self.x_, self.z_) 
    end)
    return true
end

function enable_click_show(self)
    local prop = self:get_prop()
    local main_lv = BuildManager:get_main_lv()
    if main_lv < prop.limit then
        local str = lang("RESPOINT_23", prop.limit)
        MsgCenter.send_message(Msg.SHOW_HINT, str)
        return false
    end    
    return true
end

-- 获取布阵优先级  1=等级 2=负重 3=速度 4=搭配
function get_troops_order(self)
    return 2
end