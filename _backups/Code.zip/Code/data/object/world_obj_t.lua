module("WorldObj", mkcall)

mt = {
    __index = WorldObj,
}


function init(self, x, z)
    self.x_ = x
    self.z_ = z
    self.obj_type_ = config.WORLD_OBJ
end

function get_prop(self)
    return nil
end

function get_type(self)
    return self.obj_type_
end

function get_name(self)
    return ""
end

-- 场景中物件自我删除
function delete_self(self)
    return false
end

--获取场景坐标到屏幕坐标的偏移（主城池）
function get_offset_pos(self)
    return 0, 0
end

-- 出征界面，类型名字
function get_troop_type_name(self)
    return ""
end

-- 获得配置战力
function get_prop_power(self, callback)
    return
end

-- 是否可点击显示
function enable_click_show(self)
    return true
end

--重新加载，初始化
function prepare_reload(self)
    self.is_load_ = false
end

-- 获取布阵优先级  1=等级 2=负重 3=速度 4=搭配
function get_troops_order(self)
    return 1
end

-- 只有行军才有的接口
function get_march_id_str(self)
    return ""
end

-- 体力消耗
function get_energy_cost(self)
    return 5
end
