 module("CityBuild", _G.mkcall)

Movable   = 1 -- 可移动的建筑
UnMovable = 2 -- 不可移动的建筑

-- CAN_UPGRADE_BUILD = 1
-- FUNCTION_BUILD = 2
-- CANNOT_UPGRADE_BUILD = 3

local config = _G.config
local lang = _G.lang
local resmng = _G.resmng
local Net = _G.Net

 --建筑和菜单数据
local CityConfig = _G.Database.CityConfig
local BuildopenConfig = _G.Database.BuildopenConfig
local Attrs

function new(data)
    local obj = {}
    setmetatable(obj, {__index = CityBuild})
    obj:init(data)
    return obj
end

function init(self, data)
    --build mark
    self.buildMark = data.mark
    --server data
    self.build_type_ = data.buildtype
    self.lv_ = data.level or 0
    self.pos_ = data.pos --位置
    --local data
    self.prop_ = self:get_prop_build()

    self.name_ = lang(self.prop_.name)
    self.introduce_ = lang(self.prop_.introduce)   --建筑说明
    self.mdetails_title_ = lang(self.prop_.mdetailstitle)
    if self.buildMark == config.BUILD_MARK.NORMAL then
        if data.pos then
            self.space_id_ = data.pos + self:get_prop_build().startpos - 1
        end
        self.max_lv_ = self.prop_.maxlevel       --最大等级
        self.max_count_ = self.prop_.maxcnt      --建筑最多可建造的数量

        self.start_time_ = nil
        self.end_time_ = nil
        self.total_time_ = nil
        self.state_ = nil

        self.soldier_id_ = nil   --正在训练的士兵id
    elseif self.buildMark == config.BUILD_MARK.NOLV then
        self.space_id_ = data.startpos
        self.path = data.path
        self.menu = data.menu
    end
end

function update_server(self, data)
    if not data then return end
    self.lv_ = data.level
    self.id_ = data.id
    local runinfo = data.runinfo
    if runinfo then
        self.start_time_ = runinfo.ti_start
        self.end_time_ = runinfo.ti_end
        self.total_time_ = runinfo.ti_long
        self.dec = runinfo.ti_dec or 0
        local state
        --如果是拆除的话
        if runinfo.mark == "dismantle" then
            self.is_distantle_ = true
            state = config.Build_State.REMOVING
        else
            self.is_distantle_ = false
            state = self.lv_ > 0 and config.Build_State.LV_UP or config.Build_State.BUILDING
        end
        self.state_ = state
    else
        self:reset()
    end
end

function reset_dismantle(self)
    self.start_time_ = nil
    self.end_time_ = nil
    self.total_time_ = nil
    self.dec = nil
    self.is_distantle_ = false
end

function update_soldier_cure_server(self, data)
    if not data then return end
    if self.build_type_ ~= config.BUILD_TYPE.HOSPITAL then return end
    local cure = data.cure
    if data.total then
        self.cure_total_ = data.total
    end
    if cure then
        local obj = {}
        obj.dec_ = cure.ti_dec or 0
        obj.start_time_ = cure.ti_start
        obj.total_time_ = cure.ti_long
        obj.end_time_ = cure.ti_end
        self.cure_timer_ = obj
        self.state_ = config.Build_State.CURE
    else
        self.cure_timer_ = nil
        if self.end_time_ and self.end_time_ > Net.server_time() and not self.is_distantle_ then
            local state = self.lv_ > 0 and config.Build_State.LV_UP or config.Build_State.BUILDING
            self.state_ = state
        else
            if self.is_distantle_ then
                self.state_ = config.Build_State.REMOVING
                return
            end
            self.state_ = config.Build_State.NONE
        end
    end
end

function set_soldier_cure_info(self, timer_obj, count)
    if not timer_obj or not count then return end
    self.cure_timer_ = timer_obj
    self.cure_total_ = count
    self.state_ = config.Build_State.CURE
end

function reset(self)
    self.start_time_ = nil
    self.end_time_ = nil
    self.total_time_ = nil
    if self.cure_timer_ then
        self.state_ = config.Build_State.CURE
    else
        self.state_ = config.Build_State.NONE
    end
end

function GetNameLV(self)
    if self.buildMark == config.BUILD_MARK.NORMAL then
        return lang("UI_BUILD_NAME_LV", self.name_, self.lv_)
    elseif self.buildMark == config.BUILD_MARK.NOLV then
        return self.name_
    end
end

--获取建筑UI路径(lv 可选参数)
function GetPath(self, lv)
    if self.buildMark == config.BUILD_MARK.NORMAL then
        if not lv then
            lv = self.lv_
        end
        local upinfo = self:get_update_info_by_level(lv)
        if upinfo then
            return upinfo.path
        end
    elseif self.buildMark == config.BUILD_MARK.NOLV then
        return self.path
    end
end

function IsHaveMenu(self)
    if self.menu and #self.menu > 0 then
        return true
    end
    return false
end

function GetMenu(self)
    if self.buildMark == config.BUILD_MARK.NORMAL then
        return self:get_update_info_by_level().menu
    elseif self.buildMark == config.BUILD_MARK.NOLV then
        return self.menu
    end
end
--更多详情标题
function GetMdetailsTitle(self)
    local prop = self:get_prop_build()
    return prop.mdetailstitle
end

--获取更多详情
function get_build_more_details(self)
    local data = {}
    for i = 1, self.max_lv_ do
        local up_lv_info = self:get_update_info_by_level(i)
        if up_lv_info then
            up_lv_info.moredetails[1] = up_lv_info.level
            data[up_lv_info.level] = up_lv_info.moredetails
        end
    end
    return data
end

--建筑表
function get_prop_build(self)
    if self.buildMark == config.BUILD_MARK.NORMAL then
        return CityConfig.BuildData[self.build_type_]
    elseif self.buildMark == config.BUILD_MARK.NOLV then
        return BuildopenConfig.BuildopenData[self.build_type_]
    end
end

--获取升级信息,可根据等级获取信息
function get_update_info_by_level(self, lv)
    if self.buildMark == config.BUILD_MARK.NOLV then
        return
    end
    if lv then lv = self.build_type_ * 10000 + lv end
    local key = lv or self.build_type_ * 10000 + self.lv_
    local data = CityConfig.BuildupdateData[key]
    if not data then 
        elog("get_update_info_by_level. key is = %s", lv)
    end
    return data
end

--获取建筑状态
function get_state(self)
    if self:is_trainning() then
        if self:is_lvup() then
            return config.Build_State.DRILL_AND_LV_UP
        else
            return config.Build_State.DRILL
        end
    end
    return self.state_
end


function enable_lvup(self)
    if self.buildMark == config.BUILD_MARK.NOLV then
        return false
    end
    if not self:lv_out_range() and
        BuildManager:check_queue() and
        self:is_enough_res_all() and
        not self:is_lvup() and
        not self:is_building() then
        return true
    end
    return false
end

--是否在建造中
function is_building(self)
    if self.is_distantle_ then return false end
    if self.end_time_ and self.end_time_ > Net.server_time() and self.lv_ == 0 then
        return true
    end
    return false
end

--是否在升级中
function is_lvup(self)
    if self.is_distantle_ then return false end
    if self.end_time_ and self.end_time_ > Net.server_time() and self.lv_ > 0 then
        return true
    end
    return false
end

--是否在治疗中
function is_curing(self)
    if not self:is_hospital_build() then
        return false
    end
    return self.cure_timer_ and self.cure_timer_.end_time_ > Net.server_time()
end

--是否在拆除中
function is_removing(self)
    return self.is_distantle_ == true
end

--是否在训练
function is_trainning(self)
    if not self:is_soldier_build() then return false end
    local timer_exist, finish_train, soldier_id = SoldierManager:check_soldier_state(self.build_type_)
    if timer_exist then
        return true
    end
    return false
end

--是否超出最大等级
function lv_out_range(self)
    if self.lv_ >= self.max_lv_ then
        return true
    end
    return false
end

--是否可以拆除
function is_can_be_removed(self)
    --资源田可以拆除
    if self:is_outside_build() then
        return true
    end
    return false
end

--是否可以移动
function is_movable(self)
    --资源田可以移动
    --拆除的时候不显示建筑移动
    --升级的时候不显示建筑移动
    --取消治疗的时候可以建筑移动
    local sapce = CityConfig.SpaceData[self.space_id_]
    if not sapce then
        elog("not fond sapce, pls check sapce_id = %s", self.space_id_)
        return
    end
    local is_movable = sapce.movecity == Movable
    if is_movable then
        if self:is_removing() or self:is_lvup() then
            return false
        end
        return true
    end
    return false
end

-- 资源是否充足(是否满足升级所需要的资源)
function is_enough_res_all(self)
    local next_upinfo = self:get_update_info_by_level(self.lv_ + 1)
    if not next_upinfo or not next_upinfo.upcost then return end
    for k, v in pairs(next_upinfo.upcost) do
        if not ItemManager:check_resource(v) then
            return false
        end
    end
    return true
end

--获取更多详情当前等级与下一级的偏差
function get_moredes_value_offset(self)
    if not self:is_show_value_build() or self:lv_out_range() or self.lv_ <= 0 then return end

    local curr_upinfo = self:get_update_info_by_level(self.lv_)
    local next_upinfo = self:get_update_info_by_level(self.lv_ + 1)
    local more_des_tb = curr_upinfo.moredetails --更多详情
    local next_more_des_tb = next_upinfo.moredetails --下一等级更多详情
    if not curr_upinfo or not next_upinfo or not more_des_tb or not next_more_des_tb then return end

    local index_tb = self:get_introductions_value_index() --获取数值映射表
    if not index_tb then return end
    local offset_tb = {}
    local white_value_tb = {} --白色数值(不带附加值)

    for _, v in pairs(index_tb) do
        local next_v, curr_v = next_more_des_tb[v], more_des_tb[v]
        local offset
        --征兵处数值带有%号。
        if not tonumber(next_v) or not tonumber(curr_v) then
            next_v = string.gsub(next_v, "%%", "")
            curr_v = string.gsub(curr_v, "%%", "")
            offset = next_v - curr_v
            offset = offset.."%"
        else
            offset = math.floor(next_v - curr_v)
        end
        table.insert(offset_tb, offset)
        table.insert(white_value_tb, more_des_tb[v])
    end
    return white_value_tb, offset_tb
end

--升级说明需要显示加成的建筑,数值映射表.(在moredetails表中的映射)
Introductions_Value_Map = {
    --key: build_type  value: 在更多详情表中的角标
    [6]  = {3, 4},  --农田
    [7]  = {3, 4},  --伐木场
    [8]  = {3, 4},  --采石场
    [9]  = {3, 4},  --冶炼厂
    [10] = {3}   ,  --医馆
    [11] = {4, 3},  --征兵处
    [23] = {3, 4},  --城墙
    [24] = {3, 2},  --箭塔
}

--获取升级说明数值索引（更多详情表中）
function get_introductions_value_index(self)
    if not Introductions_Value_Map[self.build_type_] then return end
    return Introductions_Value_Map[self.build_type_]
end

--获取无法通过配置得到的属性值
--@param:index -详情列表索引
function get_details_value(self, index)
    index = index or 1
    local builds = BuildManager:get_all_builds_by_type(self.build_type_)
    local ret = 0
    for build_id, build in pairs(builds) do
        local propid = build.build_type_ * 10000 + build.lv_
        local attr = CityConfig.BuildupdateData[propid].attr
        if not attr then
            return
        end
        self.soilder_num_attrid_ = attr[1][1]
        ret = ret + attr[index][2]
    end
    return ret
end

function get_hospital_max_cnt(self)
    if not self:is_hospital_build() then
        elog("this build is not hospital! check it")
        return
    end
    return AttrsManager:get_attrs_value_by_name("cure_num")
end

function get_details_attrs(self, value, index)
    -- 资源点先写死
    if self:is_collect_build() then
        return CollectManager:get_attrs_buff(self.id_, value) or 0
    end
    if self:is_draft_build() then
        if index == 2 then
            local base = self:get_details_value()
            local total = AttrsManager:get_attrs(self.soilder_num_attrid_).value_
            return total - base
        end
    end
    if self:is_hospital_build() then
        if index == 2 then
            local base = self:get_details_value()
            local cure_num = AttrsManager:get_attrs_value_by_name("cure_num")
            return cure_num - base
        end
    end
    if self.build_type_ == config.BUILD_TYPE.WALL then
        local base = self:get_details_value(index)
        if index == 1 then
            local trapCapa = AttrsManager:get_attrs_value_by_name("trap_capa")
            return trapCapa - base
        elseif index == 2 then
            local cityDef = AttrsManager:get_attrs_value_by_name("city_def")
            return cityDef - base
        end
    end
    if self.build_type_ == config.BUILD_TYPE.TRAP then
        if index == 2 then
            local base = self:get_details_value()
            local trapNum = AttrsManager:get_attrs_value_by_name("train_num_trap")
            return trapNum - base
        end
    end
    return 0
end

--根据状态获取剩余时间
function get_remaining_time(self)
    local state = self:get_state()
    if self.Check_State[state] and self.Check_State[state]["get_remaining_time"] then
        return self.Check_State[state]["get_remaining_time"](self)
    end
end

-- 获取建筑剩建造or升级剩余时间
function get_build_remaining_time(self)
    if not self.end_time_ then return end
    if self.end_time_ < Net.server_time() then return end
    local remainning_time = self.end_time_ - Net.server_time()
    local curr_time = self.total_time_ - remainning_time

    return remainning_time, curr_time, self.total_time_
end

-- 获取伤兵恢复剩余时间
function get_cure_remaining_time(self)
    if not self:is_hospital_build() then return end
    if self.cure_timer_.end_time_ and self.cure_timer_.end_time_ > Net.server_time() then
        local remainning_time = self.cure_timer_.end_time_ - Net.server_time()
        local curr_time = self.cure_timer_.total_time_ - remainning_time
        return remainning_time, curr_time, self.cure_timer_.total_time_
    end
end

--获取升级界面队列文字（如：步兵营正在升级）
function get_queue_txt(self)
    if not self.name_ then return end
    if self:is_lvup() then
        return lang("UI_BUILDSPEND_UPDATING", self.name_)
    elseif self:is_building() then
        return lang("UI_BUILDSPEND_BUILDING", self.name_)
    elseif self:is_removing() then
        return lang("UI_BUILDSPEDN_DISTANTLE", self.name_)
    end
end

--是否小于免费时间
function is_less_free_time(self)
    --如果剩余时间为nil。无法比较，返回false
    if not self:get_remaining_time() then return false end
    self.free_time_ = AttrsManager:get_attrs_value_by_name("free_build_time")
    if self:get_remaining_time() <= self.free_time_ then
        return true
    end
    return false
end

--建筑是否需要在升级界面显示数值
function is_show_value_build(self)
     if self.build_type_ == config.BUILD_TYPE.FARM or
        self.build_type_ == config.BUILD_TYPE.LOGGING_CAMP or
        self.build_type_ == config.BUILD_TYPE.STONE_PIT or
        self.build_type_ == config.BUILD_TYPE.SMELTER or
        self.build_type_ == config.BUILD_TYPE.HOSPITAL or
        self.build_type_ == config.BUILD_TYPE.ENLISTMENT or
        self.build_type_ == config.BUILD_TYPE.WALL or
        self.build_type_ == config.BUILD_TYPE.TOWER then
        --扩展在这里加
            return true
    end
    return false
end

function is_outside_build(self)
    if self.build_type_ == config.BUILD_TYPE.FARM or 
        self.build_type_ == config.BUILD_TYPE.LOGGING_CAMP or
        self.build_type_ == config.BUILD_TYPE.STONE_PIT or 
        self.build_type_ == config.BUILD_TYPE.SMELTER or
        self.build_type_ == config.BUILD_TYPE.HOSPITAL or
        self.build_type_ == config.BUILD_TYPE.ENLISTMENT then
            return true
    end
    return false
end

function is_soldier_build(self)
    if self.build_type_ == config.BUILD_TYPE.JSY or 
        self.build_type_ == config.BUILD_TYPE.SJY or 
        self.build_type_ == config.BUILD_TYPE.QNY or 
        self.build_type_ == config.BUILD_TYPE.XQY or
        self.build_type_ == config.BUILD_TYPE.TRAP then
            return true
    end
    return false
end

function is_collect_build(self)
    if self.build_type_ == config.BUILD_TYPE.FARM or 
        self.build_type_ == config.BUILD_TYPE.LOGGING_CAMP or 
        self.build_type_ == config.BUILD_TYPE.STONE_PIT or 
        self.build_type_ == config.BUILD_TYPE.SMELTER then
            return true
    end
    return false
end

-- 是否征兵处
function is_draft_build(self)
    return self.build_type_ == config.BUILD_TYPE.ENLISTMENT
end

-- 是否医馆
function is_hospital_build(self)
    return self.build_type_ == config.BUILD_TYPE.HOSPITAL
end

--建筑状态
--key get_remaining_time 获取剩余时间
Check_State = {
    [config.Build_State.BUILDING] = {
        ["get_remaining_time"] = get_build_remaining_time,
    },
    [config.Build_State.LV_UP] = {
        ["get_remaining_time"] = get_build_remaining_time,
    },
    [config.Build_State.DRILL_AND_LV_UP] = {
        ["get_remaining_time"] = get_build_remaining_time,
    },
    [config.Build_State.CURE] = {
        ["get_remaining_time"] = get_cure_remaining_time,
    },
    [config.Build_State.REMOVING] = {
        ["get_remaining_time"] = get_build_remaining_time,
    }
}