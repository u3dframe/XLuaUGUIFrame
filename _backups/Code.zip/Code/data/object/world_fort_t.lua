module("WorldFort", package.seeall)
deriveClass(WorldFort, WorldObj) 



local BasicConfig = _G.Database.BasicConfig
local HeroConfig = _G.Database.HeroConfig
local FortifiedConfig = _G.Database.FortifiedConfig


function init(self, x, z, data)
    WorldObj.init(self, x, z)
    self.idx_ = data.id
    self.id_ = data.defid
    self.obj_type_ = config.WORLD_FORT
    self.is_load_ = false
    self.name_ = data.name
    self.owner_ = data.owner
    self.cnt_ = data.cnt
    self.runinfo_ = data.runinfo
    self.mainlevel_ = data.mainlevel
    self.heroes_ = {}
    if data.heroes then
        for k,v in pairs(data.heroes) do
            local hero = Hero(v.id)
            hero:update_server_data(v)
            table.insert(self.heroes_, hero)
        end
    end
end

function get_prop(self)
    return FortifiedConfig.FortifiedData[self.id_]
end

function get_name(self)
    return lang("UI_FORT_07")
end

function get_hero_name(self)
    local prop = self:get_prop()
    local hero = prop.general[1]
    if not hero then return end
    hero = HeroConfig.ListData[hero[1]]
    return hero and hero.name
end

function set_fort_text_mesh(self, textMesh, owner)
   if not textMesh then return end
   local prop = self:get_prop()
   local str = lang("UI_FORT_08",prop.level, self:get_hero_name())
   if self:has_troop() then
        --dump(self.name_, "WorldFort self.name_: ", 9)
       str = string.format("%d<%s>", prop.level, self.name_)
   else
       if self:get_frozen_state() then
            str = lang("UI_FORT_16")
       end
   end
   local render = textMesh.transform:GetComponent(MeshRenderer)
   render.sortingOrder = 1
   textMesh.text = str
end

function set_owner_active(self, owner)
    if self:has_troop() then
        local menu = SceneManager.World_Scene.world_menu_
        if menu and menu.obj_ and menu.obj_.idx_ == self.idx_ then
            owner:SetActive(false)
        else
            owner:SetActive(true)            
        end
    else
        owner:SetActive(false)
    end
end

-- 获得配置战力
function get_prop_power(self, callback)
    if self:get_frozen_state() then return 0 end
    local power = 0
    _G.WorldManager:GetTroops(self, function(troops)
        for _,v in ipairs(troops.soldiers) do
            local prop = _G.SoldierManager:get_soldier_prop_by_id(v[1])
            local tmp_power = prop.power * v[2]
            power = power + tmp_power
        end
        if callback then
            callback(math.ceil(power/100))
        end
    end)
end

function show_obj_desc(self)
    local str = lang("UI_FORT_09")..self.cnt_
    if self:has_troop() then
        str = self.name_
    end
    return str
end

-- 出征界面，野怪
function get_troop_type_name(self)
    return lang("UI_FORT_10")
end

function get_battle_msg(self)
    return "battle_fortified"
end

function get_cancel_msg(self)
    return "fortified_cancel"
end

function get_detect_msg(self)
    return "fortified_detect"
end

-- 是否有玩家军队
function has_troop(self)
    return self.owner_ and self.owner_ > 0
end

-- 刷新次
function refresh_data(self, data)
    local is_push = true
    if self.owner_ == data.owner then
        is_push = false
    end

    self.name_ = data.name
    self.cnt_ = data.cnt
    self.runinfo_ = data.runinfo
    self.owner_ = data.owner
    -- 等数据更新了再推消息
    if is_push then
        MsgCenter.send_message(Msg.WORLD_FORT_REFRESH, self.idx_)
    end
end

function get_one_time_bar(self)
    if not self.runinfo_ then return 0 end
    if Net.server_time() > self.runinfo_.ti_end then return 0 end
    local delta_up = self.runinfo_.ti_end - Net.server_time()
    local delta_down = self.runinfo_.ti_end - self.runinfo_.ti_start
    local ratio = delta_up/delta_down
    return ratio
end

function get_one_time(self)
    if not self.runinfo_ then return 0 end
    if Net.server_time() > self.runinfo_.ti_end then return 0 end
    return self.runinfo_.ti_end - Net.server_time()
end

function delete_self(self)
    MsgCenter.send_message(Msg.WORLD_DELETE_OBJ, self.idx_)
    MsgCenter.send_message(Msg.WORLD_CLEAR_MENU)
    if _G.FairyGUI then
        _G.event.fire(_G.EventKey.WORLD_FORT_DELETE, self.idx_)
    else
        MsgCenter.send_message(Msg.WORLD_FORT_DELETE, self.idx_)
    end
    LuaTimer.Add( 0, function()
        if WorldManager.world_fort_[self.x_] then
            WorldManager.world_fort_[self.x_][self.z_] = nil
        end
        MsgCenter.send_message(Msg.WORLD_DELETE_OBJ_BUILD, self.x_, self.z_) 
    end)
    return true
end

function get_frozen_state(self)
    --_G.dump(self.runinfo_, "self.runinfo_: ", 9)
    if not self.runinfo_ then return false end
    local delta_up = self.runinfo_.ti_end or 0 - self.runinfo_.ti_start or 0 - self.runinfo_.ti_dec or 0
    local delta_down = self.runinfo_.ti_end or 0 - self.runinfo_.ti_start or 0
    delta_down = delta_down ~= 0 and delta_down or 1;
    local ratio = delta_up/delta_down
    return ratio
end

-- 体力消耗
function get_energy_cost(self)
    return BasicConfig.BasicData.fortified_cost[3]
end