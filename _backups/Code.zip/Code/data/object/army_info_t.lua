module("ArmyInfo", mkcall)


SPEED = 1     -- 加速
RETURN = 2    -- 撤军


TO_MONSTER = 1      -- 去怪物路上
CITY = 2
BOSS = 3
RET_CITY = 4        -- 回城路上
DO_FORTIFIED = 5    -- 采集中据点
TO_FORTIFIED = 6    -- 去势力据点
TO_RESPOINT = 7     -- 去采集点
DO_RESPOINT = 8     -- 采集中资源
DETECT_RESPOINT = 9     -- 侦察资源
DETECT_FORT = 11     -- 侦察势力据点

function new(data)
    local obj = {}
    setmetatable(obj, {__index = ArmyInfo})
    obj:init(data)
    return obj
end

function init(self, data)
    self.id_ = data.id
    self.army_type_ = data.armytype
    self.finish_ = {}
    if data.finish then
        self.finish_.x = data.finish.x
        self.finish_.z = data.finish.y
        self.finish_.id = data.finish.id
    end
    self.runinfo_ = data.runinfo
    self.is_play_ = false
end

function GetAllTime(self)
    if not self.runinfo_ then return 0 end

    local ti_dec = self.runinfo_.ti_dec or 0
    local all_time = (self.runinfo_.ti_end + ti_dec) - self.runinfo_.ti_start
    return all_time
end

function GetLastTime(self)
    if not self.runinfo_ then return 0 end

    local lastTime = self.runinfo_.ti_end - Net.server_time()
    return lastTime
end

function GetCostTime(self)
    return self:GetAllTime() - self:GetLastTime()
end

function get_start_percent(self)
    if not self.runinfo_ then return 0 end

    local percent = 1- self:GetLastTime() / self:GetAllTime()
    return percent
end

function get_time(self)
    return (self.runinfo_.ti_end+self.runinfo_.ti_dec) - Net.server_time()
end

function get_name(self)
    local obj = WorldManager:get_world_obj(self.finish_.x, self.finish_.z)
    if not obj then return "" end
    local name = obj:get_name()
    return name
end

function get_bar_state(self)
    if self.army_type_ == TO_MONSTER or self.army_type_ == RET_CITY 
        or self.army_type_ == TO_FORTIFIED or self.army_type_ == TO_RESPOINT
        or self.army_type_ == DETECT_RESPOINT then
        return SPEED
    end
    if self.army_type_ == DO_FORTIFIED or self.army_type_ == DO_RESPOINT then
        return RETURN
    end
    
    return
end

function get_icon(self)
    if self:get_bar_state() == SPEED then
        return "UI/Common/item/xingjunjiasu2" 
    end
    if self:get_bar_state() == RETURN then
        if self.army_type_ == DO_FORTIFIED then
            return "UI/Common/item/xingjunjiasu1" 
        end
        return "UI/Common/item/1"
    end
    return
end

function get_match(self)
    if not self.march_ then
        self.march_ = WorldManager:get_march_by_idx(self.id_)
    end
    return self.march_
end

function get_btn_desc(self)
    if self:get_bar_state() == SPEED then
        return lang("EXPEDITION_4")
    end
    if self:get_bar_state() == RETURN then
        return lang("EXPEDITION_42")
    end
    return
end

function get_bar_desc(self)
    if self:get_bar_state() == SPEED then
        return lang("EXPEDITION_36", self:get_name())
    end
    if self:get_bar_state() == RETURN then
        if self.army_type_ == DO_FORTIFIED then
            return lang("UI_FORT_15")
        end
        return lang("UI_FORT_04")
    end
    return
end


