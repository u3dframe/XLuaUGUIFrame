module("Tips", mkcall)



function new(trans, data, tipsType)
    local obj = {}
    setmetatable(obj, {__index = Tips})
    obj:init(trans, data, tipsType)
    return obj
end

function init(self, trans, data, tipsType)
    self.trans_ = trans
    self:update_data(data, tipsType)
end

function update_data(self, data, tipsType)
    self.data_ = data
    self.type_ = tipsType
end

function get_data(self)
    return self.data_
end