--市舶司
local CityWharf = {}

local Net = _G.Net

function CityWharf:New(data)
    local obj = setmetatable({}, {__index = self})
    obj:RefreshData(data)
    return obj
end

function CityWharf:RefreshData(data)
    if not data then
        return
    end
    self.dropItem = data.reward --掉落道具ID
    self.endTime = data.time
end

--是否有奖励
function CityWharf:EnableReward()
    if Net.server_time() >= self.endTime then
        return true
    end
    return false
end

--获取结束时间
function CityWharf:GetEndTime()
    return self.endTime
end

--获取剩余时间
function CityWharf:GetremainingTime()
    if self.endTime - Net.server_time() < 0 then
        return 0
    end
    return self.endTime - Net.server_time()
end

function CityWharf:GetReward()
    return self.dropItem[1]["array"]
end

return CityWharf