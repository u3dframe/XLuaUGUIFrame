module("Skill", mkcall)

local HeroConfig = _G.Database.HeroConfig


function new(id, count)
    local obj = {}
    setmetatable(obj, {__index = Skill})
    obj:init(id, count)
    return obj
end

function init(self, id, count)
    self.id_ = id
    self.count_ = count
    self.cfg_ = HeroConfig.SkillData[id]
    if not self.cfg_ then
        elog("Cannot find skill id: "..tostring(id))
    end
end

function is_rare(self)
    return self.cfg_.rare > 0
end
