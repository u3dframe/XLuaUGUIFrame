module("CityCollect", mkcall)

MAP_ITEM = {
    [6] = config.ITEM_FOOD,  -- 农田
    [7] = config.ITEM_WOOD,  -- 伐木场
    [8] = config.ITEM_STONE, -- 采石场
    [9] = config.ITEM_IRON,  -- 冶炼厂
}


local BasicConfig = _G.Database.BasicConfig
local CityConfig = _G.Database.CityConfig


function new(id)
	local obj = {}
    setmetatable(obj, {__index = CityCollect})
    obj:init(id)
    return obj
end

function init(self, id)	
    self.build_id_ = id
    self.count_ = 0    
    local build = BuildManager:get_build_info_by_id(self.build_id_)    
    local build_prop = build:get_prop_build() 
    self.type_ = build_prop.buildtype    
    for i,v in ipairs(BasicConfig.BasicData.resouce_buff) do
        if v[1] == self.type_ then
            self.attr_id_ = v[2]
        end
    end
    local prop_buff_item = BasicConfig.BasicData["resouce_buffitem"..self.type_]
    self.buff_item_ = prop_buff_item[1]
    self.name_ = build.name_
end

function get_prop(self)
    local build = BuildManager:get_build_info_by_id(self.build_id_)    
    local index = self.type_ * 10000 + build.lv_
    return CityConfig.CollecterData[index]
end

function refresh_data(self, data)
    self.buff_ = data.buff or 0
    self.start_time_ = data.ti_start
    if not self.start_time_ then return end
    self.end_time_ = data.ti_end
    self.buf_time_ = data.ti_buff or 0
    self.is_full_ = self.end_time_ - self.start_time_
    if not self:enable_collect() then
        local prop = self:get_prop()
        local timer = Timer("collect"..self.build_id_, prop.time)
        timer.need_scene_ = "City"
        TimerManager:add_listener(timer, function()
            MsgCenter.send_message(Msg.CITY_COLLECT_REFRESH, self.build_id_)
        end)
    end
end

function get_attrs_buff(self, value)
    if not self.attr_id_ then return 0 end
    local basic_data = AttrsManager:get_attrs_value(self.attr_id_)
    if not self:has_buff() then 
        local result = value*basic_data
        return result 
    end 
    
    local other_data = 0
    local prop_data = BasicConfig.BasicData["resouce_prod"..self.type_]
    local result = value*(basic_data + 1) * prop_data - value
    return result
end

function enable_collect(self)
    if not self.start_time_ then return end
    local build = BuildManager:get_build_info_by_id(self.build_id_)
    if not build then return false end
    if build:is_less_free_time() then
        return false
    end

    local prop = self:get_prop()
    local delta_time = Net.server_time() - self.start_time_
    if delta_time >= prop.time then
        return true
    end
    return false
end

function has_buff(self)
    if self.buf_time_ > Net.server_time() then
        return true
    end
    return false
end

function get_buff_time(self)
    if not self:has_buff() then return "" end
    local delta_time = self.buf_time_ - Net.server_time()
    return UIUtil.get_format_time(delta_time)
end