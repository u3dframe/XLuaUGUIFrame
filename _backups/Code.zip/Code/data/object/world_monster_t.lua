module("WorldMonster", package.seeall)
deriveClass(WorldMonster, WorldObj) 



local MonsterConfig = _G.Database.MonsterConfig
local BasicConfig = _G.Database.BasicConfig


function init(self, x, z, id, idx)
    WorldObj.init(self, x, z)
    self.id_ = id
    self.idx_ = idx
    self.obj_type_ = config.WORLD_MONSTER
    self.prop_ = self:get_prop()
    self.lv_ = self.prop_.lv
    self.is_load_ = false
end

function get_prop(self)
    local prop = MonsterConfig.MonsterData[self.id_]
    if not prop then 
        elog("propMonsterData findn't config, pls check the data, id = "..self.id_)
        return {} 
    end
    return MonsterConfig.MonsterData[self.id_]
end

function get_name(self)
    return self.prop_.name
end

function delete_self(self)
    MsgCenter.send_message(Msg.WORLD_DELETE_OBJ, self.idx_)
    LuaTimer.Add( 0, function()
        if WorldManager.world_monster_[self.x_] then
            WorldManager.world_monster_[self.x_][self.z_] = nil
        end
        MsgCenter.send_message(Msg.WORLD_DELETE_OBJ_BUILD, self.x_, self.z_)        
    end)
    return true
end

-- 出征界面，野怪
function get_troop_type_name(self)
    return lang("UI_TROOPS_FIELD") 
end

-- 获得配置战力
function get_prop_power(self, callback)
    if callback then
        callback(self.prop_.power)
    end
end

function get_battle_msg(self)
    return "battle_monster"
end

-- 体力消耗
function get_energy_cost(self)
    return BasicConfig.BasicData.monster_cost[3]
end