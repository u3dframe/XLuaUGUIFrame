module("CitySoldier", mkcall)

local Attr = _G.config.SOLDIER_ATTRIBUTES
local BasicConfig = _G.Database.BasicConfig
local SoldierskillConfig = _G.Database.SoldierskillConfig
local SoldierConfig = _G.Database.SoldierConfig
local TrapConfig = _G.Database.TrapConfig
local config = _G.config


function new(id, class)
	local obj = {}
    setmetatable(obj, {__index = CitySoldier})
	obj.id_ = id
	obj.class_ = class or config.SOLDIER_CLASS.COMMON
    obj:init()
    return obj
end

function init(self)	
	self.prop_ = self:get_prop()
	local data = self.prop_
	self.build_type_ = data.buildtype      --建筑类型
	self.soldier_type_ = data.soldiertype  --士兵类型
	self.number_ = self.number_ or 0   	   --士兵总数
	--normal
	self.spend_ = data.upcost              --造兵消耗
	self.uplong_ = data.uplong             --造兵时长
	--hurts
	self.hurts_number_ = self.hurts_number_ or 0  --伤兵总数
	self.hurts_spend_ = data.recost        --伤兵恢复消耗
	self.hurts_uplong_ = data.relong       --伤兵恢复时长

 	self.name_ = data.name                --士兵name
	self.lv_ = data.lv                    --士兵等级
	self.fighting_power_ = data.power / 100    --战斗力
	self.attribute_ = self:get_attribute(self.prop_.attr)  --属性
	
	self.unlock_ = self.prop_.unlock      --士兵解锁条件
	self.describe_ = data.describe        --士兵描述
	self.rebate_ = data.rebate            --返利

	self.max_value_ = data.maxvalue           --攻防血最大值
	self.skill_info_ = self:init_skill_info() --技能

	-- 士兵美术资源
	self.path_ = data.path                --全身像
	self.small_icon_path_ = data.route    --icon (训练滑动区域icon)
	self.half_icon_path_ = data.half      --半身像

	self.start_time_ = nil
	self.end_time_ = nil
	self.total_time_ = nil
	self.select_count_ = nil    --选中的数量
	self.build_id_ = nil
end

function init_skill_info(self)
	local obj = {}
	for k, v in ipairs(self.prop_.skillinfo or {}) do
		local data = self:get_skill_prop(v)
		obj[k] = {}
		obj[k].id_ = data.id
		obj[k].name_ = data.name
		obj[k].des_ = data.skilldescribe
		obj[k].path_ = data.route
	end
	return obj
end

function get_attribute(self, attr)
	if not attr then return end
	local obj = {}
	obj.atk_ = attr[Attr.ATK] --攻击
	obj.def_ = attr[Attr.DEF] --防御
	obj.hp_ = attr[Attr.HP]   --血量
	obj.atk_distance_ = attr[Attr.ATK_DESTANCE] --攻击距离
	obj.speed_ = attr[Attr.SPEED]    --速度
	obj.weight_ = attr[Attr.WEIGHT]  --负重
	obj.expend_ = attr[Attr.EXPEND]  --粮草消耗
	return obj
end

-- 是否在倒计时中
function is_counting(self)
	return self.end_time_ and self.end_time_ > Net.server_time()
end


--是否在训练中
function is_training(self)
	if self.target_ then
		return false
	end
	return self:is_counting()
end

--是否在晋升中
function is_soldier_updating(self)
	if self.target_ then
		return true
	end
	return false
end

function get_prop(self)
	if self.class_ == config.SOLDIER_CLASS.TRAP then
		return TrapConfig.TrapData[self.id_]
	end
	return SoldierConfig.SoldierData[self.id_]
end

--get skill data
function get_skill_prop(self, skill_id)
	return SoldierskillConfig.SoldierskillData[skill_id]
end

function get_speed(self)
	if self.attribute_ and self.attribute_.speed_ then
    	return self.attribute_.speed_
    end
    return 0
end

function get_power(self)
    return self.prop_.power
end

--获取训练最大数量
function get_drill_max_count(self)
	if not self.build_type_ or not self.soldier_type_ then return end
	local count
	local att = {
		"train_num", "train_num_camp"..self.build_type_, "train_num_soldier"..self.soldier_type_
	}
	local train_num = AttrsManager:get_attrs_value_by_name(att[1])
	local train_num_camp = AttrsManager:get_attrs_value_by_name(att[2])
	local train_num_soldier = AttrsManager:get_attrs_value_by_name(att[3])
	count = train_num + train_num_camp + train_num_soldier
	return math.floor(count)
end

--获取训练时间
function get_drill_time(self, count)
	if not count or count <= 0 then
		return 0
	end

	-- 除以1000 单位转成秒
	local total_time = self.uplong_ * count / 1000
	local up
	if self.class_ == config.SOLDIER_CLASS.COMMON then
		local att = {
			"train_speed", "train_speed_camp"..self.build_type_, "train_speed_soldier"..self.soldier_type_
		}
		-- 时间=时间/(1+加成)
		local train_speed = AttrsManager:get_attrs_value_by_name(att[1])
		local train_speed_camp = AttrsManager:get_attrs_value_by_name(att[2])
		local train_speed_soldier = AttrsManager:get_attrs_value_by_name(att[3])
		up = train_speed + train_speed_camp + train_speed_soldier
	elseif self.class_ == config.SOLDIER_CLASS.TRAP then
		up = AttrsManager:get_attrs_value_by_name("train_speed_trap")
	end
	local time = total_time / (1 + up)
	return time
end
--晋升消耗时间
function GetPromoteTime(self,targetId,count)
	local upInfo=SoldierManager:get_lvup_info_by_lv(self.id_, targetId)
	if not count then return end
	if count <= 0 then return 0 end
	-- 除以1000 单位转成秒
	local total_time = upInfo.prolong * count / 1000
	local up
	if self.class_ == config.SOLDIER_CLASS.COMMON then
		local att = {
			"train_speed", "train_speed_camp"..self.build_type_, "train_speed_soldier"..self.soldier_type_
		}
		-- 时间=时间/(1+加成)
		local train_speed = AttrsManager:get_attrs_value_by_name(att[1])
		local train_speed_camp = AttrsManager:get_attrs_value_by_name(att[2])
		local train_speed_soldier = AttrsManager:get_attrs_value_by_name(att[3])
		up = train_speed + train_speed_camp + train_speed_soldier
	elseif self.class_ == config.SOLDIER_CLASS.TRAP then
		up = AttrsManager:get_attrs_value_by_name("train_speed_trap")
	end
	local time = total_time / (1 + up)
return time
end
function get_remaining_drill_time(self)
	if not self:is_counting() then return 0 end
	return self.end_time_ - Net.server_time()
end

function get_gold_drill_number(self, count)
	local remaining_time
	if self:is_counting() then
		remaining_time = self:get_remaining_drill_time()
	else
		remaining_time = self:get_drill_time(count)
	end
	-- 金币=系数1*（训练时间）^系数2-系数3.   结果四舍五入,最小值为1
	local basic = BasicConfig.BasicData
	local number = basic.train_gold1 * remaining_time ^ basic.train_gold2 - basic.train_gold3
	local integer_num = math.floor(number + 0.5)
	if integer_num <= 0 then integer_num = 1 end
	return integer_num
end

function update_server(self, data)
	if not data then return end
	self.build_id_ = data.id
	self.select_count_ = data.soldiercnt
	self.target_ = data.target --晋升的时候才会有这个字段
	if data.runinfo then
		self.start_time_ = data.runinfo.ti_start
		self.end_time_ = data.runinfo.ti_end
		self.total_time_ = data.runinfo.ti_long
		self.dec = data.runinfo.ti_dec or 0
	else
		self:reset()
	end
end

function reset(self)
	self.start_time_ = nil
	self.end_time_ = nil
	self.total_time_ = nil
end

function get_attribute_by_type(self, attt_type)
	if not self.prop_.attr or not attt_type then return end
	return self.prop_.attr[attt_type]
end

function GetTotalTrainTime(self)

end
