module("Hero", mkcall)

Max_Star = 5  --最大星级
Max_lv   = 120 --武将最大等级



ST_HOME = 1
ST_DEFENCE = 2  -- 驻守在城墙
ST_OUT = 3      -- 出征

local BasicConfig = _G.Database.BasicConfig
local HeroConfig = _G.Database.HeroConfig


function new(id)
    local obj = {}
    setmetatable(obj, {__index = Hero})
    obj:init(id)
    return obj
end

function init(self, id)
    self.id_ = id

    
    local prop = self:get_prop()
    if not prop then
        elog("hero findn't config , hero id = "..id)
        return
    end
    self.name_ = prop.name
    self.is_active_ = false
    self.head_icon_ = prop.icon
    self.drawing_ = prop.path
    self.drawing_data_ = prop.scale
    self.cur_exp_ = 0
    self.max_exp_ = 1000
    self.star_ = 0
    self.lv_ = 0
    self.quality_ = prop.quality
    self.type_ =  prop.type         -- 职业（统帅、政务、智谋）
    self.innate_skillID_ = prop.innate
    self.skills_ = {}
    self.state_ = ST_HOME     -- 1在家
end

-- 复制武将卡牌属性
function clone(self, hero)
    self.cur_exp_ = hero.cur_exp_
    self.max_exp_ = hero.max_exp_
    self.star_ = hero.star_
    self.lv_ = hero.lv_
    self.skills_ = hero.skills_
    self.state_ = hero.state_
    self.pos_ = hero.pos
end

function update_server_data(self, data)
    self.is_active_ = true
    self.star_ = data.star
    self:set_level(data.level)
    self.cur_exp_ = data.exp
    local prop_lv = self:get_prop_lv()
    local exp_para = self:get_star_exp_para()
    self.max_exp_ = prop_lv.exp * exp_para
    self.state_ = data.state
    self.pos_ = data.pos
    self.skills_ = data.skills or {}
end

--武将等级
function set_level(self, level)
    local lv = level
    --等级不能超过 当前星级的最大等级
    if tonumber(lv) and lv > self:get_max_lv() then
        lv = self:get_max_lv()
    end
    self.lv_ = lv or 0
end

function get_prop(self)
    return HeroConfig.ListData[self.id_]
end

function get_prop_star(self)
    if self.star_ == 0 then return end
    local key = self.id_*100 + self.star_
    return HeroManager.star_prop_map_[key]
end

function get_prop_lv(self)
    if self.lv_ == 0 then return end
    return HeroConfig.PropertyData[self.lv_]
end

-- 获取显示星级
function get_star_lv(self)
    local prop_star = self:get_prop_star()
    if not prop_star then return 0 end
    return prop_star.star
end

-- 获取显示星阶段
function get_stage_lv(self)
    local prop_star = self:get_prop_star()
    if not prop_star then return 0 end
    return prop_star.stage
end

-- 获取战力
function get_power(self)
    local hero_power = BasicConfig.BasicData.hero_power
    local attrs_value = self:get_attr()
    local power = 0
    for i,v in ipairs(hero_power) do
        power = power + v*attrs_value[i]
    end
    return math.floor(power)
end

-- 获取升级经验   lv 指定等级，可以为空
function get_exp(self, lv)
    local key = lv or self.lv_
    local prop = HeroConfig.PropertyData[key]
    if not prop then
        elog("-------------------------------> Error: not found data from HeroConfig.PropertyData.  key = %s", key)
    end
    return prop.exp * self:get_star_exp_para()
end

--计算升到目标等级需要的总经验
--假设星级不变
function GetTotalExpToLevel(self, level)
    if level <= self.lv_ then return 0 end
    local exp = self:get_exp() - self.cur_exp_
    for lv = self.lv_ + 1, level - 1 do
        exp = exp + self:get_exp(lv)
    end
    return exp
end

-- 是否可招募
function enable_awake(self)
    if self.is_active_ then return false end
    local prop = self:get_prop()
    return ItemManager:check(prop.activate)
end

-- 是否可升阶
function enable_stage(self)
    local star = self:get_star_and_stage()
    if star >= self:get_max_star() then
        return false
    end
    local total_cnt = self:get_stage_up_cost()
    local chip_num = self:get_chip_num()
    if chip_num >= total_cnt then
        return true
    end
    return false
end

-- 是否可升星
function enable_star(self)
    local star = self:get_star_and_stage()
    if star >= self:get_max_star() then
        return false
    end
    local total_cnt = self:get_star_up_cost()
    local chip_num = self:get_chip_num()
    if chip_num >= total_cnt then
        return true
    end
    return false
end

-- 武将是否可以兑换
function enable_exchange(self)
    local prop = self:get_prop()
    return prop.trade_item ~= nil
end

-- 是否可以升级
function enable_lvup(self)
    if self.lv_ >= self:get_max_lv() then
        return false
    end
    return true
end

-- 获取碎片数量
function get_chip_num(self)
    local prop = self:get_prop()
    return ItemManager:get_count_by_prop(prop.activate)
end

-- 获取碎片ID
function get_chip_id(self)
    local prop = self:get_prop()
    return prop.activate[2]
end


function get_star_and_stage(self)
    local prop_star = self:get_prop_star()
    if not prop_star then return 0,0 end
    return prop_star.star, prop_star.stage
end

function get_max_lv(self)
    if self.star_ == 0 then return 0 end
    local prop = self:get_prop_star()
    return prop.maxlevel
end

function get_max_star(self)
    return Max_Star
end

function get_max_hero_lv(self)
    return Max_lv
end

function get_star_para(self)
    local prop_star = self:get_prop_star()
    if not prop_star then return end
    return prop_star.para
end

function get_star_exp_para(self)
    local prop_star = self:get_prop_star()
    if not prop_star then return end
    return prop_star.exp_para
end

function get_color_name(self)
    local str = string.format("<color=%s>%s</color>", config.GROW_COLOR[self.quality_], self.name_)
    return str
end

-- 获取属性，统帅、政务、智谋 attrType=nil就全部获取
function get_attr(self, attrType)
    local prop_star_para = self:get_star_para()
    local prop_lv = self:get_prop_lv()
    local prop_lv_value = {prop_lv.leader, prop_lv.affairs, prop_lv.wit}
    if not attrType then 
        local type_value = {}
        for i=1,3 do
            type_value[i] = math.floor(prop_star_para[i] * prop_lv_value[i]+0.5)
        end
        return type_value
    end
    if attrType > config.HERO_TYPE3 then return 0 end
    if attrType < config.HERO_TYPE1 then return 0 end
    local type_value = prop_star_para[attrType] * prop_lv_value[attrType]
    return math.floor(type_value+0.5)
end

-- 获取当前武将升级一阶的消耗总数
function get_stage_up_cost(self)
    local prop = self:get_prop_star()
    if not prop then return end
    return prop.cost[3]
end

-- 获取当前武将升级一星的消耗总数
function get_star_up_cost(self)
    local star, stage = self:get_star_and_stage()
    if stage == 5 then return end
    local count = 0
    for i = stage, 4 do
        local key = self.id_*100 + (star - 1) * 5 + i + 1
        local star =  HeroManager.star_prop_map_[key]
        if star and star.cost then
            count = count + star.cost[3]
        end
    end
    return count
end

-- 属性快照
function set_attrs_snapshot(self)
    self.attrs_snapshot_ = {}
    self.attrs_snapshot_.star_ = self.star_
    local star_lv, starge = self:get_star_and_stage()
    self.attrs_snapshot_.star_lv_ = star_lv
    self.attrs_snapshot_.star_stage_ = starge
    self.attrs_snapshot_.lv_ = self.lv_
    self.attrs_snapshot_.power_ = self:get_power()
    self.attrs_snapshot_.attrs_value_ = self:get_attr()
    self.attrs_snapshot_.max_lv_ = self:get_max_lv()
    self.attrs_snapshot_.max_skill_lv_ = _G.HeroManager:get_hero_skill_max_lv(self.id_, self.star_)
end

-- 属性快照
function get_attrs_snapshot(self)
    if not self.attrs_snapshot_ then
        self.attrs_snapshot_ = {}
    end
    return self.attrs_snapshot_
end

function get_skill_by_pos(self, pos)
    return self.skills_[pos]
end

function has_skill(self, skillid)
    for _, skill in pairs(self.skills_) do
        if skill.skillid == skillid then
            return true
        end
    end
    return false
end

function learn_skill_on_lient(self, pos, skillid)
    if self.skills_[pos] then
        elog("Hero has skill on pos: "..pos)
        return
    end
    self.skills_[pos] = {
        pos = pos,
        level = 1,
        exp = 0,
        skillid = skillid,
    }
    MsgCenter.send_message(Msg.UI_SKILL_CHANGE, self.id_)
end

function levelup_skill_on_client(self, pos, skillid, level, exp)
    if not self.skills_[pos] then
        elog("Hero has no skill on pos: "..pos)
        return
    end
    self.skills_[pos].level = level
    self.skills_[pos].exp = exp
    MsgCenter.send_message(Msg.UI_SKILL_CHANGE, self.id_)
end

function forget_skill_on_client(self, pos, skillid)
    if not self.skills_[pos] or self.skills_[pos].skillid ~= skillid then
        elog("Error skill")
        return
    end
    self.skills_[pos] = nil
    MsgCenter.send_message(Msg.UI_SKILL_CHANGE, self.id_)
end
