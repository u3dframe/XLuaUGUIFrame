-- 行军, 出征部队
module("WorldMarch", package.seeall)
deriveClass(WorldMarch, WorldObj) 


function init(self, data)
    self.idx_ = data.id
    -- 参考ArmyInfo
    self.army_type_ = data.armytype
    self.owner_ = data.owner
    self.name_ = data.name
    self.runinfo_ = data.runinfo
    self.runinfo_delta_ = 0
    self.delta_time_ = 0
    self.start_ = data.start
    self.finish_ = data.finish
    self.to_obj_ = WorldManager:get_world_obj(self.finish_.x, self.finish_.y)
    self.from_obj_ = WorldManager:get_world_obj(self.start_.x, self.start_.y)
    self.obj_type_ = config.WORLD_MARCH
    self.is_play_ = false
    self.soldiers_ = {}
    for i,v in ipairs(data.soldiers) do
        local data = {}
        data.id = v.array[1]
        data.cnt = v.array[2]
        table.insert(self.soldiers_, data)
    end
    self.heroes_ = {}
    if data.heroes then
        for k,v in pairs(data.heroes) do
            local hero = Hero(v.id)
            hero:update_server_data(v)
            table.insert(self.heroes_, hero)
        end
    end
end

function get_troops_hero(self)
    local hero_list = {}
    for i,v in ipairs(self.heroes_) do
        local path = "Sprites/"..v.head_icon_
        table.insert(hero_list, path)
    end    
    return hero_list
end

function get_march_id_str(self)
    return tostring(self.idx_)
end

function get_from_map_axis(self)
    if self.from_obj_ and self.from_obj_.obj_type_ == config.WORLD_MAIN then
        local x,y = UIUtil.logic_axis_to_map_axis(self.start_.x, self.start_.y)
        return x+2, y-2
    else
        return UIUtil.logic_axis_to_map_axis(self.start_.x, self.start_.y)
    end
end

function get_to_map_axis(self)
    if self.to_obj_ and self.to_obj_.obj_type_ == config.WORLD_MAIN then
        local x,y = UIUtil.logic_axis_to_map_axis(self.finish_.x, self.finish_.y)
        return x+2, y-2
    else
        return UIUtil.logic_axis_to_map_axis(self.finish_.x, self.finish_.y)
    end
end

function get_logic_distance(self)
    local logic_form_x = self.from_obj_.x_
    local logic_from_z = self.from_obj_.z_
    local logic_to_x = self.to_obj_.x_
    local logic_to_z = self.to_obj_.z_
    local delta_x = logic_to_x - logic_form_x
    local delta_z = logic_to_z - logic_from_z
    local distance = math.sqrt(delta_x*delta_x + delta_z*delta_z)
    return distance
end

function get_march_time(self)
    self.cur_time_ = Net.server_time() - self.delta_time_
    -- 由于和服务器误差，当前时间小于服务器开始时间，取服务器开始时间
    if self.cur_time_ < self.runinfo_.ti_start  then
        self.cur_time_ = self.runinfo_.ti_start
    end
    local time = self.runinfo_.ti_end - self.cur_time_
    local delta_up = self.cur_time_ - self.runinfo_.ti_start
    local delta_down = self.runinfo_.ti_end - self.runinfo_.ti_start
    -- print("need time = "..time)
    -- print("delta_up = "..delta_up)
    -- print("delta_down = "..delta_down)
    local ratio = delta_up / delta_down

    local speed = self.runinfo_.ti_dec/(delta_down+self.runinfo_.ti_dec)*2 + 1
    return time, ratio, speed
end

-- 记录本次时间消耗比例来计算客户端动画比例（暂时不用了）
function snapshot_ratio(self)
    -- 总共动画已经消耗时间
    local real_time = Net.server_time() - self.runinfo_.ti_start
    -- 本次动画消耗时间，缓存一下
    local delta_up = Net.server_time() - (self.cur_time_ or 0)
    -- 服务器剩下时间
    local delta_all = self.runinfo_.ti_end - self.runinfo_.ti_start
    -- 本次动画 服务器剩下的时间 - 已经消耗时间 + 本次消耗时间
    -- 比如
    -- 1、总共73s，没加速情况走了13s，接下来开始使用+50%道具 剩下60s就变成30s（扣了30s）
    -- 2、在此+50%状态情况下走了10s, delta_up = 10 | real_time= 13+10 | delta_all = 73-30
    -- 3、delta_down就是本次走得比例分母， delta_down = 30
    local delta_down = delta_all - real_time + delta_up
    -- 获得了比例，但是他是相当于 60s，需要换算到73s的比例
    local ratio = delta_up / delta_down
    -- 这里要分2中情况，第一次和非第一次，下一次的实际总时间
    if self.next_down_ then
        -- 从上一次剩余时间转换成 73s的比例
        ratio = ratio*self.next_down_/(self.runinfo_.ti_end - self.runinfo_.ti_start + self.runinfo_.ti_dec)
        self.next_down_ = self.next_down_ - real_time
    else
        -- 第一次没有比例变换，就是总时间73s, 减去实际用的时间等于剩余时间
        self.next_down_ = self.runinfo_.ti_end - self.runinfo_.ti_start - real_time
    end
    self.runinfo_delta_ = self.runinfo_delta_ + ratio    
end

function push_delta_time(self, data)
    self.runinfo_delta_ = data[1]
    self.delta_time_ = data[2]
    self.next_down_ = data[3]
end


function delete_self(self)
    self.is_play_ = false
    WorldManager.battle_queue_[self.idx_] = nil
    WorldManager.world_march_queue_[self.idx_] = nil
    _G.event.fire(_G.EventKey.WORLD_MARCH_DELETE, self.idx_)
    MsgCenter.send_message(Msg.WORLD_MARCH_DELETE, self.idx_)
    return true
end

function get_other_obj(self)
    if not self.to_obj_ then return end
    if self.to_obj_.obj_type_ ~= config.WORLD_MAIN then
        return self.to_obj_
    end
    return self.from_obj_
end

function get_soldiers_list(self)
    local list_tmp = {}
    for i,v in ipairs(self.soldiers_) do
        local prop = SoldierManager:get_soldier_prop_by_id(v.id)
        if not list_tmp[prop.marchAnimation] then
            list_tmp[prop.marchAnimation] = 0
        end
        list_tmp[prop.marchAnimation] = list_tmp[prop.marchAnimation] + v.cnt
    end
    return list_tmp
end
