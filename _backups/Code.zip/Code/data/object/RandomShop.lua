local RandomShop = {}

local MerchantConfig = _G.Database.MerchantConfig
local lang = _G.lang
local dump = _G.dump

local itemLabel = {
    lang("UI_BASIC_RES"),       --资源
    lang("UI_BASIC_SPEEDUP"),   --加速
    lang("UI_BASIC_GAIN"),      --增益
    lang("UI_BASIC_OTHER")      --其他
}

function RandomShop:New(data)
    local obj = setmetatable({}, {__index = self})
    obj:RefreshData(data)
    return obj
end

------------------------interface

function RandomShop:RefreshData(data)
    self.currTimes =  data.exhibit_times     --当前上货次数
    self.currIntimacy = data.favorability   --当前亲密度
    self.currConsume = data.expense       --当前消耗
    self.currRefresh = data.refresh_times   --当前刷新次数
    self.startTime = data.open_time or 0         --开始时间戳
    self.propList = self:InitProp(data.item_pool)   --道具列表
end

--是否是主动上货
function RandomShop:IsInitiativeGoods()
    if self.currRefresh and
        self.currRefresh == 0 and
        self.startTime > 0 and
        self:IsOpen() then
        return true
    end
    return false
end

--设置亲密度
function RandomShop:SetIntimacy(intimacy)
    self.currIntimacy = intimacy
end

--设置今日消耗
function RandomShop:SetCost(expense)
    if not expense then
        expense = 0
    end
    self.currConsume = expense
end

function RandomShop:GetBasic()
    return MerchantConfig.MerbasicData
end

--是否关门
function RandomShop:IsClose()
    if self.currTimes and not self.currIntimacy then
        return true
    end
    return false
end


--商店是否开放
function RandomShop:IsOpen()
    local endTime = self.startTime + self:GetDuration()
    if endTime and endTime > _G.Net.server_time()
        and self.currTimes <= self:GetBasic().times then
        return true
    end
    return false
end

function RandomShop:IsFreeRefresh()
    return self.currRefresh == 0
end

--当前上货
function RandomShop:IsSupplementGoods()
    if self.currTimes == 1 then
        return true
    end
    return false
end

--是否可以刷新
function RandomShop:EnableRefresh()
    if self:IsOpen() and self.currRefresh < self:GetBasic().refresh_limit then
        return true
    end
    return false
end

--是否可以领取奖励
function RandomShop:EnableReward()
    if self.currIntimacy == self:GetBasic().intimacy_limit then
        return true
    end
    return false
end

--获取时间戳
function RandomShop:GetTimeStamp()
    local timeObj = {
        startTime = self.startTime,
        endTime = self.startTime + self:GetDuration()
    }
    timeObj.totalTime = timeObj.endTime - timeObj.startTime
    return timeObj
end

function RandomShop:GetDuration()
    local basic = self:GetBasic()
    if not basic then
        dump(basic, "basic is nil, please check it!", 1, "#CF2D2D")
        return
    end
    return basic.last_time
end

--获取刷新道具的价格
function RandomShop:GetRefreshPrice()
    local key = self.currRefresh + 1
    if key > self:GetBasic().refresh_limit then
        key = self:GetBasic().refresh_limit
    end
    local refreshPrice = MerchantConfig.RefreshData[key]
    if not refreshPrice then
        local str = string.format("refreshPrice is nil. key = %d", key)
        dump(refreshPrice, str, 1, "#CF2D2D")
        return
    end
    if key == 1 then
        return lang("UI_BASIC_FREE").."1/1", lang("UI_BASIC_REFRESH")
    end
    return refreshPrice.price[3]..lang("UI_BASIC_GOLD"), lang("UI_BASIC_REFRESH")
end

function RandomShop:InitProp(data)
    if not data then
        return
    end
    local items = {}
    for i, v in ipairs(data) do
        items[i] = {}
        for j, value in ipairs(v.info) do
           local itemData = {
                prop = MerchantConfig.MerchantData[value.id],
                pos = value.pos,
                enable = value.bought == nil --是否购买过(nil 是没买过)
           }
           items[i][j] = itemData
        end
    end
    return items
end

--获取道具列表
function RandomShop:GetPropList()
    return self.propList
end

--设置道具为已经购买
function RandomShop:SetItemEnable(itemPos)
    if not self.propList or not itemPos then
        return
    end
    local itemType = itemPos[1]
    local pos = itemPos[2]
    if self.propList[itemType] and self.propList[itemType][pos] then
        self.propList[itemType][pos].enable = false
    end
end

--获取道具标签
function RandomShop:GetItemdLabel()
    return itemLabel
end



--获取奖励预览道具
function RandomShop:GetPreviewReward()
    local basic = self:GetBasic()
    if not basic then
        dump(basic, "basic is nil, please check it!", 1, "#CF2D2D")
        return
    end
    return basic.show_reward
end

return RandomShop