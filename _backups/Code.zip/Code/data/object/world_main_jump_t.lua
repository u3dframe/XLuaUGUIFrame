module("WorldMainJump", package.seeall)
deriveClass(WorldMainJump, WorldMain) 


function init(self, x, z, mx, mz)
    WorldObj.init(self, x, z)
    self.obj_type_ = config.WORLD_MAIN_JUMP
    self.main_x_ = mx
    self.main_z_ = mz
end

function get_main(self)
    return self.main_x_, self.main_z_
end