--祭祀
local CityFete  = {}

local SacrificeConfig = _G.Database.SacrificeConfig
local config = _G.config
local elog = _G.elog
local lang = _G.lang

local feteObj  --祭祀的建筑对象
function CityFete:New(data)
    local obj = setmetatable({}, {__index = self})
    feteObj = _G.BuildManager:get_build_info_by_build_type(config.BUILD_TYPE.FETE)
    if not feteObj then
        elog("Fete build is nil!")
    end
    obj:RefreshData(data)
    return obj
end

function CityFete:RefreshData(data)
    self.data = data
    self.cntList = data.point_count or {}
    self.extraCnt = data.other_count or 0
    self:InitItemTimes()

    self:InitAlreadyUsedTime()
end

function CityFete:SetFeteCnt(itemPos, count)
    if not count then
        count = 1
    end
    local upInfo = self:GetSacUpdate()
    local currFreeTimes = self:GetFreeTimes()

    --无免费次数
    if currFreeTimes <= 0 then
        self:AddGoldTimes(itemPos, count)
        return
    end

    --有免费次数
    --免费次数 + count <= 配置
    if self.allFreeTimes + count <= upInfo.free_times then
        self:AddFreeTimes(itemPos, count)
        return
    end

    local num = upInfo.free_times - self.allFreeTimes
    self:AddFreeTimes(itemPos, num)

    if self.extraCnt <= 0 then
        return
    end

    --额外的次数 > 剩余的次数（count - num）
    if self.extraCnt > count - num then
        self:AddItemTimes(itemPos, count - num)
        self.extraCnt = self.extraCnt - (count - num)
        return
    end

    local goldCnt = count - num - self.extraCnt
    self:AddItemTimes(itemPos, self.extraCnt)
    self.extraCnt = 0
    self:AddGoldTimes(itemPos, goldCnt)
end

function CityFete:InitItemTimes()
    for i = 1, 4 do
        local itemTimes = self.cntList[i] or {}
        itemTimes.free_cnt = itemTimes.free_cnt or 0
        itemTimes.item_cnt = itemTimes.item_cnt or 0
        itemTimes.normal_cnt = itemTimes.normal_cnt or 0
        self.cntList[i] = itemTimes
    end
end

function CityFete:AddFreeTimes(itemPos, count)
    self.cntList[itemPos].free_cnt =  self.cntList[itemPos].free_cnt + count
    self.allFreeTimes = self.allFreeTimes + count
    self.allTimes = self.allTimes + count
end

function CityFete:AddItemTimes(itemPos, count)
    self.cntList[itemPos].item_cnt =  self.cntList[itemPos].item_cnt + count
    self.allItemTimes = self.allItemTimes + count
    self.allTimes = self.allTimes + count
end

function CityFete:AddGoldTimes(itemPos, count)
    self.cntList[itemPos].normal_cnt = self.cntList[itemPos].normal_cnt + count
    self.allGoldTimes = self.allGoldTimes + count
    self.allTimes = self.allTimes + count
end

--是否是第一次用金币祭祀
function CityFete:IsFirstTimeGoldFete()
    if (self.allGoldTimes and self.allGoldTimes > 0) or
        self:GetFreeTimes() > 0 then
        return false
    end
    return true
end

function CityFete:GetFreeTimes()
    local upInfo = self:GetSacUpdate()
    local num = upInfo.free_times - self.allFreeTimes
    if num + self.extraCnt < 0 then
        elog("Error: residueFreeTimes cant less then 0!")
        return 0
    end
    return num + self.extraCnt
end

function CityFete:GetResidueTimes()
    local residue = self:GetSacBasic().times - self.allTimes
    if residue < 0 then
        residue = 0
    end
    return residue
end

function CityFete:EnableItem(itemPos)
    local open = self:GetSacBasic().open_level
    if not open or not open[itemPos] then
        print("Not found open_level. itemPos is ", itemPos)
        return false
    end
    local conditions = open[itemPos]
    local build = _G.BuildManager:get_build_info_by_build_type(conditions[1])
    if not build then
        elog("Not found build. buildType is %s", conditions[1])
        return false
    end
    return build.lv_ >= conditions[2], build, conditions[2]
end

-- 根据位置获取道具 （obj.prop 道具三维，obj.unlock 是否解锁，obj.price 道具价格）
function CityFete:GetItem(itemPos)
    local obj = {}
    local update = self:GetSacUpdate()
    local item = update["point"..itemPos]
    local isUnlock, build, targetLv = self:EnableItem(itemPos)
    obj.unlock = isUnlock
    --计算资源数
    local itemData = self.cntList[itemPos]
    local cnt = (itemData.normal_cnt or 0) + (itemData.free_cnt or 0) + (itemData.item_cnt) + 1
    if cnt > self:GetSacBasic().times then
        cnt = self:GetSacBasic().times
    end
    local resConsume = self:GetSacConsume(cnt)
    obj.prop = {item[1], item[2], item[3]}
    obj.prop[3] = math.floor(obj.prop[3] * (resConsume.para / 10000))
    --计算价格
    if not isUnlock then
        obj.price = lang("UI_CITYFETE_ITEM_UNLOCK", build.name_, targetLv)
        return obj
    end

    if self:GetFreeTimes() > 0 then
        obj.price = lang("UI_BASIC_FREE")
        return obj
    end

    local goldCnt = itemData and itemData.normal_cnt or 0
    goldCnt = goldCnt + 1
    if goldCnt > self.GetSacBasic().times then
        goldCnt = self.GetSacBasic().times
    end
    local consume = self:GetSacConsume(goldCnt)
    obj.price = consume.price

    return obj
end

function CityFete:GetItemHint(itemPos)
    local isUnlock, build, targetLv = self:EnableItem(itemPos)
    if not isUnlock then
        return lang("UI_CITYFETE_ITEM_UNLOCK", build.name_, targetLv)
    end
end

function CityFete:GetItemPrice(itemPos)
    if not itemPos then
        elog("itemPos is nil")
        return
    end
    local itemData = self.cntList[itemPos]
    local goldCnt = itemData and itemData.normal_cnt or 0
    local consume = self:GetSacConsume(goldCnt + 1)
    return consume.price
end

function CityFete:InitAlreadyUsedTime()
    if not self.cntList then
        return 0
    end
    self.allTimes = 0
    self.allFreeTimes = 0
    self.allItemTimes = 0
    self.allGoldTimes = 0
    for _, v in ipairs(self.cntList) do
        local freeCnt = v.free_cnt or 0
        local itemCnt = v.item_cnt or 0
        local normalCnt = v.normal_cnt or 0
        self.allFreeTimes = self.allFreeTimes + freeCnt
        self.allItemTimes = self.allItemTimes + itemCnt
        self.allGoldTimes = self.allGoldTimes + normalCnt
        self.allTimes = self.allTimes + freeCnt + itemCnt + normalCnt
    end
end

function CityFete:GetSacBasic()
    return SacrificeConfig.Sac_basicData
end

function CityFete:GetSacUpdate()
    local update = SacrificeConfig.Sac_updateData
    return update[feteObj.lv_]
end

function CityFete:GetSacConsume(times)
    local consume = SacrificeConfig.Sac_consumeData
    return consume[times]
end

return CityFete