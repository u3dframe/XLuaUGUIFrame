local Account = {}
local gfs          = require("tools/GameFileSystem"):New("/PlayerSetting")
local key          = "8291e8f29568af61b4a93fa5a2fdd03c"

function Account:Init()
    local account = Account.Read({})
    dump(account, "account")

    self:SaveName(account.userName)
    self:SaveServerId(account.serverId)
    self:SaveRID(account.rid)
end

function Account:SaveName(userName)
    self.userName = userName
end

function Account:GetName()
    return self.userName
end

function Account:SaveRID(rid)
    self.rid = rid
end

function Account:GetRID()
    return self.rid
end

function Account:SaveServerId(serverId)
    self.serverId = serverId
end

function Account:GetAccountInfo()
    return {
        serverId = self.serverId or 1,
        userName = self.userName or "",
        rid = self.rid or 12345
    }
end

function Account:SaveAccount()
    Account.Save(self:GetAccountInfo())
end

function Account.Read(default)
    return gfs:ReadEncryptTable("acd.a", key) or default
end

function Account.Save(account)
    gfs:WriteEncryptTable("acd.a", account, key)
end

--FIXME:
function Account:SyncServerList(serverList)
    _G.event.fire(_G.EventKey.EVENT_SERVER_LIST_CHANGE)
end

return Account
