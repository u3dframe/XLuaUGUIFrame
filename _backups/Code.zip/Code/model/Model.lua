local Model = {}
local wrapperNames = {
    Login     = require("model/Login"),
    Master    = require("model/Master"),
    -- Master     = require("model/Master"),

}

local models = {} --GameData

function Model.InitLoginData()
    for k, v  in pairs(wrapperNames) do
        if not models[k] then
            models[k] = v
        end
        if v.InitData then
            v:InitData()
        end
        if v.RegisterNetHandle then
            v:RegisterNetHandle()
        end
    end
end

function Model.GetModel(modelName)
    if not models[modelName] then
        models[modelName] = wrapperNames[modelName]
    end

    return models[modelName]
end

_G.Model = Model
return Model
