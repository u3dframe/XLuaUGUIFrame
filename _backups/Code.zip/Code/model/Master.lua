local Master = {}
local BasicConfig = _G.Database.BasicConfig
local EnergyConfig = _G.Database.EnergyConfig
local MsgCenter = _G.MsgCenter
local Msg = _G.Msg
local resmng  = _G.resmng
local Net  = _G.Net
local lang = _G.lang
local event = _G.event
local EventKey = _G.EventKey

function Master:InitData()
    self.user_ = {}
    self.user_.energy_ = 0
    self.user_.energy_buytime_ = 0
end

function Master:RegisterNetHandle()
    dump(self.InitBasicInfo)
    -- Net.register(self, "role_object", self.InitBasicInfo)
    -- Net.register(self, "energy_info", self.OnEnergyInfo)
    -- Net.register(self, "energy_change", self.OnEnergyChange)
    -- Net.register(self, "energy_change_one", self.OnEnergyChangeOne)
end

--------------------NetHandler start------------------------
function Master:InitBasicInfo(data)
    dump(data, "aidotank.roledata")
    self.user_.name_ = data.rname or self.user_.name_
    self.user_.rid_ = data.rid or self.user_.rid_           -- 角色ID
    MsgCenter.send_message(Msg.REFRESH_MASTER_USER, data)
end

function Master:OnEnergyInfo(data)
    self.user_.energy_ = data.cnt or self.user_.energy_
    self.user_.energy_buytime_ = data.buycnt or self.user_.energy_buytime_
    MsgCenter.send_message(Msg.ENERGY_REFRESH)
    if EventKey then
        event.fire(EventKey.ENERGY_REFRESH)
    end
end

--可以能有多次操作,以最后一次为准
function Master:OnEnergyChange(data)
    local tmp_energy
    for _,v in ipairs(data.list) do
        MsgCenter.send_message(Msg.ENERGY_CHANGE, v.change)
        tmp_energy = v.last
    end
    self.user_.energy_ = tmp_energy
    MsgCenter.send_message(Msg.ENERGY_REFRESH)
    if EventKey then
        event.fire(EventKey.ENERGY_REFRESH)
    end
end

function Master:OnEnergyChangeOne(data)
    self.user_.energy_ = data.last
    MsgCenter.send_message(Msg.ENERGY_CHANGE, data.change)
    MsgCenter.send_message(Msg.ENERGY_REFRESH)
    if EventKey then
        event.fire(EventKey.ENERGY_REFRESH)
    end
end

--------------------NetHandler END------------------------
function Master:IsMaster(owner)
    if not owner then
        return false
    end
    if owner == self.user_.rid_ then
        return true
    end
    return false
end

function Master:GetEnergy()
    return self.user_.energy_
end

function Master:GetEnergyPercent()
    local percent = self.user_.energy_ / BasicConfig.BasicData.emergy_full[1]
    return percent > 1 and 1 or percent
end

function Master:BuyEnergy()
    if self.user_.energy_ > BasicConfig.BasicData.emergy_full[2] then
        MsgCenter.send_message(Msg.SHOW_HINT, lang("EXPEDITION_37"))
        return false
    end

    --先使用道具在使用金币噶
    local item_data
    for _,v in ipairs(BasicConfig.BasicData.energy) do
        if ItemManager:check_item_count(v[1]) then
            item_data = v
        end
    end
    -- 使用道具

    -- 使用金币
    local time = self.user_.energy_buytime_+1
    local prop = EnergyConfig.EnergyData[time]
    if not prop then
        MsgCenter.send_message(Msg.SHOW_HINT, lang("EXPEDITION_38"))
        return false
    end
    if not ItemManager:check(prop.gold) then
        MsgCenter.send_message(Msg.SHOW_HINT, lang("RESOURCE_BUILDING_6"))
        return false
    end

    local str = lang("EXPEDITION_39", prop.gold[3], prop.energy[3])
    local msg_ = {
        mode=0,
        title = lang("UI_BASIC_HINT"),
        content = str,
        buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")},
        callback = function()
           -- if index == 2 then
                Master:BuyEnergy(time)
          --  end
        end
    }
   -- MsgCenter.send_message(Msg.SHOW_NOTIFY,msg_)
    _G.UIController:ShowUI('UICommonPop', msg_)
    return true
end

function Master:RequestBuyEnergy(time)
    Net.send("energy_buy",{buycnt = time}, function()
        self.user_.energy_buytime_ = self.user_.energy_buytime_ + 1
        MsgCenter.send_message(Msg.SHOW_HINT, lang("EXPEDITION_40"))
    end)
end

return Master
