local Login = {}

function Login:InitData()
end

function Login:RegisterNetHandle()
    Net.register(self, "role_list",  self.OnRoleList )
end

function Login:LoginGame(rid)
    local params = {
        rid = rid
    }
    Net.send("role_login", params, function(result)
        _G.event.fire(_G.EventKey.LOGIN_SUCCESS)
        -- 关闭loading界面
        --[[
        GameManager:on_enter_main(data, function()
            -- _G.event.fire(_G.EventKey.LOGIN_SUCCESS)
            local win = UIManager.get_window("LoadSceneWindow")
            if win then
                win:fade_out()
            end
        end)
        --]]
    end,
    function(result)
        MsgCenter.send_message(Msg.SHOW_HINT, "登陆失败！")
    end)
end

function Login:OnRoleList(data)
    local _,role = next(data.roles)
    dump(data, "OnRoleList.data")
    if role then
        self:LoginGame(role.rid)
        return
    end

    local create_data = {}
    create_data.rname = _G.Account:GetName()
    Net.send("role_create", create_data, function(result)
        if result.e == 0 then
            self:LoginGame(result.rid)
        else
            local win = UIManager.get_window("LoadSceneWindow")
            if win then
                win:fade_out()
            end
            Net.disconnect_server()
        end
    end)
end


return Login
