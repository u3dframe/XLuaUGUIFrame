import "UnityEngine"
import "UnityEngine.UI"

_G.Application          =  _G.UnityEngine.Application
_G.Mathf                =  _G.UnityEngine.Mathf
_G.Vector2              =  _G.UnityEngine.Vector2
_G.Vector3              =  _G.UnityEngine.Vector3
_G.GameObject           =  _G.UnityEngine.GameObject
_G.Input                =  _G.UnityEngine.Input
_G.Object               =  _G.UnityEngine.Object
_G.Camera               =  _G.UnityEngine.Camera
_G.Quaternion           =  _G.UnityEngine.Quaternion



-- 网络通讯
require("net/net")

--Tools
require("LuaExtend/tablex")
require("tools/fun")()
require("tools/CoController")

require "tools/list"
require "tools/event"
-- require "tools/FairyGUI"



--工具
require("utility/coroutine")
require("utility/msg/messager")
require("utility/msg/msg")
require("utility/msg/msg_center")
require("utility/lua_utils")
require("utility/class")
require("utility/mydebug")
require("model/Model")

--管理器
-- require "Controller/UIController"
-- require "Controller/SceneManager"



--[[
_G.Net     = _G.Net
_G.GameLog = _G.GameLog
_G.Yield   = _G.Yield
_G.XEase   = _G.XEase

--]]

