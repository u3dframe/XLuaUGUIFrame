local tiny                     = require("Tools/tiny")
local Time = _G.UnityEngine.Time
local BuildingSystem  = tiny.processingSystem(_G.fclass "BuildingSystem")
BuildingSystem.filter = tiny.requireAll("location")

function BuildingSystem:ctor(index)
    self.index = index
    self.building = nil
    self.locationMap = {}
end

function BuildingSystem:onModify()
end

function BuildingSystem:preProcess()
    if not self.building then
        return
    end
end

function BuildingSystem:dispose()
    
end

return BuildingSystem
