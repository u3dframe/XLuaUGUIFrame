local tiny         = require("Tools/tiny")
local MainInputSystem  = tiny.processingSystem(_G.fclass "MainInputSystem")
MainInputSystem.filter = tiny.requireAll("location", "gameObject")

local BuildManager = _G.BuildManager

local Layer_Mask_City      =  512   --1<<9
local Layer_Mask_CityTitle = 1024   --1<<10
local CITY_CAMERA_LOCATE_SIZE = 5 -- 定位之后的size
local CITY_CAMERA_INIT_SIZE = 3.5
local CITY_CAMERA_MIN_SIZE = 2.8
local CITY_CAMERA_MAX_SIZE = 6.5
local CITY_CAMERA_MAX_BACK_SIZE = CITY_CAMERA_MAX_SIZE - (CITY_CAMERA_MAX_SIZE - CITY_CAMERA_MIN_SIZE) * 0.05
local CITY_CAMERA_MIN_BACK_SIZE = CITY_CAMERA_MIN_SIZE + (CITY_CAMERA_MAX_SIZE - CITY_CAMERA_MIN_SIZE) * 0.05
local CITY_CAMERA_BUILD_JUMP_SIZE = 4
local CITY_CAMERA_OUTSIZE_BUILD_JUMP_SIZE = 2 --资源田建筑跳转大小

local CITY_LEFT_LIMIT = -19
local CITY_RIGHT_LIMIT = 19
local CITY_TOP_LIMIT = 14
local CITY_BOTTOM_LIMIT = -12.2

local RANDOM_SHOP_SPACE_ID  = 47 --随机商店空地ID
local WHARF_SPACE_ID        = 51 --市舶司空地ID
local SACRIFICE_SPACE_ID    = 45 --祭坛

function MainInputSystem:ctor(index)
    self.index = index

    self.canvas_ = GameObject.Find("CityCanvas").transform
    self.camera_ = Camera.main
	self.canvas_scaler_ = self.canvas_:GetComponent(CanvasScaler)
	self.mapTrans = GameObject.Find("Map").transform
    self.builds_parent_ = self.mapTrans:Find("Buildings")

    self.click_callbacks_ = {}

    self.camera_.orthographicSize = CITY_CAMERA_INIT_SIZE

    self.screen_half_height_ = Screen.height / 2
    self.inertial_acceleration_ = 6000
    self.min_inertial_speed_ = 5
    self.max_inertial_speed_ = 30
    self.pinch_factor_ = 0.01
    self.drag_velocity_ = Vector2.zero

    self.easy_touch_event_ = self.mapTrans.gameObject:GetComponent(EasyTouchEvent)

    local cameraController = _G.SceneController.currentScene:GetCameraController()
    cameraController.OnFocusComplete = function()
        GameLog.Log("OnFocusComplete")
    end
    cameraController.OnMoveLuaDelegate = function()
        self:set_move_board()
    end
    self.easy_touch_event_.OnETTouchStart = function(ge)
        self:on_et_touch_start(ge)
    end
    self.easy_touch_event_.OnETSimpleClick = function(ge)
        self:on_et_click(ge)
    end
    
    self.easy_touch_event_.OnETTouchUp = function(ge)
        self:on_et_touch_up(ge)
    end

    self.messager_ = Messager:new(self)
    self.messager_:add_listener(Msg.CITY_UP_LV_UPDATE, MainInputSystem.on_up_lv_update)
    self.messager_:add_listener(Msg.CITY_UP_LV_FINISHED, MainInputSystem.on_up_lv_finished)
    self.messager_:add_listener(Msg.CITY_GOLD_UP_LV, MainInputSystem.on_gold_lvup_update)
    self.messager_:add_listener(Msg.CITY_SOIDIER_UPDATE, MainInputSystem.on_soldier_drill_update)
    self.messager_:add_listener(Msg.CITY_SOIDIER_FINISHED, MainInputSystem.on_soldier_drill_finished)
    self.messager_:add_listener(Msg.CITY_COLLECT_REFRESH, MainInputSystem.on_collect_refresh)
    self.messager_:add_listener(Msg.CITY_COLLECT_FINISHED, MainInputSystem.on_collect_finished)
    self.messager_:add_listener(Msg.CITY_SOLDIER_CURE_UPDATE, MainInputSystem.on_soldier_cure_update)
    self.messager_:add_listener(Msg.CITY_SOLDIER_CURE_FINISHED, MainInputSystem.on_soldier_cure_finish)
    self.messager_:add_listener(Msg.CITY_BUILD_REMOVED_FINISHED, MainInputSystem.on_build_removed_finish)
    self.messager_:add_listener(Msg.CITY_BUILD_REMOVED_CANCEL, MainInputSystem.on_build_removed_cancel)
    self.messager_:add_listener(Msg.CITY_SHOW_CAN_EXCHANGE_BUILD, MainInputSystem.on_show_movable_build)
    self.messager_:add_listener(Msg.CITY_BUILD_MOVE_FINISHED, MainInputSystem.on_build_change_finished)
    self.messager_:add_listener(Msg.RESOURCE_OR_COIN_CHANGE, MainInputSystem.on_resource_change)
    self.messager_:add_listener(Msg.CITY_RANDOM_SHOP_UPDATE, MainInputSystem.OnUpdateRandomShop)
    self.messager_:add_listener(Msg.CITY_FETE_UPDATE, MainInputSystem.OnCityFeteUpdate)
    self.messager_:add_listener(Msg.CITY_WHARF_UPDATE, MainInputSystem.OnWharfUpdate)
    self.messager_:add_listener(Msg.CITY_STOP_TIMER2, MainInputSystem.OnStopTimer2)

    self:AddEventListener(_G.EventKey.CITY_SOIDIER_UPDATE, function(args)
        self:on_soldier_drill_update(args)
    end)
    self:AddEventListener(_G.EventKey.CITY_SOIDIER_FINISHED, function(args)
        self:on_soldier_drill_finished(args)
    end)
    self:AddEventListener(_G.EventKey.CITY_FETE_UPDATE, function(args)
        self:OnCityFeteUpdate(args)
    end)
    self:AddEventListener(_G.EventKey.CITY_STOP_TIMER2, function(args)
        self:OnStopTimer2(args)
    end)
    self:AddEventListener(_G.EventKey.CITY_RANDOM_SHOP_UPDATE, function(args)
        self:OnUpdateRandomShop(args)
    end)
    self:AddEventListener(_G.EventKey.CITY_WHARF_UPDATE, function(args)
        self:OnWharfUpdate(args)
    end)
    self:AddEventListener(_G.EventKey.CITY_UP_LV_FINISHED, function(args)
        self:on_up_lv_finished(args)
    end)


    --加载显示name 和 lv的组件
    self:init_builds()
    --加载菜单
    self:init_build_menu()

    self:InitClickListener()
end

--增加事件监听
function MainInputSystem:AddEventListener(keys , callBack)
    if not self.regCallBacks then
        self.regCallBacks = {}
    end

    if type(keys) ~= "table" then
        keys = { keys }
    end

    for _, key in ipairs(keys) do
        if not self.regCallBacks[key] then
            self.regCallBacks[key] = callBack
            _G.event.add_listener(key, self , function(args)
                self.regCallBacks[key](args)
            end)
        end
    end
end

--移除事件监听
function MainInputSystem:RemoveEventListener()
    if not self.regCallBacks then
        return
    end

    for key, _ in pairs(self.regCallBacks) do
        _G.event.remove_listener(key ,self)
    end
    self.regCallBacks = nil
end

function MainInputSystem:on_up_lv_update(build_id)
    print("on_up_lv_update")
    local space = self:get_space_by_build_id(build_id)
    if space then
        BuildManager:append_queue(build_id)
        if _G.EventKey then
            _G.event.fire(_G.EventKey.CITY_REFRESH_QUEUE)
        end
        space:on_building()
    end
end

--金币建造升级不参与队列
function MainInputSystem:on_gold_lvup_update(build_id)
    local space = self:get_space_by_build_id(build_id)
    if space then
        space:on_building() 
    end
end

function MainInputSystem:on_up_lv_finished(build_id)
    local space = self:get_space_by_build_id(build_id)
    if space then
        space:on_up_lv_finished(build_id)
    end

    --刷新建筑mark
    local builds = BuildManager:GetNormalBuild()
    if not builds then return end
    for k, v in pairs(builds) do
        local id = v.id_
        local space = self:get_space_by_build_id(v.id_)
        if space then
            space:get_bill_board():set_build_mark()
        end
    end

end

function MainInputSystem:on_soldier_drill_update(arg1, soldier_id, soldier_class)
    local build_id = arg1
    if _G.EventKey then
        soldier_id = arg1.soldierID
        build_id = arg1.buildID
        soldier_class = arg1.soldierClass
    end
    local space = self:get_space_by_build_id(build_id)
    if space then space:play_timer(soldier_id, soldier_class) end
end

function MainInputSystem:on_soldier_drill_finished(arg1, soldier_id, soldier_class)
    local build_id = arg1
    if _G.EventKey then
        soldier_id = arg1.soldierID
        build_id = arg1.buildID
        soldier_class = arg1.soldierClass
    end
    local space = self:get_space_by_build_id(build_id)
    if space then space:on_soldier_drill_finished(build_id, soldier_id, soldier_class) end
end

function MainInputSystem:on_soldier_cure_update(build_type)
    local builds = BuildManager:get_all_builds_by_type(build_type)
    if builds then
        for k, v in pairs(builds) do
            local space = self.space_item_tb_[v.space_id_]
            if space then
                space:hurts_timer()
            end
        end
    end
end

function MainInputSystem:on_soldier_cure_finish(data)
    local builds = BuildManager:get_all_builds_by_type(config.BUILD_TYPE.HOSPITAL)
    if builds then
        for k, v in pairs(builds) do
            local space = self.space_item_tb_[v.space_id_]
            if space then
                space:on_soldier_cure_finished(data)
            end
        end
    end
end

function MainInputSystem:on_collect_refresh(build_id)
    local space = self:get_space_by_build_id(build_id)
    if space then
        space:on_collect_refresh(build_id)
    end
end

function MainInputSystem:on_collect_finished(build_id)
    local space = self:get_space_by_build_id(build_id)
    if space then
        space:on_collect_finished(build_id)
    end
end

--资源数量改变,刷新BuildMark
function MainInputSystem:on_resource_change()
    for k, v in pairs(self.space_item_tb_) do
        if v then
            local b = v:get_bill_board()
            if b then b:set_build_mark() end
        end
    end
end

function MainInputSystem:on_build_removed_cancel(build_id)
    local space = self:get_space_by_build_id(build_id)
    if space then
        space:on_build_removed_cancel()
    end
end

--移动建筑 显示效果
function MainInputSystem:on_show_movable_build(build_id)
    local build = BuildManager:get_build_info_by_id(build_id)
    if build then
        for k, v in pairs(self.space_item_tb_) do
            if v then 
                v:show_build_effect(build_id)
                v:build_exchange_last_id(build_id)
            end
        end
    end
end

-- --取消建筑移动  隐藏效果
-- function on_hide_mvable_build()
--     for k, v in pairs(self.space_item_tb_) do
--         if v then
--             v:hide_build_effect()
--         end
--     end
-- end

--建筑移动完成
function MainInputSystem:on_build_change_finished(data)
    if not data then return end
    for k, v in pairs(self.space_item_tb_) do
        if v then
            v:on_build_exchanged(data)
        end
    end
end

--建筑拆除完成
function MainInputSystem:on_build_removed_finish(space_id)
    local space = self.space_item_tb_[space_id]
    if not space then return end
    space:on_build_removed_finished()
end

function MainInputSystem:OnUpdateRandomShop(isClose)
    local space = self.space_item_tb_[47]
    if space then
        if isClose == 1 then
            space:get_bill_board():HideBuildTitle()
        elseif isClose == 2 then
            space:get_bill_board():set_build_title(config.BUILD_TITLE_TYPE.RANDOM_SHOP)
        end
    end
end

function MainInputSystem:OnStopTimer2(spaceId)
    local space = self.space_item_tb_[spaceId]
    if space then
        space:stop_timer_2()
    end
end

function MainInputSystem:OnCityFeteUpdate(isShow)
    local space = self.space_item_tb_[SACRIFICE_SPACE_ID]
    if space then
        if isShow then
            space:get_bill_board():set_build_title(config.BUILD_TITLE_TYPE.FETE)
        else
            space:get_bill_board():HideBuildTitle()
        end
    end
end

--刷新市舶司
function MainInputSystem:OnWharfUpdate()
    local space = self.space_item_tb_[WHARF_SPACE_ID]
    if space then
        space:RefreshWharf()
    end
end

--根据id 获取space
function MainInputSystem:get_space_by_build_id(build_id)
    local space
    local build = BuildManager:get_build_info_by_id(build_id)
    if build and build.space_id_ then
        space = self.space_item_tb_[build.space_id_]
    end
    if not space then elog("not found build by id.  id = %s", build_id) end
    return space
end

function MainInputSystem:register_click(gameObject, callback)
    --注册点击回调
    if type(callback) == "function" then
        self.click_callbacks_[gameObject] = callback
    end
end

function MainInputSystem:deregister_click(gameObject, callback)
    --注销点击回调
    self.click_callbacks_[gameObject] = nil
end

--根据id 获取space
function MainInputSystem:get_space_by_build_id(build_id)
    local space
    local build = BuildManager:get_build_info_by_id(build_id)
    if build and build.space_id_ then
        space = self.space_item_tb_[build.space_id_]
    end
    if not space then elog("not found build by id.  id = %s", build_id) end
    return space
end

function MainInputSystem:get_raycast_object(gesture, layer)
    --根据touch坐标做射线检测，返回碰撞的第一个物体
    --_G.dump(gesture.position, "gesture.position: ", 99)
    local ray = self.camera_:ScreenPointToRay(Vector3(gesture.position.x, gesture.position.y, 10000))
    --_G.dump(ray, "ray: ", 99)
    local r = Physics.RaycastAll(ray.origin, ray.direction, 1000, layer).Table
    if #r > 1 then
        for i,v in ipairs(r) do
            local name = v.collider.transform.gameObject.name
            
            local pos = string.find(name, 'BuildMask')
            if pos then
                return v.collider.transform.gameObject
            end
        end
    end
    if #r > 0 then
        --print("raycast name = "..r[1].collider.transform.gameObject.name)
        return r[1].collider.transform.gameObject
    end
end

function MainInputSystem:on_et_touch_start(gesture)
    if self.camera_tween_ then
        self.camera_tween_:Kill(false)
    end
    if gesture.touchCount == 1 and self.move_obj_into_screen_tween_ then
        self.move_obj_into_screen_tween_:Pause()
    end
    if self.build_menu_ then
        self.build_menu_:animation_hide()
    end
end

function MainInputSystem:on_et_touch_up(gesture)
    if gesture.touchCount == 1 and self.move_obj_into_screen_tween_ then
        self.move_obj_into_screen_tween_:Play()
    end
end

function MainInputSystem:on_et_click(gesture)
    local obj = self:get_raycast_object(gesture, Layer_Mask_CityTitle)
    -- 点击city_space的气泡
    if obj and self.click_callbacks_[obj] then
        self.click_callbacks_[obj]()
        return
    end   

    obj = self:get_raycast_object(gesture, Layer_Mask_City)
    if obj and self.click_callbacks_[obj] then
        for _, space in ipairs(self.space_item_tb_) do
            if space.gameObject == obj then
                self.click_callbacks_[obj](space)
                return
            end
        end
        if self.click_callbacks_[obj] then
            self.click_callbacks_[obj]()
        end
    end
end

function MainInputSystem:is_alive()
    return true
end

function MainInputSystem:set_move_board()
    for _, space in ipairs(self.space_item_tb_) do
        if space.bill_board_ then
            space.bill_board_:set_mark_axis()
        end
    end
    if self:is_alive() and self.build_menu_ and self.build_menu_.gameObject.activeSelf then
        self.build_menu_:set_menu_axis()
    end
end

function MainInputSystem:on_hide_all()
    for k, v in pairs(self.space_item_tb_) do
        if v then v:get_bill_board():hide_build_mark() end
    end
end

function MainInputSystem:on_show_all()
    for k, v in pairs(self.space_item_tb_) do
        if v then v:get_bill_board():set_build_mark() end
    end
end

function MainInputSystem:move_obj_to_screen_upper(gameObject, size, duration)
    --将场景中的指定物体对准屏幕上部跳转点
    self:move_world_pos_to_screen_point(gameObject.transform.position, size, duration,
                                        --Vector3(Screen.width / 2, Screen.height * 0.75, 0), true)
                                        Vector3(Screen.width * 0.25, Screen.height / 2, 0), true)
end

function MainInputSystem:move_obj_to_screen_center(gameObject, size, duration)
    --将场景中的指定物体对准屏幕中心跳转点
    self:move_world_pos_to_screen_point(gameObject.transform.position, size, duration, 
                                        Vector3(Screen.width / 2, Screen.height / 2, 0), true)
end

-- 将物体定位到屏幕中心
function MainInputSystem:locate_obj_to_screen_center(gameObject, size, duration)
    if not gameObject then return end
    self.cameraController:FocusOn(gameObject.transform.position)
end

function MainInputSystem:move_world_pos_to_screen_point(world_pos, size, duration, screen_point, restorable)
    if self.move_obj_into_screen_tween_ then
        self.move_obj_into_screen_tween_:Kill(false)
    end
    new_size = size or CITY_CAMERA_BUILD_JUMP_SIZE
    if new_size > CITY_CAMERA_MAX_SIZE then
        new_size = CITY_CAMERA_MAX_SIZE
    end
    if new_size < CITY_CAMERA_MIN_SIZE then
        new_size = CITY_CAMERA_MIN_SIZE
    end
    local old_size = self.camera_.orthographicSize
    self.camera_.orthographicSize = new_size
    local src_screen_pos = self.camera_:WorldToScreenPoint(world_pos)
    self.camera_.orthographicSize = old_size
    local src_screen_offset = screen_point - src_screen_pos
    local camera_offset = -src_screen_offset / self.screen_half_height_ * new_size
    camera_offset.z = 0
    local camera_target = self.camera_.transform.position + camera_offset
    self:modify_camera_state(camera_target, new_size, duration, restorable)
end

function MainInputSystem:modify_camera_state(new_pos, new_size, duration, restorable)
    --设置摄像机状态
    self:on_hide_all()
    if restorable then
        if self.camera_restore_point_ then return false end
        self.camera_restore_point_ = {
            position = self.camera_.transform.position,
            orthographicSize = self.camera_.orthographicSize
        }
    end
    self.cameraController:FocusOn(new_pos)
    return true
end

function MainInputSystem:restore_camera_state(duration)
    --恢复摄像机状态至还原点
    self:on_show_all()
    if not self.camera_restore_point_ then return false end
    duration = duration or 0.2
    local state = self.camera_restore_point_
    GameTween.DOMove(self.camera_.transform, state.position, duration, false):OnUpdate(function()
        self:set_move_board()
    end)
    GameTween.To(function(v)
        self.camera_.orthographicSize = v
    end, self.camera_.orthographicSize, state.orthographicSize, duration)
    self.camera_restore_point_ = nil
    return true
end

function MainInputSystem:move_obj_into_screen(obj)
    local objTrans = obj:GetComponent(Transform)
    local objSpriteRenderer = objTrans:Find("Build/BuildCollider"):GetComponent(SpriteRenderer)
    local world_center = objTrans.position
    local obj_half_width = objSpriteRenderer.size.x
    local obj_half_height = objSpriteRenderer.size.y
    local min_pos = self.camera_:WorldToScreenPoint(world_center - Vector3(obj_half_width, obj_half_height, 100))
    local max_pos = self.camera_:WorldToScreenPoint(world_center + Vector3(obj_half_width, obj_half_height, 100))
    local rect_left_limit = min_pos.x
    local rect_right_limit = max_pos.x
    local rect_top_limit = max_pos.y
    local rect_bottom_limit = min_pos.y

    local screen_center = self.camera_:WorldToScreenPoint(world_center)
    local menu_half_width = Screen.width * 0.27
    local menu_half_height = Screen.height * 0.27
    local menu_left_limit = screen_center.x - menu_half_width
    local menu_right_limit = screen_center.x + menu_half_width
    local menu_bottom_limit = screen_center.y - menu_half_height

    local left_limit = rect_left_limit > menu_left_limit and menu_left_limit or rect_left_limit
    local right_limit = rect_right_limit > menu_right_limit and rect_right_limit or menu_right_limit
    local top_limit = rect_top_limit
    local bottom_limit = rect_bottom_limit > menu_bottom_limit and menu_bottom_limit or rect_bottom_limit

    local screen_offset = Vector3.zero
    if right_limit - left_limit > Screen.width then
        screen_offset.x = screen_center.x - Screen.width / 2
    elseif left_limit < 0 then
        screen_offset.x = left_limit
    elseif right_limit > Screen.width then
        screen_offset.x =  right_limit - Screen.width
    end
    if top_limit - bottom_limit > Screen.height then
        screen_offset.y = screen_center.y - Screen.height / 2
    elseif bottom_limit < 0 then
        screen_offset.y = bottom_limit
    elseif top_limit > Screen.height then
        screen_offset.y = top_limit - Screen.height
    end
    if screen_offset == Vector3.zero then return end
    local world_offset = screen_offset / self.screen_half_height_ * self.camera_.orthographicSize
    self.move_obj_into_screen_tween_ = GameTween.DOMove(self.camera_.transform,
                                                        self.camera_.transform.position + world_offset,
                                                        0.5, false)
    self.move_obj_into_screen_tween_:OnUpdate(
        function() self:set_move_board() end
    )
end

function MainInputSystem:map_move_to_upper(build_class)
    -- local sapce = build_class.space_info_
    -- local isOutsizeBuild
    -- if sapce then
    --     isOutsizeBuild = sapce:isOutSideSpace()
    -- end
    -- local size = isOutsizeBuild and CITY_CAMERA_OUTSIZE_BUILD_JUMP_SIZE or CITY_CAMERA_BUILD_JUMP_SIZE
    self:move_obj_to_screen_upper(build_class.gameObject)
end


function MainInputSystem:back_play_animate()
    self:restore_camera_state()
end



-----------------------------------------------load----------------------------------------------

function MainInputSystem:init_builds()
    self.space_item_tb_ = {}
    for _, space in pairs(BuildManager.build_space_) do
        local obj = self.mapTrans.transform:Find("Buildings/Build"..space.id_)
        local space_item_class = CitySpace:new(space.id_, self)
        space_item_class:AddLuaComponent(obj.gameObject)
        table.insert(self.space_item_tb_, space_item_class)
    end
end

function MainInputSystem:init_cityspace_callback()
    
end

function MainInputSystem:init_build_menu()
    local build_meun_tb = {}
    
    local ui_canvas = UIManager.get_canvas()
    UIManager.BoardLayer = ui_canvas.transform:Find(UIConfig.Layers[UIConfig.LayerType.Board]).gameObject
    self:load_gameobject("Common/BuildMenu", UIManager.BoardLayer, BuildMenu, 1, build_meun_tb)
end

function MainInputSystem:InitClickListener()
    for i,v in ipairs(BuildManager.build_space_) do
        local str = "Build"..i
        self:register_click(self.builds_parent_:Find(str).gameObject, function(space)
            self:on_click_build(space, self.build_menu_)
        end)
    end
    local main_lv = BuildManager:get_main_lv()
    for i,v in ipairs(BuildManager.build_res_unlock_) do
        if v.unlock > 1 then
            local str = "BuildMask"..i
            if CollectManager.collect_unlock_[v.id] then
                self.builds_parent_:Find(str).gameObject:SetActive(false)
            end
            self:register_click(self.builds_parent_:Find(str).gameObject, function()
                self:on_click_build_mask(v)
            end)
        end
    end
end

--1.组件名称 2.父物体 3.组件类名 4.需要实例化的个数 5.存放的表(可空)
function MainInputSystem:load_gameobject(name, parent, class, count, obj_tb)
    UIUtil.load_component(name, function(obj)
        for i = 1, count do
            local go = GameObject.Instantiate(obj)
            go.name = name..i
            go.transform:SetParent(parent.gameObject.transform, false)
            go.transform.localScale = Vector3.one
            go:SetActive(false)
            if class then
                local obj_class = class:new(i)
                obj_class:AddLuaComponent(go)
                obj_class:init()
                if obj_tb then
                   table.insert(obj_tb, obj_class)
                end
            else
                if obj_tb then
                   table.insert(obj_tb, go)
                end
            end
        end
        self.build_menu_ = obj_tb[1]
    end)
end

function MainInputSystem:on_click_build(space)
    --self:move_obj_into_screen(space.gameObject)
    space:click_build(self.build_menu_)
end

function MainInputSystem:on_click_build_mask(prop)
    if not prop then return end
    if not prop.unlock then return end
    local main_lv = BuildManager:get_main_lv()
    if prop.unlock > main_lv then
        _G.dump(prop, "prop:  ", 99)
        MsgCenter.send_message(Msg.SHOW_HINT, lang("RESOURCE_BUILDING_1", prop.unlock))
    else
        local data = {}
        data.items = prop.resource
        data.title = lang("UI_BASIC_HINT")
        data.content = lang("RESOURCE_BUILDING_9")--"解锁当前区域需要消耗道具："
        UIManager.open_window("NotifyItemWindow", nil, data, function()
            Net.send("cityunlock_buy",{id = prop.id}, function(result)
                if result.e == 0 then
                    local main_lv = BuildManager:get_main_lv()
                    for i,v in ipairs(BuildManager.build_res_unlock_) do
                        if v.unlock > 1 then
                            local str = "BuildMask"..i
                            if CollectManager.collect_unlock_[v.id] then
                                self.builds_parent_:Find(str).gameObject:SetActive(false)
                            end
                        end
                    end
                end
            end)
        end)
    end
end

function MainInputSystem:dispose()
    self.messager_:dispose()
end

function MainInputSystem:preProcess()

end

return MainInputSystem
