local tiny         = require("Tools/tiny")
local WorldInputSystem  = tiny.processingSystem(_G.fclass "WorldInputSystem")
WorldInputSystem.filter = tiny.requireAll("location", "gameObject")

local BuildManager = _G.BuildManager

local Max_Base_X = 33
local Max_Base_Z = 33

-- Old
local FIELDOFVIEW_MIN = 7
local FIELDOFVIEW_MAX = 11

local Layer_Mask_World_Base       = 32768     -- 1<<15
local Layer_Mask_World_Terrain    = 65536     -- 1<<16
local Layer_Mask_World_Logic      = 262144    -- 1<<18
local Layer_Mask_World_Build      = 524288    -- 1<<19
local Layer_Mask_World_Ani        = 1048576   -- 1<<20
local Layer_Mask_World            = 4194304   -- 1<<22

-- 设置边缘点
local MAP_TOP_VECTEX = Vector3(0, 30, -100.8)
local MAP_BOTTOM_VECTEX = Vector3(0, 30, -2364.59)
local MAP_LEFT_VECTEX = Vector3(-1132, 30, -1232.8)
local MAP_RIGHT_VECTEX = Vector3(1132, 30, -1232.8)
local MAP_CENTER = Vector3(0, 30, -1232.8)

function WorldInputSystem:on_resource()
    local list = {
        "Model/World/Base/Materials/caodi_01",
        "Model/World/Base/Materials/caodi_02",
        "Model/World/Base/Materials/caodi_03",
        "Model/World/Base/Materials/caodi_04"
    }
    self.mats_ = {}
    Yield(ResourcesManager.LoadObjectMultiAsync(list, function(mats)
        for i=1,4 do
            self.mats_[i] = mats[i]
        end
    end))
    Yield(ResourcesManager.LoadObjectAsync("Model/World/Common/select", function(go)
        self.Select_Go = GameObject.Instantiate(go)
       self.Select_Go.name = "select_go"
        local sr = self.Select_Go.transform:Find("sprite"):GetComponent(SpriteRenderer)
        --GameTween.DOFade(sr, 0.6, 0.6):SetEase(XEase.Linear):SetLoops(-1, XLoopType.Yoyo)
    end))
    local list_com = {
        "Common/WorldMenu",
    }
    Yield(_G.UIUtil.load_component(list_com, function(prefabs)
        self.world_menu_prefab_ = prefabs[1]
        self:init_world_menu()
    end))
    Yield(WorldBuildTmp:init())
    Yield(WorldAniTmp:init())
    self:init_base_offset(2, 2)
end

function WorldInputSystem:init_base_offset(x, z)
    if not self.base_pool_ then
        self.base_pool_ = {}
    end

    for i=x-1,x+1 do
        if not self.base_pool_[i] then
            self.base_pool_[i] = {}
        end
        for j=z-1,z+1 do
            self.base_pool_[i][j] = 1
        end
    end
end

function WorldInputSystem:init_world_menu()
    if self.world_menu_ then
        self.world_menu_:on_dispose()
        self.world_menu_ = nil
    end
    local layer = UIManager.get_canvas().transform:Find(UIConfig.Layers[UIConfig.LayerType.Board])
    self.menu_panel_ = layer:Find("MenuPanel")
    if not self.menu_panel_ then
        local go = GameObject("MenuPanel")
        go:AddComponent(UnityEngine.RectTransform)
        go.transform:SetParent(layer, false)
        go.transform.localPosition = Vector3.zero
        go.transform.localScale = Vector3.one
        go.transform.anchorMin = Vector2.zero
        go.transform.anchorMax = Vector2.one
        go.transform.offsetMax = Vector2.zero
        go.transform.offsetMin = Vector2.zero
        self.menu_panel_ = go.transform
    end
    UIUtil.destroy_all_children(self.menu_panel_, true)
    local world_menu = GameObject.Instantiate(self.world_menu_prefab_)
    world_menu.transform:SetParent(self.menu_panel_, false)
    world_menu:SetActive(true)
    self.world_menu_ = WorldMenu:new(self)
    self.world_menu_:AddLuaComponent(world_menu)
    self.world_menu_:init()

    self:hide_world_menu()
end

function WorldInputSystem:hide_world_menu()
    if self.world_menu_ then
        self.world_menu_:clear_data()
        self.world_menu_.gameObject:SetActive(false)
    end
end

function WorldInputSystem:ctor(index)
    self.index = index
    StartCoroutine(function()
        self:on_resource()
    end)

    self.main_camera_ = Camera.main
    self.world_map_ = _G.GameObject.Find("WorldMap").transform
    self.animation_ = self.world_map_:Find("Animation")
    self.scroll_camera_ = self.world_map_.gameObject:GetComponent(EasyTouchEvent)
    self.scroll_base_ = self.world_map_:Find("Base")
    self.scroll_logic_ = self.world_map_:Find("LogicBox")

    self.screen_half_height_ = Screen.height / 2
    self.screen_half_width_ = Screen.width / 2

    self.inertial_acceleration_ = 5000
    self.min_inertial_speed_ = 5
    self.max_inertial_speed_ = 30

    self.scroll_camera_.OnETTouchDown = function(ge)
        if self.move_camera_ then
            self.move_camera_state_ = true
        end
    end
    self.scroll_camera_.OnETTouchUp = function(ge)
        if self.move_camera_state_ then
            self.move_camera_ = false
        end
        self.move_camera_state_ = false
    end


    self.scroll_camera_.OnETTouchStart = function(ge)
        self:on_et_touch_start(ge)
    end

    self.scroll_camera_.OnETDrag = function(ge)
        self:on_et_drag(ge)
    end
    self.scroll_camera_.OnETDragEnd = function(ge)
        self:on_et_drag_end(ge)
    end

    self.scroll_camera_.OnETPinch = function(ge)
        self:on_et_pinch(ge)
    end

    self.scroll_camera_.OnETPinchEnd = function(ge)
        self:on_et_pinch_end(ge)
    end

    self.scroll_camera_.OnETSimpleClick = function(ge)
        self:on_et_click(ge)
    end

    self.ui_main_ = GameManager.UI_Main
    self.ui_camera_ = UIManager.get_camera()
    self.screen_size_ = UIManager.get_canvas_size()
    self.goto_go_ = self.world_map_.transform:Find("Goto")
    WorldTerrainLoader:init(self.world_map_)

    self.messager_ = Messager:new(self)
    self.messager_:add_listener(Msg.WORLD_CLEAR_MENU, on_clear_menu)
    self.messager_:add_listener(Msg.WORLD_CLEAR_MARCH_MENU, on_clear_arrow_menu)
    self.messager_:add_listener(Msg.WORLD_CLEAR_JOURNEY_MENU, on_clear_journey_menu)
    self.messager_:add_listener(Msg.WORLD_JUMP_JOURNEY, on_jump_journey)
    self.messager_:add_listener(Msg.WORLD_ENABLE_WATCH_CB, on_goto_axis_complete)

    local x,z = WorldManager:get_my_build_logic_axis()
    self:goto_axis(x, z)
end

function WorldInputSystem:goto_axis( x, z, show)
    show = show ~= nil and show or false
    if not x or not z then
       return
   end
    -- 删除原来的
    for i=1,9 do
        local go_base = self.scroll_base_:GetChild(i-1)
        local go_x,go_z = UIUtil.get_grid_xz_by_name(go_base.gameObject.name)
        WorldBuildTmp:remove_build(go_x, go_z)
    end
    --计算新地点
    self.goto_go_.localPosition = Vector3((x - 1 + config.WORLD_START) * 2, 0, -(z - 1 + config.WORLD_START) * 2)
    local radian = math.tan(config.WORLD_CAMERA_RADIAN)

    local delta_z = math.abs(self.main_camera_.transform.position.y - self.goto_go_.position.y) * radian

    local pos = Vector3(self.goto_go_.position.x, self.main_camera_.transform.position.y, self.goto_go_.position.z - delta_z - 1)
    self.main_camera_.transform.position = pos
    local center_x = math.floor(self.goto_go_.localPosition.x / 50) + 1
    -- 这里不用绝对值了，直接取反，反正确定是负数
    local center_z = math.floor(-self.goto_go_.localPosition.z / 50) + 1
    local index_list = {}
    local start_x = (center_x-1) < 1 and 1 or (center_x-1)
    local start_z = (center_z-1) < 1 and 1 or (center_z-1)
    local index = 0
    local start_xlist = {start_x+1, start_x, start_x+2}
    local start_zlist = {start_z+1, start_z, start_z+2}
    for _,i in ipairs(start_xlist) do
        for _,j in ipairs(start_zlist) do
            -- base
            local go_base = self.scroll_base_:GetChild(index)
            go_base.localPosition = Vector3((i-1)*50, go_base.localPosition.y, -(j-1)*50)
            go_base.gameObject.name = string.format("base{%d}{%d}}", i, j)
            self:set_base_mat(go_base)
            -- logic
            local go_logic = self.scroll_logic_:GetChild(index)
            go_logic.localPosition = Vector3((i-1)*50, go_logic.localPosition.y, -(j-1)*50)
            go_logic.gameObject.name = string.format("LogicCell{%d}{%d}}", i, j)
            index = index + 1
            -- terrain
            WorldTerrainLoader:check_terrain(i, j)
            -- build
            WorldBuildTmp:check_build(go_logic)
        end
    end

    local str = string.format("base{%d}{%d}}", center_x, center_z)
    self:set_cur_base_name(str)
    self:clear_base_pool()
    -- 自动移动的时候不需要清除世界菜单
    if not self.move_camera_ then
        self:clear_world_menu()
    end
    if self.ui_main_ then
        self.ui_main_:set_axis_value(x, z)
        self.ui_main_:updata_track_position_ex()
    end
    self.show_menu_ = show
    MsgCenter.send_message(Msg.WORLD_ENABLE_WATCH2, x, z)
end

function WorldInputSystem:clear_base_pool()
    self.base_pool_ = {}
    for i=1,self.scroll_base_.childCount do
        local go = self.scroll_base_:GetChild(i-1)
        local _x, _z = UIUtil.get_grid_xz_by_name(go.gameObject.name)
        if not self.base_pool_[_x] then
            self.base_pool_[_x] = {}
        end
        self.base_pool_[_x][_z] = 1
    end
end

function WorldInputSystem:set_cur_base_name( name)
    self.cur_base_name_ = name
end

function WorldInputSystem:set_base_mat(goBase)
    if not goBase then return end
end


function WorldInputSystem:on_et_touch_start(gesture)
    if self.camera_inertial_tween_ then
        self.camera_inertial_tween_:Kill(false)
    end
end

function WorldInputSystem:on_et_drag( gesture)
    if self.move_camera_ then return end
    if gesture.deltaPosition == Vector2.zero then return end
    local pos = self.main_camera_.transform.position

    local factorX = self.main_camera_.fieldOfView/self.screen_half_width_ * 0.67
    local factorY = self.main_camera_.fieldOfView/self.screen_half_height_ * 0.67
    local offset = -Vector3(gesture.deltaPosition.x*factorX, 0, gesture.deltaPosition.y*factorY)

    -- 将当前鼠标的屏幕坐标转换成世界坐标，再加上两者间的距离
    self.main_camera_.transform.position = self:checked_camera_position(pos + offset)
    self.drag_velocity_ = Vector2(-gesture.deltaPosition.x / Time.deltaTime * factorX, -gesture.deltaPosition.y / Time.deltaTime * factorY)
    if self.drag_velocity_.sqrMagnitude > self.max_inertial_speed_ * self.max_inertial_speed_ then
        self.drag_velocity_ = self.drag_velocity_.normalized * self.max_inertial_speed_
    end
    self:on_et_drag_move(false)
end

function WorldInputSystem:checked_camera_position(position)
    if position.x < MAP_LEFT_VECTEX.x then
        return MAP_LEFT_VECTEX
    elseif position.x > MAP_RIGHT_VECTEX.x then
        return MAP_RIGHT_VECTEX
    end
    local s1
    local angle
    if position.z > MAP_CENTER.z then
        s1 = MAP_TOP_VECTEX
        local v = position - s1
        angle = Vector2.SignedAngle(Vector2(v.x, v.z), Vector2.right)
    else
        s1 = MAP_BOTTOM_VECTEX
        local v = position - s1
        angle = Vector2.SignedAngle(Vector2.right, Vector2(v.x, v.z))
    end
    if angle >= 45 and angle <= 135 then return position end
    local s2 = position.x > MAP_CENTER.x and MAP_RIGHT_VECTEX or MAP_LEFT_VECTEX
    local start1 = Vector2(s1.x, s1.z)
    local end1 = Vector2(s2.x, s2.z)
    local start2 = Vector2(position.x, position.z)
    local end2 = start2 + Vector2.up
    local pos_2d = UIUtil.get_cross_point(start1, end1, start2, end2)
    local new_pos = Vector3(pos_2d.x, position.y, pos_2d.y)
    return new_pos
end

function WorldInputSystem:on_et_drag_end(gesture)
    if not self.drag_velocity_ then return end
    local drag_speed = self.drag_velocity_.magnitude
    if drag_speed <= self.min_inertial_speed_ then
        MsgCenter.send_message(Msg.WORLD_ENABLE_WATCH, self.cur_logic_name_, self.cur_base_name_)
        return
    end
    local inertial_acceleration = self.inertial_acceleration_ * self.main_camera_.orthographicSize / self.screen_half_height_
    local inertial_time = drag_speed / inertial_acceleration
    local pos = self.main_camera_.transform.position
    local a = -self.drag_velocity_.normalized * inertial_acceleration
    local max_s = self.drag_velocity_ * inertial_time + a * inertial_time * inertial_time * 0.5
    max_s.y = max_s.y / math.sin(self.main_camera_.transform.eulerAngles.x * math.pi / 180)
    self:on_et_drag_move(true)
    self.camera_inertial_tween_ = GameTween.DOMove(self.main_camera_.transform, 
                                                   pos + Vector3(max_s.x, 0, max_s.y),
                                                   inertial_time, 
                                                   false):OnUpdate(
        function()
            local new_pos = self.main_camera_.transform.position
            self.main_camera_.transform.position = self:checked_camera_position(new_pos)
            self:on_et_drag_move(false)
        end
    )

    self.camera_inertial_tween_:SetEase(XEase.OutQuad)
    self.camera_inertial_tween_:OnComplete(
    function()
        MsgCenter.send_message(Msg.WORLD_ENABLE_WATCH, self.cur_logic_name_, self.cur_base_name_)
    end)
end

function WorldInputSystem:on_et_drag_move( isEnd)
    if not self:is_alive() then
        return
    end

    local ray = self.main_camera_:ScreenPointToRay(Vector3(Screen.width / 2, Screen.height / 2, 0))
    local hit_point_base = Physics.RaycastAll(ray, 1000, Layer_Mask_World_Base)
    if hit_point_base and hit_point_base.Length > 0 then
        local map_ceil = hit_point_base[1].transform
        if map_ceil.gameObject.name ~= self.cur_base_name_ then
            self:check_grid_change(map_ceil.gameObject.name)
            self:set_cur_base_name(map_ceil.gameObject.name)
        end
    end
    local map_ceil = self:get_map_ceil_by_screen_position(Vector2(Screen.width / 2, Screen.height / 2))
    if map_ceil and map_ceil.gameObject.name ~= self.cur_logic_name_ then
        self:set_cur_logic_name(map_ceil)
    end
    if self.ui_main_ then
        self.ui_main_:updata_track_position_ex()
    end
    if self.move_camera_ then return end
    if isEnd then
        self:clear_world_menu(true)
    elseif self.world_menu_ and self.world_menu_.gameObject.activeSelf then
        if self.world_menu_.obj_ and self.world_menu_.obj_.obj_type_ == config.WORLD_MARCH then
            local march_id = self.world_menu_.obj_.idx_
            local obj = self.animation_.transform:Find(tostring(march_id).."/point")
            self:set_world_menu_axis_by_postion(obj)
        else
            self:set_world_menu_axis()
        end
    end
end


function WorldInputSystem:check_grid_change(name)
    local x, z = UIUtil.get_grid_xz_by_name(name)
    local move_x
    local move_z
    if x ~= 1 then
        for i=x-1,x+1 do
            if not self.base_pool_[i] then
                move_x = i
                break
            end
        end
    end
    if z ~= 1 then
        for i=x-1,x+1 do
            for _i=z-1,z+1 do
                if self.base_pool_[i] and not self.base_pool_[i][_i] then
                    move_z = _i
                    break
                end
            end
        end
    end
    local old_x, old_z = UIUtil.get_grid_xz_by_name(self.cur_base_name_)
    -- X轴
    if move_x then
        if old_x == move_x then elog("old_x == move_x, why?, value="..tostring(move_x)) end
        local pos_to = (move_x - 1) * 50
        local pos_from
        if old_x < move_x then
            -- 向右移动
            pos_from = (move_x - 1 - 3) * 50 < 0 and 0 or (move_x - 1 - 3) * 50
        else
            -- 向左移动
            pos_from = (move_x - 1 + 3) * 50
        end
        if not pos_from then elog("pos_from == nil, why?, value="..tostring(move_x)) end
        local list = {5, 4, 6, 2, 8, 1, 3, 7, 9}
        for _,i in ipairs(list) do
            local go_base = self.scroll_base_:GetChild(i-1)
            if go_base.localPosition.x == pos_from then                    
                go_base.localPosition = Vector3(pos_to, go_base.localPosition.y, go_base.localPosition.z)
                local go_x,go_z = UIUtil.get_grid_xz_by_name(go_base.gameObject.name)
                go_base.gameObject.name = string.format("base{%d}{%d}}", move_x, go_z)
                self:set_base_mat(go_base)
                WorldTerrainLoader:check_terrain(move_x, go_z)
                WorldBuildTmp:remove_build(go_x, go_z)
            end
            local go_logic = self.scroll_logic_:GetChild(i-1)
            if go_logic.localPosition.x == pos_from then                    
                go_logic.localPosition = Vector3(pos_to, go_logic.localPosition.y, go_logic.localPosition.z)
                local go_x,go_z = UIUtil.get_grid_xz_by_name(go_logic.gameObject.name)
                local old_name = go_logic.gameObject.name
                go_logic.gameObject.name = string.format("LogicCell{%d}{%d}}", move_x, go_z)
                WorldBuildTmp:check_build(go_logic)
            end
        end
    end
    -- Z轴
    if move_z then
        if old_z == move_z then elog("old_z == move_z, why?, value="..tostring(move_z)) end
        local pos_to = -(move_z - 1) * 50
        local pos_from
        if old_z < move_z then
            pos_from = (move_z - 1 - 3) * 50 < 0 and 0 or (move_z - 1 - 3) * 50
        else
            pos_from = (move_z - 1 + 3) * 50
        end
        pos_from = -pos_from
        if not pos_from then elog("pos_from == nil, why?, value="..tostring(move_z)) end
        local list = {5, 4, 6, 2, 8, 1, 3, 7, 9}
        for _,i in ipairs(list) do
            local go_base = self.scroll_base_:GetChild(i-1)
            if go_base.localPosition.z == pos_from then                    
                go_base.localPosition = Vector3(go_base.localPosition.x, go_base.localPosition.y, pos_to)
                local go_x,go_z = UIUtil.get_grid_xz_by_name(go_base.gameObject.name)
                go_base.gameObject.name = string.format("base{%d}{%d}}", go_x, move_z)
                self:set_base_mat(go_base)
                WorldTerrainLoader:check_terrain(go_x, move_z)
                WorldBuildTmp:remove_build(go_x, go_z)
            end
            local go_logic = self.scroll_logic_:GetChild(i-1)
            if go_logic.localPosition.z == pos_from then                    
                go_logic.localPosition = Vector3(go_logic.localPosition.x, go_logic.localPosition.y, pos_to)
                local go_x,go_z = UIUtil.get_grid_xz_by_name(go_logic.gameObject.name)
                go_logic.gameObject.name = string.format("LogicCell{%d}{%d}}", go_x, move_z)
                WorldBuildTmp:check_build(go_logic)
            end            
        end
    end    
    if move_x or move_z then 
        if not self.move_camera_ then
            self:clear_world_menu()
        end
        self:clear_base_pool()
    end
end


function WorldInputSystem:set_cur_logic_name(map_ceil)
    if not map_ceil then
        self.ui_main_:set_axis_value(0, 0)
        self.cur_logic_name_ = ""
        return
    end
    self.cur_logic_name_ = map_ceil.gameObject.name
    local x, z = UIUtil.get_world_axis(map_ceil.gameObject.name, map_ceil.parent.name)
    if self.ui_main_ then
        self.ui_main_:set_axis_value(x, z)
    end
end

function WorldInputSystem:set_world_menu_axis()
    if not Select_Go then return end
    if not self.world_menu_ then return end
    local map_ceil = Select_Go.transform.parent
    if not map_ceil then return end
    local x, z = UIUtil.get_world_axis(map_ceil.gameObject.name, map_ceil.parent.gameObject.name)
    local obj = WorldManager:get_world_obj(x, z)
    local tmp_pos = Select_Go.transform.position
    if obj and obj.obj_type_ == config.WORLD_MAIN_JUMP then
        local _x, _z = obj:get_main()
        local tmp_select_go = WorldBuildTmp:get_build(_x, _z)
        tmp_pos = tmp_select_go.transform.position
    end
    local screenPos = self.main_camera_:WorldToScreenPoint(tmp_pos)

    local b,p = RectTransformUtility.ScreenPointToLocalPointInRectangle(self.screen_size_, screenPos, self.ui_camera_)
    self.world_menu_.gameObject:SetActive(true)
    local menu_rect = self.world_menu_.gameObject:GetComponent(RectTransform)
    local off_x = 0
    local off_y = 0
    if obj then
        off_x, off_y = obj:get_offset_pos(self.main_camera_.fieldOfView, p)
    end
    menu_rect.anchoredPosition = Vector2(math.floor(p.x) + off_x, math.floor(p.y) + off_y)
end


function WorldInputSystem:clear_world_menu(onlgMenu)
    if self.world_menu_ then
        self:hide_world_menu()
        self:clear_all_arrow_point()
    end
    if onlgMenu then return end
    if self.Select_Go then
        self.Select_Go.transform:SetParent(nil, false)
    end
end


function WorldInputSystem:clear_all_arrow_point()
    if not self.animation_ then return end
    for i=1,self.animation_.childCount do
        local go = self.animation_:GetChild(i-1)
        local arrow_point = go.transform:Find("point")
        if arrow_point then
            arrow_point.gameObject:SetActive(false)
        end
    end
end

function WorldInputSystem:on_et_pinch( gesture)
    if self.move_camera_ then
        self.move_camera_ = false
        return
    end

    dump(gesture.position, "gesture")

    if not self.screen_pinch_center_ then
        local pos0 = self.scroll_camera_.TouchPosition0
        local pos1 = self.scroll_camera_.TouchPosition1
        local mid = (pos0 + pos1) / 2
        self.screen_pinch_center_ = Vector3(mid.x, mid.y, 0)
        self.world_pinch_center_ = self.main_camera_:ScreenToWorldPoint(self.screen_pinch_center_)
    end
    local newSize = self.main_camera_.fieldOfView - gesture.deltaPinch * 0.1
    if newSize > FIELDOFVIEW_MAX then
        newSize = FIELDOFVIEW_MAX
    end
    if newSize < FIELDOFVIEW_MIN then
        newSize = FIELDOFVIEW_MIN
    end
    self.main_camera_.fieldOfView = newSize
    -- 暂时保留
--    local new_screen_center = self.main_camera_:WorldToScreenPoint(self.world_pinch_center_)
--    local screen_offset = new_screen_center - self.screen_pinch_center_
--    local world_offset = screen_offset / self.screen_half_height_ * self.main_camera_.orthographicSize
--    world_offset.y = world_offset.y / math.sin(self.main_camera_.transform.eulerAngles.x * math.pi / 180)
--    world_offset = Vector3(world_offset.x, 0, world_offset.y)
--    local new_camera_pos = self:checked_camera_position(self.main_camera_.transform.position + world_offset)
--    self.main_camera_.transform.position = new_camera_pos

    self:hide_world_menu()
end

function WorldInputSystem:on_et_pinch_end(self, gesture)
    self.screen_pinch_center_ = nil
    self.world_pinch_center_ = nil
end


function WorldInputSystem:on_et_click(self, gesture)
    if self.move_camera_ then return end
    local map_ceil = self:get_map_ceil_by_screen_position(gesture.position)
    if not map_ceil then return end
    local hit_obj
    local obj_type -- 1出征线  2队伍  3势力据点头上气泡
    local ray = Camera.main:ScreenPointToRay(Vector3(gesture.position.x, gesture.position.y, 0))
    local hit_point_ani = Physics.RaycastAll(ray, 1000, Layer_Mask_World_Ani)
    if hit_point_ani and hit_point_ani.Length > 0 then
        -- 优先选择队伍
        for i=1,hit_point_ani.Length do 
            local map_ceil = hit_point_ani[i].transform
            local a = string.find(map_ceil.gameObject.name, 'j')
            obj_type = a and 2 or 1
            local b = string.find(map_ceil.gameObject.name, 'owner')
            if b then
                obj_type = 3
                hit_obj = hit_point_ani[i].transform.parent.parent
            else
                hit_obj = hit_point_ani[i]
            end
            if obj_type == 2 then
                break
            end
        end
    end
    
    -- 点中了移动物件
    if hit_obj then
        -- 出征线 = 1
        if obj_type == 1 then
            self:on_click_march_arrow(hit_obj)
        -- 队伍 = 2
        elseif obj_type == 2 then
            local parent_obj = hit_obj.transform.parent
            self:on_click_march_journey(parent_obj)
        --势力据点 = 3
        elseif obj_type == 3 then
            local parent_obj = hit_obj.transform.parent
            self:check_world_click(hit_obj.transform)
            local x,z = UIUtil.get_world_axis(hit_obj.gameObject.name, hit_obj.parent.gameObject.name)
            MsgCenter.send_message(Msg.WORLD_FORT_OWNER_HIDE, x, z)
        end
    else
        self:check_world_click(map_ceil)
    end
end


function WorldInputSystem:get_map_ceil_by_screen_position(screen_pos)
    local radian = math.rad(self.main_camera_.transform.eulerAngles.x)    
    local center_distance = self.main_camera_.transform.position.y / math.sin(radian)
    local bottom_distance = center_distance * math.tan(math.rad(self.main_camera_.fieldOfView/2))
    local ratio = (screen_pos.y - Screen.height/2 ) / (Screen.height/2)
    local actural_distance = bottom_distance * ratio
    local actural_angle = math.atan(actural_distance / center_distance)
    local actural_radian = radian - actural_angle
    -- 后面 - math.abs(ratio*2)我也不知道为什么，反正就是对了，求数学高手解答 2019.10.11
    local cross_distance = self.main_camera_.transform.position.y / math.sin(actural_radian) - math.abs(ratio*2)
    local click_map_pos = self.main_camera_:ScreenToWorldPoint(Vector3(screen_pos.x, screen_pos.y, cross_distance))
    click_map_pos = click_map_pos - self.world_map_.position
    click_map_pos = Quaternion.AngleAxis(-self.world_map_.eulerAngles.y, Vector3.up) * click_map_pos
    click_map_pos = Vector3(click_map_pos.x, 0, click_map_pos.z)
    local ceil_x = math.floor(math.abs(click_map_pos.x) / 2) - (config.WORLD_START - 1)
    local ceil_z = math.floor(math.abs(click_map_pos.z) / 2) - (config.WORLD_START - 1)
    if ceil_x < 0 or ceil_x > 800 or ceil_z < 0 or ceil_z > 800 then return end
    return UIUtil.get_logic_parent(ceil_x, ceil_z, self.scroll_logic_)
end



--增加事件监听
function WorldInputSystem:AddEventListener(keys , callBack)
    if not self.regCallBacks then
        self.regCallBacks = {}
    end

    if type(keys) ~= "table" then
        keys = { keys }
    end

    for _, key in ipairs(keys) do
        if not self.regCallBacks[key] then
            self.regCallBacks[key] = callBack
            _G.event.add_listener(key, self , function(args)
                self.regCallBacks[key](args)
            end)
        end
    end
end

--移除事件监听
function WorldInputSystem:RemoveEventListener()
    if not self.regCallBacks then
        return
    end

    for key, _ in pairs(self.regCallBacks) do
        _G.event.remove_listener(key ,self)
    end
    self.regCallBacks = nil
end

function WorldInputSystem:on_up_lv_update(build_id)
    print("on_up_lv_update")
    local space = self:get_space_by_build_id(build_id)
    if space then
        BuildManager:append_queue(build_id)
        if _G.EventKey then
            _G.event.fire(_G.EventKey.CITY_REFRESH_QUEUE)
        end
        space:on_building()
    end
end

--金币建造升级不参与队列
function WorldInputSystem:on_gold_lvup_update(build_id)
    local space = self:get_space_by_build_id(build_id)
    if space then
        space:on_building() 
    end
end

function WorldInputSystem:on_up_lv_finished(build_id)
    local space = self:get_space_by_build_id(build_id)
    if space then
        space:on_up_lv_finished(build_id)
    end

    --刷新建筑mark
    local builds = BuildManager:get_builds_all()
    if not builds then return end
    for k, v in pairs(builds) do
        local id = v.id_
        local space = self:get_space_by_build_id(v.id_)
        if space then
            space:get_bill_board():set_build_mark()
        end
    end

end

function WorldInputSystem:on_soldier_drill_update(arg1, soldier_id, soldier_class)
    local build_id = arg1
    if _G.EventKey then
        soldier_id = arg1.soldierID
        build_id = arg1.buildID
        soldier_class = arg1.soldierClass
    end
    local space = self:get_space_by_build_id(build_id)
    if space then space:play_timer(soldier_id, soldier_class) end
end

function WorldInputSystem:on_soldier_drill_finished(arg1, soldier_id, soldier_class)
    local build_id = arg1
    if _G.EventKey then
        soldier_id = arg1.soldierID
        build_id = arg1.buildID
        soldier_class = arg1.soldierClass
    end
    local space = self:get_space_by_build_id(build_id)
    if space then space:on_soldier_drill_finished(build_id, soldier_id, soldier_class) end
end

function WorldInputSystem:on_soldier_cure_update(build_type)
    local builds = BuildManager:get_all_builds_by_type(build_type)
    if not builds then
        return
    end

    for _, v in pairs(builds) do
        local space = self.space_item_tb_[v.space_id_]
        if space then
            space:hurts_timer()
        end
    end
end

function WorldInputSystem:on_soldier_cure_finish(data)
    local builds = BuildManager:get_all_builds_by_type(config.BUILD_TYPE.HOSPITAL)
    if builds then
        for k, v in pairs(builds) do
            local space = self.space_item_tb_[v.space_id_]
            if space then
                space:on_soldier_cure_finished(data)
            end
        end
    end
end

function WorldInputSystem:on_collect_refresh(build_id)
    local space = self:get_space_by_build_id(build_id)
    if space then
        space:on_collect_refresh(build_id)
    end
end

function WorldInputSystem:on_collect_finished(build_id)
    local space = self:get_space_by_build_id(build_id)
    if space then
        space:on_collect_finished(build_id)
    end
end

--资源数量改变,刷新BuildMark
function WorldInputSystem:on_resource_change()
    for k, v in pairs(self.space_item_tb_) do
        if v then v:get_bill_board():set_build_mark() end
    end
end

function WorldInputSystem:on_build_removed_cancel(build_id)
    local space = self:get_space_by_build_id(build_id)
    if space then
        space:on_build_removed_cancel()
    end
end

--移动建筑 显示效果
function WorldInputSystem:on_show_movable_build(build_id)
    local build = BuildManager:get_build_info_by_id(build_id)
    if build then
        for k, v in pairs(self.space_item_tb_) do
            if v then 
                v:show_build_effect(build_id)
                v:build_exchange_last_id(build_id)
            end
        end
    end
end

-- --取消建筑移动  隐藏效果
-- function on_hide_mvable_build()
--     for k, v in pairs(self.space_item_tb_) do
--         if v then
--             v:hide_build_effect()
--         end
--     end
-- end

--建筑移动完成
function WorldInputSystem:on_build_change_finished(data)
    if not data then return end
    for k, v in pairs(self.space_item_tb_) do
        if v then
            v:on_build_exchanged(data)
        end
    end
end

--建筑拆除完成
function WorldInputSystem:on_build_removed_finish(space_id)
    local space = self.space_item_tb_[space_id]
    if not space then return end
    space:on_build_removed_finished()
end

function WorldInputSystem:CITY_RANDOM_SHOP_UPDATE(isClose)
    local space = self.space_item_tb_[47]
    if space then
        if isClose == 1 then
            space:get_bill_board():HideBuildTitle()
        elseif isClose == 2 then
            space:get_bill_board():set_build_title(config.BUILD_TITLE_TYPE.RANDOM_SHOP)
        end
    end
end

function WorldInputSystem:OnStopTimer2()
    local space = self.space_item_tb_[WHARF_SPACE_ID]
    if space then
        space:stop_timer_2()
    end
end

--根据id 获取space
function WorldInputSystem:get_space_by_build_id(build_id)
    local space
    local build = BuildManager:get_build_info_by_id(build_id)
    if build and build.space_id_ then
        space = self.space_item_tb_[build.space_id_]
    end
    if not space then elog("not found build by id.  id = %s", build_id) end
    return space
end

function WorldInputSystem:register_click(gameObject, callback)
    --注册点击回调
    if type(callback) == "function" then
        self.click_callbacks_[gameObject] = callback
    end
end

function WorldInputSystem:deregister_click(gameObject, callback)
    --注销点击回调
    self.click_callbacks_[gameObject] = nil
end

--根据id 获取space
function WorldInputSystem:get_space_by_build_id(build_id)
    local space
    local build = BuildManager:get_build_info_by_id(build_id)
    if build and build.space_id_ then
        space = self.space_item_tb_[build.space_id_]
    end
    if not space then elog("not found build by id.  id = %s", build_id) end
    return space
end

function WorldInputSystem:get_raycast_object(gesture, layer)
    --根据touch坐标做射线检测，返回碰撞的第一个物体
    --_G.dump(gesture.position, "gesture.position: ", 99)
    local ray = self.camera_:ScreenPointToRay(Vector3(gesture.position.x, gesture.position.y, 10000))
    --_G.dump(ray, "ray: ", 99)
    local r = Physics.RaycastAll(ray.origin, ray.direction, 1000, layer).Table
    if #r > 1 then
        for i,v in ipairs(r) do
            local name = v.collider.transform.gameObject.name
            
            local pos = string.find(name, 'BuildMask')
            if pos then
                return v.collider.transform.gameObject
            end
        end
    end
    if #r > 0 then
        --print("raycast name = "..r[1].collider.transform.gameObject.name)
        return r[1].collider.transform.gameObject
    end
end

function WorldInputSystem:on_et_touch_start(gesture)
    if self.camera_tween_ then
        self.camera_tween_:Kill(false)
    end
    if gesture.touchCount == 1 and self.move_obj_into_screen_tween_ then
        self.move_obj_into_screen_tween_:Pause()
    end
    if self.build_menu_ then
        self.build_menu_:animation_hide()
    end
end

function WorldInputSystem:on_et_touch_up(gesture)
    if gesture.touchCount == 1 and self.move_obj_into_screen_tween_ then
        self.move_obj_into_screen_tween_:Play()
    end
end

function WorldInputSystem:is_alive()
    return true
end

function WorldInputSystem:set_move_board()
    for _, space in ipairs(self.space_item_tb_) do
        if space.bill_board_ then
            space.bill_board_:set_mark_axis()
        end
    end
    if self:is_alive() and self.build_menu_ and self.build_menu_.gameObject.activeSelf then
        self.build_menu_:set_menu_axis()
    end
end

function WorldInputSystem:on_hide_all()
    for k, v in pairs(self.space_item_tb_) do
        if v then v:get_bill_board():hide_build_mark() end
    end
end

function WorldInputSystem:on_show_all()
    for k, v in pairs(self.space_item_tb_) do
        if v then v:get_bill_board():set_build_mark() end
    end
end

function WorldInputSystem:move_obj_to_screen_upper(gameObject, size, duration)
    --将场景中的指定物体对准屏幕上部跳转点
    self:move_world_pos_to_screen_point(gameObject.transform.position, size, duration,
                                        --Vector3(Screen.width / 2, Screen.height * 0.75, 0), true)
                                        Vector3(Screen.width * 0.25, Screen.height / 2, 0), true)
end

function WorldInputSystem:move_obj_to_screen_center(gameObject, size, duration)
    --将场景中的指定物体对准屏幕中心跳转点
    self:move_world_pos_to_screen_point(gameObject.transform.position, size, duration, 
                                        Vector3(Screen.width / 2, Screen.height / 2, 0), true)
end

-- 将物体定位到屏幕中心
function WorldInputSystem:locate_obj_to_screen_center(gameObject, size, duration)
    if not gameObject then return end
    self.cameraController:FocusOn(gameObject.transform.position)
end

function WorldInputSystem:move_world_pos_to_screen_point(world_pos, size, duration, screen_point, restorable)
    if self.move_obj_into_screen_tween_ then
        self.move_obj_into_screen_tween_:Kill(false)
    end
    new_size = size or CITY_CAMERA_BUILD_JUMP_SIZE
    if new_size > CITY_CAMERA_MAX_SIZE then
        new_size = CITY_CAMERA_MAX_SIZE
    end
    if new_size < CITY_CAMERA_MIN_SIZE then
        new_size = CITY_CAMERA_MIN_SIZE
    end
    local old_size = self.camera_.orthographicSize
    self.camera_.orthographicSize = new_size
    local src_screen_pos = self.camera_:WorldToScreenPoint(world_pos)
    self.camera_.orthographicSize = old_size
    local src_screen_offset = screen_point - src_screen_pos
    local camera_offset = -src_screen_offset / self.screen_half_height_ * new_size
    camera_offset.z = 0
    local camera_target = self.camera_.transform.position + camera_offset
    self:modify_camera_state(camera_target, new_size, duration, restorable)
end

function WorldInputSystem:modify_camera_state(new_pos, new_size, duration, restorable)
    --设置摄像机状态
    self:on_hide_all()
    if restorable then
        if self.camera_restore_point_ then return false end
        self.camera_restore_point_ = {
            position = self.camera_.transform.position,
            orthographicSize = self.camera_.orthographicSize
        }
    end
    self.cameraController:FocusOn(new_pos)
    return true
end

function WorldInputSystem:restore_camera_state(duration)
    --恢复摄像机状态至还原点
    self:on_show_all()
    if not self.camera_restore_point_ then return false end
    duration = duration or 0.2
    local state = self.camera_restore_point_
    GameTween.DOMove(self.camera_.transform, state.position, duration, false):OnUpdate(function()
        self:set_move_board()
    end)
    GameTween.To(function(v)
        self.camera_.orthographicSize = v
    end, self.camera_.orthographicSize, state.orthographicSize, duration)
    self.camera_restore_point_ = nil
    return true
end

function WorldInputSystem:cleanUp()
end

function WorldInputSystem:preProcess()

end

return WorldInputSystem
