-- LuaComponent 脚本基类
-- 映射绑定引擎的LuaComponent类
module("LuaComponentBase", package.seeall)


function init(self, go)
    if go then
        self.lua_comp_ = self:AddLuaComponent(go)
        self.disposed_ = false
    end
end

function OnDestroy( self )

    self:clear_members()

    self.disposed_ = true
end

function clear_members(self)
    for k,v in pairs(self) do
        local t = type(v)
        if t == "userdata" then
            self[k] = nil
        elseif t == "table" and not getmetatable(v) then
            self:clear_table(v, 0)
        end
    end
end

function clear_table(self, tab, layers)
    local layer_count = layers + 1
    if layer_count > 2 then return end

    for k,v in pairs(tab) do
        if type(v) == "table" and not getmetatable(v) then
            self:clear_table(v, layer_count)
        elseif type(v) == "userdata" then
            tab[k] = nil
        end
    end
end

function bind_funcs(self)
    local Func = LuaComponentFunc
    local MaxFunc = Func.Max

    local funcs = {
        -- {Func.Awake, self.Awake},
        {Func.Start, self.Start},
        {Func.OnDestroy, self.OnDestroy},
        {Func.Update, self.Update},
        {Func.LateUpdate, self.LateUpdate},
        {Func.FixedUpdate, self.FixedUpdate},
    }
    return funcs
end

function AddLuaComponent(self, obj)
    self.gameObject = obj
    self.transform = obj.transform
    local comp = LuaComponent.Bind(obj, self, self:bind_funcs())
    self.this = comp
    self.lua_comp_ = comp
    if comp and self.Awake then
        self:Awake()
    end

    return comp
end

