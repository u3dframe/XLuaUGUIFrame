---所有UI的基类
_G.UIBase    = {}
local UIBase = _G.UIBase
local dkjson = require "Tools/dkjson"
local react  = require "Tools/VMUtils"
local timerKeys = {}
local TimerController = _G.EngineCore.GameController.TimerController

-- 基础类方法 new
function UIBase:New(uiName)
    print("UIBase:New" , uiName)
    local obj = {uiName = uiName , comDic = {}}
    self.__index = self
    return setmetatable(obj , self )
end

--WARNING:This is interval function!!!
function UIBase:VMsubscribe(list, vm)
    for k, v in pairs(list or {}) do
        local vmItem = vm[k]

        if type(v) == "table" then
            if vmItem then
                self:VMsubscribe(v, vmItem)
            end
        end

        if type(v) == "function" then
            if vmItem then
                vmItem.rx:subscribe(v)
            end
        end
    end
end

--显示UI
function UIBase:Show(args, callBack)
    local InitUI = function()
        _G.GRoot.inst:AddChild(self.mainCom)
        self.mainCom.fairyBatching = true
        --1 处理UI类型
        self.args = args
        self.callBack = callBack
        if self.args and self.args.targetUIType then
            self.uiType = self.args.targetUIType
        else
            self.uiType = _G.GlobalEmum.UIType.NormalUI
        end

        _G.UIController:PushToActiveUI(self)

        --2 处理控件
        self:ParseNode(self.mainCom)

        if type(self.BindUI) == "function" then
            self:BindUI()
        end
        self:Awake()

        if type(self.InitVM) == "function" then
            local vm = self:InitVM()
            _G.UIInjectController:InjectAfterInitVM(self, vm)
            self.vm = react(vm)
        end

        if type(self.InitBinds) == "function" then
            local bindList = self:InitBinds()
            for key, func in pairs(bindList or {}) do
                local vmItem = self.vm[key]
                if vmItem then
                    vmItem.rx:subscribe(func)
                end
            end
        end

        _G.UIInjectController:InjectAfterInitBinds(self)

        if type(self.InitEvents) == "function" then
            self:InitEvents()
        end

        self:Start()

        self:SetIntervalCallTimer(("%s_update"):format(self.uiName), function()
            if self.update and self.mainCom then
                if type(self.InitVM) == "function" then
                    local vm = self:InitVM()
                    _G.UIInjectController:InjectAfterInitVM(self, vm)
                    for k,v in pairs(vm) do
                        self.vm[k] = v
                    end
                end
                self.update = false
            end
        end, 0.01)
    end

    if not self.mainCom then
        _G.GameController.uiController:LoadCom(self.uiName, self.uiName, function(com)
            self.mainCom = com
            self.mainCom:MakeFullScreen()
            InitUI()
        end)
    else
        InitUI()
    end
end

--aNode:FGUI Element
function UIBase:ParseNode(aNode)
    if not aNode.asCom then
        return
    end
    if aNode.numChildren == 0 then
        return
    end

    for i = 1, aNode.numChildren do
        local csIdx = i - 1
        local child = aNode:GetChildAt(csIdx)
        --列表里的内容不处理
        if not child.asList then
            local button = child.asButton
            if button then
                self:ProcessButton(button, child.name)
            end

            self:ParseNode(child)
        end
    end
end

--处理按钮的用户数据
function UIBase:ProcessButton(button , buttonName ,  userArgs)
    if not button then
        return
    end

    --清除按钮之前的监听
    -- button.onClick:Clear()
    if not button.onClick.isEmpty then
        return
    end

    button.onClick:Set(function()
        print(string.format("点击按钮%s" , buttonName))

         --1 特殊处理每个按钮单独事件
        local callName = string.format("On%sClick" , buttonName)
        local func = self[callName]
        if func then
            func(self)
        end

        --2 处理用户数据
        if not userArgs then
            return
        end

        if not _G.string.IsNullOrEmpty(userArgs.targetUI) then
            local args = {}
            args.targetUIType = userArgs.targetUIType
            _G.UIController:ShowUI(userArgs.targetUI ,args)
        end
    end)
end

function UIBase:GetControl(controlPath, noLog)
    if not self.controlMap then
        self.controlMap = {}
    end

    if self.controlMap[controlPath] then
        return self.controlMap[controlPath]
    end

    local control
    if _G.table.size(_G.string.split(controlPath, ".")) > 0 then
        control =  self.mainCom:GetChildByPath(controlPath)
    else
        control = self.mainCom:GetChild(controlPath)
    end

    if (not control) and (not noLog) then
        _G.dump(string.format("找不到控件 %s" , controlPath))
    end
    self.controlMap[controlPath] = control
    return control
end

function UIBase:GetController(controllerName)
    if not self.controllerMap then
        self.controllerMap = {}
    end

    if self.controllerMap[controllerName] then
        return self.controllerMap[controllerName]
    end

    local controller = self.mainCom:GetController(controllerName)
    self.controllerMap[controllerName] = controller
    return controller
end

function UIBase:GetTransition(transitionName)
    if not self.transitionMap then
        self.transitionMap = {}
    end

    if self.transitionMap[transitionName] then
        return self.transitionMap[transitionName]
    end

    local transition = self.mainCom:GetTransition(transitionName)
    self.transitionMap[transitionName] = transition
    return transition
end

function UIBase:GetTransitionAt(transitionIdx)
    if not self.transitionIdxMap then
        self.transitionIdxMap = {}
    end

    if self.transitionIdxMap[transitionIdx] then
        return self.transitionIdxMap[transitionIdx]
    end

    local transition = self.mainCom:GetTransition(transitionIdx)
    self.transitionIdxMap[transitionIdx] = transition
    return transition
end

function UIBase:GetControlAt()
end


--当打开UI的生命周期
function UIBase:Awake()
end

--当打开UI的生命周期
function UIBase:Start()
    print(string.format("总共有%s个控件" , _G.table.size(self.controlMap)))
end

function UIBase:IsLoaded()
    return not not self.mainCom and self.mainCom.onStage
end

--隐藏界面
function UIBase:Hide()
    dump("Hide UI")
    if self.vm then
        self.vm:cleanUp()
    end

    _G.UIInjectController:InjectBeforeHide(self)

    --回掉lua脚本
    self:OnDestroy()

    --销毁ui
    if self.mainCom then
        _G.GRoot.inst:RemoveChild(self.mainCom)
        self.mainCom:Dispose()
        _G.GameController.uiController:TryRemovePackage(self.uiName)
    end

    --移除所有事件
    self:RemoveEventListener()
    --移除协程序
    for _, v in ipairs(self.coroutines or {}) do
        self:StopCoroutine(v)
    end

    --移除所有timer
    for _, key in ipairs(timerKeys[self.uiName] or {}) do
        TimerController:RemoveTimerEvent(key)
    end
    timerKeys[self.uiName] = nil

    self.controlMap = nil
    self.mainCom = nil
    self.controllerMap = nil
    self.transitionMap = nil
    self.transitionIdxMap = nil

    self.controlMap = nil
    self.mainCom = nil

    _G.UIController:RemoveFromActiveUI(self.uiName)
end

--摧毁界面
function UIBase:Close()
    _G.UIController:CloseAllUI()
end

--当关闭UI时的生命周期
function UIBase:OnDestroy()
end

--显示UI
function UIBase:LoadCom(comName , callBack)
     _G.GameController.UIController:LoadCom(self.uiName, comName, function(com)
        callBack(com)
    end)
end

--加载vm
function UIBase:TryLoadVM()
    if self.isWithVM then
        local luaScript = string.format("UIVM/%sVM" , self.uiName)
        self.vm = require(luaScript)
    end
end

--增加事件监听
function UIBase:AddEventListener(keys , callBack)
    if not self.regCallBacks then
        self.regCallBacks = {}
    end

    if type(keys) ~= "table" then
        keys = { keys }
    end

    for _, key in ipairs(keys) do
        if not self.regCallBacks[key] then
            self.regCallBacks[key] = callBack
            _G.event.add_listener(key, self , function(args)
                self.regCallBacks[key](args)
            end)
        end
    end
end


function UIBase:StartCoroutine(func)
    local coroutine = _G.StartCoroutine(func)

    if not self.coroutines then
        self.coroutines ={}
    end
    table.insert(self.coroutines, coroutine)
    return coroutine
end

function UIBase:StopCoroutine(coroutine)
    _G.StopCoroutine(coroutine)
end


--移除事件监听
function UIBase:RemoveEventListener()
    if not self.regCallBacks then
        return
    end

    for key, _ in pairs(self.regCallBacks) do
        _G.event.remove_listener(key ,self)
    end
    self.regCallBacks = nil
end

function UIBase:GetUISpineScale()
    local scaleX = 1/(_G.GRoot.inst.scaleX * _G.Stage.inst.scaleX)
    local scaleY = 1/(_G.GRoot.inst.scaleY * _G.Stage.inst.scaleY)
    return _G.Vector3(scaleX,scaleY,1)
end


function UIBase:SetIntervalCallTimer(className, call, interval, notSecond)
    if not interval then
        interval = 1
    end

    local isSecond = not notSecond
    if not timerKeys[self.uiName] then
        timerKeys[self.uiName] = {}
    end
    table.insert(timerKeys[self.uiName], className)
    TimerController:AddTimerEvent(className, call, isSecond, interval)
end

function UIBase:SetCallbackTimer(className, endCall, totalCount, notSecond)
    local isSecond = not notSecond
    if not timerKeys[self.uiName] then
        timerKeys[self.uiName] = {}
    end
    table.insert(timerKeys[self.uiName], className)
    TimerController:AddTimerEvent(className, endCall, totalCount, isSecond)
end

--:className@分类名字eg:builder_1
--:call@间隔调用
--:endCall@结束回调
--:totalTime@总时间
--:interval@时间间隔
--:notSecond@不是每秒调用
function UIBase:SetEngineTimer(className, call, endCall, totalTime, interval, notSecond)
    if not totalTime then
        _G.GameUtils.LogError("调用该函数，必须传入总时间（totalTime）")
        return
    end

    if not interval then
        interval = 1
    end
    local isSecond = not notSecond
    if not timerKeys[self.uiName] then
        timerKeys[self.uiName] = {}
    end
    table.insert(timerKeys[self.uiName], className)
    TimerController:AddTimerEvent(className, call, totalTime, endCall, interval, isSecond)
end

function UIBase:Refresh()
    self.update = true
end


return UIBase
