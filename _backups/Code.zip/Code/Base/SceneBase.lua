_G.SceneBase           = {}
local SceneBase        = _G.SceneBase

-- 基础类方法 new
function SceneBase:New(sceneName)
    self.__index = self
    self.sceneName = sceneName
    return setmetatable({}, self )
end

--加载场景
function SceneBase:LoadScene()
    _G.GameController.sceneController:LoadScene("Scenes/"..self.sceneName , function(isSuccess)
        if not isSuccess then
            return
        end

        self.camObj = _G.GameObject.Find("MainCamera")
        if self.camObj then
            self.cameraController = self.camObj:GetComponent(_G.CameraController)
        end
        self:OnLoad()
    end)
end

--加载场景
function SceneBase:GetMainCameraObj()
    return self.camObj
end

function SceneBase:GetCameraController()
    return self.cameraController
end

--完成加载
function SceneBase:OnLoad()
    -- print(_G.DataConfigManager.GetConst('TAB_HERO_OTHER5'))
end

--卸载场景
function SceneBase:Unload()
end

--Update
function SceneBase:OnUpdate()
end

return SceneBase