
local emptyFunc = function()
end

-------------------Global Var Manager-------------------------
local __G__ = _G
local __g = {}
_G.__g = __g

setmetatable(__g, {
    __newindex = function(_, name, value)
        rawset(__G__, name, value)
    end,

    __index = function(_, name)
        return rawget(__G__, name)
    end
})
local function DefineGVar(globalName, var, hotreload)

    if hotreload then
        if type(rawget(__G__, globalName)) == type(var) then
            return rawget(__G__, globalName)
        end
    end

    rawset(__G__, globalName, var)

    return var
end

DefineGVar("DefineGVar", DefineGVar)
-------------------Global Var Manager-------------------------

local function DisableGlobal ()
    setmetatable(__g, {
        __newindex = function(_, name, value)
            error(string.format("USE \" cc.exports.%s = value \" INSTEAD OF SET GLOBAL VARIABLE", name), 0)
            rawset()

        end
    })
end
-- DisableGlobal()

local isDebug = false
function _G.SafeCall(call, errorHandle)
    if isDebug then
        call()
    else
        errorHandle = errorHandle or emptyFunc
        xpcall(call, function(msg)
            errorHandle()
            _G.GameLog.LogError(debug.traceback(msg))
        end)
    end
end

function _G.SafeRequire(name)
    _G.SafeCall(function()
        require(name)
    end)
end

require("LuaExtend/stringex")
require("utility/mydebug")
--管理器
require "Controller/UIController"
require "Controller/UIInjectController"
_G.UIInjectController:Use(require "FUI/Plugin/CommonResPlugin")
require "Controller/SceneController"
_G.GameController = _G.EngineCore.GameController

-- require "tools/indexer"
-- require "Other/GlobalEmum"



local function InitGame()
    -- _G.LocalizationManager:SetLanguage(_G.GlobalEmum.LTType.CN)
    _G.GRoot.inst:SetContentScaleFactor(1920, 1080, _G.FairyGUI.UIContentScaler.ScreenMatchMode.MatchWidthOrHeight)
end

local function StartGame()
    _G.SceneController:LoadScene("SceneLogin")
end

local function InitModel()
    _G.Net:InitProto()
    _G.UIConfig.init()
    _G.GameManager:Init()
    ConfigTool:process_audio_config()
end

local function LoadConfig()
require 'EngineLua'
end

local function EngineBoot()
    local t1 = os.clock()
    StartGame()
    LoadConfig()
    InitGame()
    InitModel()
    local t2 = os.clock()
    print("diffTime=", t2-t1)
end

function OnUpdate(dt)
    -- print("dt",dt)
    if _G.SceneController then
        _G.SceneController:OnUpdate(dt)
    end
end

function lua_send_heart_beat()
    print("heart_Beat")
    _G.Net:SyncServerTime()
end

EngineBoot()
