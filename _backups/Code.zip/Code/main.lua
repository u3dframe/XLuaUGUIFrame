-- import "UnityEngine"
-- import "UnityEngine.UI"
_G.Database = require("Database")
require("Other/ConfigTool")
require "GameLua"
_G.FairyGUI = nil


local GameLog        = _G.GameLog
local Yield          = _G.Yield
local BootScreen     = _G.BootScreen
local WaitForSeconds = _G.WaitForSeconds
local GameUtil       = _G.GameUtil
local GameObject     = _G.GameObject
local StartCoroutine = _G.StartCoroutine
local lang           = _G.lang

function load_progress(cpn, value)
    cpn:SetProgress(value)
end

local config_list = {}

function add_config(file)
    table.insert(config_list, file)
end

local boot_screen

local function LoadConfig()
    boot_screen = BootScreen.GetInstance()

    local ret, msg = pcall(require, "resmng")
    if not ret then
        GameLog.LogError(string.format("load config failed: \n%s", msg))
    end

    local total = #config_list

    boot_screen:SetLabel("正在加载配置")

    for idx, mod in ipairs(config_list) do
        local ret, msg = pcall(require, mod)
        if not ret then
            GameLog.LogError(string.format("load config %s failed: \n%s", mod, msg))
        end

        if math.fmod(idx, 50) == 0 then
            boot_screen:SetProgress(0.1+idx/total*0.7)
            Yield()
        end
    end

    boot_screen:SetProgress(1)
    Yield()
    resmng.process_config_data()
    Yield()
    GameLog.Log("load config complete!")
end

local require_list = {}

function add_require(file)
    table.insert(require_list, file)
end

local function LoadRequire()
    local ret, msg = pcall(require, "require")
    if not ret then
        GameLog.LogError(string.format("load require failed: \n%s", msg))
    end

    local total = #require_list

    boot_screen:SetLabel("正在加载脚本")

    for idx, mod in ipairs(require_list) do
        local ret, msg = pcall(require, mod)
        if not ret then
            GameLog.LogError(string.format("load require %s failed: \n%s", mod, msg))
        end

        if math.fmod(idx, 50) == 0 then
            boot_screen:SetProgress(0.1+idx/total*0.7)
            Yield()
        end
    end

    boot_screen:SetProgress(1)
    Yield()

    GameLog.Log("load require complete!")
end

local function LoadUI()
    BootScreen.GetInstance():SetLabel("初始化UI")
    _G.UIConfig.init(function(v)
        boot_screen:SetProgress(v)
        Yield()
    end)
end

local function LoadGame(OnLoadDone)
    LoadConfig()
    Yield(WaitForSeconds(0.01))
    LoadRequire()
    Yield(WaitForSeconds(0.01))
    OnLoadDone()
end

local function InitGame()
    _G.Net.init_proto()
    _G.GameManager:Init()
end

function lua_send_heart_beat()
    _G.Net.send("ping",{any = 0},function(result)
        _G.Net:UpdateServerTime(result)
    end)
end

function lua_net_send(cmd, content)
    _G.Net.make_send(cmd, content)
end

function ui_image_localize(key)
    local language = resmng.local_language
    if language == resmng.default_language then
        return key
    end

    return string.format("%s_%s", key, language)
end

local function OnEscape()
    local msg_ = {
        mode=0,
        title = lang("UI_BASIC_HINT"),
        content = "是否重新登录",
        --buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")},
        callback = function()
           -- if index == 2 then
                StartCoroutine(function ()
                    Yield(WaitForSeconds(1))
                    GameManager:exit_to_clean()
                end)
           -- end
        end
    }
   -- MsgCenter.send_message(Msg.SHOW_NOTIFY,msg_)
    _G.UIController:ShowUI('UICommonPop', msg_)
end

local function StartGame()
    local co = coroutine.create(LoadGame)
    coroutine.resume(co, function()
        LoadUI()
        InitGame()
        Yield(WaitForSeconds(0.01))
        boot_screen:SetLabel("启动游戏")
        Yield(WaitForSeconds(0.01))
        GameUtil.RegisterEscapeHandler(OnEscape)
        GameManager:EnterLogin(function()
            GameObject.Destroy(boot_screen.gameObject)
        end)
    end)
end

StartGame()