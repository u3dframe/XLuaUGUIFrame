-- game_manager.lua
-- 游戏管理类
-- module("GameManager", package.seeall)
local GameManager = {}

local lang = _G.lang
GameManager.UI_Main = nil

function GameManager:Init()
    math.randomseed(os.time())
    AttrsManager:initialize()
    WorldManager:initialize()
    MasterManager:initialize()
    BuildManager:initialize()
    SoldierManager:initialize()
    CollectManager:initialize()
    PopupManager:initialize()
    ItemManager:initialize()
    MailManager:initialize()
    TimerManager:initialize()
    _G.BgmManager:initialize()
    HeroManager:initialize()
    RecruitManager:initialize()
    SkillManager:initialize()
    MessageQueueManager:Initialize()
    Net.register(self, 'game_over', self.OnGameOver)
    Net.register(self, 'chat_chating', self.on_chat_chating)

    _G.Model.InitLoginData()
end

function GameManager:OnLogined()
end

function GameManager:on_chat_chating(self)

end

function GameManager:EnterLogin(callback)
    _G.SceneManager.EnterLogin(function()
        self:OpenLogin(callback)
    end)
end

function GameManager:OpenLogin( callback)
    UIManager.open_window("LoginWindow", function()
        if callback then callback() end
    end)
end

--登陆成功
function GameManager:on_enter_main( _, callback)
    Net:SyncServerTime()
    self:OnLogined()

    SceneManager.enter_city(function()
        --创建主UI/唯一
        ResourcesManager.InstantiateGameObjectAsync("UI/Component/Common/Main", function(obj)
            local layer = UIManager.get_canvas().transform:Find(UIConfig.Layers[UIConfig.LayerType.Main])
            if Slua.IsNull(obj) then
                return
            end
            obj.transform:SetParent(layer, false)
            self.UI_Main = UIMain:new()
            self.UI_Main:AddLuaComponent(obj)
            self.UI_Main:init()

            local Role = _G.Model.GetModel("Role")
            dump(_G.Model.GetModel("Role"),"aidotank.Role")
            if callback then
                callback()
            end
        end)
    end)
    -- 保存配置，暂时写在这里 2019.8.28
    GameData.Save()
end

function GameManager:OnGameOver(msg)
    local msg_ = {}
    msg_.mode=0
    msg_.title = lang("UI_BASIC_HINT")
    msg_.content = "你被服务器主动踢下线了:" .. tostring(msg.why)
    local func = function()
        self:exit_to_clean()
    end
    msg_.cover_close = func
    msg_.callback = func
    _G.UIController:ShowUI('UICommonPop', msg_)
end

function GameManager:exit_to_clean()
    Net.disconnect_server()
    SceneManager.enter_clean(function()
        LuaTimer.DeleteAll()
        UIManager.close_window_all()
        _G.SceneController:UnloadAll()
        
        if _G.FairyGUI then
            _G.UIController.CloseAllUI()
        end
        UIManager.clear_cached_resource()
        if self.UI_Main then
            Object.Destroy(self.UI_Main.gameObject)
        end
    end)
end

_G.GameManager = GameManager
return GameManager