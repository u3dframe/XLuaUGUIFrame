

-- 网络通讯
--[[
require("net/net_require")
--工具
--
require("utility/coroutine")
require("utility/msg/messager")
require("utility/msg/msg")
require("utility/msg/msg_center")
require("utility/lua_utils")
require("utility/class")
require("utility/mydebug")
--]]

--基础
--
add_require("lua_component_base")
add_require("game_manager")



--数据类
add_require("data/object/world_obj_t")
add_require("data/object/world_monster_t")
add_require("data/object/world_main_t")
add_require("data/object/world_main_jump_t")
add_require("data/object/world_march_t")
add_require("data/object/world_fort_t")
add_require("data/object/world_respoint_t")
add_require("data/object/item_t")
add_require("data/object/mail_t")
add_require("data/object/city_build_space_t")
add_require("data/object/city_build_t")
add_require("data/object/city_soldier_t")
add_require("data/object/army_info_t")
add_require("data/object/city_collect_t")
add_require("data/object/timer_t")
add_require("data/object/attrs_t")
add_require("data/object/tips_t")
add_require("data/object/hero_t")
add_require("data/object/skill_t")
add_require("data/object/city_fete_t")
add_require("data/object/CityWall")

add_require("data/attrs_manager")
add_require("data/world_manager")
add_require("data/master_manager")
add_require("data/build_manager")
add_require("data/item_manager")
add_require("data/mail_manager")
add_require("data/soldier_manager")
add_require("data/popup_manager")
add_require("data/collect_manager")
add_require("data/timer_manager")
add_require("data/bgm_manager")
add_require("data/hero_manager")
add_require("data/recruit_manager")
add_require("data/skill_manager")
add_require("data/message_queue_manager")

add_require("ui/base/base_component")
add_require("ui/base/base_window")
add_require("ui/ui_util")
add_require("ui/ui_config")
add_require("ui/ui_manager")
add_require("ui/ui_main")

--场景相关
add_require("scene/base_scene")
add_require("scene/scene_manager")
add_require("scene/city/city_scene")
add_require("scene/world/world_scene")
add_require("scene/world/world_terrain_loader")
add_require("scene/world/world_build_tmp")
add_require("scene/world/world_ani_tmp")