local ConfigTool = {}
_G.ConfigTool = ConfigTool

local AudioConfig = _G.Database.AudioConfig
local LanguageConfig = _G.Database.LanguageConfig


function ConfigTool:propLanguageByKey(id, ...)
    local arg = {...}
    if #arg == 0 then
        return LanguageConfig.CnData[id] or id or "undefine"
    else
        return format_ex(LanguageConfig.CnData[id], unpack(arg))
    end
end

function ConfigTool.GetI18nText(id, ... )
    local count  = select('#', ...)
    if count == 0 then
        return LanguageConfig.CnData[id] or id or "undefine"

    end
    return string.strfmt(LanguageConfig.CnData[id], unpack(arg))
end

_G._lt = ConfigTool.GetI18nText

function ConfigTool:process_audio_config()
    local register = AudioManager.RegisterConfig 
    for id, prop in pairs(AudioConfig.AudioData) do
        register(prop.id, prop.respath, prop.cache==1)
    end
end


function ConfigTool:process_config_data()
    self:process_audio_config()
end
