local GlobalEmum = {}
local indexer = _G.Indexer.New()


--元素的类型
GlobalEmum.ElementType =
{
    "elementA","elementB" ,"elementC" ,"elementD" , "elementE"
}

GlobalEmum.UIType =
{
    Static        = "Static", --永远不会被关闭
    NormalUI      = "UI" ,    --不会受到Close影响
    Window        = "Window",--会随着Close事件而被销毁
}

GlobalEmum.LTType =
{
    CN = "cn",
    EN = "en",
}

--UIConfirmTips  弹窗类型
GlobalEmum.ConfirmPopType =
{
    confirm = 0,
    info    = 1,
    cost    = 2
}

GlobalEmum.MailType =
{
    MAIL_UNKNOW = 0,
    MAIL_ACTIVITY = 1,
    MAIL_SYSTEM = 2,
    MAIL_BATTLE = 3,
    MAIL_COLLECT = 4,
    MAIL_WARLORD = 5,
    MAIL_LEAGUE = 6,
    MAIL_ZOMBIE = 7,
}

_G.GlobalEmum = GlobalEmum