local EventKey         = {}

local indexer          = _G.Indexer.New()

---登陆
EventKey.LOGIN_SUCCESS = indexer()
EventKey.ENERGY_REFRESH = indexer()


EventKey.ITEM_CHANGE = indexer()    --物品变化
EventKey.RESOURCE_CHANGE = indexer()    --资源变化
EventKey.MAIL_CHANGE = indexer()    --邮件变化
EventKey.CITY_OVER = indexer()       --城池被摧毁
EventKey.UPDATE_CITY_WALL = indexer()  --更新城墙
EventKey.CITY_SOIDIER_UPDATE = indexer()  --更新士兵
EventKey.CITY_SOIDIER_FINISHED = indexer()  --士兵训练结束
EventKey.CITY_TRAP_CHANGE = indexer()  --陷阱变化
EventKey.CITY_BUILDING_SUCCEED = indexer() --建筑建造完成
EventKey.CITY_UP_LV_FINISHED = indexer() --建筑升级完成

EventKey.CITY_UP_LV_FINISHED = indexer()          --建筑升级完成
EventKey.CITY_SOLDIER_CURE_FINISHED = indexer()   --士兵治疗完成
EventKey.CITY_BUILD_REMOVED_FINISHED = indexer()  --建筑拆除完成
EventKey.CITY_REFRESH_QUEUE          = indexer()  --更新队列
EventKey.CITY_FETE_UPDATE            = indexer()  --祭坛更新
EventKey.CITY_STOP_TIMER2            = indexer()  --关闭计时器2
EventKey.CITY_RANDOM_SHOP_UPDATE     = indexer()  --随机商店更新
EventKey.CITY_WHARF_UPDATE           = indexer()  --市舶司更新
EventKey.CITY_WORLD_MARCH_BAR             = indexer() -- 战斗进度条
EventKey.CITY_WORLD_MARCH_END             = indexer() -- 出征结束
EventKey.RECRUIT_SET_MARK = indexer()              --设置招募寻访
EventKey.CITY_HERO_LVUP = indexer()                --武将等级提升
EventKey.CITY_HERO_STARUP = indexer()                --武将星级提升
EventKey.CHIP_EXCHANGE_SUCCESS = indexer()          --碎片兑换成功
EventKey.CITY_HERO_SKILL = indexer()          --英雄技能变更
EventKey.SKILL_BAG = indexer()          --技能背包变更
EventKey.WORLD_MARCH_DELETE = indexer()  --行军队列删除
EventKey.WORLD_FORT_DELETE  = indexer()  --势力据点删除
EventKey.WORLD_RESPOINT_DELETE=indexer()    --世界资源点删除
EventKey.WORLD_RESPOINT_REFRESH=indexer()    --世界资源点刷新

EventKey.SELECT_HERO_CONFIRM = indexer()   --英雄选择界面选择完成后刷新
_G.EventKey            = EventKey
