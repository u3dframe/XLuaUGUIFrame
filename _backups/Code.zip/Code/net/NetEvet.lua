local NetEvent = class("NetEvet")

local HandlerList    = {
    {
        protocolName = "role_object",
        modelName    = "Role",
        callbackName = "InitBasicInfo"
    },{
        protocolName = "role_object",
        modelName    = "Role",
        callbackName = "InitBasicInfo"
    }

}

-- Net.register(Role, "energy_change_one", Role.on_energy_change_one)

-- Net.register("energy_change_one", partial(Role.on_energy_change_one, Role))


-- for _, v in ipairs(HandlerList) do
--     local model = _G.Model.GetModel(v.modelName)
--     if model then
--         local callback = model[v.callbackName]
--         if callback then
--             _G.Net.register(model, v.protocolName, callback)
--         end
--     end
-- end
