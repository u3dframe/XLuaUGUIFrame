-- module("Net", package.seeall)
local Net         = {}
local Packet      = _G.Packet
local ResourcesManager   = _G.ResourcesManager
local GameUtil    = _G.GameUtil
local LanguageConfig = _G.Database.LanguageConfig
local GameManager = _G.GameManager
local TextAsset   = _G.TextAsset
local GameData = _G.GameData
local NetFilter = _G.NetTools.NetFilter
local json = require "Tools/dkjson"

NetFilter.luaSend = function (cmd, request)
    local msg = json.decode(request)
    Net.send(cmd, msg)
end

-- local lang = _G.lang

local NET_DISCONNECT = 0      -- 断开连接
local NET_CONNECTING = 1      -- 连接中
local NET_CONNECTED = 2       -- 接连成功

local sproto        = require "net/sproto"
local sender        = nil
local host          = nil
local callbacks     = {}
local handler_table = {}
local handler_owner = {}
local session       = 1
local session_name  = {}
local default_host  = 0
local default_ip    = "192.168.0.20"--"106.53.91.60"
local default_port  = 1024

function Net.register(owner, msgId, handler)
    dump(handler, msgId)
    if msgId then
        handler_table[msgId] = handler
        handler_owner[msgId] = owner
    end
end

function Net.init_proto(callback)
    Net.is_init = false
    Net.net_server = nil
    Net.connect_state = NET_DISCONNECT
    _G.ResourcesManager.LoadTextAssetAsync("DataFile/proto_c2s", function(prefab1)
        _G.ResourcesManager.LoadTextAssetAsync("DataFile/proto_s2c", function(prefab2)
            Net.is_init = true
            local c2s=sproto.parse(prefab1.text)
            local s2c=sproto.parse(prefab2.text)
            host=s2c:host "package"
            sender=host:attach(c2s)
            if callback then callback() end
        end)
    end)
end

function Net:InitProto(callback)
    self.is_init = false
    self.net_server = nil
    self.connect_state = NET_DISCONNECT
    local c2sTextAsset = _G.ResourcesManager.LoadTextAssetSync( "DataFile/proto_c2s"  )
    local s2cTextAsset = _G.ResourcesManager.LoadTextAssetSync( "DataFile/proto_s2c"  )
    Net.is_init = true
    local c2s=sproto.parse(c2sTextAsset.text)
    local s2c=sproto.parse(s2cTextAsset.text)
    host=s2c:host "package"
    sender=host:attach(c2s)
    if callback then
        callback()
    end
end


function Net:on_connect_server(ip, port, serverid, host1)
    host1 = host1 or default_host
    ip = ip or default_ip
    port = port or default_port

    if (nil == self.net_server) then
        -- 1代表同步消息，2代表异步
       self.net_server = _G.Server(1, serverid, true, _G.partial(self.network_handler, self))
       self.net_server:Activate()
       self.net_server.autoReconnect = true
    end
    self.net_server.serverID = serverid
    return self.net_server:Connect(host1, ip, port)
end

function Net:network_handler(packet)
    local bytes = Packet.GetBytesStringEx(packet)
    if #bytes ~= 0 then
        Net.dispatch(bytes)
    else
        local pack_type = Packet.GetType(packet)
        if not self.net_server.autoReconnect and pack_type == 2 then
            local msg_ = {}
            msg_.title = lang("UI_BASIC_HINT")
            msg_.content = "服务器已经重启"
            msg_.buttons = {lang("UI_BASIC_SURE")}
            msg_.callback = function()
                _G.StartCoroutine(function ()
                    Yield(WaitForSeconds(0.2))
                    _G.GameManager:exit_to_clean()
                end)
            end
            _G.MsgCenter.send_message(_G.Msg.SHOW_NOTIFY,msg_)
        end
        if self.connect_state == NET_CONNECTING then
            local accountId
            if _G.FairyGUI then
                accountId = _G.Account:GetRID()
            else
                accountId = tonumber(GameData.GetString("LoginAccount"))
            end
            Net.send("game_auth",{uid = accountId}, function(result)
                self.connect_state = NET_CONNECTED
            end)
        end
    end
end

function Net.dispatch(msg) -- 如果有illegal byte squence 错误用这个,平时用下面的
    local ok, err = pcall(Net.dispatch_inner, msg)
    if not ok then
        elog(err)
    end
end

function Net.dispatch1(msg) -- 收到消息派发handler
    return Net.dispatch_inner(msg)
end

function Net.error_tips(cmd, result)
    local e = result.e
    if e and e ~= 0 then
        local tips = result.m or lang(string.upper(cmd)..e)
        MsgCenter.send_message(Msg.SHOW_HINT, tips)
    end
end

function Net.dispatch_inner(msg)
    local type_, name, args, resp = host:dispatch(msg)
    if type_ == "RESPONSE" then--客户端请求返回
        local session, result = name, args
        if NetFilter.open then
            NetFilter.response({session = session, response = json.encode(args)})
        end

        local cb = callbacks[session]
        callbacks[session] = nil
        dump(args, string.format("<color=green>%s</color>:receiver Result data from Server", name) )
        if not cb then
            return
        end
        local cmd = session_name[session]
        session_name[session] = nil
        local str = string.format("<color=red>s->c: %s %s</color>", cmd, Net.make_data(result))
        GameUtil.PrintNetLog(str, 2)
        local noTips = cb(result)
        if not noTips then
            Net.error_tips(cmd, result)
        end
    else--服务器请求或者推送s2c
        if NetFilter.open then
            NetFilter.response({name = name, session = 0, response = json.encode(args)})
        end

        local handlerFunc = handler_table[name]
        if handlerFunc then
            -- resp用与服务器主动请求客户端数据，推送是没有的resp
            if resp then
                dump(args, string.format("<color=green>%s</color>:receiver Result data from Server", name) )
            else
                dump(args, string.format("<color=green>%s</color>:receiver Push data from Server", name))
            end
            local owner = handler_owner[name]
            if owner then
                handlerFunc(owner, args, resp)
            else
                handlerFunc(args, resp)
            end
            local str = string.format("<color=red>s->c: %s %s</color>", name, Net.make_data(args))
            GameUtil.PrintNetLog(str, 2)
        else
            local str = string.format("findn't %s function, pls check Net.register(self, '%s', on_%s)", name, name, name)
            elog(str)
        end
    end
end

function Net.response(resp,result)--返回服务器主动请求数据 resp及是26行的resp
    --socket.send(pack(resp(result)))
    local packet = Packet(0)
    packet:CopyBlock(Net.pack(resp(result)))
    Net.net_server:Send(packet)
end

function Net.pack(result) --大端编码 --2字节包长度+包内容
    return string.pack(">s2", response(result))
end

-- 生成消息
function Net.make_send(cmd, content)
    local data = split_date(content)
    Net.send(cmd, data)
end

-- string -> table
function Net.split_date(content)
    local data = {}
    local num1 = string.find(content, '{')
    local num2 = string.find(content, '}')
    local str = string.sub(content, num1+1, num2-1)
    return loadstring("return  "..content)()
end

-- table -> string
function Net.make_data(data)
    if not data then return "{}" end
    local str_tmp = "{"
    for k,v in pairs(data) do
        local v_str = v
        if type(v_str) == "table" then
            v_str = Net.make_data(v)
        end
        local str_child
        if type(k) == "number" then
            str_child = "["..tostring(k).."] = "..tostring(v_str)
        else
            str_child = tostring(k).." = "..tostring(v_str)
        end
        if str_tmp == "{" then
            str_tmp = str_tmp..str_child
        else
            str_tmp = str_tmp..","..str_child
        end
    end
    str_tmp = str_tmp.."}"
    return str_tmp
end

function Net.send(cmd, data, successCallback, failedCallback)
    session=session+1
    session_name[session] = cmd
    local packet = Packet(0)
    packet:CopyBlock(Net.pack(sender(cmd, data, session)))
    Net.net_server:Send(packet)
    if successCallback then
        callbacks[session]=successCallback
    end
    -- 编辑日志开始
    if cmd ~= "ping" then
        local str = string.format("<color=green>c->s: %s %s</color>", cmd, Net.make_data(data))
        print(str)
        GameUtil.PrintNetLog(str, 1)
    end
    -- 编辑日志结束
    if NetFilter.open then
        NetFilter.request({
           name    = cmd,
           session = session,
           request = json.encode(data)
        })
    end
end
--连接断开的时候需要清空callback，防止泄露
function Net.on_disconnect()
    callbacks={}
end

-- 提供逻辑调用
function Net.reconnect_server()
    Net.net_server:Disconnect()
    Net.on_disconnect()
    _G.LuaTimer.Add(1000, function()
        Net.net_server:Reconnect()
    end)
end

-- 提供逻辑调用 Net.reconnect_server()
function Net.disconnect_server()
   Net.net_server:Disconnect()
   Net.net_server:Deactivate()
   Net.net_server = nil
   Net.on_disconnect()
   Net.connect_state = NET_DISCONNECT
end

-- 提供逻辑调用
function Net:connect_server(ip, port, serverid)
    if not self.is_init then
        print("init proto failed, pls check DataFile/proto_c2s or DataFile/proto_s2c")
        return
    end
    if self.connect_state == NET_CONNECTING then
        if self.net_server and not self.net_server.Connected then
           self.disconnect_server()
        end
    end
    if self.connect_state == NET_DISCONNECT then
        self.connect_state = NET_CONNECTING
       return self:on_connect_server(ip, port, serverid)
    end
end

function Net:SyncServerTime()
    self.server_time_delta = 0
    Net.send("ping", {any = 0}, function(result)
        self:UpdateServerTime(result)
    end)
end

function Net:UpdateServerTime(result)
    if not result then return end
    if not result.ti then return end
    self.server_time_delta = result.ti - os.time()
end

function Net.server_time()
    return os.time() + (Net.server_time_delta or 0)
end

_G.Net = Net
return Net
