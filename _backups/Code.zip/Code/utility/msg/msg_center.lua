-- 消息管理中心，全局唯一，用于系统间互相通信
module("MsgCenter", package.seeall)

--消息载体池
Messagers = Messagers or {}

--添加消息关联
function add_messager(msg_name, msgr)
    local msgs = Messagers[msg_name]
    if not msgs then
        Messagers[msg_name] = {}
        table.insert(Messagers[msg_name],msgr)
    else
        for i = #msgs, 1, -1 do
            if msgs[i].id_ == msgr.id_ then
                return
            end
        end
        table.insert(Messagers[msg_name], msgr)
    end
end

--移除组件全部消息关联
function remove_all_messager(msgr)
    if not msgr  then
        return
    end

    for k,v in pairs(msgr.listeners_ or {}) do
        local msgs = Messagers[k]

        for i = #msgs, 1, -1 do
            if Messagers[k][i].id_ == msgr.id_ then
                table.remove(Messagers[k], i)
                break
            end
        end
    end
end

--移除组件指定消息关联
function remove_messager(msgr, msg_name)
    local msgs = Messagers[msg_name]

    if not msgs then
        return
    end

    for i = #msgs, 1, -1 do
        if msgs[i].id_ == msgr.id_ then
            table.remove(msgs, i)
            break
        end
    end
end

--发送消息
function send_message(msg_name, ...)
    local msgrs = Messagers[msg_name]
    if not msgrs then
        return
    end
    local count = #msgrs
    for i = #msgrs, 1, -1 do
        if msgrs[i] and msgrs[i].owner_ then
            msgrs[i]:receive_message(msg_name, ...)
        end
    end
end

