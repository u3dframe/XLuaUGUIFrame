-- 消息发送器
module("Messager", package.seeall)

--消息器实例计数
id = 0

function new(self, owner)
    local obj = {}
    setmetatable(obj, {__index = self})
    id = id + 1
    obj.id_ = id
    obj.owner_ = owner
    obj.listeners_ = {}
    return obj
end

--添加一个监听器
function add_listener(self, msg_name, callback)
    if msg_name and msg_name ~= "" and callback then
        self.listeners_[msg_name] = self.listeners_[msg_name] or {}
        table.insert(self.listeners_[msg_name], callback)
        MsgCenter.add_messager(msg_name, self)
    end
end

--移除一个监听器
function remove_listener(self, msg_name)
    if self.listeners_[msg_name] then
        self.listeners_[msg_name] = nil
        MsgCenter.remove_messager(self, msg_name)
    end
end

-- 他不需要发送, 2019.08.04 cz
--function send_message(self, msg_name, data)
--    MsgCenter.send_message(msg_name, data)
--end

function receive_message(self, msg_name, ...)
    if self.listeners_[msg_name] then
        for _, callback in ipairs(self.listeners_[msg_name]) do
            if self.owner_ then
                callback(self.owner_, ...)
            end
        end
    end
end

function dispose(self)
    MsgCenter.remove_all_messager(self)
    self.owner_ = nil
    self.listeners_ = {}
end
