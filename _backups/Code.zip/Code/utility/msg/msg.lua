--UI消息定义
module("Msg",package.seeall)

----------------------------------------------------------------------------
-- 消息ID定义规范，分为基础类、UI类、主城类、大地图类等，根据各个功能对号入座
-- 基础类 1-10000
----------------------------------------------------------------------------
REFRESH_MASTER_USER = 1     -- 玩家身上数据有改变
SCENE_UPDATE = 100
SHOW_HINT = 101
SHOW_NOTIFY = 102
SHOW_BUILD_LV_UP = 103
ITEM_CHANGE = 110
RESOURCE_OR_COIN_CHANGE = 111
ENERGY_REFRESH = 112        -- 体力刷新
ENERGY_CHANGE = 113         -- 体力改变
RESPOINT_REFRESH = 114      -- 资源采集点刷新
SHOW_GOLD_NOTIFY = 115      -- 显示带有金币显示的提示窗口
SKILL_CHANGE = 130          -- 技能改变
UI_SKILL_CHANGE = 131       -- 技能改变，用于实时更新UI


----------------------------------------------------------------------------
-- UI类 10001-20000
----------------------------------------------------------------------------
POPUP_WINDOW = 10001        -- 弹个窗口
SHOW_UI_TIPS = 10002        -- 弹tips

MAIL_ADD = 11001            --新增邮件
MAIL_DEL = 11002            --删除邮件
MAIL_READ = 11003           --读邮件
MAIL_GAIN_REWARDS = 11004   --邮件获取奖励

TOP_BANNER_REWARDS_ANI = 11100  --top banner 获得奖励动画

RECRUIT_INFO_ALL = 11200        -- 招募信息更新
RECRUIT_FREE_SUCCESS = 11201    -- 免费招募成功
RECRUIT_ONE_SUCCESS = 11202     -- 招募一次成功
RECRUIT_TEN_SUCCESS = 11203     -- 招募十次成功
RECRUIT_SET_MARK = 11204        -- 招募设置寻访

UI_HERO_INFO = 11300            -- UI英雄信息更新


----------------------------------------------------------------------------
-- 主城类 20001-30000
----------------------------------------------------------------------------
CITY_HIDE_UI_ALL             = 20001 --隐藏主界面的UI
CITY_BUILDING_SUCCEED        = 20002 --建造成功
CITY_UP_LV_UPDATE            = 20003 --升级建造更新
CITY_UP_LV_FINISHED          = 20004 --升级建造完成
CITY_GOLD_UP_LV              = 20005 --金币建造升级（不参与队列）
CITY_SOIDIER_UPDATE          = 20006 --训练时间更新
CITY_SOIDIER_FINISHED        = 20007 --训练完成
CITY_SOLDIER_CURE_UPDATE     = 20008 --更新治疗倒计时
CITY_SOLDIER_CURE_FINISHED   = 20009 --治疗完成
CITY_COLLECT_FINISHED        = 20010 --收集资源完成
CITY_COLLECT_REFRESH         = 20011 --收集资源刷新
CITY_COLLECT_ANI             = 20012 --收集动画
CITY_QUEUE_UPDATE            = 20013 --更新队列
CITY_BUILD_REMOVED_FINISHED  = 20014 --建筑拆除完成
CITY_BUILD_REMOVED_CANCEL    = 20015 --取消建筑拆除
CITY_SHOW_CAN_EXCHANGE_BUILD = 20016 --显示可以交换的建筑
CITY_BUILD_MOVE_FINISHED     = 20017 --建筑移动完成
CITY_HERO_LVUP               = 20018 --武将一键升级
CITY_RANDOM_SHOP_UPDATE      = 20019 --随机商店刷新
CITY_FETE_UPDATE             = 20020 --更新祭祀建筑
CITY_WHARF_UPDATE            = 20020 --刷新市舶司表现
CITY_WALL_UPDATE             = 20021 --刷新城墙
CITY_OVER                    = 20022 --城池被摧毁
CITY_REBUILD                 = 20023 --城池重建
CITY_STOP_TIMER2             = 20024 --停止倒计时

----------------------------------------------------------------------------
-- 大地图类 30001-40000
----------------------------------------------------------------------------

WORLD_MARCH_START               = 30001 -- 出征开始
WORLD_MARCH_RETURN              = 30002 -- 出征返程
WORLD_MARCH_END                 = 30003 -- 出征结束
WORLD_MARCH_RESULT              = 30004 -- 战斗结算
WORLD_MARCH_BAR                 = 30005 -- 战斗进度条
WORLD_DELETE_OBJ                = 30006 -- 删除世界地图物件
WORLD_REFRESH_OBJ               = 30007 -- 刷新世界地图物件
WORLD_ENABLE_WATCH              = 30008 -- 可刷新当前大地图范围数据
WORLD_CLEAR_MENU                = 30009 -- 清除世界菜单
WORLD_CLEAR_MARCH_MENU          = 30010 -- 清除世界行军线菜单
WORLD_CLEAR_JOURNEY_MENU        = 30011 -- 清除世界行军队伍跟随及菜单
WORLD_JUMP_JOURNEY              = 30012 -- 跳转世界部队
WORLD_ENABLE_WATCH2             = 30013 -- 可刷新当前大地图范围数据提供坐标
WORLD_MARCH_DELETE              = 30014 -- 行军队列删除
WORLD_FORT_DELETE               = 30015 -- 势力据点删除
WORLD_FORT_REFRESH              = 30016 -- 势力绝点数据变化即刷新
WORLD_DELETE_OBJ_BUILD          = 30017 -- 删除世界地图建筑数据
WORLD_RESPOINT_REFRESH          = 30018 -- 资源点数据变化即刷新
WORLD_ENABLE_WATCH_CB           = 30019 -- 世界坐标跳转完成
WORLD_RESPOINT_DELETE           = 30020 -- 资源点删除
WORLD_MENU_SHOW_UPDATE          = 30021 -- 世界菜单表现有变动
WORLD_FORT_OWNER_HIDE           = 30022 -- 隐藏势力据点占据的ICON
