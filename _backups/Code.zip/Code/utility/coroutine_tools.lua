module("CoroutineTools", package.seeall)

local co_dict = {}
local func_dict = {}

function WaitForSeconds( sec )
	sec = sec * 1000
	local co = coroutine.running()
	-- Timer的单位为毫秒
	co_dict[co] = LuaTimer.Add(sec, function()
		coroutine.resume(co)
	end)
	coroutine.yield()
end

function StartCoroutine( func, ... )
	if coroutine.running() then
		WaitForSeconds(0)
	end

	local co = coroutine.create( func )
	func_dict[func]=co
	coroutine.resume(co, ...)
	return co
end

function StopCoroutine( func )
	local co = func_dict[func]
	if co then
		local timer_id = co_dict[co]
		if timer_id then
			LuaTimer.Delete(timer_id)
			co_dict[co] = nil
		end
		func_dict[func] = nil
	end
end

function StopAllCoroutines()
	for co, timer_id in pairs(co_dict) do
		if timer_id then
			LuaTimer.Delete(timer_id)
		end
	end
	co_dict = {}
	func_dict = {}
end

function Sync(func)
    return function(...)
        local co

        local arg = {...}
        local len = select("#", ...) + 1
        arg[len] = function(...)
            if co == nil then
                co = {...}
            else
                coroutine.resume(co, ...)
            end
        end

        func(unpack(arg, 1, len))

        if co then
            return unpack(co)
        end

        co = coroutine.running()
        return coroutine.yield()
    end
end
