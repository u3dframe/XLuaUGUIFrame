import "UnityEngine"
import "UnityEngine.UI"



_G.Application          =  _G.UnityEngine.Application
_G.Mathf                =  _G.UnityEngine.Mathf
_G.Vector2              =  _G.UnityEngine.Vector2
_G.Vector3              =  _G.UnityEngine.Vector3
_G.GameObject           =  _G.UnityEngine.GameObject
_G.Input                =  _G.UnityEngine.Input
_G.Object               =  _G.UnityEngine.Object
_G.Camera               =  _G.UnityEngine.Camera
_G.Quaternion           =  _G.UnityEngine.Quaternion


_G.Database = require("Database")
-- 网络通讯
SafeRequire("net/net")

--Tools
require("tools/fun")()
require("tools/CoController")

require "tools/list"
require "tools/fclass"
require "tools/event"
require "tools/FairyGUI"
require "tools/indexer"
require "Other/EventKey"

require("Other/ConfigTool")
require("common/define")
require("common/tools")

--工具
require("utility/coroutine")
require("utility/msg/messager")
require("utility/msg/msg")
require("utility/msg/msg_center")
require("utility/lua_utils")
require("utility/class")

require("LuaExtend/functionex")
require("LuaExtend/tablex")
require("LuaExtend/mathex")

require("model/Model")

require("lua_component_base")
require("game_manager")


--数据类
require("data/object/world_obj_t")
require("data/object/world_monster_t")
require("data/object/world_main_t")
require("data/object/world_main_jump_t")
require("data/object/world_march_t")
require("data/object/world_fort_t")
require("data/object/world_respoint_t")
require("data/object/item_t")
require("data/object/mail_t")
require("data/object/city_build_space_t")
require("data/object/city_build_t")
require("data/object/city_soldier_t")
require("data/object/army_info_t")
require("data/object/city_collect_t")
require("data/object/timer_t")
require("data/object/attrs_t")
require("data/object/tips_t")
require("data/object/hero_t")
require("data/object/skill_t")
require("data/object/CityWall")
require("data/object/RandomShop")

require("data/attrs_manager")
require("data/world_manager")
require("data/master_manager")
require("data/build_manager")
require("data/item_manager")
require("data/mail_manager")
require("data/soldier_manager")
require("data/popup_manager")
require("data/collect_manager")
require("data/timer_manager")
require("data/bgm_manager")
require("data/hero_manager")
require("data/skill_manager")
require("data/recruit_manager")
require("data/message_queue_manager")

require("ui/base/base_component")
require("ui/base/base_window")
require("ui/ui_util")
-- require("ui/ui_config")
require("ui/UIConfig")
require("ui/ui_manager")
require("ui/ui_main")

--场景相关
require("scene/base_scene")
require("scene/scene_manager")
require("scene/city/city_scene")
require("scene/world/world_scene")
require("scene/world/world_terrain_loader")
require("scene/world/world_build_tmp")
require("scene/world/world_ani_tmp")

_G.Account = require("Model/Account")
_G.Account:Init()




--[[
--管理器
require "Controller/UIController"
require "Controller/UIInjectController"
_G.UIInjectController:Use(require "FUI/Plugin/CommonResPlugin")
require "Controller/SceneController"
--]]

require "tools/indexer"
require "Other/GlobalEmum"



--[[
_G.Net     = _G.Net
_G.GameLog = _G.GameLog
_G.Yield   = _G.Yield
_G.XEase   = _G.XEase

--]]

