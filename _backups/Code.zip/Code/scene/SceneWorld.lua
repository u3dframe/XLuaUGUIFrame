local tiny      = require("Tools/tiny")
local SceneWorld = _G.SceneController:Get("SceneWorld")

function SceneWorld:OnLoad()
    self.world = tiny.world(unpack({
        require("System/WorldInputSystem"):create(1),
    }))

    self.activeWorld = self.mainWorld

    WorldManager:build_world_obj()
    WorldManager:init_watch_pos()

    MsgCenter.send_message(_G.Msg.SCENE_UPDATE)

    _G.UIController:Get("UIMain"):SwitchSceneState(true)
    _G.UIController:Get("UILoading"):FadeOut()
end

function SceneWorld:Unload()
    if self.activeWorld then
        tiny.dispose(self.activeWorld)
    end
end

function SceneWorld:OnUpdate(dt)
    if self.activeWorld then
        tiny.update(self.activeWorld, dt)
    end
end