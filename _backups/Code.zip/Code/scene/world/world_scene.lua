-- 世界场景，操作管理、拖拽、点击
module("WorldScene",package.seeall)
setmetatable( WorldScene, {__index = BaseScene})


Max_Base_X = 33
Max_Base_Z = 33

-- Old
-- FIELDOFVIEW_MIN = 10.5
-- FIELDOFVIEW_MAX = 18.5
FIELDOFVIEW_MIN = 7
FIELDOFVIEW_MAX = 22

Layer_Mask_World_Base       = 32768     -- 1<<15
Layer_Mask_World_Terrain    = 65536     -- 1<<16
Layer_Mask_World_Logic      = 262144    -- 1<<18
Layer_Mask_World_Build      = 524288    -- 1<<19
Layer_Mask_World_Ani        = 1048576   -- 1<<20
Layer_Mask_World            = 4194304   -- 1<<22

-- 设置边缘点
MAP_TOP_VECTEX = Vector3(0, 30, -100.8)
MAP_BOTTOM_VECTEX = Vector3(0, 30, -2364.59)
MAP_LEFT_VECTEX = Vector3(-1132, 30, -1232.8)
MAP_RIGHT_VECTEX = Vector3(1132, 30, -1232.8)
MAP_CENTER = Vector3(0, 30, -1232.8)

function on_awake(self)
    self.world_map_ = GameObject.Find("WorldMap").transform
    self.animation_ = self.world_map_:Find("Animation")
    self.scroll_camera_ = self.world_map_.gameObject:GetComponent(EasyTouchEvent)
    self.scroll_base_ = self.world_map_:Find("Base")
    self.scroll_logic_ = self.world_map_:Find("LogicBox")

    self.screen_half_height_ = Screen.height / 2
    self.screen_half_width_ = Screen.width / 2
    self.inertial_acceleration_ = 5000
    self.min_inertial_speed_ = 5
    self.max_inertial_speed_ = 30

    self.scroll_camera_.OnETTouchDown = function(ge)
        if self.move_camera_ then
            self.move_camera_state_ = true
        end
    end
    self.scroll_camera_.OnETTouchUp = function(ge)
        if self.move_camera_state_ then
            self.move_camera_ = false
        end
        self.move_camera_state_ = false
    end
    
    self.scroll_camera_.OnETTouchStart = function(ge)
        self:on_et_touch_start(ge)
    end

    self.scroll_camera_.OnETDrag = function(ge)
        self:on_et_drag(ge)
    end
    self.scroll_camera_.OnETDragEnd = function(ge)
        self:on_et_drag_end(ge)
    end

    self.scroll_camera_.OnETPinch = function(ge)
        self:on_et_pinch(ge)
    end

    self.scroll_camera_.OnETPinchEnd = function(ge)
        self:on_et_pinch_end(ge)
    end
    
    self.scroll_camera_.OnETSimpleClick = function(ge)
        self:on_et_click(ge)
    end
    
    if _G.FairyGUI then
        self.ui_main_ = _G.UIController:Get("UIMain")
    else
        self.ui_main_ = GameManager.UI_Main
    end
    self.ui_camera_ = UIManager.get_camera()
    self.screen_size_ = UIManager.get_canvas_size()
    self.goto_go_ = self.world_map_.transform:Find("Goto")
    WorldTerrainLoader:init(self.world_map_)
    
    self.messager_ = Messager:new(self)
    self.messager_:add_listener(Msg.WORLD_CLEAR_MENU, on_clear_menu)
    self.messager_:add_listener(Msg.WORLD_CLEAR_MARCH_MENU, on_clear_arrow_menu)
    self.messager_:add_listener(Msg.WORLD_CLEAR_JOURNEY_MENU, on_clear_journey_menu)
    self.messager_:add_listener(Msg.WORLD_JUMP_JOURNEY, on_jump_journey)
    self.messager_:add_listener(Msg.WORLD_ENABLE_WATCH_CB, on_goto_axis_complete)
end

function on_resource(self)
    local list = {
        "Model/World/Base/Materials/caodi_01",
        "Model/World/Base/Materials/caodi_02",
        "Model/World/Base/Materials/caodi_03",
        "Model/World/Base/Materials/caodi_04"
    }
    self.mats_ = {}
    Yield(ResourcesManager.LoadObjectMultiAsync(list, function(mats)
        for i=1,4 do
            self.mats_[i] = mats[i]
        end
    end))
    Yield(ResourcesManager.LoadObjectAsync("Model/World/Common/select", function(go)
        Select_Go = GameObject.Instantiate(go)
        Select_Go.name = "select_go"
        local sr = Select_Go.transform:Find("sprite"):GetComponent(SpriteRenderer)
        --GameTween.DOFade(sr, 0.6, 0.6):SetEase(XEase.Linear):SetLoops(-1, XLoopType.Yoyo)
    end))
    local list_com = {
        "Common/WorldMenu",
    }
    Yield(UIUtil.load_component(list_com, function(prefabs) 
        self.world_menu_prefab_ = prefabs[1]
        self:init_world_menu()
    end))
    Yield(WorldBuildTmp:init())
    Yield(WorldAniTmp:init())
    self:init_base_offset(2, 2)
end

-- 这个是批量生产地表的调试代码，误删
function init_logic_local(self)
    local logic_box = self.world_map_.transform:Find("LogicBox")
    ResourcesManager.LoadObjectAsync("Model/World/Common/LogicCellClone", function(go)
        local go_tmp = GameObject.Instantiate(go)
        go_tmp.transform:SetParent(logic_box, false)
        local child_go_prefab = go_tmp.transform:Find("select").gameObject
        for i=1,25 do
            for j=1,25 do
                local child_go = GameObject.Instantiate(child_go_prefab)
                child_go.transform:SetParent(go_tmp.transform, false)
                child_go.transform.localPosition = Vector3((i-1)*2, 0, -(j-1)*2)
                child_go.name = string.format("select{%d}{%d}}", i, j)
            end
        end        
    end)
end

function on_start(self)
    self.main_camera_ = Camera.main
    local x,z = WorldManager:get_my_build_logic_axis()
    self:goto_axis(x, z)
end

function on_dispose(self)
    self.is_complete_ = false
    Select_Go = nil
    WorldTerrainLoader:on_dispose()
    WorldBuildTmp:on_dispose()
    WorldAniTmp:on_dispose()
    WorldManager:on_dispose()
end

function checked_camera_position(self, position)
    if position.x < MAP_LEFT_VECTEX.x then
        return MAP_LEFT_VECTEX
    elseif position.x > MAP_RIGHT_VECTEX.x then
        return MAP_RIGHT_VECTEX
    end
    local s1
    local angle
    if position.z > MAP_CENTER.z then
        s1 = MAP_TOP_VECTEX
        local v = position - s1
        angle = Vector2.SignedAngle(Vector2(v.x, v.z), Vector2.right)
    else
        s1 = MAP_BOTTOM_VECTEX
        local v = position - s1
        angle = Vector2.SignedAngle(Vector2.right, Vector2(v.x, v.z))
    end
    if angle >= 45 and angle <= 135 then return position end
    local s2 = position.x > MAP_CENTER.x and MAP_RIGHT_VECTEX or MAP_LEFT_VECTEX
    local start1 = Vector2(s1.x, s1.z)
    local end1 = Vector2(s2.x, s2.z)
    local start2 = Vector2(position.x, position.z)
    local end2 = start2 + Vector2.up
    local pos_2d = UIUtil.get_cross_point(start1, end1, start2, end2)
    local new_pos = Vector3(pos_2d.x, position.y, pos_2d.y)
    return new_pos
end

function on_et_touch_start(self, gesture)
    if self.camera_inertial_tween_ then
        self.camera_inertial_tween_:Kill(false)
    end
end

function on_et_drag(self, gesture)
    if self.move_camera_ then return end
    if gesture.deltaPosition == Vector2.zero then return end
    local pos = self.main_camera_.transform.position
    
    local factorX = self.main_camera_.fieldOfView/self.screen_half_width_ * 0.67
    local factorY = self.main_camera_.fieldOfView/self.screen_half_height_ * 0.67
    local offset = -Vector3(gesture.deltaPosition.x*factorX, 0, gesture.deltaPosition.y*factorY)
    
    -- 将当前鼠标的屏幕坐标转换成世界坐标，再加上两者间的距离
    self.main_camera_.transform.position = self:checked_camera_position(pos + offset) 
    self.drag_velocity_ = Vector2(-gesture.deltaPosition.x / Time.deltaTime * factorX, -gesture.deltaPosition.y / Time.deltaTime * factorY) 
    if self.drag_velocity_.sqrMagnitude > self.max_inertial_speed_ * self.max_inertial_speed_ then
        self.drag_velocity_ = self.drag_velocity_.normalized * self.max_inertial_speed_
    end
    self:on_et_drag_move(false)
end

function on_et_drag_end(self, gesture)
    if not self.drag_velocity_ then return end
    local drag_speed = self.drag_velocity_.magnitude
    if drag_speed <= self.min_inertial_speed_ then
        MsgCenter.send_message(Msg.WORLD_ENABLE_WATCH, self.cur_logic_name_, self.cur_base_name_)
        return
    end
    local inertial_acceleration = self.inertial_acceleration_ * self.main_camera_.orthographicSize / self.screen_half_height_
    local inertial_time = drag_speed / inertial_acceleration
    local pos = self.main_camera_.transform.position
    local a = -self.drag_velocity_.normalized * inertial_acceleration
    local max_s = self.drag_velocity_ * inertial_time + a * inertial_time * inertial_time * 0.5
    max_s.y = max_s.y / math.sin(self.main_camera_.transform.eulerAngles.x * math.pi / 180)
    self:on_et_drag_move(true)
    self.camera_inertial_tween_ = GameTween.DOMove(self.main_camera_.transform, 
                                                   pos + Vector3(max_s.x, 0, max_s.y),
                                                   inertial_time, 
                                                   false):OnUpdate(
        function()
            local new_pos = self.main_camera_.transform.position
            self.main_camera_.transform.position = self:checked_camera_position(new_pos)
            self:on_et_drag_move(false)
        end
    )
    
    self.camera_inertial_tween_:SetEase(XEase.OutQuad)
    self.camera_inertial_tween_:OnComplete(
		function() 
			MsgCenter.send_message(Msg.WORLD_ENABLE_WATCH, self.cur_logic_name_, self.cur_base_name_)
		end)
end

function on_et_drag_move(self, isEnd)
    if not self:is_alive() then return end
    
    local ray = self.main_camera_:ScreenPointToRay(Vector3(Screen.width / 2, Screen.height / 2, 0))
    local hit_point_base = Physics.RaycastAll(ray, 1000, Layer_Mask_World_Base)
    if hit_point_base and hit_point_base.Length > 0 then
        local map_ceil = hit_point_base[1].transform
        if map_ceil.gameObject.name ~= self.cur_base_name_ then
            self:check_grid_change(map_ceil.gameObject.name)
            self:set_cur_base_name(map_ceil.gameObject.name)
        end
    end
    local map_ceil = self:get_map_ceil_by_screen_position(Vector2(Screen.width / 2, Screen.height / 2))
    if map_ceil and map_ceil.gameObject.name ~= self.cur_logic_name_ then
        self:set_cur_logic_name(map_ceil)
    end
    if self.ui_main_ then
        self.ui_main_:updata_track_position_ex()
    end
    if self.move_camera_ then return end
    
    if isEnd then
        self:clear_world_menu(true)
    elseif self.world_menu_ and self.world_menu_.gameObject.activeSelf then
        if self.world_menu_.obj_ and self.world_menu_.obj_.obj_type_ == config.WORLD_MARCH then
            local march_id = self.world_menu_.obj_.idx_
            local obj = self.animation_.transform:Find(tostring(march_id).."/point")
            self:set_world_menu_axis_by_postion(obj)
        else
            self:set_world_menu_axis()
        end
    end
end

function get_map_ceil_by_screen_position(self, screen_pos)
    local radian = math.rad(self.main_camera_.transform.eulerAngles.x)    
    local center_distance = self.main_camera_.transform.position.y / math.sin(radian)
    local bottom_distance = center_distance * math.tan(math.rad(self.main_camera_.fieldOfView/2))
    local ratio = (screen_pos.y - Screen.height/2 ) / (Screen.height/2)
    local actural_distance = bottom_distance * ratio
    local actural_angle = math.atan(actural_distance / center_distance)
    local actural_radian = radian - actural_angle
    -- 后面 - math.abs(ratio*2)我也不知道为什么，反正就是对了，求数学高手解答 2019.10.11
    local cross_distance = self.main_camera_.transform.position.y / math.sin(actural_radian) - math.abs(ratio*2)
    local click_map_pos = self.main_camera_:ScreenToWorldPoint(Vector3(screen_pos.x, screen_pos.y, cross_distance))
    click_map_pos = click_map_pos - self.world_map_.position
    click_map_pos = Quaternion.AngleAxis(-self.world_map_.eulerAngles.y, Vector3.up) * click_map_pos
    click_map_pos = Vector3(click_map_pos.x, 0, click_map_pos.z)
    local ceil_x = math.floor(math.abs(click_map_pos.x) / 2) - (config.WORLD_START - 1)
    local ceil_z = math.floor(math.abs(click_map_pos.z) / 2) - (config.WORLD_START - 1)
    if ceil_x < 0 or ceil_x > 800 or ceil_z < 0 or ceil_z > 800 then return end
    return UIUtil.get_logic_parent(ceil_x, ceil_z, self.scroll_logic_)
end

function clear_world_arrow_menu(self, marchID)
    if not self.world_menu_ then return end
    if self.world_menu_.obj_ then
        if type(marchID) == "string" then
            if self.world_menu_.obj_:get_march_id_str() ~= marchID then return end
        else
            if self.world_menu_.obj_.idx ~= marchID then return end
        end
    end
    self:hide_world_menu()
    self:clear_all_arrow_point()
    if Select_Go then
        Select_Go.transform:SetParent(nil, false)
    end
end

function clear_world_menu(self, onlgMenu)
    if self.world_menu_ then
        self:hide_world_menu()
        self:clear_all_arrow_point()
    end
    if onlgMenu then return end
    if Select_Go then
        Select_Go.transform:SetParent(nil, false)
    end
end

function clear_all_arrow_point(self)
    if not self.animation_ then return end
    for i=1,self.animation_.childCount do
        local go = self.animation_:GetChild(i-1)
        local arrow_point = go.transform:Find("point")
        if arrow_point then
            arrow_point.gameObject:SetActive(false)
        end
    end
end

function set_cur_base_name(self, name)
    self.cur_base_name_ = name
end

function set_cur_logic_name(self, map_ceil)
    if not map_ceil then
        self.ui_main_:set_axis_value(0, 0)
        self.cur_logic_name_ = ""
        return
    end
    self.cur_logic_name_ = map_ceil.gameObject.name
    local x, z = UIUtil.get_world_axis(map_ceil.gameObject.name, map_ceil.parent.name)
    if self.ui_main_ then
        self.ui_main_:set_axis_value(x, z)
    end
end

function check_grid_change(self, name)
    local x, z = UIUtil.get_grid_xz_by_name(name)
    local move_x
    local move_z
    if x ~= 1 then
        for i=x-1,x+1 do
            if not self.base_pool_[i] then
                move_x = i
                break
            end
        end
    end
    if z ~= 1 then
        for i=x-1,x+1 do
            for _i=z-1,z+1 do
                if self.base_pool_[i] and not self.base_pool_[i][_i] then
                    move_z = _i
                    break
                end
            end
        end
    end
    local old_x, old_z = UIUtil.get_grid_xz_by_name(self.cur_base_name_)
    -- X轴
    if move_x then
        if old_x == move_x then elog("old_x == move_x, why?, value="..tostring(move_x)) end
        local pos_to = (move_x - 1) * 50
        local pos_from
        if old_x < move_x then
            -- 向右移动
            pos_from = (move_x - 1 - 3) * 50 < 0 and 0 or (move_x - 1 - 3) * 50
        else
            -- 向左移动
            pos_from = (move_x - 1 + 3) * 50
        end
        if not pos_from then elog("pos_from == nil, why?, value="..tostring(move_x)) end
        local list = {5, 4, 6, 2, 8, 1, 3, 7, 9}
        for _,i in ipairs(list) do
            local go_base = self.scroll_base_:GetChild(i-1)
            if go_base.localPosition.x == pos_from then                    
                go_base.localPosition = Vector3(pos_to, go_base.localPosition.y, go_base.localPosition.z)
                local go_x,go_z = UIUtil.get_grid_xz_by_name(go_base.gameObject.name)
                go_base.gameObject.name = string.format("base{%d}{%d}}", move_x, go_z)
                self:set_base_mat(go_base)
                WorldTerrainLoader:check_terrain(move_x, go_z)
                WorldBuildTmp:remove_build(go_x, go_z)
            end
            local go_logic = self.scroll_logic_:GetChild(i-1)
            if go_logic.localPosition.x == pos_from then                    
                go_logic.localPosition = Vector3(pos_to, go_logic.localPosition.y, go_logic.localPosition.z)
                local go_x,go_z = UIUtil.get_grid_xz_by_name(go_logic.gameObject.name)
                local old_name = go_logic.gameObject.name
                go_logic.gameObject.name = string.format("LogicCell{%d}{%d}}", move_x, go_z)
                WorldBuildTmp:check_build(go_logic)
            end
        end
    end
    -- Z轴
    if move_z then
        if old_z == move_z then elog("old_z == move_z, why?, value="..tostring(move_z)) end
        local pos_to = -(move_z - 1) * 50
        local pos_from
        if old_z < move_z then
            pos_from = (move_z - 1 - 3) * 50 < 0 and 0 or (move_z - 1 - 3) * 50
        else
            pos_from = (move_z - 1 + 3) * 50
        end
        pos_from = -pos_from
        if not pos_from then elog("pos_from == nil, why?, value="..tostring(move_z)) end
        local list = {5, 4, 6, 2, 8, 1, 3, 7, 9}
        for _,i in ipairs(list) do
            local go_base = self.scroll_base_:GetChild(i-1)
            if go_base.localPosition.z == pos_from then                    
                go_base.localPosition = Vector3(go_base.localPosition.x, go_base.localPosition.y, pos_to)
                local go_x,go_z = UIUtil.get_grid_xz_by_name(go_base.gameObject.name)
                go_base.gameObject.name = string.format("base{%d}{%d}}", go_x, move_z)
                self:set_base_mat(go_base)
                WorldTerrainLoader:check_terrain(go_x, move_z)
                WorldBuildTmp:remove_build(go_x, go_z)
            end
            local go_logic = self.scroll_logic_:GetChild(i-1)
            if go_logic.localPosition.z == pos_from then                    
                go_logic.localPosition = Vector3(go_logic.localPosition.x, go_logic.localPosition.y, pos_to)
                local go_x,go_z = UIUtil.get_grid_xz_by_name(go_logic.gameObject.name)
                go_logic.gameObject.name = string.format("LogicCell{%d}{%d}}", go_x, move_z)
                WorldBuildTmp:check_build(go_logic)
            end            
        end
    end    
    if move_x or move_z then 
        if not self.move_camera_ then
            self:clear_world_menu()
        end
        self:clear_base_pool() 
    end
end

function set_base_mat(self, goBase)
    if not goBase then return end
end

function init_base_offset(self, x, z)
    if not self.base_pool_ then
        self.base_pool_ = {}
    end
    for i=x-1,x+1 do
        if not self.base_pool_[i] then
            self.base_pool_[i] = {}
        end            
        for j=z-1,z+1 do
            self.base_pool_[i][j] = 1
        end
    end 
end

function on_et_pinch(self, gesture)
    if self.move_camera_ then
        self.move_camera_ = false
        return 
    end
    
    if not self.screen_pinch_center_ then
        local pos0 = self.scroll_camera_.TouchPosition0
        local pos1 = self.scroll_camera_.TouchPosition1
        local mid = (pos0 + pos1) / 2
        self.screen_pinch_center_ = Vector3(mid.x, mid.y, 0)
        self.world_pinch_center_ = self.main_camera_:ScreenToWorldPoint(self.screen_pinch_center_)
    end
    local newSize = self.main_camera_.fieldOfView - gesture.deltaPinch * 0.1
    if newSize > FIELDOFVIEW_MAX then
        newSize = FIELDOFVIEW_MAX
    end
    if newSize < FIELDOFVIEW_MIN then
        newSize = FIELDOFVIEW_MIN
    end
    self.main_camera_.fieldOfView = newSize
    -- 暂时保留
--    local new_screen_center = self.main_camera_:WorldToScreenPoint(self.world_pinch_center_)
--    local screen_offset = new_screen_center - self.screen_pinch_center_
--    local world_offset = screen_offset / self.screen_half_height_ * self.main_camera_.orthographicSize
--    world_offset.y = world_offset.y / math.sin(self.main_camera_.transform.eulerAngles.x * math.pi / 180)
--    world_offset = Vector3(world_offset.x, 0, world_offset.y)
--    local new_camera_pos = self:checked_camera_position(self.main_camera_.transform.position + world_offset)
--    self.main_camera_.transform.position = new_camera_pos
    
    self:hide_world_menu()
end

function on_et_pinch_end(self, gesture)
    self.screen_pinch_center_ = nil
    self.world_pinch_center_ = nil
end


function on_et_click(self, gesture)
    if self.move_camera_ then return end
    local map_ceil = self:get_map_ceil_by_screen_position(gesture.position)
    if not map_ceil then return end
    
    local hit_obj
    local obj_type -- 1出征线  2队伍  3势力据点头上气泡
    local ray = Camera.main:ScreenPointToRay(Vector3(gesture.position.x, gesture.position.y, 0))
    local hit_point_ani = Physics.RaycastAll(ray, 1000, Layer_Mask_World_Ani)
    if hit_point_ani and hit_point_ani.Length > 0 then
        -- 优先选择队伍
        for i=1,hit_point_ani.Length do 
            local map_ceil = hit_point_ani[i].transform
            local a = string.find(map_ceil.gameObject.name, 'j')
            obj_type = a and 2 or 1
            
            local b = string.find(map_ceil.gameObject.name, 'owner')
            if b then 
                obj_type = 3
                hit_obj = hit_point_ani[i].transform.parent.parent
            else
                hit_obj = hit_point_ani[i]
            end           
            
            if obj_type == 2 then
                break
            end            
        end
    end
    
    -- 点中了移动物件
    if hit_obj then
        -- 出征线 = 1
        if obj_type == 1 then
            self:on_click_march_arrow(hit_obj)
        -- 队伍 = 2
        elseif obj_type == 2 then
            local parent_obj = hit_obj.transform.parent
            self:on_click_march_journey(parent_obj)
        --势力据点 = 3
        elseif obj_type == 3 then
            local parent_obj = hit_obj.transform.parent
            self:check_world_click(hit_obj.transform)
            local x,z = UIUtil.get_world_axis(hit_obj.gameObject.name, hit_obj.parent.gameObject.name)
            MsgCenter.send_message(Msg.WORLD_FORT_OWNER_HIDE, x, z)
        end
    else
        self:check_world_click(map_ceil)
    end
end

function on_jump_journey(self, marchID)
    if not marchID then return end
    local obj = self.animation_.transform:Find("j"..marchID)
    if not obj then return end
    self:on_click_march_journey(obj)
end

function enter_move_camera_state(self, obj, marchID)
    self.move_camera_ = true
    local x,z = UIUtil.map_axis_to_logic_axis(obj.transform.position.x, obj.transform.position.z)
    local xa, za = UIUtil.get_world_axis(self.cur_logic_name_, self.cur_base_name_)
    if math.abs(xa - x) > 10 or math.abs(za - z) > 10 then
        self:goto_axis(x, z)
    end
    self.move_delta_time_ = os.time()
    StartCoroutine(function()
        while true do
            if not self.move_camera_ then break end
            if Slua.IsNull(obj) then break end
            local radian = math.tan(config.WORLD_CAMERA_RADIAN)
            local move_pos = Vector3(obj.transform.position.x, 30, obj.transform.position.z-30*radian)
            self.main_camera_.transform.position = move_pos
            Yield()
            self:set_world_menu_axis_by_postion(obj)
            local delta = os.time() - self.move_delta_time_
            if delta > 1 then
                self.move_delta_time_ = os.time()
                MsgCenter.send_message(Msg.WORLD_ENABLE_WATCH, self.cur_logic_name_, self.cur_base_name_)
            end
            self:on_et_drag_move(false)
        end
        self:clear_world_arrow_menu(marchID)
    end)
end

function on_clear_journey_menu(self)
    self.move_camera_ = false
end

function on_clear_arrow_menu(self, marchID)
    self:clear_world_arrow_menu(marchID)
end

function on_clear_menu(self)
    self:clear_world_menu()
end

function on_click_march_journey(self, journey)
    if Select_Go then
        local map_ceil = Select_Go.transform.parent
        local sprite_render = Select_Go.transform:Find("sprite").gameObject
        sprite_render:SetActive(false)
    end
    if self.world_menu_ then
        local march_id = string.sub(journey.gameObject.name, 2, string.len(journey.gameObject.name))
        self:clear_world_arrow_menu(march_id)
        self.world_menu_:set_data_by_journey(march_id)
        self:enter_move_camera_state(journey, march_id)
    end
    if Select_Go then
        Select_Go.transform:SetParent(nil, false)
    end
end

function on_click_march_arrow(self, hit)
    -- 设置选框
    if Select_Go then
        local map_ceil = Select_Go.transform.parent
        local sprite_render = Select_Go.transform:Find("sprite").gameObject
        sprite_render:SetActive(false)
    end
    self:clear_all_arrow_point()
    if self.world_menu_ then
        local march_id = tostring(hit.transform.gameObject.name)
        local arrow_point = hit.transform:Find("point")        
        arrow_point.position = hit.point
        arrow_point.localPosition = Vector3(arrow_point.localPosition.x, -0.075, arrow_point.localPosition.z)
        arrow_point.gameObject:SetActive(true)
        self.world_menu_:set_data_by_arrow(march_id)
        self:set_world_menu_axis_by_postion(arrow_point)
    end
    if Select_Go then
        Select_Go.transform:SetParent(nil, false)
    end
end

function check_world_click(self, map_ceil)
    if not map_ceil then return end
    local x,z = UIUtil.get_world_axis(map_ceil.gameObject.name, map_ceil.parent.gameObject.name)
    if self.world_menu_ then
        self.world_menu_:set_axis_value(x, z)
    end
    local obj = WorldManager:get_world_obj(x, z)
    -- 设置选框
    if Select_Go then
        Select_Go.transform:SetParent(map_ceil, false)
        self:set_world_menu_axis()
        local map_ceil = Select_Go.transform.parent

        local sprite_render = Select_Go.transform:Find("sprite").gameObject
        if obj then
            sprite_render:SetActive(false)
        else
            sprite_render:SetActive(true)
        end
    end
    if self.world_menu_ then
        self:clear_all_arrow_point()
        if not obj then
            self.world_menu_:set_data()
        elseif obj:enable_click_show() then
            self.world_menu_:set_data(obj)
        else
            self:hide_world_menu()
        end
    end
    if obj and obj.obj_type_ == config.WORLD_MONSTER then
    else
        self:move_obj_into_screen(x, z, obj)
    end
end

function move_obj_into_screen(self, x, z, obj)
    local logic_x = x
    local logic_z = z
    if obj and obj.obj_type_ == config.WORLD_MAIN_JUMP then
        logic_x, logic_z = obj:get_main()
    end
    local build = WorldBuildTmp:get_build(logic_x, logic_z)
    if not build then
        build = UIUtil.get_logic_parent(logic_x, logic_z, self.scroll_logic_)
    end
    local screenPos = self.main_camera_:WorldToScreenPoint(build.transform.position)
    local b,p = RectTransformUtility.ScreenPointToLocalPointInRectangle(self.screen_size_, screenPos, self.ui_camera_)
    if math.abs(p.x) > 412 then
        local delta_x = (math.abs(p.x) - 412)*0.5
        local result = p.x < 0 and -1 or 1
        local end_x = self.main_camera_.transform.localPosition.x + result*delta_x*0.04
        self.camera_tween_ = GameTween.DOLocalMoveX(self.main_camera_.transform, 
                                end_x , 0.5, false):OnUpdate(
        function()
            self:set_world_menu_axis()
        end)
        self.camera_tween_:SetEase(XEase.OutQuad)
    end
end

function set_world_menu_axis_by_postion(self, arrow)
    if not arrow then return end
    if Slua.IsNull(arrow) then return end
    local screenPos = self.main_camera_:WorldToScreenPoint(arrow.position)                                 
    local b,p = RectTransformUtility.ScreenPointToLocalPointInRectangle(self.screen_size_, screenPos, self.ui_camera_)
    local menu_rect = self.world_menu_.gameObject:GetComponent(RectTransform)
    menu_rect.anchoredPosition = Vector2(math.floor(p.x), math.floor(p.y)+100)
    if not self.world_menu_.gameObject.activeSelf then
        self.world_menu_.gameObject:SetActive(true)
    end
end

function set_world_menu_axis(self)
    if not Select_Go then return end
    if not self.world_menu_ then return end
    local map_ceil = Select_Go.transform.parent
    if not map_ceil then return end
    local x, z = UIUtil.get_world_axis(map_ceil.gameObject.name, map_ceil.parent.gameObject.name)
    local obj = WorldManager:get_world_obj(x, z)
    local tmp_pos = Select_Go.transform.position
    if obj and obj.obj_type_ == config.WORLD_MAIN_JUMP then
        local _x, _z = obj:get_main()
        local tmp_select_go = WorldBuildTmp:get_build(_x, _z)
        tmp_pos = tmp_select_go.transform.position
    end    
    local screenPos = self.main_camera_:WorldToScreenPoint(tmp_pos)
    local b,p = RectTransformUtility.ScreenPointToLocalPointInRectangle(self.screen_size_, screenPos, self.ui_camera_)
    self.world_menu_.gameObject:SetActive(true)
    local menu_rect = self.world_menu_.gameObject:GetComponent(RectTransform)    
    local off_x = 0
    local off_y = 0
    if obj then
        off_x, off_y = obj:get_offset_pos(self.main_camera_.fieldOfView, p)
    end
    menu_rect.anchoredPosition = Vector2(math.floor(p.x) + off_x, math.floor(p.y) + off_y)
end

function init_world_menu(self)
    if self.world_menu_ then
        self.world_menu_:on_dispose()
        self.world_menu_ = nil
    end
    if _G.FairyGUI then
        local layer = UIManager.get_canvas().transform:Find(UIConfig.Layers[UIConfig.LayerType.Board])
        self.menu_panel_ = layer:Find("MenuPanel")
        if not self.menu_panel_ then
            local go = GameObject("MenuPanel")
            go:AddComponent(UnityEngine.RectTransform)
            go.transform:SetParent(layer, false)
            go.transform.localPosition = Vector3.zero
            go.transform.localScale = Vector3.one
            go.transform.anchorMin = Vector2.zero
            go.transform.anchorMax = Vector2.one
            go.transform.offsetMax = Vector2.zero
            go.transform.offsetMin = Vector2.zero
            self.menu_panel_ = go.transform
        end
        UIUtil.destroy_all_children(self.menu_panel_, true)
        local world_menu = GameObject.Instantiate(self.world_menu_prefab_)
        world_menu.transform:SetParent(self.menu_panel_, false)
        world_menu:SetActive(true)
        self.world_menu_ = WorldMenu:new(self)
        self.world_menu_:AddLuaComponent(world_menu)
        self.world_menu_:init()
    else
        if self.ui_main_ then
            UIUtil.destroy_all_children(self.ui_main_.menu_panel_, true)
            local world_menu = GameObject.Instantiate(self.world_menu_prefab_)
            world_menu.transform:SetParent(self.ui_main_.menu_panel_, false)
            world_menu:SetActive(true)
            self.world_menu_ = WorldMenu:new(self)
            self.world_menu_:AddLuaComponent(world_menu)
            self.world_menu_:init()
        end
    end

    self:hide_world_menu()
end

function hide_world_menu(self)
    if self.world_menu_ then
        self.world_menu_:clear_data()
        self.world_menu_.gameObject:SetActive(false)
    end
end


function goto_axis(self, x, z, show)
    if show == nil then show = false end
    if not x or not z then return end
    -- 删除原来的
    for i=1,9 do
        local go_base = self.scroll_base_:GetChild(i-1)                
        local go_x,go_z = UIUtil.get_grid_xz_by_name(go_base.gameObject.name)
        WorldBuildTmp:remove_build(go_x, go_z)
    end
    --计算新地点
    self.goto_go_.localPosition = Vector3((x - 1 + config.WORLD_START) * 2, 0, -(z - 1 + config.WORLD_START) * 2)
    local radian = math.tan(config.WORLD_CAMERA_RADIAN)

    local delta_z = math.abs(self.main_camera_.transform.position.y - self.goto_go_.position.y) * radian

    local pos = Vector3(self.goto_go_.position.x, self.main_camera_.transform.position.y, self.goto_go_.position.z - delta_z - 1)
    self.main_camera_.transform.position = pos
    local center_x = math.floor(self.goto_go_.localPosition.x / 50) + 1
    -- 这里不用绝对值了，直接取反，反正确定是负数
    local center_z = math.floor(-self.goto_go_.localPosition.z / 50) + 1
    local index_list = {}
    local start_x = (center_x-1) < 1 and 1 or (center_x-1)
    local start_z = (center_z-1) < 1 and 1 or (center_z-1)
    local index = 0
    local start_xlist = {start_x+1, start_x, start_x+2}
    local start_zlist = {start_z+1, start_z, start_z+2}
    for _,i in ipairs(start_xlist) do
        for _,j in ipairs(start_zlist) do
            -- base
            local go_base = self.scroll_base_:GetChild(index)
            go_base.localPosition = Vector3((i-1)*50, go_base.localPosition.y, -(j-1)*50)
            go_base.gameObject.name = string.format("base{%d}{%d}}", i, j)
            self:set_base_mat(go_base)
            -- logic
            local go_logic = self.scroll_logic_:GetChild(index)
            go_logic.localPosition = Vector3((i-1)*50, go_logic.localPosition.y, -(j-1)*50)
            go_logic.gameObject.name = string.format("LogicCell{%d}{%d}}", i, j)
            index = index + 1
            -- terrain
            WorldTerrainLoader:check_terrain(i, j)
            -- build
            WorldBuildTmp:check_build(go_logic)
        end
    end
    local str = string.format("base{%d}{%d}}", center_x, center_z)    
    self:set_cur_base_name(str)
    self:clear_base_pool()
    -- 自动移动的时候不需要清除世界菜单
    if not self.move_camera_ then
        self:clear_world_menu()
    end
    if self.ui_main_ then
        self.ui_main_:set_axis_value(x, z)
        self.ui_main_:updata_track_position_ex()
    end
    self.show_menu_ = show
    MsgCenter.send_message(Msg.WORLD_ENABLE_WATCH2, x, z)
end

function on_goto_axis_complete(self, x, z)
    if self.show_menu_ then
        self.show_menu_ = false
        local map_ceil = UIUtil.get_logic_parent(x, z, self.scroll_logic_)
        self:check_world_click(map_ceil)
    end
end

function clear_base_pool(self)
    self.base_pool_ = {}
    for i=1,self.scroll_base_.childCount do
        local go = self.scroll_base_:GetChild(i-1)
        local _x, _z = UIUtil.get_grid_xz_by_name(go.gameObject.name)
        if not self.base_pool_[_x] then
            self.base_pool_[_x] = {}
        end            
        self.base_pool_[_x][_z] = 1
    end
end
