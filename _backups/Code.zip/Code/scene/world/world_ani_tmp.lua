-- 世界地图动画相关出征、线路
module("WorldAniTmp", package.seeall)


function init(self, world)
    self.world_ani_ = {}
    self.march_ratio_protect_ = {}
    Yield(ResourcesManager.LoadObjectAsync("Model/World/Soldier/journey", function(obj)
        self.world_journey_prefab_ = obj
    end))
    self.ani_list = {"LeadingGeneral", "Archer", "Infantry", "Knight", "Tank"}
    for i,v in ipairs(self.ani_list) do 
        self:load_soldier_model(v, function(obj)
            self.world_ani_[v] = obj
        end)
    end

    --位置排布
    self.pos_value = {0,1,-1,2,-2,3,-3,4,-4,5,-5,6,-6,7,-7,8,-8,9,-9}

    --动画规则请勿删
    --"1",        -- ↘
    --"2",        -- ↓
    --"3",        -- ↙
    --"4",        -- ←
    --"5",        -- ↖
    --"6",        -- ↑
    --"7",        -- ↗
    --"8",        -- →
    self.anidir_map_ = {}
    self.anidir_map_[1] = 2
    self.anidir_map_[2] = 1
    self.anidir_map_[3] = 8
    self.anidir_map_[4] = 7
    self.anidir_map_[5] = 6
    self.anidir_map_[6] = 5
    self.anidir_map_[7] = 4
    self.anidir_map_[8] = 3
    local list_arrow = {
        "Model/World/Arrow/worldarrow1",
        "Model/World/Arrow/worldarrow2",
        "Model/World/Arrow/worldpoint",
    }
    Yield(ResourcesManager.LoadObjectMultiAsync(list_arrow, function(objs)
        self.world_arrow_prefab_ = {}
        self.world_arrow_prefab_[1] = objs[1]
        self.world_arrow_prefab_[2] = objs[2]
        self.world_arrow_point_prefab_ = objs[3]        
    end))
    if SceneManager.Scene_Tags.World == SceneManager.Local_Scene then 
        self.world_map_ = GameObject.Find("WorldMap").transform
        self.animation_ = self.world_map_:Find("Animation")
    end
    
    self.messager_ = Messager:new(self)
    self.messager_:add_listener(Msg.WORLD_MARCH_START, on_march_start)
    self.messager_:add_listener(Msg.WORLD_MARCH_DELETE, on_march_delete)   
end

function load_soldier_model(self, name, callback)
    local str_path = string.format("Model/World/Soldier/%s", name)
    Yield(ResourcesManager.LoadObjectAsync(str_path, function(obj)
        if callback then callback(obj) end
    end))
end

function on_update_scene(self)
    if SceneManager.Scene_Tags.City == SceneManager.Local_Scene then
        for k,v in pairs(self.march_ani_ or {}) do
            v:Kill(true)
        end
        self.march_ani_ = {}
        self.march_ratio_ = {}
        self.march_ratio_protect_ = {}
    end
end

--行军动画的删除由动画自己控制
function on_march_delete(self, marchID)
    -- print("on_march_delete")
    -- self.march_ratio_[marchID] = nil
end

function on_march_start(self, marchID)
    local march = WorldManager:get_march_by_idx(marchID)
    if not march then return end
    if march.is_play_ then return end
    march.is_play_ = true
    local map_fx, map_fz = march:get_from_map_axis()
    local map_tx, map_tz = march:get_to_map_axis() 
    local delta_x = map_tx - map_fx
    local delta_z = map_tz - map_fz
    local go, back = self:get_animation_direction(delta_x, delta_z)
    local time, ratio, speed = march:get_march_time()
    -- 这里暂时先加了个0.5s的延迟，等待服务器主动删除
    --if march.army_type_ == 1 then time = time + 0.5 end
    local data = {}
    data.ani = go
    data.ratio = ratio
    data.fx = map_fx
    data.fz = map_fz
    data.tx = map_tx
    data.tz = map_tz
    data.dx = delta_x
    data.dz = delta_z
    data.time = time
    data.speed = speed
    data.marchID = marchID
    self:play_march_animation(data, function()end)
end

function on_dispose(self)
    self.messager_:dispose()
end

function play_march_animation(self, data, cb)
    if not self.march_ani_ then self.march_ani_ = {} end
    if not self.march_ratio_ then self.march_ratio_ = {} end
    local ratio = self.march_ratio_[data.marchID] or data.ratio
    --召回的时候，需要在原来的行程进度上返回（需要改用之前的行军信息结束时间判断）
    if self.march_ratio_protect_[data.marchID] then
        dump(self.march_ratio_protect_[data.marchID], "self.march_ratio_protect_[data.marchID]")
        self.march_ratio_protect_[data.marchID] = nil
        self.march_ratio_[data.marchID] = 1-self.march_ratio_[data.marchID]
        ratio = self.march_ratio_[data.marchID]
    end

    --当前行军存在时加速会走的逻辑
    if self.march_ani_[data.marchID] then
        self.march_ani_[data.marchID]:Kill(false)
        local tmpAnmObj = self.animation_:Find("j"..data.marchID);
        local tmpArrowObj = self.animation_:Find(data.marchID);
        if not Slua.IsNull(tmpAnmObj) then
            Object.Destroy(tmpAnmObj.gameObject)
        end
        if not Slua.IsNull(tmpArrowObj) then
            Object.Destroy(tmpArrowObj.gameObject)
        end
        _G.MsgCenter.send_message(_G.Msg.WORLD_CLEAR_MARCH_MENU, tostring(data.marchID))
        if cb then cb() end
        self.march_ani_[data.marchID] = nil
    end

    --print(string.format("time %f, ratio %f, speed %f", data.time, data.ratio, data.speed))
    local journey = GameObject.Instantiate(self.world_journey_prefab_)
    journey.transform:SetParent(self.animation_, false)
    journey.gameObject.name = "j"..data.marchID
    journey.transform.localPosition = Vector3(data.fx+data.dx*ratio, 0, data.fz+data.dz*ratio)
    local world_arrow = self:init_world_arrow(data.fx, data.fz, data.tx, data.tz, data.marchID, data.speed)

    --领军头像
    local march = WorldManager:get_march_by_idx(data.marchID)
    local hero_list = march:get_troops_hero()
    local head_go = journey.transform:Find("hero").gameObject
    if next(hero_list) then
        head_go:SetActive(true)
        self:init_head_animation(journey, hero_list)
    else
        head_go:SetActive(false)
    end

    local leaderResName = self.ani_list[1]
    --print("ani = ", data.ani)
    --领队 和 士兵队列
    local leaderAnimator = self:GenerateSoldier(self.world_ani_[leaderResName], journey, leaderResName, 1, 1, data)
    local armyAnimators = {}
    local soldier_list = march:get_soldiers_list()
    local num = next(soldier_list) and 0 or 1   --没有士兵的队列是侦察队列，显示一个领队
    for k,v in pairs(soldier_list) do
        num = num + 1
        local max = config.BATTLE_ANI_MAXNUM[k][1]
        if v > 1000 then
            max = config.BATTLE_ANI_MAXNUM[k][2]
        elseif v > 10000 then
            max = config.BATTLE_ANI_MAXNUM[k][3]
        end
        for _i=1,max do
            local world_ani_prefab = self.world_ani_[k]
            if world_ani_prefab then
                local animator = self:GenerateSoldier(world_ani_prefab, journey, k..num, num+1, _i, data)
                table.insert(armyAnimators, animator)
            end
        end
    end
    local box_index = 1
    if march.army_type_ == ArmyInfo.RET_CITY then box_index = 2 end

    --点击框
    local box_size = {
        {{1.7,2.2}, {2.8,2.5}, {3.6, 2.8}, {4.8,3}},
        {{1.5,2.2}, {2.5,3}, {3.5,3}, {4.5,3.2}},
    }
    local box_center = {
        {{0.2,0.2}, {0.6,0.4}, {1.2,0.5}, {1.5,-0.5}},
        {{-0.6,-0.2}, {-1,-1}, {-1.6,0.5}, {-2,0.5}},
    }
    local box = journey.transform:Find("journey"):GetComponent(BoxCollider)
    box.size = Vector3(box_size[box_index][num][1], 1, box_size[box_index][num][2])
    box.center = Vector3(0, 0.5, 0)

    --_G.dump(march, "start animation march = ", 9);
    --动画相关
    self.march_ani_[data.marchID] = GameTween.To(function(v)
        if not Slua.IsNull(journey) and not Slua.IsNull(journey.transform.localPosition) then
            journey.transform.localPosition = Vector3(data.fx+data.dx*v, 0, data.fz+data.dz*v)
            if v <= 0.999 then
                self.march_ratio_[data.marchID] = v
            end
        end
    end, ratio, 1, data.time):SetEase(XEase.Linear):OnComplete(function(v)
        --行军结束,到达目的地之后的逻辑(包括触发战斗延迟销毁  或者  直接销毁)
        -- if self.march_ratio_[data.marchID] then
        --     print("march ratio = "..self.march_ratio_[data.marchID])
        -- end
        if not _G.Slua.IsNull(journey) then
            Object.Destroy(world_arrow)
            --_G.dump(march, "play_march_animation march = ", 99)
            --_G.dump(armyAnimators, "armyAnimators = ", 99)
            local worldFort = WorldManager:get_world_obj_by_id(march.finish_.id)
            if WorldAniTmp.isNeedAttack(march, worldFort) and
                armyAnimators and
                next(armyAnimators) then
                --_G.dump(march, "end animation march = ", 9);
                for _, value in ipairs(armyAnimators) do
                    if not _G.Slua.IsNull(value) then
                        value:Play(string.format("Attack%d", self.anidir_map_[data.ani]))
                        value.speed = 1
                    end
                end
                _G.LuaTimer.Add( (_G.config.BATTLE_COST_TIME - 0.5) * 1000, function()
                    MsgCenter.send_message(Msg.WORLD_MARCH_DELETE, data.marchID)
                    Object.Destroy(journey)
                    march.is_play_ = false
                end)
                --立即隐藏领军和头像
                leaderAnimator.gameObject:SetActive(false)
                head_go:SetActive(false)
            else
                MsgCenter.send_message(Msg.WORLD_MARCH_DELETE, data.marchID)
                Object.Destroy(journey)
                march.is_play_ = false
            end
        end
        --关闭行军线菜单并且初始化
        _G.MsgCenter.send_message(_G.Msg.WORLD_CLEAR_MARCH_MENU, tostring(data.marchID))
        if cb then cb() end
        self.march_ani_[data.marchID] = nil
        self.march_ratio_[data.marchID] = nil
    end)
end

function GenerateSoldier(self, soldierPrefab, journey, name, num, _i, data)
    local ani = GameObject.Instantiate(soldierPrefab)
    ani.transform:SetParent(journey.transform, false)
    ani.gameObject.name = name
    local animator = ani.transform:Find("animator1"):GetComponent(Animator)
    animator.speed = 1
    animator:Play(string.format("Run%d", self.anidir_map_[data.ani]))
    --横向排布参数
    local step = self.pos_value[_i]*0.5
    --纵向排布参数1,2
    local step2 = math.abs(num-1)*1.5 + math.abs(step)*0.5
    local ver = Vector3(data.fx-data.tx,0,data.fz-data.tz)
    local ver2 = self:get_vertical_dir(ver)
    ani.transform:Translate(ver.normalized*step2)
    ani.transform:Translate(ver2.normalized*step)
    return animator
end

function isNeedAttack(march, worldFort)
    return march.army_type_ == _G.ArmyInfo.TO_MONSTER or
        (march.army_type_ == _G.ArmyInfo.TO_FORTIFIED and worldFort);
end

function get_vertical_dir(self, dir)
    if dir.z == 0 then
        return Vector3(0, 0, -1)
    else
        return Vector3(-dir.z / dir.x, 0, 1).normalized
    end
end

function init_world_arrow(self, fromX, fromZ, toX, toZ, marchID, speed)
    local delta_x = toX - fromX
    local delta_z = toZ - fromZ
    local angle = math.atan(math.abs(delta_z)/math.abs(delta_x))*(180/math.pi)
    if delta_x < 0 and delta_z > 0 then
        angle = 180 - angle
    elseif delta_x < 0 and delta_z < 0 then
        angle = 180 + angle
    elseif delta_x > 0 and delta_z < 0 then
        angle = 360 - angle
    end
    local world_angle = angle - 45
    local distance = math.sqrt(delta_x*delta_x + delta_z*delta_z)
    local march = WorldManager:get_march_by_idx(marchID)
    local prefab = self.world_arrow_prefab_[1]
    if not MasterManager:is_master(march.owner_) then
        prefab = self.world_arrow_prefab_[2]
    end    
    local world_arrow = GameObject.Instantiate(prefab)
    world_arrow.gameObject.name = marchID
    world_arrow.transform:SetParent(self.animation_, false)
    local sprite_render = world_arrow.transform:GetComponent(SpriteRenderer)    
    local value_x = -0.1 * math.sin(math.rad(angle))
    local value_z = 0.1 * math.cos(math.rad(angle))
    world_arrow.transform.localPosition = Vector3(fromX+value_x, 0, fromZ+value_z)
    world_arrow.transform.rotation = Quaternion.Euler(90, 0, world_angle)
    -- 6.4是箭头图标到目的地的一个系数，会根据图片大小决定
    local weight_sin = 1 - math.abs(math.sin(math.rad(world_angle)))
    world_arrow.transform.localScale = Vector3(distance*6.4,2+weight_sin,1)
    local point = GameObject.Instantiate(self.world_arrow_point_prefab_) 
    point.transform:SetParent(world_arrow.transform, false)
    point.transform.localScale = Vector3(0.3/distance, 1, 1)
    point.transform.localRotation = Quaternion.Euler(0, 0, 0)
    point.gameObject.name = "point"
    point.gameObject:SetActive(false)
    sprite_render.material:SetFloat("RepeatX", distance*2+distance*2*weight_sin)
    sprite_render.material:SetFloat("SpeedX", 20*speed)
    return world_arrow
end

-- 原坐标一象限是 15° 75°，然后顺时针旋转了45°，所有动作往旁边移动一位
function get_animation_direction(self, x, z)
    local goto_dir
    -- tan15° = 2-√3 = 0.268
    local tan_15 = 0.268
    -- tan30° = √3/3 = 1.732
    local tan_30 = 0.577
    -- tan60° = √3 = 1.732
    local tan_60 =1.732
    -- tan75° = 2+√3 = 3.732
    local tan_75 = 3.732
    local tan_value = math.abs(z) / math.abs(x)
    --print("tan_value = "..tan_value)
    -- 第一象限
    if x >= 0 and z >= 0 then
        if tan_value < tan_30 then
            goto_dir = 2  --右下
        elseif tan_value > tan_60 then
            goto_dir = 4  --右上
        else
            goto_dir = 3  --右
        end
    -- 第二象限
    elseif x < 0 and z >= 0 then
        if tan_value < tan_30 then
            goto_dir = 6  --左上
        elseif tan_value > tan_60 then
            goto_dir = 4  --右上
        else
            goto_dir = 5  --上
        end
    -- 第三象限
    elseif x < 0 and z < 0 then
        if tan_value < tan_30 then
            goto_dir = 6  --左上
        elseif tan_value > tan_60 then
            goto_dir = 8  --左下
        else
            goto_dir = 7  --左
        end
    -- 第四象限
    elseif x >= 0 and z < 0 then
        if tan_value < tan_30 then
            goto_dir = 2   --右下
        elseif tan_value > tan_60 then
            goto_dir = 8    --左下
        else
            goto_dir = 1   --下
        end
    -- 错误情况
    else
        elog("world ani get_animation_direct occur error, x="..tostring(x)..", z="..tostring(z))
    end
    return goto_dir, self.anidir_map_[goto_dir]
end

function init_head_animation(self, journey, hero_list)
    ResourcesManager.LoadObjectMultiAsync(hero_list, function(loaded)
        if not journey then return end
        if not loaded then return end
        local objs = loaded.Table
        local objs_list = {}
        for i,v in ipairs(objs) do
            local head_image = journey.transform:Find("hero/head"..i):GetComponent(SpriteRenderer)
            head_image.sprite = v:GetComponent(SpriteRenderer).sprite
            table.insert(objs_list, head_image)
        end
        self:start_head_animation(journey, objs_list)
    end)
end

function start_head_animation(self, journey, objs_list)
    if #objs_list == 1 then
        objs_list[1].gameObject:SetActive(true)
        return
    end    
    local num = 1
    local num_delta = #objs_list
    StartCoroutine(function()
        for i=1,10000 do
            if not journey.gameObject then break end
            local index = num%num_delta == 0 and num_delta or num%num_delta
            for _i,_v in ipairs(objs_list) do
                if _i == index then
                    if not _v.gameObject.activeSelf then
                        _v.gameObject:SetActive(true)
                    end
                else
                    if _v.gameObject.activeSelf then
                        _v.gameObject:SetActive(false)
                    end
                end
            end
            num = num +1 
            Yield(WaitForSeconds(3))
        end
    end)
end
