-- 世界地表管理和加载
module("WorldTerrainLoader", package.seeall)


function init(self, world)
    self.com_parent_ = world.transform:Find("Terrain")
    self.terrain_map_ = {}
    self.prefab_map_ = {}
    self.terain_data_ = {}
    ResourcesManager.InstantiateAsync("DataFile/terrain", function(obj)
        WorldTerrainObject.Instance = obj
        if obj ~= nil then
            local arr_ = obj:getCurves()
            for i=1,#arr_ do                
                local c = arr_[i]
                local data = c.x*1000 + c.z
                self.terain_data_[data] = c.path
            end
        end
    end)
end

function on_dispose(self)
    for _,v in pairs(self.terrain_map_) do
        for _,_v in pairs(v) do
            Object.Destroy(_v)
        end
    end
    self.terrain_map_ = {}
    self.prefab_map_ = {}
end


function load_terrain(self, x, z, path)    
    if not self.terrain_map_[x] then
        self.terrain_map_[x] = {}
    end
    if self.prefab_map_[path] then
        local go_tmp = GameObject.Instantiate(self.prefab_map_[path])
        go_tmp.transform:SetParent(self.com_parent_, false)
        go_tmp.gameObject.name = string.format("TerrainCell{%d}{%d}}", x, z)
        self.terrain_map_[x][z] = go_tmp
        self:terrain_position(go_tmp.transform, x, z)
    else
        ResourcesManager.LoadObjectAsync(path, function(go)
            self.prefab_map_[path] = go
            local go_tmp = GameObject.Instantiate(self.prefab_map_[path])
            go_tmp.transform:SetParent(self.com_parent_, false)
            go_tmp.gameObject.name = string.format("TerrainCell{%d}{%d}}", x, z)
            self.terrain_map_[x][z] = go_tmp
            self:terrain_position(go_tmp.transform, x, z)
        end)
    end
end

--暂时不加载terrain
function check_terrain(self, x, z)
    -- if not self.terrain_map_[x] then
    --     local path = self:get_terrain_path(x, z)
    --     self:load_terrain(x, z, path)
    --     return
    -- end
    -- if not self.terrain_map_[x][z] then
    --     local path = self:get_terrain_path(x, z)
    --     self:load_terrain(x, z, path)
    --     return
    -- end
end

--不要传空字符串
-- 获取地形当前是否有物件层
function get_terrain_path(self, x, z)
    return "Model/World/Terrain/terrain_01"
end


function terrain_position(self, goTerrain, x, z)
    goTerrain.localPosition = Vector3((x-1)*50, goTerrain.localPosition.y, -(z-1)*50)
end
