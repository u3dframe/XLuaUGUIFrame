-- 世界建筑 显示和管理(world_obj、monster、main)
module("WorldBuildTmp", package.seeall)


function init(self, world)
    self.world_build_ = {}
    self.world_build_preload_ = {}
    -- WorldBuildTmp 这个的加载时间比怪物推送时间要晚一些
--    local data = WorldManager:get_world_monster()
--    for i,v in ipairs(data) do
--        self:push_build(v)
--    end
--    local data1 = WorldManager:get_my_build()
--    for i,v in ipairs(data1) do
--        self:push_build(v)
--    end
    
    
    local list = {
        "Model/World/Common/mainbuild01",
        "Model/World/Common/enemy01",
        "Model/World/Common/fort",
        "Model/World/Common/respoint",
    }
    self.build_prefabs_ = {}
    Yield(ResourcesManager.LoadObjectMultiAsync(list, function(obj)
        self.build_prefabs_[config.WORLD_MAIN] = obj[1]
        self.build_prefabs_[config.WORLD_MONSTER] = obj[2]
        self.build_prefabs_[config.WORLD_FORT] = obj[3]
        self.build_prefabs_[config.WORLD_RESPOINT] = obj[4]
    end))
    self.world_map_ = GameObject.Find("WorldMap").transform
    self.logic_box_ = self.world_map_:Find("LogicBox")
    self.messager_ = Messager:new(self)
    self.messager_:add_listener(Msg.WORLD_DELETE_OBJ, on_delete_obj)
    self.messager_:add_listener(Msg.WORLD_REFRESH_OBJ, on_refresh_obj)
    self.messager_:add_listener(Msg.WORLD_FORT_REFRESH, on_refresh_fort)
    self.messager_:add_listener(Msg.WORLD_RESPOINT_REFRESH, on_refresh_respoint)
    self.messager_:add_listener(Msg.WORLD_DELETE_OBJ_BUILD, on_delete_obj_build)
    self.messager_:add_listener(Msg.WORLD_FORT_OWNER_HIDE, on_fort_owner_hide)
    self.messager_:add_listener(Msg.WORLD_MENU_SHOW_UPDATE, on_menu_update)    
end

-- 卸载
function remove_build(self, oldX, oldZ)
    if not self.logic_box_ then return end
    if oldX and oldZ then
        local str1 = string.format("LogicCell{%d}{%d}}", oldX, oldZ)
        local old_logic_panel = self.logic_box_:Find(str1)
        local first_select = old_logic_panel:Find("select{1}{1}}")
        local first_x,first_z = UIUtil.get_world_axis(first_select.gameObject.name, old_logic_panel.gameObject.name)
        local last_select = old_logic_panel:Find("select{25}{25}}")
        local last_x,last_z = UIUtil.get_world_axis(last_select.gameObject.name, old_logic_panel.gameObject.name)
        for i=first_x,last_x do
            if self.world_build_[i] then
                for j=first_z,last_z do
                    if self.world_build_[i][j] then
                        self:pop_build(self.world_build_[i][j][1])
                    end
                end
            end
        end
    end
end

-- 加载
function check_build(self, logicGo)
    if not self.world_build_ then
        LuaTimer.Add( 100, function() self:check_build(logicGo) end)
        return
    end
    if not logicGo then return end
    if Slua.IsNull(logicGo) then return end
    StartCoroutine(function()
        Yield(WaitForSeconds(0.5))
        local x, z = UIUtil.get_grid_xz_by_name(logicGo.gameObject.name)
        local first_select = logicGo:Find("select{1}{1}}")
        local first_x,first_z = UIUtil.get_world_axis(first_select.gameObject.name, logicGo.gameObject.name)
        local last_select = logicGo:Find("select{25}{25}}")
        local last_x,last_z = UIUtil.get_world_axis(last_select.gameObject.name, logicGo.gameObject.name)
        local num = 0
        for i=first_x,last_x do            
            if self.world_build_[i] then
                for j=first_z,last_z do
                    if self.world_build_[i] and self.world_build_[i][j] then
                        local data = {}
                        data.logicX = i
                        data.logicZ = j
                        data.baseX = i-first_x+1
                        data.baseZ = j-first_z+1
                        data.logicGo = logicGo
                        self:load_build(data)
                        num = num + 1
                        if num > 10 then
                            Yield()
                            num = 0
                        end
                    end
                end
            end
        end
        self.cur_logic_go_ = logicGo
    end)
end

function load_build(self, data)
    if Slua.IsNull(data.logicGo) then return end
    if not self.build_prefabs_ then
        LuaTimer.Add( 100, function() self:load_build(data) end)
        return
    end
    if not self.logic_box_ then
        LuaTimer.Add( 100, function() self:load_build(data) end)
        return
    end
    
    local str = string.format("select{%d}{%d}}", data.baseX, data.baseZ)
    local select_panel = data.logicGo.transform:Find(str)
    local prefab = nil
    local world_obj
    if self.world_build_[data.logicX][data.logicZ] then
        world_obj = self.world_build_[data.logicX][data.logicZ][1]
    end
    if not world_obj or not self.build_prefabs_[world_obj.obj_type_] then
        if world_obj.obj_type_ == config.WORLD_MAIN_JUMP then return end
        LuaTimer.Add( 100, function() self:load_build(data) end)
        return
    end
    
    self:push_build(world_obj)
    self:load_build_by_obj(world_obj)
end

function load_build_by_obj(self, obj)
    local parent = UIUtil.get_logic_parent(obj.x_, obj.z_, self.logic_box_)
    if not parent then return end
    if obj.is_load_ then return end
    local load_build
    if obj.obj_type_ == config.WORLD_MONSTER then
        obj.is_load_ = true
        load_build = self.world_build_[obj.x_][obj.z_][2]
        if not load_build then
            load_build = GameObject.Instantiate(self.build_prefabs_[obj.obj_type_])
            load_build.transform:SetParent(parent.transform, false)
            self.world_build_[obj.x_][obj.z_][2] = load_build
        end
        local lv_txt = load_build.transform:Find("lv/Text"):GetComponent(TextMesh)
        lv_txt.text = obj.lv_
        load_build.name = "enemy"..obj.idx_
    elseif obj.obj_type_ == config.WORLD_MAIN then
        obj.is_load_ = true
        load_build = self.world_build_[obj.x_][obj.z_][2]
        if not load_build then
            load_build = GameObject.Instantiate(self.build_prefabs_[obj.obj_type_])
            load_build.transform:SetParent(parent.transform, false)
            self.world_build_[obj.x_][obj.z_][2] = load_build
        end
        load_build.name = "city"..obj.idx_
        local x = UIUtil.get_precise_decimal(load_build.transform.position.x,2)
        local y = UIUtil.get_precise_decimal(load_build.transform.position.y,2)
        local z = UIUtil.get_precise_decimal(load_build.transform.position.z,2)
        if MasterManager:is_master(obj.idx_) then
            WorldManager.main_position_ = Vector3(x, y, z-2)
        end
        local name_txt = load_build.transform:Find("flag/Name"):GetComponent(TextMesh)
        obj:set_city_text_mesh(name_txt)
    elseif obj.obj_type_ == config.WORLD_FORT then
        obj.is_load_ = true
        load_build = self.world_build_[obj.x_][obj.z_][2] 
        if not load_build then
            load_build = GameObject.Instantiate(self.build_prefabs_[obj.obj_type_])
            load_build.transform:SetParent(parent.transform, false)
            self.world_build_[obj.x_][obj.z_][2] = load_build
        end
        load_build.name = "fort"..obj.idx_
        local time_txt = load_build.transform:Find("time/Text"):GetComponent(TextMesh)
        local owner = load_build.transform:Find("owner").gameObject
        obj:set_fort_text_mesh(time_txt)
        obj:set_owner_active(owner)
    elseif obj.obj_type_ == config.WORLD_RESPOINT then
        obj.is_load_ = true
        load_build = self.world_build_[obj.x_][obj.z_][2]
        if not load_build then
            load_build = GameObject.Instantiate(self.build_prefabs_[obj.obj_type_])
            load_build.transform:SetParent(parent.transform, false)
            self.world_build_[obj.x_][obj.z_][2] = load_build
        end
        load_build.name = "respoint"..obj.idx_
        obj:make_component(load_build)
    end
    if self.world_build_preload_[obj.x_] and self.world_build_preload_[obj.x_][obj.z_] then
        self.world_build_preload_[obj.x_][obj.z_](load_build)
        self.world_build_preload_[obj.x_][obj.z_] = nil
    end
end

function on_dispose(self)
    self.logic_box_ = nil
    self.messager_:dispose()
    if self.world_build_ then
        for k,v in pairs(self.world_build_) do
            for _k,_v in pairs(v) do
                Object.Destroy(_v[2])
            end
        end
    end
    self.world_build_preload_ = {}
    self.world_build_ = {}
    self.cur_fort_owner_ = nil
end

-- 这里单独删除模型数据,用于逻辑-彻底删除逻辑数据
function on_delete_obj_build(self, x, z)
    if not self.world_build_ then return end
    if not self.world_build_[x] then return end
    if not self.world_build_[x][z] then return end
        -- 这里逻辑上需要释放点~如果出现BUG~考虑一下时序问题
    self.world_build_[x][z][1] = nil
    self.world_build_[x][z] = nil
end

-- 这个只是删除模型，不删除数据，因为由于逻辑需要-模型数据暂时缓存
function on_delete_obj(self, id)
    local obj = WorldManager:get_world_obj_by_id(id)
    self:pop_build(obj)
end

function on_refresh_obj(self, id)
    local obj = WorldManager:get_world_obj_by_id(id)
    if not obj then return end
    self:push_build(obj)
    self:load_build_by_obj(obj)
end

function on_refresh_respoint(self, id)
    local obj = WorldManager:get_world_obj_by_id(id)
    if not obj then return end
    local res_build = self.world_build_[obj.x_][obj.z_][2]
    -- 这里不用设置预加载
    if not res_build then return end
    obj:make_component(res_build)
end

-- 刷新势力据点
function on_refresh_fort(self, id)
    local obj = WorldManager:get_world_obj_by_id(id)
    if not obj then return end
    local fort_build = self.world_build_[obj.x_][obj.z_][2]
    -- 这里不用设置预加载
    if not fort_build then return end
    local time_txt = fort_build.transform:Find("time/Text"):GetComponent(TextMesh)
    local owner = fort_build.transform:Find("owner").gameObject
    --如果有当前据点相关的战斗动画未完成,延迟修改状态
    --print("on_refresh_fort id: "..id)
    if WorldManager:hasBattleQueue(id) then
        _G.LuaTimer.Add( _G.config.BATTLE_COST_TIME * 1000, function()
            obj:set_fort_text_mesh(time_txt)
            obj:set_owner_active(owner)
        end)
        return
    end

    obj:set_fort_text_mesh(time_txt)
    obj:set_owner_active(owner)
end

function pop_build(self, obj)
    if not obj then return end
    if self.world_build_[obj.x_] and self.world_build_[obj.x_][obj.z_] then
        if self.world_build_[obj.x_][obj.z_][2] then
            Object.Destroy(self.world_build_[obj.x_][obj.z_][2])
            self.world_build_[obj.x_][obj.z_][2] = nil
        end
        obj:prepare_reload()
    end
end

function push_build(self, obj)
    if not obj then return end
    if not self.world_build_[obj.x_] then
        self.world_build_[obj.x_] = {}
    end
    if not self.world_build_[obj.x_][obj.z_] then
        self.world_build_[obj.x_][obj.z_] = {}
    end
    self.world_build_[obj.x_][obj.z_][1] = obj
end

function get_build(self, x, z)
    if not x then return end
    if not z then return end
    if not self.world_build_ then return end
    if not self.world_build_[x] then return end
    if not self.world_build_[x][z] then return end    
    return self.world_build_[x][z][2]
end

-- 设置预加载回调函数
function set_world_build_preload(self, x, z, callback)
    if not self.world_build_preload_[x] then
        self.world_build_preload_[x] = {}
    end
    self.world_build_preload_[x][z] = callback
end

function on_fort_owner_hide(self, x, z)
    self.cur_fort_owner_ = nil
    if not x or not z then return end
    local obj = WorldManager:get_world_obj(x, z)
    if not obj then return end
    if obj.obj_type_ ~= config.WORLD_FORT then return end    
    local fort_build = self.world_build_[obj.x_][obj.z_][2]
    if not fort_build then
        self:set_world_build_preload(x, z, function(fort_build)
            local owner = fort_build.transform:Find("owner").gameObject
            self.cur_fort_owner_ = {x, z, owner} 
        end)
        return 
    end
    local owner = fort_build.transform:Find("owner").gameObject
    obj:set_owner_active(owner)
    self.cur_fort_owner_ = {x, z, owner}      
end

function on_menu_update(self)
    if self.cur_fort_owner_ then
        local x = self.cur_fort_owner_[1]
        local z = self.cur_fort_owner_[2]
        local owner = self.cur_fort_owner_[3]
        if not Slua.IsNull(owner) then
            local obj = WorldManager:get_world_obj(x, z)
            if obj then 
                obj:set_owner_active(owner)
            end
        end
        self.cur_fort_owner_ = nil
    end
end