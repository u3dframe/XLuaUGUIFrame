local SceneLogin        = _G.SceneController:Get("SceneLogin")

function SceneLogin:OnLoad()
    _G.UIController:ShowUI("UILogin", {targetUIType = _G.GlobalEmum.UIType.Static })
    -- _G.UIController:ShowUI("test")
end
