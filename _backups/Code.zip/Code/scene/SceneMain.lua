local tiny      = require("Tools/tiny")
local SceneMain = _G.SceneController:Get("SceneMain")

function SceneMain:OnLoad()
    _G.UIController:ShowUI("UIMain", {targetUIType = _G.GlobalEmum.UIType.Static})

    self.MainInputSystem = require("System/MainInputSystem"):create(1)
    self.BuildingSystem = require("System/Main/BuildingSystem"):create(1)
    self.mainWorld = tiny.world(unpack({
        self.MainInputSystem,
        self.BuildingSystem
    }))

    self.activeWorld = self.mainWorld

    _G.UIController:Get("UILoading"):FadeOut()
end

function SceneMain:Unload()
    print("tiny.dispose")
    if self.MainInputSystem then
        self.MainInputSystem:dispose()
        self.MainInputSystem = nil
    end
    if self.BuildingSystem then
        self.BuildingSystem:dispose()
        self.BuildingSystem = nil
    end
    -- if self.activeWorld then
    --     tiny.dispose(self.activeWorld)
    -- end
end

function SceneMain:OnUpdate(dt)
    if self.activeWorld then
        tiny.update(self.activeWorld, dt)
    end
end