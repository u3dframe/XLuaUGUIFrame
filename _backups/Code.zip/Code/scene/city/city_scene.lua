module("CityScene",package.seeall)
setmetatable( CityScene, {__index = BaseScene})

local Msg = _G.Msg

Layer_Mask_City      =  512   --1<<9
Layer_Mask_CityTitle = 1024   --1<<10
CITY_CAMERA_LOCATE_SIZE = 5 -- 定位之后的size
CITY_CAMERA_INIT_SIZE = 3.5
CITY_CAMERA_MIN_SIZE = 2.8
CITY_CAMERA_MAX_SIZE = 6.5
CITY_CAMERA_MAX_BACK_SIZE = CITY_CAMERA_MAX_SIZE - (CITY_CAMERA_MAX_SIZE - CITY_CAMERA_MIN_SIZE) * 0.05
CITY_CAMERA_MIN_BACK_SIZE = CITY_CAMERA_MIN_SIZE + (CITY_CAMERA_MAX_SIZE - CITY_CAMERA_MIN_SIZE) * 0.05
CITY_CAMERA_BUILD_JUMP_SIZE = 4
CITY_CAMERA_OUTSIZE_BUILD_JUMP_SIZE = 2 --资源田建筑跳转大小

CITY_LEFT_LIMIT = -19
CITY_RIGHT_LIMIT = 19
CITY_TOP_LIMIT = 14
CITY_BOTTOM_LIMIT = -12.2

local RANDOM_SHOP_SPACE_ID  = 47 --随机商店空地ID
local WHARF_SPACE_ID        = 51 --市舶司空地ID

--city_build
function on_awake(self)
	self.canvas_ = GameObject.Find("CityCanvas").transform
    self.camera_ = Camera.main
    self.farMoveBg = GameObject.Find("FarMoveBg"):GetComponent(RectTransform)
    self.middleMoveBg = GameObject.Find("MiddleMoveBg"):GetComponent(RectTransform)
    self.backGround = GameObject.Find("BackGroup"):GetComponent(RectTransform)
	self.canvas_scaler_ = self.canvas_:GetComponent(CanvasScaler)
	self.input_rect_ = self.canvas_:Find("Input"):GetComponent(RectTransform)
	self.container_ = self.canvas_:Find("Container")
    self.map_rect_ = self.container_.transform:Find("Map")
    self.builds_parent_ = self.map_rect_:Find("Buildings")
    self.components_ = self.canvas_.transform:Find("Components")
    self.scroll_rect_ = self.container_:GetComponent(ScrollRect)
    --获取层级
    self.layer_ = self.gameObject.layer

    self.click_callbacks_ = {}

    self.camera_.orthographicSize = CITY_CAMERA_INIT_SIZE

    self.screen_half_height_ = Screen.height / 2
    self.inertial_acceleration_ = 6000
    self.min_inertial_speed_ = 5
    self.max_inertial_speed_ = 30
    self.pinch_factor_ = 0.01
    self.drag_velocity_ = Vector2.zero

    --后面改透视,估计都不需要了,临时这样
    --关于远景分层
    --local backGroundWidth = self.backGround.sizeDelta.x;
    self.farMoveSpeedX = 0.12 * (self.camera_.orthographicSize / CITY_CAMERA_MIN_SIZE)
    self.middleMoveSpeedX= 0.07 * (self.camera_.orthographicSize / CITY_CAMERA_MIN_SIZE)
    self.farMoveSpeedY = 0.1
    self.middleMoveSpeedY = 0.05

    self.easy_touch_event_ = self.map_rect_.gameObject:GetComponent(EasyTouchEvent)
    self.easy_touch_event_.OnETDrag = function(ge)
        self:on_et_drag(ge)
    end
    self.easy_touch_event_.OnETDragEnd = function(ge)
        self:on_et_drag_end(ge)
    end
    self.easy_touch_event_.OnETTouchStart = function(ge)
        self:on_et_touch_start(ge)
    end
    self.easy_touch_event_.OnETSimpleClick = function(ge)
        self:on_et_click(ge)
    end

    self.easy_touch_event_.OnETPinch = function(ge)
        self:on_et_pinch(ge)
    end

    self.easy_touch_event_.OnETPinchEnd = function(ge)
        self:on_et_pinch_end(ge)
    end

    self.easy_touch_event_.OnETTouchUp = function(ge)
        self:on_et_touch_up(ge)
    end

    self.messager_:add_listener(Msg.CITY_UP_LV_UPDATE, on_up_lv_update)
    self.messager_:add_listener(Msg.CITY_UP_LV_FINISHED, on_up_lv_finished)
    self.messager_:add_listener(Msg.CITY_GOLD_UP_LV, on_gold_lvup_update)
    self.messager_:add_listener(Msg.CITY_SOIDIER_UPDATE, on_soldier_drill_update)
    self.messager_:add_listener(Msg.CITY_SOIDIER_FINISHED, on_soldier_drill_finished)
    self.messager_:add_listener(Msg.CITY_COLLECT_REFRESH, on_collect_refresh)
    self.messager_:add_listener(Msg.CITY_COLLECT_FINISHED, on_collect_finished)
    self.messager_:add_listener(Msg.CITY_SOLDIER_CURE_UPDATE, on_soldier_cure_update)
    self.messager_:add_listener(Msg.CITY_SOLDIER_CURE_FINISHED, on_soldier_cure_finish)
    self.messager_:add_listener(Msg.CITY_BUILD_REMOVED_FINISHED, on_build_removed_finish)
    self.messager_:add_listener(Msg.CITY_BUILD_REMOVED_CANCEL, on_build_removed_cancel)
    self.messager_:add_listener(Msg.CITY_SHOW_CAN_EXCHANGE_BUILD, on_show_movable_build)
    self.messager_:add_listener(Msg.CITY_BUILD_MOVE_FINISHED, on_build_change_finished)
    self.messager_:add_listener(Msg.RESOURCE_OR_COIN_CHANGE, on_resource_change)
    self.messager_:add_listener(Msg.CITY_RANDOM_SHOP_UPDATE, CITY_RANDOM_SHOP_UPDATE)
    self.messager_:add_listener(Msg.CITY_FETE_UPDATE, OnCityFeteUpdate)
    self.messager_:add_listener(Msg.CITY_WHARF_UPDATE, OnWharfUpdate)
    self.messager_:add_listener(Msg.CITY_STOP_TIMER2, OnStopTimer2)

    if _G.event and _G.EventKey then
        self:AddEventListener(_G.EventKey.CITY_SOIDIER_UPDATE, function()
            self:on_soldier_drill_update()
        end)
        self:AddEventListener(_G.EventKey.CITY_SOIDIER_FINISHED, function()
            self:on_soldier_drill_finished()
        end)
        self:AddEventListener(_G.EventKey.CITY_FETE_UPDATE, function(args)
            self:OnCityFeteUpdate(args)
        end)
    end
end

function on_up_lv_update(self, build_id)
    local space = self:get_space_by_build_id(build_id)
    if space then
        BuildManager:append_queue(build_id)
        space:on_building()
    end
end

--金币建造升级不参与队列
function on_gold_lvup_update(self, build_id)
    local space = self:get_space_by_build_id(build_id)
    if space then
        space:on_building()
    end
end

function on_up_lv_finished(self, build_id)
    local space = self:get_space_by_build_id(build_id)
    if space then
        space:on_up_lv_finished(build_id)
    end

    --刷新建筑mark 资源更新需要刷新绿色箭头
    local builds = BuildManager:GetNormalBuild()
    if not builds then return end
    for _, v in pairs(builds) do
        local space = self:get_space_by_build_id(v.id_)
        if space then
            space:get_bill_board():set_build_mark()
        end
    end
end

function on_soldier_drill_update(self, arg1, soldier_id, soldier_class)
    local build_id = arg1
    if _G.EventKey then
        soldier_id = arg1.soldierID
        build_id = arg1.buildID
        soldier_class = arg1.soldierClass
    end
    local space = self:get_space_by_build_id(build_id)
    if space then space:play_timer(soldier_id, soldier_class) end
end

function on_soldier_drill_finished(self, arg1, soldier_id, soldier_class)
    local build_id = arg1
    if _G.EventKey then
        soldier_id = arg1.soldierID
        build_id = arg1.buildID
        soldier_class = arg1.soldierClass
    end
    local space = self:get_space_by_build_id(build_id)
    if space then space:on_soldier_drill_finished(build_id, soldier_id, soldier_class) end
end

function on_soldier_cure_update(self, build_type)
    local builds = BuildManager:get_all_builds_by_type(build_type)
    if builds then
        for k, v in pairs(builds) do
            local space = self.space_item_tb_[v.space_id_]
            if space then
                space:hurts_timer()
            end
        end
    end
end

function on_soldier_cure_finish(self, data)
    local builds = BuildManager:get_all_builds_by_type(config.BUILD_TYPE.HOSPITAL)
    if builds then
        for k, v in pairs(builds) do
            local space = self.space_item_tb_[v.space_id_]
            if space then
                space:on_soldier_cure_finished(data)
            end
        end
    end
end

function on_collect_refresh(self, build_id)
    local space = self:get_space_by_build_id(build_id)
    if space then
        space:on_collect_refresh(build_id)
    end
end

function on_collect_finished(self, build_id)
    local space = self:get_space_by_build_id(build_id)
    if space then
        space:on_collect_finished(build_id)
    end
end

--资源数量改变,刷新BuildMark
function on_resource_change(self)
    for k, v in pairs(self.space_item_tb_) do
        if v then v:get_bill_board():set_build_mark() end
    end
end

function on_build_removed_cancel(self, build_id)
    local space = self:get_space_by_build_id(build_id)
    if space then
        space:on_build_removed_cancel()
    end
end

--移动建筑 显示效果
function on_show_movable_build(self, build_id)
    local build = BuildManager:get_build_info_by_id(build_id)
    if build then
        for k, v in pairs(self.space_item_tb_) do
            if v then 
                v:show_build_effect(build_id)
                v:build_exchange_last_id(build_id)
            end
        end
    end
end

-- --取消建筑移动  隐藏效果
-- function on_hide_mvable_build(self)
--     for k, v in pairs(self.space_item_tb_) do
--         if v then
--             v:hide_build_effect()
--         end
--     end
-- end

--建筑移动完成
function on_build_change_finished(self, data)
    if not data then return end
    for k, v in pairs(self.space_item_tb_) do
        if v then
            v:on_build_exchanged(data)
        end
    end
end

--建筑拆除完成
function on_build_removed_finish(self, space_id)
    local space = self.space_item_tb_[space_id]
    if not space then return end
    space:on_build_removed_finished()
end

function CITY_RANDOM_SHOP_UPDATE(self, isClose)
    local space = self.space_item_tb_[RANDOM_SHOP_SPACE_ID]
    if space then
        if isClose == 1 then
            space:get_bill_board():HideBuildTitle()
        elseif isClose == 2 then
            space:get_bill_board():set_build_title(config.BUILD_TITLE_TYPE.RANDOM_SHOP)
        end
    end
end

--刷新市舶司
function OnWharfUpdate(self)
    local space = self.space_item_tb_[WHARF_SPACE_ID]
    if space then
        space:RefreshWharf()
    end
end

function OnStopTimer2(self)
    local space = self.space_item_tb_[WHARF_SPACE_ID]
    if space then
        space:stop_timer_2()
    end
end

function OnCityFeteUpdate(self, isShow)
    local space = self.space_item_tb_[45]
    if space then
        if isShow then
            space:get_bill_board():set_build_title(config.BUILD_TITLE_TYPE.FETE)
        else
            space:get_bill_board():HideBuildTitle()
        end
    end
end

--根据id 获取space
function get_space_by_build_id(self, build_id)
    local space
    local build = BuildManager:get_build_info_by_id(build_id)
    if build and build.space_id_ then
        space = self.space_item_tb_[build.space_id_]
    end
    if not space then elog("not found build by id.  id = %s", build_id) end
    return space
end

function register_click(self, gameObject, callback)
    --注册点击回调
    if type(callback) == "function" then
        self.click_callbacks_[gameObject] = callback
    end
end

function deregister_click(self, gameObject, callback)
    --注销点击回调
    self.click_callbacks_[gameObject] = nil
end

function get_raycast_object(self, gesture, layer)
    --根据touch坐标做射线检测，返回碰撞的第一个物体
    local ray = self.camera_:ScreenPointToRay(Vector3(gesture.position.x, gesture.position.y, 0))
    local r = Physics2D.RaycastAll(ray.origin, ray.direction, 1000, layer).Table
    if #r > 1 then
        for i,v in ipairs(r) do
            local name = v.collider.transform.gameObject.name
            local pos = string.find(name, 'BuildMask')
            if pos then
                return v.collider.transform.gameObject
            end
        end
    end
    if #r > 0 then return r[1].collider.transform.gameObject end
end

function checked_camera_position(self, target)
    -- 返回边界检查后的摄像机目标位置
    local offset = target - self.camera_.transform.position
    local offset_by_pixel = offset / self.camera_.orthographicSize * self.screen_half_height_
    local world_offset = self.camera_:ScreenToWorldPoint(offset_by_pixel)
    local new_world_offset = Vector3(world_offset.x, world_offset.y, world_offset.z)
    if new_world_offset.x < CITY_LEFT_LIMIT then
        new_world_offset.x = CITY_LEFT_LIMIT
    end
    if new_world_offset.y < CITY_BOTTOM_LIMIT then
        new_world_offset.y = CITY_BOTTOM_LIMIT
    end
    local world_pos1 = self.camera_:ScreenToWorldPoint(Vector3(offset_by_pixel.x + Screen.width, offset_by_pixel.y + Screen.height, 0))
    if world_pos1.x > CITY_RIGHT_LIMIT then
        new_world_offset.x = new_world_offset.x - (world_pos1.x - CITY_RIGHT_LIMIT)
    end
    if world_pos1.y > CITY_TOP_LIMIT then
        new_world_offset.y = new_world_offset.y - (world_pos1.y - CITY_TOP_LIMIT)
    end
    if new_world_offset == world_offset then return target end
    local camera_offset = self.camera_:WorldToScreenPoint(new_world_offset)
    camera_offset = camera_offset / self.screen_half_height_ * self.camera_.orthographicSize
    return self.camera_.transform.position + camera_offset
end

function on_et_touch_start(self, gesture)
    if self.camera_tween_ then
        self.camera_tween_:Kill(false)
    end
    if gesture.touchCount == 1 and self.move_obj_into_screen_tween_ then
        self.move_obj_into_screen_tween_:Pause()
    end
    if self.build_menu_ then
        self.build_menu_:animation_hide()
    end
end

function on_et_touch_up(self, gesture)
    if gesture.touchCount == 1 and self.move_obj_into_screen_tween_ then
        self.move_obj_into_screen_tween_:Play()
    end
end

function on_et_click(self, gesture)
    local obj
    if _G.GRichTextField then
        obj = self:get_raycast_object(gesture, Layer_Mask_CityTitle)
        -- 点击city_space的气泡
        if obj and self.click_callbacks_[obj] then
            self.click_callbacks_[obj]()
            return
        end
    end

    obj = self:get_raycast_object(gesture, Layer_Mask_City)
    if obj and self.click_callbacks_[obj] then
        for _, space in ipairs(self.space_item_tb_) do
            if space.gameObject == obj then
                self.click_callbacks_[obj](space)
                return
            end
        end
        if self.click_callbacks_[obj] then
            self.click_callbacks_[obj]()
        end
    end
end

function on_et_drag(self, gesture)
    if gesture.deltaPosition == Vector2.zero then return end
    local pos = self.camera_.transform.position
    local factor = self.camera_.orthographicSize / self.screen_half_height_
    local offset = -gesture.deltaPosition * factor
    pos = pos + Vector3(offset.x, offset.y, 0)
    self.camera_.transform.position = self:checked_camera_position(pos)
    self.drag_velocity_ = -gesture.deltaPosition / Time.deltaTime * factor
    if self.drag_velocity_.sqrMagnitude > self.max_inertial_speed_ * self.max_inertial_speed_ then
        self.drag_velocity_ = self.drag_velocity_.normalized * self.max_inertial_speed_
    end

    -- 设置移动UI组件
    self:set_move_board()
    if self.move_obj_into_screen_tween_ then
        self.move_obj_into_screen_tween_:Kill(false)
    end
end

--关于远景分层
function updateMoveBg(self)
    local offset = self.camera_.transform.position - self.oldPos
    moveBg(self.farMoveBg, offset, self.farMoveSpeedX, self.farMoveSpeedY)
    moveBg(self.middleMoveBg, offset, self.middleMoveSpeedX, self.middleMoveSpeedY)
    self.oldPos = self.camera_.transform.position
end

function moveBg(target, offset, speedX, SpeedY)
    local offsetX = offset.x
    local offsetY = offset.y
    offsetX = offsetX * speedX
    offsetY = offsetY * SpeedY
    local moveBgOffset = _G.Vector3(offsetX, offsetY, 0)
    target.transform.position = target.transform.position + moveBgOffset
end

function set_move_board(self)
    self:updateMoveBg()

    for _, space in ipairs(self.space_item_tb_) do
        if space.bill_board_ then
            space.bill_board_:set_mark_axis()
        end
    end
    if self:is_alive() and self.build_menu_ and self.build_menu_.gameObject.activeSelf then
        self.build_menu_:set_menu_axis()
    end
end

function on_et_drag_end(self)
    local drag_speed = self.drag_velocity_.magnitude
    if drag_speed <= self.min_inertial_speed_ then
        return
    end
    local inertial_acceleration = self.inertial_acceleration_ * self.camera_.orthographicSize / self.screen_half_height_
    local inertial_time = drag_speed / inertial_acceleration
    local pos = self.camera_.transform.position
    local a = -self.drag_velocity_.normalized * inertial_acceleration
    local max_s = self.drag_velocity_ * inertial_time + a * inertial_time * inertial_time * 0.5
    local limit_pos = self:checked_camera_position(pos + Vector3(max_s.x, max_s.y, 0))
    local limit_s = limit_pos - pos
    self.camera_tween_ = GameTween.DOMove(self.camera_.transform, 
                                          pos + Vector3(max_s.x, max_s.y, 0),
                                          inertial_time, 
                                          false):OnUpdate(
        function()
            local new_pos = self.camera_.transform.position
            if math.abs(new_pos.x - pos.x) > math.abs(limit_s.x) then
                new_pos.x = limit_pos.x
            end
            if math.abs(new_pos.y - pos.y) > math.abs(limit_s.y) then
                new_pos.y = limit_pos.y
            end
            self.camera_.transform.position = new_pos
            self:set_move_board()
        end
    )
    self.camera_tween_:SetEase(XEase.OutQuad)
end

function on_et_pinch(self, gesture)
    if not self:is_alive() then return end
    if not self.screen_pinch_center_ then
        local pos0 = self.easy_touch_event_.TouchPosition0
        local pos1 = self.easy_touch_event_.TouchPosition1
        local mid = (pos0 + pos1) / 2
        self.screen_pinch_center_ = Vector3(mid.x, mid.y, 0)
        self.world_pinch_center_ = self.camera_:ScreenToWorldPoint(self.screen_pinch_center_)
    end
    local newSize = self.camera_.orthographicSize - gesture.deltaPinch * self.pinch_factor_
    if newSize > CITY_CAMERA_MAX_SIZE then
        newSize = CITY_CAMERA_MAX_SIZE
    end
    if newSize < CITY_CAMERA_MIN_SIZE then
        newSize = CITY_CAMERA_MIN_SIZE
    end
    self.camera_.orthographicSize = newSize
    local new_screen_center = self.camera_:WorldToScreenPoint(self.world_pinch_center_)
    local screen_offset = new_screen_center - self.screen_pinch_center_
    local world_offset = screen_offset / self.screen_half_height_ * self.camera_.orthographicSize
    world_offset.z = 0
    local new_camera_pos = self:checked_camera_position(self.camera_.transform.position + world_offset)
    self.camera_.transform.position = new_camera_pos

    self:set_move_board()
    if self.move_obj_into_screen_tween_ then
        self.move_obj_into_screen_tween_:Kill(false)
    end

    if self.camera_.orthographicSize <= 3.5 then
        for k, v in pairs(self.space_item_tb_) do
            if v and v:get_bill_board() then v:get_bill_board():set_build_mark() end
        end
    else
        if not self.space_item_tb_ then return end
        for k, v in pairs(self.space_item_tb_) do
            if v and v:get_bill_board() then v:get_bill_board():hide_build_mark() end
        end
    end
end

function on_et_pinch_end(self, gesture)
    if not self:is_alive() or not self.camera_ then return end
    local size = self.camera_.orthographicSize
    if size > CITY_CAMERA_MAX_BACK_SIZE then
        self.camera_tween_ = GameTween.To(function(v)
            self.camera_.orthographicSize = v
        end, size, CITY_CAMERA_MAX_BACK_SIZE, 1, false):OnUpdate(
            function() self:set_move_board() end
        )
    elseif size < CITY_CAMERA_MIN_BACK_SIZE then
        self.camera_tween_ = GameTween.To(function(v)
            self.camera_.orthographicSize = v
        end, size, CITY_CAMERA_MIN_BACK_SIZE, 1, false):OnUpdate(
            function() self:set_move_board() end
        )
    end
    self.screen_pinch_center_ = nil
    self.world_pinch_center_ = nil
end

function on_hide_all(self)
    for k, v in pairs(self.space_item_tb_) do
        if v then v:get_bill_board():hide_build_mark() end
    end
end

function on_show_all(self)
    for k, v in pairs(self.space_item_tb_) do
        if v then v:get_bill_board():set_build_mark() end
    end
end

function move_obj_to_screen_upper(self, gameObject, size, duration)
    --将场景中的指定物体对准屏幕上部跳转点
    self:move_world_pos_to_screen_point(gameObject.transform.position, size, duration,
                                        --Vector3(Screen.width / 2, Screen.height * 0.75, 0), true)
                                        Vector3(Screen.width * 0.25, Screen.height / 2, 0), true)
end

function move_obj_to_screen_center(self, gameObject, size, duration)
    --将场景中的指定物体对准屏幕中心跳转点
    self:move_world_pos_to_screen_point(gameObject.transform.position, size, duration, 
                                        Vector3(Screen.width / 2, Screen.height / 2, 0), true)
end

-- 将物体定位到屏幕中心
function locate_obj_to_screen_center(self, gameObject, size, duration)
    if not gameObject then return end
    local new_size = size
    local pos = gameObject.transform.position
    local new_pos = Vector3(pos.x, pos.y, 0)
    if size then
        new_size = size
    else
        new_size = CITY_CAMERA_LOCATE_SIZE
    end
    -- 不传参数默认 0.5
    if not duration then duration = 0.3 end

    GameTween.To(function(v)
        self.camera_.orthographicSize = v
    end,self.camera_.orthographicSize, new_size, duration)
    GameTween.DOLocalMove(self.camera_.transform, new_pos, duration, false):OnUpdate(function()
        self:set_move_board()
    end)
end

function move_world_pos_to_screen_point(self, world_pos, size, duration, screen_point, restorable)
    if self.move_obj_into_screen_tween_ then
        self.move_obj_into_screen_tween_:Kill(false)
    end
    new_size = size or CITY_CAMERA_BUILD_JUMP_SIZE
    if new_size > CITY_CAMERA_MAX_SIZE then
        new_size = CITY_CAMERA_MAX_SIZE
    end
    if new_size < CITY_CAMERA_MIN_SIZE then
        new_size = CITY_CAMERA_MIN_SIZE
    end
    local old_size = self.camera_.orthographicSize
    self.camera_.orthographicSize = new_size
    local src_screen_pos = self.camera_:WorldToScreenPoint(world_pos)
    self.camera_.orthographicSize = old_size
    local src_screen_offset = screen_point - src_screen_pos
    local camera_offset = -src_screen_offset / self.screen_half_height_ * new_size
    camera_offset.z = 0
    local camera_target = self.camera_.transform.position + camera_offset
    self:modify_camera_state(camera_target, new_size, duration, restorable)
end

function modify_camera_state(self, new_pos, new_size, duration, restorable)
    --设置摄像机状态
    self:on_hide_all()
    if restorable then
        if self.camera_restore_point_ then return false end
        self.camera_restore_point_ = {
            position = self.camera_.transform.position,
            orthographicSize = self.camera_.orthographicSize
        }
    end
    duration = duration or 0.2
    GameTween.DOMove(self.camera_.transform, new_pos, duration, false):OnUpdate(function()
        self:set_move_board()
    end)
    GameTween.To(function(v)
        self.camera_.orthographicSize = v
    end, self.camera_.orthographicSize, new_size, duration)
    return true
end

function restore_camera_state(self, duration)
    --恢复摄像机状态至还原点
    self:on_show_all()
    if not self.camera_restore_point_ then return false end
    duration = duration or 0.2
    local state = self.camera_restore_point_
    GameTween.DOMove(self.camera_.transform, state.position, duration, false):OnUpdate(function()
        self:set_move_board()
    end)
    GameTween.To(function(v)
        self.camera_.orthographicSize = v
    end, self.camera_.orthographicSize, state.orthographicSize, duration)
    self.camera_restore_point_ = nil
    return true
end

function move_obj_into_screen(self, obj)
    local obj_rect = obj:GetComponent(RectTransform)
    local world_center = obj_rect.position
    local scale = self.canvas_.localScale
    local obj_half_width = obj_rect.sizeDelta.x / 2 * scale.x
    local obj_half_height = obj_rect.sizeDelta.y / 2 * scale.y
    local min_pos = self.camera_:WorldToScreenPoint(world_center - Vector3(obj_half_width, obj_half_height, 100))
    local max_pos = self.camera_:WorldToScreenPoint(world_center + Vector3(obj_half_width, obj_half_height, 100))
    local rect_left_limit = min_pos.x
    local rect_right_limit = max_pos.x
    local rect_top_limit = max_pos.y
    local rect_bottom_limit = min_pos.y

    local screen_center = self.camera_:WorldToScreenPoint(world_center)
    local menu_half_width = Screen.width * 0.27
    local menu_half_height = Screen.height * 0.27
    local menu_left_limit = screen_center.x - menu_half_width
    local menu_right_limit = screen_center.x + menu_half_width
    local menu_bottom_limit = screen_center.y - menu_half_height

    local left_limit = rect_left_limit > menu_left_limit and menu_left_limit or rect_left_limit
    local right_limit = rect_right_limit > menu_right_limit and rect_right_limit or menu_right_limit
    local top_limit = rect_top_limit
    local bottom_limit = rect_bottom_limit > menu_bottom_limit and menu_bottom_limit or rect_bottom_limit

    local screen_offset = Vector3.zero
    if right_limit - left_limit > Screen.width then
        screen_offset.x = screen_center.x - Screen.width / 2
    elseif left_limit < 0 then
        screen_offset.x = left_limit
    elseif right_limit > Screen.width then
        screen_offset.x =  right_limit - Screen.width
    end
    if top_limit - bottom_limit > Screen.height then
        screen_offset.y = screen_center.y - Screen.height / 2
    elseif bottom_limit < 0 then
        screen_offset.y = bottom_limit
    elseif top_limit > Screen.height then
        screen_offset.y = top_limit - Screen.height
    end
    if screen_offset == Vector3.zero then return end
    local world_offset = screen_offset / self.screen_half_height_ * self.camera_.orthographicSize
    self.move_obj_into_screen_tween_ = GameTween.DOMove(self.camera_.transform,
                                                        self.camera_.transform.position + world_offset,
                                                        0.5, false)
    self.move_obj_into_screen_tween_:OnUpdate(
        function() self:set_move_board() end
    )
end

function on_click_build(self, space)
    self:move_obj_into_screen(space.gameObject)
    space:click_build(self.build_menu_)
end

function on_click_build_mask(self, prop)
    if not prop then return end
    if not prop.unlock then return end
    local main_lv = BuildManager:get_main_lv()
    if prop.unlock > main_lv then
        MsgCenter.send_message(Msg.SHOW_HINT, lang("RESOURCE_BUILDING_1", prop.unlock))
    else
        local data = {}
        data.items = prop.resource
        data.title = lang("UI_BASIC_HINT")
        data.content = lang("RESOURCE_BUILDING_9")--"解锁当前区域需要消耗道具："
        UIManager.open_window("NotifyItemWindow", nil, data, function()
            Net.send("cityunlock_buy",{id = prop.id}, function(result)
                if result.e == 0 then
                    local main_lv = BuildManager:get_main_lv()
                    for i,v in ipairs(BuildManager.build_res_unlock_) do
                        if v.unlock > 1 then
                            local str = "BuildMask"..i
                            if CollectManager.collect_unlock_[v.id] then
                                self.builds_parent_:Find(str).gameObject:SetActive(false)
                            end
                        end
                    end
                end
            end)
        end)
    end
end

function on_resource(self)
    --加载显示name 和 lv的组件
    self:init_builds()
    --加载菜单
    self:init_build_menu()

    --关于远景分层,后面改透视,估计都不需要了,临时这样
    --固定位置
    self.oldPos = Vector3(0,9.4,-10)
    self:updateMoveBg()
end

function on_start(self)
    for i,v in ipairs(BuildManager.build_space_) do
        local str = "Build"..i
        self:register_click(self.builds_parent_:Find(str).gameObject, function(space)
            self:on_click_build(space)
        end)
    end
    local main_lv = BuildManager:get_main_lv()
    for i,v in ipairs(BuildManager.build_res_unlock_) do
        if v.unlock > 1 then
            local str = "BuildMask"..i
            if CollectManager.collect_unlock_[v.id] then
                self.builds_parent_:Find(str).gameObject:SetActive(false)
            end
            self:register_click(self.builds_parent_:Find(str).gameObject, function()
                self:on_click_build_mask(v)
            end)
        end
    end
end

function on_dispose(self)
    if self.build_menu_ then
        Object.Destroy(self.build_menu_.gameObject)
    end
    if self.space_item_tb_ then
        for _, space in ipairs(self.space_item_tb_) do
            if space then
                space:on_dispose()
            end
        end
        self.space_item_tb_ = nil
    end
end


function map_move_to_upper(self, build_class)
    -- local sapce = build_class.space_info_
    -- local isOutsizeBuild
    -- if sapce then
    --     isOutsizeBuild = sapce:isOutSideSpace()
    -- end
    -- local size = isOutsizeBuild and CITY_CAMERA_OUTSIZE_BUILD_JUMP_SIZE or CITY_CAMERA_BUILD_JUMP_SIZE
    self:move_obj_to_screen_upper(build_class.gameObject)
end


function back_play_animate(self)
    self:restore_camera_state()
end



-----------------------------------------------load----------------------------------------------

function init_builds(self)
    self.space_item_tb_ = {}
    for _, space in pairs(BuildManager.build_space_) do
        local obj = self.map_rect_.transform:Find("Buildings/Build"..space.id_)
        local space_item_class = CitySpace:new(space.id_, self)
        space_item_class:AddLuaComponent(obj.gameObject)
        table.insert(self.space_item_tb_, space_item_class)
    end
end

function init_cityspace_callback(self)
    
end

function init_build_menu(self)
    local build_meun_tb = {}
    self:load_gameobject("Common/BuildMenu", UIManager.BoardLayer, BuildMenu, 1, build_meun_tb)
    self.build_menu_ = build_meun_tb[1]
end

--1.组件名称 2.父物体 3.组件类名 4.需要实例化的个数 5.存放的表(可空)
function load_gameobject(self, name, parent, class, count, obj_tb)
    Yield(UIUtil.load_component(name, function(obj)
        for i = 1, count do
            local go = GameObject.Instantiate(obj)
            go.name = name..i
            go.transform:SetParent(parent.gameObject.transform, false)
            go.transform.localScale = Vector3.one
            go:SetActive(false)
            if class then
                local obj_class = class:new(i)
                obj_class:AddLuaComponent(go)
                obj_class:init()
                if obj_tb then
                   table.insert(obj_tb, obj_class)
                end
            else
                if obj_tb then
                   table.insert(obj_tb, go)
                end
            end
        end
    end))
end