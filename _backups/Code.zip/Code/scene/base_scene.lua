module("BaseScene",package.seeall)
setmetatable( BaseScene, {__index = LuaComponentBase})

function new(self, data)
	local obj = {}
	setmetatable(obj, {__index = self})
	obj.data = data
	return obj
end

---------Mono方法---------------------------------


function Awake(self)
	self.messager_ = Messager:new(self)
	self:on_awake()
    self.is_complete_ = false
    StartCoroutine(function()
        self:on_resource()
        self:on_init()
        self:load_complete()
	end)
end

function Start(self)
	self:on_start()
end

function OnDestroy(self)
	self:_dispose()
	self:on_dispose()
    LuaComponentBase.OnDestroy(self)
end

-------Mono方法包装------------------------------------------

function on_awake(self)
	          
end

function on_init(self)
    
end


function on_resource(self)

end

function on_start(self)

end

function on_dispose(self)
    
end

function is_alive(self)
    return not self.disposed_
end

-------内部工具方法----------------------------------------------------------------

--销毁释放
function _dispose(self)
	self.messager_:dispose()
	self:RemoveEventListener()

	self:_dispose_coroutines()
	self:_dispose_tweens()
    self:_dispose_members()
    self.disposed_ = true
end

function _dispose_members(self)
    self:clear_members()
end

--创建协同
function coroutine_push(self, func, auto_start)
	if not self.coroutines_ then
		self.coroutines_ = {}
	end
	table.insert(self.coroutines_,func)
	if auto_start then
		CoroutineTools.StartCoroutine(func)
	end
	return #self.coroutines_
end

--销毁协同
function _dispose_coroutines(self)
	if self.coroutines_ then
		local count = #self.coroutines_
		for i = count, 1, -1 do
			CoroutineTools.StopCoroutine(self.coroutines_[i])
		end
		self.coroutines_ = nil
	end
end

--创建缓动
function tween_push(self, tween)
	if not self.tweens_ then
		self.tweens_ = {}
	end
	table.insert(self.tweens_, tween)
	return #self.tweens_
end

--销毁缓动
function _dispose_tweens(self)
	if self.tweens_ then
		local count = #self.tweens_
		for i=count, 1, -1 do
			if self.tweens_[i] then
				self.tweens_[i]:Kill(false)
			end
		end
		self.tweens_ = nil
	end
end


--UI组件事件处理挂接包装
function add_event_handler(self, event, callback, ...)
	local args = {...}
	event:AddListener(function(event_data) 
        if callback then
            callback(self, event_data, unpack(args)) 
        end
    end)
end

function set_complete(self, callback)
    self.complete_cb_ = callback
end

function load_complete(self)
    self.is_complete_ = true
    if self.complete_cb_ then
        self.complete_cb_()
        return true
    end
    return false
end

--增加事件监听
function AddEventListener(self, keys , callBack)
    if not self.regCallBacks then
        self.regCallBacks = {}
    end

    if type(keys) ~= "table" then
        keys = { keys }
    end

    for _, key in ipairs(keys) do
        if not self.regCallBacks[key] then
            self.regCallBacks[key] = callBack
            _G.event.add_listener(key, self , function(args)
                self.regCallBacks[key](args)
            end)
        end
    end
end

--移除事件监听
function RemoveEventListener(self)
    if not self.regCallBacks then
        return
    end

    for key, _ in pairs(self.regCallBacks) do
        _G.event.remove_listener(key ,self)
    end
    self.regCallBacks = nil
end
