local SceneBattle        = _G.SceneController:Get("SceneBattle")

local testAnimationMap =
{
    "attack",
    "crouch",
    "fall",
    "head-turn",
    "idle",
    "jump",
    "run",
    "walk"
}

function SceneBattle:OnLoad()
    if not _G.BattleController  then
        require("Battle/BattleController")
    end
    _G.BattleController:StartBattle()

    _G.Global.Instance.SpineManager:CreateSkeletonAnimationGameObject("spine/eff4" , "eff4_SkeletonData" , function(obj)
        obj.name = "eff4"
        obj.transform.position = _G.Vector3(0,4,0)
        _G.Global.Instance.SpineManager:PlayAnimation(obj , "animation" , 0 , true , nil)
    end)
end

function SceneBattle:OnCompleted(obj)
    _G.Global.Instance.SpineManager:ChangeSkin(obj , "happy")
    _G.Global.Instance.SpineManager:PlayAnimation(obj , "standing" , 0 , false , function()
        self:OnCompleted(obj)
    end)
end


--Update
function SceneBattle:OnUpdate()
    if _G.BattleController then
         _G.BattleController:OnUpdate()
    end
end


--卸载场景
function SceneBattle:Unload()
    if _G.BattleController then
         _G.BattleController:ClearBattle()
    end
end
