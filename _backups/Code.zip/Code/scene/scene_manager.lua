-- module("SceneManager", package.seeall)
local SceneManager = {}
local ResourcesManager     = _G.ResourcesManager
local GameLog      = _G.GameLog
local UIManager    = _G.UIManager
local Net          = _G.Net

SceneManager.Local_Scene = nil

SceneManager.Scene_Tags = {
    City = "city",
    World = "world",
}

function SceneManager.EnterLogin(callback)
    ResourcesManager.LoadSceneAsync("Scenes/Login", false, function()
        GameLog.Log("Enter Login!")
        if callback then
            callback()
        end
    end)
end

function SceneManager.enter_clean(callback)
    ResourcesManager.LoadSceneAsync("Scenes/Clean", false, function()
        GameLog.Log("Enter Clean!")
        if callback then
            callback()
        end
    end)
end

local function StartLoading(callback)
    UIManager.open_window("LoadSceneWindow", function(load_win)
        Net.send("map_unwatch", {}, function(result)
                ResourcesManager.LoadSceneAsync("Scenes/City", false, function()
                GameLog.Log("Enter City!")
                local control = GameObject.Find("Control").gameObject
                SceneManager.City_Scene = CityScene:new()
                SceneManager.City_Scene:init(control)
                SceneManager.Local_Scene = SceneManager.Scene_Tags.City

                SceneManager.City_Scene:set_complete(function()
                    if callback then
                        callback()
                    end
                    MsgCenter.send_message(Msg.SCENE_UPDATE)
                    load_win:fade_out()
                end)
            end)
        end)
    end)
end

function SceneManager.enter_city(callback)
    local win = UIManager.get_window("LoadSceneWindow")
    if _G.FairyGUI then
        win = _G.UIController:Get("UILoading")
    end
    if not win then
        StartLoading(callback)
    else
        Net.send("map_unwatch")
        ResourcesManager.LoadSceneAsync("Scenes/City", false, function()
        GameLog.Log("Enter City!")
        if callback then
            callback()
        end

        local control = GameObject.Find("Control").gameObject
        SceneManager.City_Scene = CityScene:new()
        SceneManager.City_Scene:init(control)

        SceneManager.Local_Scene = SceneManager.Scene_Tags.City
        MsgCenter.send_message(Msg.SCENE_UPDATE)
        end)
    end
end

function SceneManager.DoEnterWorld(callback, load_win)
    Net.send("map_watch", {}, function(result)
        if result.e == 0 then
            ResourcesManager.LoadSceneAsync("Scenes/World", false, function(v)
                GameLog.Log("Enter World!")
                local control = GameObject.Find("WorldMap").gameObject
                SceneManager.World_Scene = WorldScene:new()
                SceneManager.World_Scene:init(control)
                SceneManager.Local_Scene = SceneManager.Scene_Tags.World
                SceneManager.World_Scene:set_complete(function()
                    if callback then
                        callback()
                    end
                    MsgCenter.send_message(Msg.SCENE_UPDATE)
                    if _G.FairyGUI then
                        --临时代码，等新的大地图场景加入后需要移除
                        _G.UIController:Get("UIMain"):SwitchSceneState(true)
                        --end
                        _G.UIController:Get("UILoading"):FadeOut()
                        _G.SceneController.currentScene:Unload()
                    else
                        load_win:fade_out()
                    end
                end)
            end)
        end
    end)
end

function SceneManager.enter_world(callback)
    if _G.FairyGUI then
        _G.UIController:ShowUI("UILoading")
        SceneManager.DoEnterWorld(callback)
    else
        UIManager.open_window("LoadSceneWindow", function(load_win)
            SceneManager.DoEnterWorld(callback, load_win)
        end)
    end
end

_G.SceneManager = SceneManager
return SceneManager
