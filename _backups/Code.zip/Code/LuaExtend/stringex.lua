local string = _G.string
local gmatch = string.gmatch
local format = string.format
local sub    = string.sub
local gsub   = string.gsub
function string.split(str, sep)
    local r = {}
    for i in gmatch(str, format('[^%s]+', sep)) do
        table.insert(r, i)
    end
    return r
end

function string.ltrim(input)
    return gsub(input, "^[ \t\n\r]+", "")
end

function string.rtrim(input)
    return gsub(input, "[ \t\n\r]+$", "")
end

function string.trim(input)
    input = gsub(input, "^[ \t\n\r]+", "")
    return gsub(input, "[ \t\n\r]+$", "")
end

function string.startwith(str , start)
    return (string.find(str, "^" .. start))
end

function string.endwith(str , ends)
    return (string.find(str, ends .."$"))
end


function string.IsNullOrEmpty(str)
    return not str or #str == 0
end

function string.replace(text, data)
    for oldKey in gmatch(text, "%[[%w_]+%]") do
        local key = sub(oldKey, 2,-2)
        oldKey = "%[" .. key .. "%]"
        local value = data[key]
        if  value then
            text = gsub(text, oldKey, value)
        else
            return ""
        end
    end
    return text
end

function string.CheckStringIsValid(str)

    if not str then
        _G.GameUtils.LogError(debug.traceback("str为空"))
        return false
    end
    if type(str) ~= "string" then
         _G.GameUtils.LogError(debug.traceback(string.format("非string类型参数" , str)))
         return false
    end

    if string.IsNullOrEmpty(str) then
        return false
    end

    return true
end

function string.strfmt(fmt, ...)
    local params = {...}
    return (gsub(
        fmt,
        "{(%d+)}",
        function(k)
            return params[tonumber(k)]
        end
    ))
end