_G.functions    = {}
local functions = _G.functions

function functions.memory(func)
    local memory = {}
    return function(...)
        local key = select("#", ...) > 0 and table.concat({...}, "_") or nil
        if key then
            local result = memory[key]
            if result then
                return result[1]
            else
                local v = func(...)
                memory[key] = { v }
                return v
            end
        else
            local result = memory[1]
            if result then
                return result
            else
                local v = func()
                memory[1] = v
                return v
            end
        end
    end
end

function functions.cocallnow(func, ...)
    local handle = { finished = false }
    local args = { ... }
    table.insert(args, handle)
    _G.GameController.instance:LuaCoCall(function()
        func(unpack(args))
    end)
    return handle
end

function functions.cocall(func)
    return function(...)
        return functions.cocallnow(func, ...)
    end
end

function functions.coroutineArgs(...)
    local args = {...}
    return table.remove(args, #args), unpack(args)
end

function functions.reverseCondition(func)
    return function(...)
        return not func(...)
    end
end

function functions.readOnly(dataTable)
    local proxy = {}  --定义一个空表，访问任何索引都是不存在的，所以会调用__index 和__newindex
    local mt = {
    __index = dataTable, ---__index 可以是函数，也可以是table，是table的话，调用直接返回table的索引值
    __newindex = function()
        error("attempt to update a read-only table",2)
    end
    }
    setmetatable(proxy,mt)
    return proxy
end

return functions