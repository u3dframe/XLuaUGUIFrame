local Mathf       = _G.Mathf
local _math       = _G.math
local random      = _math.random
local min         = _math.min
local max         = _math.max
_math.randomseedc = _math.randomseed
_math.nonnegative = function(value)
    return max(value, 0)
end
_math.randomc = function(minval, maxval)
    local diff = maxval - minval
    if diff > 0 then
        diff = diff * random()
        return minval + diff
    else
        return minval
    end
end
_math.hit = function(range, maximum)
    if maximum == nil then
        maximum = 100
    end
    return random(maximum) <= range
end
_math.clamp = Mathf.Clamp
_math.clamp01 = Mathf.Clamp01
_math.range = function(x, a, b)
    return min(a, b) <= x and x < max(a, b)
end
_math.inrange = function(x, a, b)
    return min(a, b) <= x and x <= max(a, b)
end
_math.decimalEqual = function(a, b, e)
    return math.abs(a - b) < (e or 0.00001)
end