module("UIConfig", package.seeall)

add_require("ui/window/login_window")
add_require("ui/window/test_window1")
add_require("ui/window/test_window2")
add_require("ui/window/test_window3")
add_require("ui/window/test_battle_data_window")
add_require("ui/window/world_axis_window")
add_require("ui/window/world_monster_info_window")
add_require("ui/window/world_troops_window")
add_require("ui/window/build_create_window")
local BuildCreateWindow = require("ui/window/build_create_window")
local BuildSpendWindow = require("ui/window/build_spend_window")
local BuildDetailsWindow = require("ui/window/build_details_window")
add_require("ui/window/notify_window")
add_require("ui/window/city_soldier_window")
add_require("ui/window/city_hospital_window")
add_require("ui/window/soldier_promote_window")
add_require("ui/window/soldier_details_window")
add_require("ui/window/soldier_kick_window")
add_require("ui/window/speedup_window")
add_require("ui/window/load_scene_window")
add_require("ui/window/hero_grow_window")
add_require("ui/window/hero_list_window")
add_require("ui/window/item_list_window")
add_require("ui/window/popup_window")
add_require("ui/window/item_journey_speed_window")
add_require("ui/window/item_journey_return_window")
add_require("ui/window/item_respoint_window")
add_require("ui/window/notify_item_window")
add_require("ui/window/item_use_count_window")
add_require("ui/window/item_use_select_window")
add_require("ui/window/item_gain_reward_window")
add_require("ui/window/world_journey_info_window")
add_require("ui/window/notify_glod_window")
add_require("ui/window/world_fort_info_window")
add_require("ui/window/world_fort_reward_window")
add_require("ui/window/world_respoint_window")
add_require("ui/window/world_respoint_desc_window")
add_require("ui/window/mail_window")
add_require("ui/window/mail_list_window")
add_require("ui/window/hero_details_window")
local HeroChipExchangeWindow = require("ui/window/hero_chip_exchange_window")
local HeroAnimeWindow = require("ui/window/hero_anime_window")
local HerolevelupdirWindow = require("ui/window/hero_levelupdir_window")
add_require("ui/window/hero_troops_window")
local ComponentModeWindow = require("ui/window/component_mode_window")
add_require("ui/window/skill_bag")
add_require("ui/window/skill_level")
add_require("ui/window/skill_auto_level")
add_require("ui/window/skill_forget")
add_require("ui/window/skill_recycle_window")
add_require("ui/window/skill_all_forget")
local CityRandomShopWindow = require("ui/window/city_random_shop_window")
local RandomShopRewardWindow = require("ui/window/random_shop_reward_window")
local HeroRecruitWindow = require("ui/window/hero_recruit_window")
local HeroRecruitPopWindow = require("ui/window/hero_recruit_pop_window")
local CityRulesWindow = require("ui/window/city_rules_window")
local RecruitGainRewardWindow = require("ui/window/recruit_gain_reward_window")
local RecruitFindWindow = require("ui/window/recruit_find_window")
local CityFeteWindow = require("ui/window/city_fete_window")
local FeteUseItemWindow = require("ui/window/use_fete_item_window")
local ReceiveAwardWindow = require("ui/window/city_receive_award_windoe")
local RebuildHintWindow = require("ui/window/rebuild_hint_window")

add_require("ui/component/world_menu")
add_require("ui/component/battle_report")
add_require("ui/component/build_menu")
add_require("ui/component/city_space")
add_require("ui/component/hint_box")
add_require("ui/component/bill_board")
add_require("ui/component/top_banner")
add_require("ui/component/build_level_up")
add_require("ui/component/tips_card")
add_require("ui/component/item_card")
add_require("ui/component/hero/hero_info")
add_require("ui/component/hero/hero_card")
add_require("ui/component/hero/hero_card_list")
add_require("ui/component/hero/hero_star")
add_require("ui/component/hero/hero_level")
add_require("ui/component/hero/hero_skill")


add_require("ui/plugins/plugin_pointer")
add_require("ui/plugins/exp_animator")

LayerType = {
	Pool = 1,           -- 缓存池
    Board = 2,          -- 广告牌
	Main = 3,		    -- 常驻UI    
    Screen = 4,		    -- 全屏窗口UI
	Window = 5,		    -- 弹出窗口UI
	Popup = 6,	        -- 局部弹出框
	Hints = 7,		    -- 小提示
    Mask = 8,           -- 遮罩层
    Guide = 9,	        -- 引导层
}


Layers = {
	"pool",
    "board",
	"main",    
    "screen",
	"window",
	"popup",
	"hints",
    "mask",
    "guide",
}

-- UI设置
Settings = Settings or {}

--------------------------------------
-- @FuncName：add_setting
-- @Function：添加界面关系映射表
-- @param：window_name   窗口名字
-- @param：window_class  窗口类名
-- @param：window_layer  窗口所在层
-- @param：winCache      窗口是否被缓存
-- @param：winMask       窗口背景可点击关闭
--------------------------------------
function add_setting(window_name, window_class, window_layer, winCache, winMask)
	Settings[window_name] = {}
	local set = Settings[window_name]
	--UI Prefab名称
	set.name = window_name
	--UI控制类
	set.class = window_class
	--所在层次
	set.layer = window_layer
    --是否缓存UI
	set.cache = winCache
    --是否Mask可点击
    set.mask = winMask
end

function init_setting()
    -- 全屏窗口
	add_setting("LoginWindow", LoginWindow, LayerType.Screen, false)
    add_setting("TestWindow1", TestWindow1, LayerType.Screen, false)
    add_setting("TestWindow2", TestWindow2, LayerType.Screen, false)
    add_setting("TestBattleDataWindow", TestBattleDataWindow, LayerType.Screen, false)
    add_setting("WorldTroopsWindow", WorldTroopsWindow, LayerType.Screen, false)
    add_setting("BuildCreateWindow", BuildCreateWindow, LayerType.Screen, false)
    add_setting("BuildSpendWindow", BuildSpendWindow, LayerType.Screen, false)
    add_setting("BuildDetailsWindow", BuildDetailsWindow, LayerType.Screen, false)
    add_setting("CitySoldierWindow", CitySoldierWindow, LayerType.Screen, false) 
    add_setting("CityHospitalWindow", CityHospitalWindow, LayerType.Screen, false)
    add_setting("HeroGrowWindow", HeroGrowWindow, LayerType.Screen, false)
    add_setting("HeroListWindow", HeroListWindow, LayerType.Screen, false) 
    add_setting("ItemListWindow", ItemListWindow, LayerType.Screen, false) 
    add_setting("MailWindow", MailWindow, LayerType.Screen, false)
    add_setting("MailListWindow", MailListWindow, LayerType.Screen, false)
    add_setting("ComponentModeWindow", ComponentModeWindow, LayerType.Screen, false)
    add_setting("CityRandomShopWindow", CityRandomShopWindow, LayerType.Screen, false)
    add_setting("HeroRecruitWindow", HeroRecruitWindow, LayerType.Screen, false)
    add_setting("RecruitFindWindow", RecruitFindWindow, LayerType.Screen, false)
    add_setting("CityFeteWindow", CityFeteWindow, LayerType.Screen, false)
    -- 弹出窗口
    add_setting("TestWindow3", TestWindow3, LayerType.Window, false, true)
    add_setting("WorldAxisWindow", WorldAxisWindow, LayerType.Window, false, true)
    add_setting("WorldMonsterInfoWindow", WorldMonsterInfoWindow, LayerType.Window, false, true)
    add_setting("NotifyWindow", NotifyWindow, LayerType.Window, false, true)
    add_setting("LoadSceneWindow", LoadSceneWindow, LayerType.Mask, false, false)
    add_setting("PopupWindow", PopupWindow, LayerType.Popup, false, false)
    add_setting("ItemJourneySpeedWindow", ItemJourneySpeedWindow, LayerType.Window, false, true)
    add_setting("ItemJourneyReturnWindow", ItemJourneyReturnWindow, LayerType.Window, false, true)
    add_setting("ItemRespointWindow", ItemRespointWindow, LayerType.Window, false, true)
    add_setting("WorldJourneyInfoWindow", WorldJourneyInfoWindow, LayerType.Window, false, true)
    add_setting("SpeedUpWindow", SpeedUpWindow, LayerType.Window, false, true)
	add_setting("NotifyItemWindow", NotifyItemWindow, LayerType.Window, false, true)
	add_setting("SoldierPromoteWindow", SoldierPromoteWindow, LayerType.Window, false, true)
    add_setting("SoldierDetailsWindow", SoldierDetailsWindow, LayerType.Window, false, true)
    add_setting("SoldierKickWindow", SoldierKickWindow, LayerType.Window, false, true)
    add_setting("ItemUseCountWindow", ItemUseCountWindow, LayerType.Window, false, true)
    add_setting("ItemUseSelectWindow", ItemUseSelectWindow, LayerType.Window, false, true)
    add_setting("ItemGainRewardWindow", ItemGainRewardWindow, LayerType.Window, false, true)
    add_setting("NotifyGoldWindow", NotifyGoldWindow, LayerType.Window, false, true)
    add_setting("WorldFortInfoWindow", WorldFortInfoWindow, LayerType.Window, false, true)
    add_setting("WorldFortRewardWindow", WorldFortRewardWindow, LayerType.Window, false, true)
    add_setting("WorldRespointWindow", WorldRespointWindow, LayerType.Window, false, true)
    add_setting("WorldRespointDescWindow", WorldRespointDescWindow, LayerType.Window, false, true)
    add_setting("HeroDetailsWindow", HeroDetailsWindow, LayerType.Window, false, true)
    add_setting("HeroChipExchangeWindow", HeroChipExchangeWindow, LayerType.Window, false, true)
    add_setting("HeroAnimeWindow", HeroAnimeWindow, LayerType.Window, false, true)
    add_setting("HerolevelupdirWindow", HerolevelupdirWindow, LayerType.Window, false, true)
    add_setting("HeroTroopsWindow", HeroTroopsWindow, LayerType.Window, false, true)
    add_setting("SkillBag", SkillBag, LayerType.Window, false, true)
    add_setting("SkillLevel", SkillLevel, LayerType.Window, false, true)
    add_setting("SkillAutoLevel", SkillAutoLevel, LayerType.Window, false, true)
    add_setting("SkillForget", SkillForget, LayerType.Window, false, true)
    add_setting("SkillRecycleWindow", SkillRecycleWindow, LayerType.Window, false, true)
    add_setting("SkillAllForget", SkillAllForget, LayerType.Window, false, true)
    add_setting("RandomShopRewardWindow", RandomShopRewardWindow, LayerType.Window, false, true)
    add_setting("HeroRecruitPopWindow", HeroRecruitPopWindow, LayerType.Window, false, true)
    add_setting("CityRulesWindow", CityRulesWindow, LayerType.Window, false, true)
    add_setting("RecruitGainRewardWindow", RecruitGainRewardWindow, LayerType.Window, false, true)
    add_setting("FeteUseItemWindow", FeteUseItemWindow, LayerType.Window, false, true)
    add_setting("ReceiveAwardWindow", ReceiveAwardWindow, LayerType.Window, false, true)
    add_setting("RebuildHintWindow", RebuildHintWindow, LayerType.Window, false, true)
end

function init(on_progress)
    init_setting()
    UIManager.init(on_progress)
end
