module("BaseComponent", package.seeall)

setmetatable(BaseComponent, {__index = LuaComponentBase})

--实例化
function new(self, ...)
	local obj = {}
	setmetatable(obj, {__index = self})
	obj.data = {...}
	return obj
end

---------Mono方法---------------------------------
function Awake(self)
	self:on_awake()
end

function Start(self)
	self:on_start()
end

function OnDestroy(self)
	self:_dispose()
	self:on_dispose()

    LuaComponentBase.OnDestroy(self)
end

-------Mono方法包装------------------------------------------

function on_awake(self)

end

function on_start(self)

end

function on_dispose(self)
    
end

function is_alive(self)
    return not self.disposed_
end

-------内部工具方法----------------------------------------------------------------

--销毁释放
function _dispose(self)
    self:_dispose_plugins()
	self:_dispose_coroutines()
	self:_dispose_tweens()
    self:_dispose_members()
    self.disposed_ = true
end

function _dispose_members(self)
    self:clear_members()
end

--UI组件事件处理挂接包装
function add_event_handler(self, event, callback, ...)
	local args = {...}
	event:AddListener(function(event_data) 
        if callback then
            callback(self, event_data, unpack(args)) 
        end
    end)
end

-- 添加插件
function add_plugin(self, plugin)
	if not self.plugins_ then
		self.plugins_ = {}
	end
	table.insert(self.plugins_, plugin)
	return plugin
end

-- 卸载插件
function _dispose_plugins(self)
	if self.plugins_ then
		for _,v in ipairs(self.plugins_) do
			v:dispose()
		end
		self.plugins_ = nil
	end
end

--创建协同
function coroutine_push(self, func, auto_start)
	if not self.coroutines_ then
		self.coroutines_ = {}
	end
	table.insert(self.coroutines_,func)
	if auto_start then
		CoroutineTools.StartCoroutine(func)
	end
	return #self.coroutines_
end

--销毁协同
function _dispose_coroutines(self)
	if self.coroutines_ then
		local count = #self.coroutines_
		for i = count, 1, -1 do
			CoroutineTools.StopCoroutine(self.coroutines_[i])
		end
		self.coroutines_ = nil
	end
end

--创建缓动
function tween_push(self, tween)
	if not self.tweens_ then
		self.tweens_ = {}
	end
	table.insert(self.tweens_, tween)
	return #self.tweens_
end

--销毁缓动
function _dispose_tweens(self)
	if self.tweens_ then
		local count = #self.tweens_
		for i=count, 1, -1 do
			if self.tweens_[i] then
				self.tweens_[i]:Kill(false)
			end
		end
		self.tweens_ = nil
	end
end

-------------------------------------------------

function add_tips_handler(self, trans, data, tipsType)
    if not trans then return end
    if not self.tips_data_ then
		self.tips_data_ = {}
	end
    -- 一个transform只允许一个tips
    for i,v in ipairs(self.tips_data_) do
        if v.trans_ == trans then
            v:update_data(data, tipsType)
            return
        end        
    end
    local index = #self.tips_data_ + 1
    self.tips_data_[index] = Tips(trans, data, tipsType)
    self:add_plugin(PluginPointer:new(self, trans.gameObject, tips_show_handler, index))
end

function tips_show_handler(self, event, index)
    if event == PluginPointer.POINTER_ALWAY_DOWN then
        local tips_data = self.tips_data_[index]
        local trans =  tips_data.trans_
        local data = tips_data:get_data()
        MsgCenter.send_message(Msg.SHOW_UI_TIPS, true, trans, data, tips_data.type_)
    elseif event == PluginPointer.POINTER_UP then
        MsgCenter.send_message(Msg.SHOW_UI_TIPS, false)
    end
end
-------------------------------------------------

--读取UI组件尺寸 Vector2
function get_size(self)
	local transform = self.gameObject:GetComponent(RectTransform)
	if transform then
		return transform.sizeDelta
	else
		return nil
	end
end

--读取UI组件宽度
function get_width(self)
	local transform = self.gameObject:GetComponent(RectTransform)
	if transform then
		return transform.sizeDelta.x
	else
		return 0
	end
end

--读取UI组件高度
function get_height(self)
	local transform = self.gameObject:GetComponent(RectTransform)
	if transform then
		return transform.sizeDelta.y
	else
		return 0
	end
end