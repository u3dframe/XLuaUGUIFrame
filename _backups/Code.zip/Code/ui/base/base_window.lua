module("BaseWindow",package.seeall)

setmetatable( BaseWindow, {__index = BaseComponent} )

function new(self, data)
    local obj = {}
    setmetatable(obj, {__index = self})
    obj.data = data
    return obj
end

--保存当前Window配置
Config = nil
on_open_function_ = nil
on_open_parameter_ = nil
handle_reconnect = nil

--首次创建初始化
function on_awake(self)
    if self.canvas_group_ then
        self.canvas_group_.alpha = 0
    end

    StartCoroutine(function()
        self:on_resource()
        self:on_build_window_bg()
        if self:is_alive() then
            self:_on_resource_complete()
        end


        if type(self.InitVM) == "function" then
            self.vm = react(self:InitVM())
        end

        if type(self.InitBinds) == "function" then
            self:InitBinds()
        end

        if type(self.InitEvents) == "function" then
            self:InitEvents()
        end
    end)
end

--准备UI完成（UI美术资源加载）
function _on_resource_complete(self)
    local window_name = self.window_name_
    self:_on_plugin_base()
    self:on_init()

    self.init_complete_ = true
    self:show()

end

function _on_plugin_base(self)
    self.messager_ = self:add_plugin(Messager:new(self))
    
    
end


function on_build_window_bg(self)
    if not self.Config then return end
    if not self.Config.mask then return end
    if self.Config.layer ~= UIConfig.LayerType.Window then return end
    if not self.transform:Find("Background") then return end
    
    self.back_image_ = self.transform:Find("Background"):GetComponent(RawImage)
    local btn = self.transform:Find("Background"):GetComponent(Button)
    if not btn then
        btn = self.transform:Find("Background").gameObject:AddComponent(Button)
    end
    btn.transition = Selectable.Transition.None
    self:add_event_handler(btn.onClick,function()
            AudioManager.Play("SOUND_BUTTON_CLOSE")
            self:close()
        end)

    self.back_image_.gameObject:SetActive(false)
    self.ui_camera_ = UIManager.get_camera()
    self.camera_blur_ = self.ui_camera_.gameObject:AddComponent(SimpleBlur)
    Yield(self.camera_blur_:Blur(0, 0))
    Yield(self.camera_blur_:GetBlurs(function(_texture)
        if _texture then
            self.back_image_.gameObject:SetActive(true)
            self.back_image_.texture = _texture 
        end
        self.camera_blur_.enabled = false
    end))
    local image_blur = self.back_image_.gameObject:AddComponent(SimpleBlur)
        
    image_blur.SourceRawImage = self.back_image_
    -- 1=texture 2=blursize 3=duration 
    Yield(image_blur:Blur(1, 6, 0))
end

function on_clear_window_bg(self)
    if not self.Config then return end
    if not self.Config.mask then return end
    if self.Config.layer ~= UIConfig.LayerType.Window then return end
    

    if self.camera_blur_ then
        GameObject.Destroy(self.camera_blur_)
    end
end


function init_done(self)
    return self.init_complete_
end

function set_top_banner(self)
    if UIManager.top_bar and self.Config and self.Config.layer == UIConfig.LayerType.Screen then
        UIManager.top_bar:set_window(self)
    end
end

---------UI流程方法------------------------------------------------------

--1.准备UI（UI美术资源加载）
function on_resource(self)

end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self) 

end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
    
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
     
end

--6.打开UI动画
function on_open_animation(self)
end

--7.关闭UI动画
function on_close_animation(self)
end

function on_after_top(self)
end

function on_hide(self)

end

function on_dispose(self)

end

--隐藏UI
function hide(self)
    if self.Config then
        self:on_hide()
    end
end

--显示UI
function show(self)
    if self.Config and self:is_alive() then
        self.gameObject:SetActive(true)
        self.canvas_group_.alpha = 1
        self:on_open()
        self:set_top_banner()
        self:on_after_top()
        UIManager.hide_active_window(self)
    end
end

function close_all(self, on_complete)
    if self.Config then
        UIManager.close_window_all(on_complete)
    end
end

function close(self, on_complete)
    if self.Config then
        UIManager.close_window(self.Config.name, self.Config.layer, on_complete)
    end
end


function to_close(self)
    self:on_clear_window_bg()
    self:on_close()
end