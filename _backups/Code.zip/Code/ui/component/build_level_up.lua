module("BuildLevelUp", package.seeall)
setmetatable(BuildLevelUp, {__index = BaseComponent})

function set_data(self, id)
	self.gameObject:SetActive(false)
	self.img_1_ = self.transform:Find("Image1")
	self.img_2_ = self.transform:Find("Image2")
	self.txt_title_ = self.transform:Find("Text"):GetComponent(Text)

	local build = BuildManager:get_build_info_by_id(id)
	if not build then return end
	if build.lv_ <= 0 then return end
	local is_build_ = build.lv_ == 1 --等级为1说明 操作为建造
	self.txt_title_.text = lang("UI_MAIN_UPDATE_COMPLETE", build.name_, build.lv_)
	self.img_1_.gameObject:SetActive(is_build_)
	self.img_2_.gameObject:SetActive(not is_build_)

	local a_pos = self.gameObject:GetComponent(RectTransform)
	local start_x = 218
	a_pos.anchoredPosition = Vector2(start_x, a_pos.anchoredPosition.y)
	local end_x = self.transform.localPosition.x - a_pos.sizeDelta.x
	self.gameObject:SetActive(true)
	local tween = XSequence()
    tween:Append(GameTween.DOLocalMoveX(self.transform, end_x, 0.5, false):SetEase(3))
    	 :AppendInterval(1.5)
    	 :Append(GameTween.DOFade(self.gameObject:GetComponent(CanvasGroup), 0, 0.8))
    	 :OnComplete(function() GameObject.Destroy(self.gameObject) end)
end