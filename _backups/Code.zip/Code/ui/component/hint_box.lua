module("HintBox", package.seeall)
setmetatable(HintBox, {__index = BaseComponent})

-- 设置内容
function set_data(self, content, horizontal, fix_pos)
	AudioManager.Play("SOUND_BUTTON_ERROR") 
	self.rect_ = self.transform:GetComponent(RectTransform)
	self.txt_ = self.transform:Find("Text"):GetComponent(Text)
	self.txt_.text = content

	local count = UIManager.HintLayer.transform.childCount
	fix_pos = fix_pos and Vector3(fix_pos[1] or 0, fix_pos[2] or 0, fix_pos[3] or 0) or Vector3.zero
	local width
	if horizontal then
		width = self.transform:GetComponent(RectTransform).sizeDelta.x
		self.transform.localPosition = Vector3(-(width + Screen.width) / 2, Screen.height * 0.3, 0) + fix_pos
	else
		self.transform.localPosition = Vector3(0, 100, 0) + fix_pos
	end

	local canvas = self.transform:GetComponent(CanvasGroup)
	canvas.alpha = 0

	self.gameObject:SetActive(true)

	if horizontal then
		GameTween.DOLocalMoveX(self.transform, -(Screen.width - width) / 2 + fix_pos.x, 0.3, true)
		GameTween.DOFade(canvas, 1, 0.3)
		GameTween.DOLocalMoveX(self.transform, width + fix_pos.x, 0.3, true):SetDelay(1.3)
		GameTween.DOFade(canvas, 0, 0.3):SetDelay(1.3):OnComplete(function() GameObject.Destroy(self.gameObject) end)
	else
		GameTween.DOLocalMoveY(self.transform, 150 + fix_pos.y, 0.3, true)
		GameTween.DOFade(canvas, 1, 0.3)
		GameTween.DOLocalMoveY(self.transform, 200 + fix_pos.y, 0.2, true):SetDelay(1)
		GameTween.DOFade(canvas, 0, 0.2):SetDelay(1):OnComplete(function() GameObject.Destroy(self.gameObject) end)
	end
end

function set_position(self, pos_y)
	
end