-- 城建的广告牌
module("BillBoard", package.seeall)
setmetatable(BillBoard, {__index = _G.BaseComponent})

local lang = _G.lang
local config = _G.config
local UnityEngine = _G.UnityEngine
local UI = _G.UnityEngine.UI
-- local UIManager = _G.UIManager
local SoldierManager = _G.SoldierManager
local Net = _G.Net
local UIUtil = _G.UIUtil
local MsgCenter = _G.MsgCenter
local Msg = _G.Msg
local BuildManager = _G.BuildManager

--建筑顶部icon显示类型
Build_Title = config.BUILD_TITLE_TYPE

function on_awake(self)
	if _G.GRichTextField then
		local fairyGuiScale = _G.GRoot.contentScaleFactor * _G.Stage.inst.cachedTransform.localScale
		--build name board
		self.build_mark_ = self.transform:Find("Name")
		self.build_mark_.localScale = fairyGuiScale
		self.build_mark_.gameObject:SetActive(false)
		local nameBoardPanel = self.build_mark_:GetComponent(_G.UIPanel)
		self.name_and_lv_txt_ = nameBoardPanel.ui:GetChild("BuildName")
		self.lvup_icon_ = nameBoardPanel.ui:GetChild("LevelUpIcon")
		--title board
		self.build_title_ = self.transform:Find("Title")
		self.build_title_.localScale = fairyGuiScale
		self.build_title_.gameObject:SetActive(false)
		local titleBoardPanel = self.build_title_:GetComponent(_G.UIPanel)
		self.build_title_btn_ = titleBoardPanel.ui:GetChild("TitleBtn").asButton
		self.build_title_img_ = titleBoardPanel.ui:GetChild("BuildTitle").asLoader
	else
		--build mark
		self.build_mark_ = self.transform:Find("BuildMark")
		self.build_mark_.gameObject:SetActive(false)
		self.name_and_lv_txt_ = self.transform:Find("BuildMark/Text"):GetComponent(Text)
		self.lvup_icon_ = self.transform:Find("BuildMark/Icon")
		--build title
		-- self.build_title_ = self.transform:Find("BuildTitle")
		-- self.build_title_.gameObject:SetActive(false)
		-- self.build_title_btn_ = self.transform:Find("BuildTitle"):GetComponent(Button)
		-- self.build_title_img_ = self.build_title_btn_.gameObject:GetComponent(Image)

		self.build_title_ = self.transform:Find("TiltleBoard")
		self.build_title_.gameObject:SetActive(false)
		self.build_title_btn_ = self.build_title_:GetComponent(Button)
		self.build_title_img_ = self.build_title_.transform:Find("BuildTitle"):GetComponent(Image)
		self.bill_board_rect_ = self.transform:GetComponent(RectTransform)
	end

	-- 做成配置
	self.height_ = 0
    self.ui_camera_ = UIManager.get_camera()
    self.screen_size_ = UIManager.get_canvas_size()
    self.bill_board_rect_ = self.transform:GetComponent(RectTransform)

    self.build_obj_ = self.data[1]
	self.build_info_ = self.build_obj_.build_info_

	self.city_canvas_ = UnityEngine.GameObject.Find("CityCanvas"):GetComponent(UnityEngine.RectTransform)

	self.title_cache_ = {}
end

function on_start(self)
	--开始需要显示的 需要调用
	self:set_build_mark()
end

function on_dispose(self)
end

--加载title
function SetTitleImg(self, path)
	if not self:is_alive() or not path then
		return
	end
	if _G.GRichTextField then
		self.build_title_img_.url = "art/"..path
	else
		UIUtil.set_sprite(path, self.build_title_img_, function()
			if not Slua.IsNull(self.build_title_img_) and self.build_title_img_.SetNativeSize then
				self.build_title_img_:SetNativeSize()
			end
		end)
	end
end

-----------------------------------build mark(建筑名称等级)-----------------------------------------

function set_build_mark(self)
	self:update_build_info()
	if not self.build_info_ or self.build_info_.lv_ <= 0 then
		self.build_mark_.gameObject:SetActive(false)
		return
	end
	if _G.GRichTextField then
		--是否显示建筑升级提示箭头
		if self.build_info_:enable_lvup() then
			self.lvup_icon_.visible = true
		else
			self.lvup_icon_.visible = false
		end
	else
		if self.build_info_:enable_lvup() then
			self.lvup_icon_.gameObject:SetActive(true)
		else
			self.lvup_icon_.gameObject:SetActive(false)
		end
	end
	self.name_and_lv_txt_.text = self.build_info_:GetNameLV()
	self.build_mark_.gameObject:SetActive(true)
end

function set_mark_axis(self)
	if _G.GRichTextField then
		return
	end

	local offert = 0
	if self.build_info_ and self.build_info_.build_type_ == config.BUILD_TYPE.XQY then
		offert = 0.3
	end
	local screen_pos = Vector3.zero
	if _G.GRichTextField then
		local buildTrans = self.build_obj_.transform
		screen_pos = Camera.main:WorldToScreenPoint(buildTrans.position)
	else
		local build_rect = self.build_obj_.transform:GetComponent(RectTransform)
		local world_pos = build_rect.position + Vector3(0, build_rect.sizeDelta.y / 2 * self.city_canvas_.localScale.y - offert, 0)
		screen_pos = Camera.main:WorldToScreenPoint(world_pos)
	end
	local b, p = RectTransformUtility.ScreenPointToLocalPointInRectangle(self.screen_size_, screen_pos, self.ui_camera_)
	self.bill_board_rect_.anchoredPosition = p
end

function hide_build_mark(self)
	self.build_mark_.gameObject:SetActive(false)
end

-----------------------------------build title(建筑顶部图标)-----------------------------------------


function set_build_title(self, title_type, ...)
	self:update_build_info()
	if not self.build_info_ then
		return
	end

	if self:IsHasSpeedupTitle(title_type) then
		return
	end

	local arg = {...}
	self.build_title_.gameObject:SetActive(true)
	if self.Check_Title[title_type]["set_data"] then
		self.Check_Title[title_type]["set_data"](self)
	end

	if _G.GRichTextField then
		self.build_title_btn_.onClick:Set(function()
			print("self.build_title_btn_.onClick")
			if self.Check_Title[title_type]["on_click"] then
				self.Check_Title[title_type]["on_click"](self, arg)
			end
		end)
	else
		self.build_title_btn_.onClick:RemoveAllListeners()
		self:add_event_handler(self.build_title_btn_.onClick, function()
			if self.Check_Title[title_type]["on_click"] then
   			self.Check_Title[title_type]["on_click"](self, arg)
			end
		end)
	end
end

---------------------------------训练title显示
function load_soldier_drill_title(self)
	self:SetTitleImg("UI/Window/main/city/build_title_1")
end

function on_soldier_drill_click(self, arg)
	local soldier_id = arg[1]
	local soldier_class
	if self.build_info_.build_type_ == config.BUILD_TYPE.TRAP then
		soldier_class = config.SOLDIER_CLASS.TRAP
	end
	local data = SoldierManager:get_soldier_info_by_id(soldier_id, soldier_class)
	SoldierManager:PickTrained(self.build_info_.id_, soldier_id, data.class_, function()
		local target = data.target_
		local str
		if target then
			local soldier = SoldierManager:get_soldier_info_by_id(target)
	        	str = data.lv_.."级"..data.name_.."晋升"..soldier.lv_..soldier.name_.."已完成"
		else
	        	str = lang("UI_HINT_DRILL_COMPLETE", data.lv_, data.name_)
		end
		MsgCenter.send_message(Msg.SHOW_HINT, str)
		self.build_title_.gameObject:SetActive(false)
		--重置状态
		data.select_count_ = nil
		data:reset()
	end)
end

----------------------------加速title显示
function load_free_speedup_title(self)
	self:SetTitleImg("UI/Window/main/city/build_title_2")
end

function on_free_speedup_click(self)
	if not self.build_info_ or not self.build_info_.id_ then return end
	local req_msg = {}
	req_msg.id = self.build_info_.id_
	Net.send("build_levelup_dectime", req_msg, function(result)
		if result.e == 0 then
			MsgCenter.send_message(Msg.CITY_GOLD_UP_LV, self.build_info_.id_)
			self:CheckSoldierTitle()
		end
	end)
end

function CheckSoldierTitle(self)
	if not self.build_info_:is_soldier_build() then
		return
	end

	local _, finish_train, soldierId, soldierClass = SoldierManager:check_soldier_state(self.build_info_.build_type_)
	if not finish_train then
		return
	end

	self:set_build_title(config.BUILD_TITLE_TYPE.SOLDIER_DRILL, soldierId, soldierClass)
end

function IsHasSpeedupTitle(self, title)
	if title ~= config.BUILD_TITLE_TYPE.SOLDIER_DRILL then
		return
	end

	if not self.build_info_:is_soldier_build() or
		not self.build_info_:is_lvup() or
		not self.build_info_:is_less_free_time() then
		return
	end

	return true
end

function hide_build_title(self)
	if self.build_info_ and self.build_info_:is_soldier_build() then
		local _, finish_train = SoldierManager:check_soldier_state(self.build_info_.build_type_)
		if finish_train then
			return
		end
	end
	self.build_title_.gameObject:SetActive(false)
end

function HideBuildTitle(self)
	self.build_title_.gameObject:SetActive(false)
end
--------------------------------随机商店
function LoadRandomShopTitle(self)
	self:SetTitleImg("UI/Window/main/city/build_title_1")
end

function LoadRandomShopClick(self)
	BuildManager.showTitle = false
	self.build_title_.gameObject:SetActive(false)
	if _G.UIController then
		UIController:ShowUI("UIRandomShop")
		return
	end
	UIManager.open_window("CityRandomShopWindow", nil)
end
---------------------------------祭坛
function LoadFeteTitle(self)
	self:SetTitleImg("UI/Window/main/city/build_title_1")
end

function LoadFeteClick(self)
	if _G.UIController then
		_G.UIController:ShowUI("UISacrifice")
		return
	end
	UIManager.open_window("CityFeteWindow", nil)
end

-------------------------------市舶司
function LoadWharfTitle(self)
	self:SetTitleImg("UI/Window/main/city/build_title_3")
end

function LoadWharfClick(self)
	if _G.UIController then
		_G.UIController:ShowUI("UIWharf")
		return
	end
	_G.UIManager.open_window("ReceiveAwardWindow")
end

function LoadCollectTitle(self)
	self:SetTitleImg("UI/Window/main/city/build_title_1")
end

function OnCollectClick(self)
	Net.send("produce_collect", {buildtype = self.build_info_.build_type_}, function(result)
		if result.e == 0 then
			local map_build = {}
			for i,v in ipairs(result.list) do
				if v.array then
					map_build[v.array[1]] = v.array[2]
				end
			end
			MsgCenter.send_message(Msg.SHOW_HINT, lang("RESOURCE_BUILDING_8"))
			local collect = CollectManager:get_collect(self.build_info_.id_)
			local list = CollectManager:get_same_collect_list(collect.type_)
			for i,v in ipairs(list) do
				if map_build[v.build_id_] then
					MsgCenter.send_message(Msg.CITY_COLLECT_FINISHED, v.build_id_)
					local count = map_build[v.build_id_]
					local item_id = CityCollect.MAP_ITEM[collect.type_]
					MsgCenter.send_message(Msg.CITY_COLLECT_ANI, v.build_id_, count, item_id)
				end
			end
		end
	end)
end

--------------------------------------

Check_Title = {
	--显示士兵训练完成title
	[Build_Title.SOLDIER_DRILL] = {
		["set_data"] = load_soldier_drill_title,
		["on_click"] = on_soldier_drill_click,
	},
	--显示免费加速title
	[Build_Title.FREE_SPEEDUP] = {
		["set_data"] = load_free_speedup_title,
		["on_click"] = on_free_speedup_click,
	},
	[Build_Title.RANDOM_SHOP] = {
		["set_data"] = LoadRandomShopTitle,
		["on_click"] = LoadRandomShopClick,
	},
	[Build_Title.FETE] = {
		["set_data"] = LoadFeteTitle,
		["on_click"] = LoadFeteClick,
	},
	[Build_Title.WHARF] = {
		["set_data"] = LoadWharfTitle,
		["on_click"] = LoadWharfClick,
	},
	[Build_Title.COLLECT] = {
		["set_data"] = LoadCollectTitle,
		["on_click"] = OnCollectClick,
	}
}

----------------------------------------------------------------------------------------------

--建筑数据可能是nil,需要重新获取
function update_build_info(self)
	if self.build_obj_ and self.build_obj_.id_ then
		self.build_info_ = BuildManager:get_build_info_by_space_id(self.build_obj_.id_)
	end
end