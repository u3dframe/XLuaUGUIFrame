-- 建筑体组件（空地、建筑、英雄、兵、活动物件等等，可以是静止、也可以是动态的）
module("CitySpace", package.seeall)
setmetatable(_G.CitySpace, {__index = _G.BaseComponent})

local UI = _G.UnityEngine.UI
local CityBuild    = _G.CityBuild
local BuildManager = _G.BuildManager
local GameManager = _G.GameManager
local UnityEngine = _G.UnityEngine
local Vector3 = _G.Vector3
local Yield = _G.Yield
local UIUtil = _G.UIUtil
local UIManager = _G.UIManager
local SceneManager = _G.SceneManager
local MsgCenter = _G.MsgCenter
local Msg = _G.Msg
local SoldierManager = _G.SoldierManager

local RANDOM_SHOP_SPACE_ID  = 47 --随机商店空地ID
local WHARF_SPACE_ID        = 51 --市舶司空地ID
local WALL_SPACE_ID         = 52 --瓮城（城墙）

function on_awake(self)
    self.buildDisplayObj = nil
    self.id_ = self.data[1]
    self.city_scene_ = self.data[2]
    self.build_info_ = BuildManager:get_build_info_by_space_id(self.id_)
    self.space_info_ = BuildManager:get_space_info_by_id(self.id_)
    if _G.GRichTextField then
        self.timer_panel_ = GameObject.Find("CityCanvas/TimerLayout/TimerSlider"..self.id_)
    else
        self.timer_panel_ = GameObject.Find("CityCanvas/Container/TimerLayout/TimerSlider"..self.id_)
    end
    StartCoroutine(function()
        local buildPath
        if _G.GRichTextField then
            buildPath = "Model/City/Common/NewBuild"
        else
            buildPath = "Model/City/Common/Build"
        end
        local urls = {
            buildPath,
            "Model/City/Common/BuildTitle"
        }
        --print("contentScaleFactor".._G.GRoot.contentScaleFactor*_G.Stage.inst.cachedTransform.localScale.x)
        Yield(ResourcesManager.LoadObjectMultiAsync(urls, function(objs) 
            local build_go = GameObject.Instantiate(objs[1])
            build_go.name ="Build"
            build_go.transform:SetParent(self.transform, false)
            build_go.transform.localScale = Vector3.one
            if _G.GRichTextField then
                self.BoardGo = build_go.transform:Find("Billboard").gameObject
                if self.BoardGo then
                    self.BoardGo.transform.localScale = Vector3.one
                    self.bill_board_ = BillBoard:new(self)
                    self.bill_board_:AddLuaComponent(self.BoardGo)
                    self.bill_board_:init()
                    self.bill_board_:set_mark_axis()
                    self.bill_board_.gameObject:SetActive(true)
                    self.collectTitle = self.bill_board_.build_title_
                end
            end

            if not _G.GRichTextField then
            local title_go = UnityEngine.GameObject.Instantiate(objs[2])
                title_go.name ="BuildTitle"
                title_go.transform:SetParent(self.timer_panel_.transform, false)
                title_go.transform.localScale = Vector3.one
            end
        end))
        if not _G.GRichTextField then
            Yield(UIUtil.load_component("Common/BillBoard", function(obj)
            local board_go = UnityEngine.GameObject.Instantiate(obj)
                board_go.name ="BuildMark"..self.id_
                board_go.transform:SetParent(UIManager.BoardLayer.transform, false)
                board_go.transform.localScale = Vector3.one
                self.bill_board_ = BillBoard:new(self)
                self.bill_board_:AddLuaComponent(board_go)
                self.bill_board_:init()
                self.bill_board_:set_mark_axis()
                self.bill_board_.gameObject:SetActive(true)
            end))
        end
        --码头（市舶司）倒计时
        if self.id_ == WHARF_SPACE_ID then
            Yield(UIUtil.load_component("Common/CityBuildTimer", function(obj)
                local wharfGo = GameObject.Instantiate(obj)
                self.wharfTimer = wharfGo
                self.wharfTimer.transform:SetParent(self.timer_panel_.transform, false)
                self.wharfTimer.transform.localScale = Vector3.one
                self.wharfTimer.gameObject:SetActive(false)
            end))
        end
        self:init()
        self:check_data_advance()
	end)
end

function init(self)
    --ui组件
    self.build_ = self.transform:Find("Build")
    if _G.GRichTextField then
        self.build_img_ = self.transform:Find("Build/BuildCollider"):GetComponent(SpriteRenderer)
        self.build_shadow_ = self.transform:Find("Build/Shadow"):GetComponent(SpriteRenderer)
    else
        self.build_img_ = self.transform:Find("Build/BuildCollider"):GetComponent(Image)
        self.build_shadow_ = self.transform:Find("Build/Shadow"):GetComponent(Image)
    end
    self.effect_ = self.transform:Find("Build/BoardEffect")
    self.effect_other_ = self.transform:Find("Build/BoardEffect/Other")
    self.effect_curr_ = self.transform:Find("Build/BoardEffect/Current")
    self.effect_other_.gameObject:SetActive(false)
    self.effect_curr_.gameObject:SetActive(false)

    if _G.GRichTextField then
        self.virtualCamera = self.transform:Find("Build/virtualCamera")
        local fairyGuiScale = _G.GRoot.contentScaleFactor * _G.Stage.inst.cachedTransform.localScale
        self.timer_solider_ = self.BoardGo.transform:Find("Timer")
        self.timer_solider_.localScale = fairyGuiScale

        local timerBoardPanel = self.timer_solider_:GetComponent(_G.UIPanel)
        self.posController = timerBoardPanel.ui:GetController("PosController")

        self.timer_1_ = timerBoardPanel.ui:GetChild("Timer1")
        self.timer_1_.visible = false
        self.timer_txt_1_ = self.timer_1_:GetChild("LvUpTimeTxt")
        self.timer_img_1_ = self.timer_1_:GetChild("Timer1Pb").asProgress

        self.timer_2_ = timerBoardPanel.ui:GetChild("Timer2")
        self.timer_2_.visible = false
        self.timer_txt_2_ = self.timer_2_:GetChild("SoldierTimeTxt")
        self.timer_img_2_ = self.timer_2_:GetChild("Timer2Pb").asProgress
        self.timer_info_2_ = self.timer_2_:GetChild("SoldierNameTxt")
        self:SetTimerPos()
    else
        self.timer_solider_ = self.timer_panel_.transform:Find("BuildTitle/TimerPanel")
        self.timer_1_ = self.timer_solider_.transform:Find("Timer_1")
        self.timer_1_.gameObject:SetActive(false)
    self.timer_txt_1_ = self.timer_1_.transform:Find("Text"):GetComponent(UI.Text)
    self.timer_img_1_ = self.timer_1_.transform:Find("Mask"):GetComponent(UI.Image)
        self.timer_2_ = self.timer_solider_.transform:Find("Timer_2")
        self.timer_2_.gameObject:SetActive(false)
    self.timer_txt_2_ = self.timer_2_.transform:Find("Text"):GetComponent(UI.Text)
    self.timer_img_2_ = self.timer_2_.transform:Find("Mask"):GetComponent(UI.Image)
    self.timer_info_2_ = self.timer_2_.transform:Find("info/Text"):GetComponent(UI.Text)

        self.collectTitle = self.timer_panel_.transform:Find("BuildTitle/CollectTitle")
        self.collectTitle.gameObject:SetActive(false)
    end
    --ui main
    self.ui_main_ = GameManager.UI_Main
end


function on_start()
end

function on_dispose(self)
    if self.bill_board_ then
        self.bill_board_:on_dispose()
        _G.Object.Destroy(self.bill_board_.gameObject)
        self.bill_board_ = nil
    end
    self:close_timer_all()
    self.buildDisplayObj = nil
end

--点击建筑
function click_build(self, menu)
    self.buildMenu = menu
    --是否正在移动位置中
    if self.is_show_effect_ or self.build_move_source_id_ then
        --是否可以移动位置
        if self.is_movable_ then
            self:check_change_build_pos()
        end
        return
    end

    self:refresh_build_info()
    if self.build_info_ then
        if self.build_info_.buildMark == config.BUILD_MARK.NORMAL then
            self:ClickNormalBuild()
        elseif self.build_info_.buildMark == config.BUILD_MARK.NOLV then
            self:ClickNoLVupBuild()
        end
    else
        self:click_space_collider()
    end
end


--点击普通建筑
function ClickNormalBuild(self)
    log("------------------------> click normal build")
    --如果是在升级
    if self.build_info_:is_building() or self.build_info_:is_lvup() or self.build_info_:is_removing() then
        if self.build_info_:is_less_free_time() then
            self.bill_board_:on_free_speedup_click()
            self:check_data_advance()
            return
        end
    end

     --如果训练完成 建筑点击
    if self.build_info_:is_soldier_build() then
        local timer_exis, finish_train, soldier_id, soldier_class = SoldierManager:check_soldier_state(self.build_info_.build_type_)
        if finish_train then
            --local soldier_id = self.build_info_.soldier_id_
            if not soldier_id then elog("soldier_id is nil") end
            self.bill_board_:on_soldier_drill_click({soldier_id, soldier_class})
            return
        end
    end
    self:show_build_menu()
end

--点击不可升级建筑
function ClickNoLVupBuild(self)
    if self.build_info_:IsHaveMenu() then
        self:show_build_menu()

    else
        if self.id_ == 59 then

            if _G.FairyGUI then
                _G.UIController:ShowUI("UIRecruit")
                return
            end

            return _G.UIManager.open_window("HeroRecruitWindow")
        end

        if self.id_ == WHARF_SPACE_ID then
            --TODO 市舶司
            if BuildManager:get_main_lv() < 10 then
                MsgCenter.send_message(_G.Msg.SHOW_HINT, "王城等级10级开启")
            end
            return
        end

        if self.id_ == RANDOM_SHOP_SPACE_ID then
            if BuildManager:get_main_lv() < 3 then
                MsgCenter.send_message(_G.Msg.SHOW_HINT, "王城等级3级开启")
                return
            end
            BuildManager.showTitle = false
            if _G.UIController then
                UIController:ShowUI("UIRandomShop")
            else
                _G.UIManager.open_window("CityRandomShopWindow")
            end

            self:get_bill_board():hide_build_title()
            return
        end

        MsgCenter.send_message(_G.Msg.SHOW_HINT, _G.lang("UI_MAIN_UNOPEN"))
    end
end

-- 打开菜单
function show_build_menu(self)
    print("show_build_menu")
    if self.buildMenu then
        self.buildMenu:callback_listerent(self)
    end
end

--点击空地碰撞体
function click_space_collider(self)
    if _G.SceneManager.City_Scene then
        SceneManager.City_Scene:map_move_to_upper(self)
    else
        _G.SceneController.currentScene:GetCameraController():FocusOn(self.virtualCamera)
    end
    if _G.FairyGUI then
        _G.UIController:ShowUI("UIBuild", {space=self})
        return
    end
    -- UIManager.open_window("BuildCreateWindow", function()
    --     --self:hide_empty_hint_icon(false) --隐藏空地提示icon
    -- end, self)
end

function check_change_build_pos(self)
    self:refresh_build_info()
    --如果是在交换建筑
    local msg_ = {}
    msg_.title = ""
    msg_.content = lang("UI_HINT_BUILD_SURE_MOVE")
    msg_.buttons = {lang("UI_BASIC_BUILD_MOVE")}
    msg_.callback = function(index)
        if index == 1 then
            --第一个建筑的id
            local build1 = BuildManager:get_build_info_by_id(self.exchange_last_id_)
            if not self.exchange_last_id_ then return end
            --该建筑的pos
            local pos = self.build_info_ and self.build_info_.pos_ or self.id_ - config.CITY_RES_BUILD_START_POS + 1
            local req_msg = {}
            req_msg.id = self.exchange_last_id_
            req_msg.target_pos = pos
            Net.send("build_exchange", req_msg, function(result)
                if result.e == 0 then
                    local data = {build1.space_id_, self.id_}
                    --参数：主动交换的建筑ID，当前建筑信息（可能为nil），当前空地id
                    BuildManager:change_build_pos(build1.id_, self.build_info_ and self.build_info_.id_ or nil, self.id_)
                    -- self:refresh_build_view()
                    MsgCenter.send_message(Msg.CITY_BUILD_MOVE_FINISHED, data)
                end
            end)
        end
    end
    MsgCenter.send_message(Msg.SHOW_NOTIFY, msg_)
    return
end

--游戏登录 检查是否存在data(倒计时,有未验收的小兵)
function check_data_advance(self)
    self:refresh_build_info()
    self:stop_timer_1()
    self:stop_timer_2()
    --显示空地表现

    self:hide_build_img()
    --隐藏title
    self.bill_board_:hide_build_title()
    --隐藏建筑名称
    self.bill_board_:hide_build_mark()


    ------------------------------------随机商店
    if self.id_ == RANDOM_SHOP_SPACE_ID then
        local randomShop = BuildManager:GetRandomShop()
        if randomShop then
            if randomShop:IsInitiativeGoods() and BuildManager.showTitle then
                self:get_bill_board():set_build_title(config.BUILD_TITLE_TYPE.RANDOM_SHOP)
            end
            if randomShop:IsClose() then
                self:get_bill_board():HideBuildTitle()
            end
        end
    end
    -----------------------------------祭坛
    if self.id_ == 45 then
        local fete = BuildManager:GetFete()
        if fete and fete:GetFreeTimes() > 0 then
            self:get_bill_board():set_build_title(config.BUILD_TITLE_TYPE.FETE)
        end
    end

    ------------------------------------市舶司
    if self.id_ == WHARF_SPACE_ID then
        self:RefreshWharf()
    end
    ------------------------------------



    if not self.build_info_ then return end
    ------------------建造 升级 处理
    local lv
    --有倒计时
    if self.build_info_:is_lvup() or self.build_info_:is_building() then
        --如果建筑正在建造过程中  那么需要加载1级时候的图片
        if self.build_info_:is_building() then lv = 1 end
        MsgCenter.send_message(Msg.CITY_UP_LV_UPDATE, self.build_info_.id_)
    end
    local path = self.build_info_:GetPath(lv)
    self:show_img_by_path(path)
    self.bill_board_:set_build_mark()
    ------------------建筑拆除
    if self.build_info_:is_removing() then
        MsgCenter.send_message(Msg.CITY_UP_LV_UPDATE, self.build_info_.id_)
    end

    ----------------兵营处理
    if self.build_info_:is_soldier_build() then
        if self.build_info_.lv_ > 0 then
            --build_idx = self.build_info_.idx_
            local timer_exis, finish_train, soldier_id, soldier_class = SoldierManager:check_soldier_state(self.build_info_.build_type_)
            if timer_exis then
                self:play_timer(soldier_id, soldier_class)
            elseif finish_train then
                if self.bill_board_ then
                    --self:show_build_title(soldier_id)
                    self.bill_board_:set_build_title(config.BUILD_TITLE_TYPE.SOLDIER_DRILL, soldier_id, soldier_class)
                end
            end
        end
    end
    ----------------收集 资源
    if self.build_info_:is_collect_build() then
        -- 刷新状态
        self:on_collect_refresh(self.build_info_.id_)
    end

    ---------------医馆治疗
    if self.build_info_:is_hospital_build() then
        if self.build_info_:is_curing() then
            self:hurts_timer()
        else
            self:SetTimerVisible(self.timer_2_, false)
        end
    end
end

--建造升级 timer
function on_building(self)
    if not self.build_info_ then
        self.build_info_ = BuildManager:get_build_info_by_space_id(self.id_)
    end
    -- 是否在建造中
   -- local is_removed = self.build_info_:is_removing()
    self:timer_control(self.timer_1_, self.timer_txt_1_, self.timer_img_1_, self.build_info_, config.TIMER_TYPE.BUILDING, nil,
        function(arg1, arg2, queue_id)
            self:every_second(arg1, arg2, queue_id)
        end)
end

function every_second(self, arg1, arg2, queue_id)
    if not GameManager.UI_Main then
        return
    end
    if not self.ui_main_ then
        self.ui_main_ = GameManager.UI_Main
    end
    if not self.ui_main_ then
        elog("ui_main is nil, get it Failure!")
    else
        self.ui_main_:on_update_queue_timer(arg1, arg2, queue_id)
    end
end

--士兵训练 timer
function play_timer(self, id, soldier_class)
    local data = SoldierManager:get_soldier_info_by_id(id, soldier_class)
    if data.target_ then
        self.timer_info_2_.text = lang("UI_MAIN_PROMOTE", data.lv_, data.name_, data.select_count_)
    else
        self.timer_info_2_.text = data.lv_.."级"..data.name_.."  "..(data.select_count_ or 0)
    end
    self:timer_control(self.timer_2_, self.timer_txt_2_, self.timer_img_2_, data, config.TIMER_TYPE.DRILL,
        function()
            self.bill_board_:set_build_title(config.BUILD_TITLE_TYPE.SOLDIER_DRILL, id, soldier_class)
        end)
end

--士兵治疗 timer
function hurts_timer(self)
    --治疗的过程中不显示升级
    self:stop_timer_1()
    if not self.build_info_.cure_timer_ or self.build_info_.cure_total_ <= 0 then return end
    self.timer_info_2_.text = lang("UI_MAIN_CURING", self.build_info_.cure_total_)
    --开启倒计时
    local obj = {}
    obj.key = "soldier_cure" --倒计时类型
    obj.id = self.build_info_.id_
    obj.end_time = self.build_info_.cure_timer_.end_time_
    obj.need_scene = "City"
    obj.on_per_second = function()
        self:SetTimerVisible(self.timer_2_, true)
        self:show_timer(self.timer_txt_2_, self.timer_img_2_, self.build_info_)
    end
    obj.on_complete = function()
        self:SetTimerVisible(self.timer_2_, false)
    end
    BuildManager:register_timer(obj)
end

function show_timer(self, txt, img, build)
    --timer_go.gameObject:SetActive(build ~= nil)
    if build then
        local remaining_time, curr_time, total_time = build:get_remaining_time()
        --log("---------->  rematime = %s, curr_time = %s", remaining_time, curr_time)
        if not remaining_time or not curr_time then return end
        txt.text = UIUtil.format_time(remaining_time)
        if _G.GRichTextField then
            img.min = 0
            img.max = total_time
            img.value = curr_time
        else
            img.fillAmount = curr_time / total_time
        end
    end
end

function get_bill_board(self)
    return self.bill_board_
end

function timer_control(self, timer_obj, txt, img, data, timer_type, complete, every_second_func)
    local timer_data = {
        start_time_ = data.start_time_,
        end_time_ = data.end_time_, 
        total_time_ = data.total_time_
    }
    if timer_type == config.TIMER_TYPE.CURE then
        timer_data = data.cure_timer_
    end
    if not timer_data.start_time_ or not timer_data.end_time_ or not timer_data.total_time_ then return end

    self.timer_tb_ = self.timer_tb_ or {}
    if self.timer_tb_[timer_obj.name] then
        self:stop_timer_time(timer_obj.name)
    end
    local toggle = false
    --获取队列ID
    local queue_id = BuildManager:get_queue_id(data.id_)
    local start_time = timer_data.start_time_
    local end_time = timer_data.end_time_
    local total_time = math.floor(timer_data.total_time_) --可能为小数
    local curr_second = total_time - (math.floor(end_time - Net.server_time()))--当前时间
    if curr_second < 0 then curr_second = 0 end
    self:SetTimerVisible(timer_obj, true)
    local last_time = Net.server_time()
    local lua_timer = LuaTimer.Add(0, 1000, function()
        --时间不精确处理
        if Net.server_time() - last_time > 1 then
            curr_second = curr_second + 1
        end
        last_time = Net.server_time()
        --结束处理
        --elog("currtime = %s, total_time = %s", curr_second, total_time)
        if curr_second > total_time then
            self:SetTimerVisible(timer_obj, false)
            if complete then complete() end
            return false
        end
        if every_second_func then every_second_func(total_time - curr_second, curr_second / total_time, queue_id) end
        --set data
        --小于免费时间
        if timer_type == config.TIMER_TYPE.BUILDING and not toggle and data:is_less_free_time() then
            toggle = true
            if data:is_collect_build() then
                self:on_collect_refresh(data.id_)
            end
            self.bill_board_:set_build_title(config.BUILD_TITLE_TYPE.FREE_SPEEDUP)
        end
        txt.text = UIUtil.format_time(total_time - curr_second)
        if _G.GRichTextField then
            img.min = 0
            img.max = total_time
            img.value = curr_second
        else
            img.fillAmount = curr_second / total_time
        end
        curr_second = curr_second + 1
    end)

    self.timer_tb_[timer_obj.name] = lua_timer
end

function close_timer_all(self)
    if not self.timer_tb_ then return end
    for k, v in pairs(self.timer_tb_) do
        if v then
            LuaTimer.Delete(v)
        end
    end
    self.timer_tb_ = nil
end

function stop_timer_1(self)
    self:SetTimerVisible(self.timer_1_, false)
    self:stop_timer_time(self.timer_1_.name)
end

function stop_timer_2(self)
    self:SetTimerVisible(self.timer_2_, false)
    self:stop_timer_time(self.timer_2_.name)
end

function SetTimerVisible(self, timer, isVisible)
    if _G.GRichTextField then
        timer.visible = isVisible
        self:SetTimerPos()
    else
        timer.gameObject:SetActive(isVisible)
    end
end

function SetTimerPos(self)
    if self.timer_1_.visible and (self.timer_2_.visible or not self.timer_2_.visible) then
        self.posController.selectedPage = "normal"
        return
    end
    self.posController.selectedPage = "sodierUp"
end

--结束倒计时
--key: 倒计时组件name
function stop_timer_time(self, key)
    if not self.timer_tb_ or not self.timer_tb_[key] then
        return
    end
    LuaTimer.Delete(self.timer_tb_[key])
    self.timer_tb_[key] = nil
end

function show_img_by_path(self, path)
    if not path or #path <= 0 then return end
    self:load_img(path, self.build_img_)
    --加载建筑阴影UI
    --self:load_img(path.."_shadow", self.build_shadow_)
end

--根据等级显示图片
function show_img_by_level(self, lv)
    if self.id_ == RANDOM_SHOP_SPACE_ID then
        return
    end
    --获取1级的图片
    local data = self.build_info_:get_update_info_by_level(lv)
    if not data or #data.path <= 0 then return end
    self:show_img_by_path(data.path)
end

--隐藏建筑UI
function hide_build_img(self)
    self.build_img_.gameObject:SetActive(false)
    self.build_shadow_.gameObject:SetActive(false)
end


function load_img(self, path, img)
    if path == nil then return end
    if _G.GRichTextField then
        _G.GameObject.Destroy(self.buildDisplayObj)
        _G.UIUtil.LoadBuildingModel(path, img.transform, function(obj)
            self.buildDisplayObj = obj;
        end);
    else
        _G.UIUtil.set_sprite(path, img, function()
            if not _G.Slua.IsNull(img) and img.SetNativeSize then
                img:SetNativeSize()
            end
        end)
    end
    if not self:is_alive() then return end
    img.gameObject:SetActive(true)
end

function get_bill_board(self)
    return self.bill_board_
end

--保存主动交换位置的建筑id
function build_exchange_last_id(self, build_id)
    if not build_id then return end
    self.exchange_last_id_ = build_id
end

--底部高亮显示
function show_build_effect(self, source_id)

    --建筑移动的情况下 可能会拆除 所以保存数据，只有移动完成才会清理
    self.build_move_source_id_ = source_id
    --保存当前状态
    self.is_show_effect_ = true --正在建筑移动中
    --如果是不可以移动的建筑 不播放动画
    if not self.space_info_:is_movable_by_build_id(source_id) then
        self.is_movable_ = false
        return
    end
    self.is_movable_ = true
    --根据id获取空地id
    local sapce_id = BuildManager:get_sapce_id_by_build_id(source_id)
    local obj
    self.effect_.gameObject:SetActive(true)
    if sapce_id == self.id_ then
        obj = self.effect_curr_
        self.effect_curr_.gameObject:SetActive(true)
        self.effect_other_.gameObject:SetActive(false)
    else
        obj = self.effect_other_
        self.effect_curr_.gameObject:SetActive(false)
        self.effect_other_.gameObject:SetActive(true)
    end
    self.effect_tween_ = GameTween.DOScale(obj.transform, 0.8, 1):SetLoops(-1, 1)
end

--隐藏底部高亮显示
function hide_build_effect(self)
    self.is_show_effect_ = false
    if self.effect_tween_ then
        self.effect_tween_:Kill(false)
    end
    self.effect_.gameObject:SetActive(false)
end

--建筑拆除完成
function on_build_removed_finished(self)
    self:refresh_build_view()
    --有可能现在处于移动建筑中
    if self.build_move_source_id_ and self.space_info_ then
        local is_movable = self.space_info_:is_movable_by_build_id(self.build_move_source_id_)
        if is_movable then
            self.effect_.gameObject:SetActive(true)
            self.effect_other_.gameObject:SetActive(true)
            self.effect_other_.transform.localScale = Vector3(1, 1, 1)
            self.effect_tween_ = GameTween.DOScale(self.effect_other_.transform, 0.8, 1):SetLoops(-1, 1)
        end
    end
end

--建筑移动完成
function on_build_exchanged(self, data)
    self:hide_build_effect()
    --建筑移动完成 清除源建筑id
    self.build_move_source_id_ = nil
    if data then
        for k, v in pairs(data) do
            if self.id_ == v then
                self:refresh_build_view()
                break
            end
        end
    end
end

--取消拆除
function on_build_removed_cancel(self)
    --关闭计时器
    self:stop_timer_1()
     --隐藏title
    self.bill_board_:hide_build_title()
end

function on_up_lv_finished(self, id)
    self:refresh_build_info()
    --建造升级完成 关闭计时器
    if not self.build_info_ then return end
    if self.build_info_.id_ ~= id then return end
    self:stop_timer_1()
    --self:show_img_by_level(self.build_info_.lv_)
    local path = self.build_info_:GetPath()
    self:show_img_by_path(path)
    self.bill_board_:set_build_mark()
    --祭坛升级的时候 不需要主动隐藏title
    if self.id_ ~= 45 then
        self.bill_board_:hide_build_title()
    end
    if self.build_info_:is_collect_build() then
        self:on_collect_refresh(self.build_info_.id_)
    end
    if self.build_info_:is_hospital_build() and self.build_info_.lv_ == 1 then
        self:hurts_timer()
    end
end

function on_soldier_drill_finished(self, build_id, soldier_id, soldier_class)
    --训练完成
    if not self.build_info_ or self.build_info_.id_ ~= build_id then return end
    if not build_id or not soldier_id then return end
    self:stop_timer_2()
    self.bill_board_:set_build_title(config.BUILD_TITLE_TYPE.SOLDIER_DRILL, soldier_id, soldier_class)
end

function on_soldier_cure_finished(self, is_cancel)
    self:refresh_build_info()
    if self.build_info_:is_hospital_build() then
        self:SetTimerVisible(self.timer_2_, false)
        BuildManager:close_timer("soldier_cure")
        --self:on_building()
    end

    if not is_cancel then
        MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_SOLDIER_CURE_FINISHED"))
    end
end

function refresh_build_info(self)
    self.build_info_ = BuildManager:get_build_info_by_space_id(self.id_)
end

--刷新建筑表现
function refresh_build_view(self)
    --隐藏建筑底部特效
    self:hide_build_effect()
    self:refresh_build_info()
    --刷新title
    self:get_bill_board():set_build_mark()
    --刷新
    self:check_data_advance()

    self:on_collect_refresh()
end

function on_collect_refresh(self, build_id)
    if self.collect_tween_ then
        self.collect_tween_:Kill(true)
        self.collect_tween_ = nil
        self.build_img_.color = Color(225, 225, 225)
    end
    if not self.collectTitle then return end
    if not self.build_info_ then
        self.collectTitle.gameObject:SetActive(false)
        return
    end
    local collect = CollectManager:get_collect(self.build_info_.id_)
    if collect and collect:has_buff() then
        self.collect_tween_ = GameTween.DOFade(self.build_img_, 0.5, 0.5):SetLoops(-1, XLoopType.Yoyo)
    else
        if self.collect_tween_ then
            self.collect_tween_:Kill(false)
            self.collect_tween_ = nil
        end
    end
    if not self.collectTitle then return end
    if not collect then self.collectTitle.gameObject:SetActive(false) return end
    if not collect:enable_collect() then
        self.collectTitle.gameObject:SetActive(false)
        return
    end
    self.collectTitle.gameObject:SetActive(true)
    self:get_bill_board():set_build_title(config.BUILD_TITLE_TYPE.COLLECT)
end

function on_collect_finished(self)
    if not self.collectTitle then return end
    self.collectTitle.gameObject:SetActive(false)
end

function RefreshWharf(self)
    local wharf = BuildManager:GetWharfInfo()
    if not wharf then
        return
    end
    if wharf:EnableReward() then
        BuildManager:close_timer("wharf")
        self:get_bill_board():set_build_title(config.BUILD_TITLE_TYPE.WHARF)
    else
        self:get_bill_board():hide_build_title()
        --开启倒计时
        if not wharf:GetEndTime() then
            return
        end
        self.wharfTimer.gameObject:SetActive(true)
        --self:SetTimerVisible(self.timer_1_, true)
        local txt = self.wharfTimer.transform:Find("Board/Text"):GetComponent(Text)
        local obj = {}
        obj.key = "wharf" --倒计时类型
        obj.id = self.build_info_.id_
        obj.end_time = wharf:GetEndTime()
        obj.need_scene = "SceneMain"
        obj.on_per_second = function()
            --self.timer_txt_1_.text = UIUtil.format_time(wharf:GetremainingTime())
            txt.text =  UIUtil.format_time(wharf:GetremainingTime())
        end
        obj.on_complete = function()
            self.wharfTimer.gameObject:SetActive(false)
            --self:SetTimerVisible(self.timer_1_, false)
            self:get_bill_board():set_build_title(config.BUILD_TITLE_TYPE.WHARF)
        end
        BuildManager:register_timer(obj)
    end
end