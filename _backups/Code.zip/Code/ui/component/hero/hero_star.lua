module("HeroStar", package.seeall)
setmetatable(HeroStar, {__index = BaseComponent})

function on_awake(self)
    
end

function init(self)
    self.star_group_ = self.transform:Find("StarGroup")
    self.stage_group_ = self.transform:Find("StartUp/ClassGroup")
    self.chip_cnt_ = self.transform:Find("Buttom/HeroChip/Board/Text"):GetComponent(Text)
    self.hint_txt_ = self.transform:Find("StartUp/Board/Hint"):GetComponent(Text)
    self.star_txt_ = self.transform:Find("StartUp/StarTxt"):GetComponent(Text)
    self.hero_chip_ = self.transform:Find("Buttom/HeroChip")
    self.chip_img_ = self.transform:Find("Buttom/HeroChip/Chip"):GetComponent(Image)
    self.hero_chip_img_ = self.transform:Find("StartUp/IconChip"):GetComponent(Image)
    self.source_btn_ = self.transform:Find("StartUp/Button"):GetComponent(Button)
    self.star_up_btn_ = self.transform:Find("Buttom/Button"):GetComponent(Button)
    self.exchange_btn_ = self.transform:Find("Buttom/HeroChip/Button"):GetComponent(Button)

    self:add_event_handler(self.source_btn_.onClick, on_source_btn_handler)
    self:add_event_handler(self.star_up_btn_.onClick, on_star_up_btn_handler)
    self:add_event_handler(self.exchange_btn_.onClick, on_exchange_btn_handler)
end

function set_data(self, hero)
	if not hero then return end
	self.hero_data_ = hero
    local star, stage = self.hero_data_:get_star_and_stage()
    local prop = self.hero_data_:get_prop()
    --将魂碎片道具
    local item1 = ItemManager:get_item_prop_by_id(prop.activate[2])

    -- 如果可以兑换
    if self.hero_data_:enable_exchange() then
         --万能碎片道具
        local item2 = ItemManager:get_item_prop_by_id(prop.trade_item[2])
        --已经拥有的万能碎片道具
        local chip_item = ItemManager:get_item_by_id(prop.trade_item[2])
        self.general_chip_cnt_ = chip_item and chip_item.count_ or 0
        self.hero_chip_.gameObject:SetActive(true)
        if not self:is_alive() then return end
        UIUtil.set_sprite(item2.icon, self.chip_img_)
    else
        self.general_chip_cnt_ = 0
        self.hero_chip_.gameObject:SetActive(false)
    end

    if not self:is_alive() then return end
    UIUtil.set_sprite(item1.icon, self.hero_chip_img_)
    
    local cur = self.hero_data_:get_chip_num()
    local all = self.hero_data_:get_stage_up_cost()
    local enable_stage = self.hero_data_:enable_stage()

    local  str
    if stage == 0 then
        str = lang("UI_HERO_STAR", star)
    else
        str = lang("UI_HERO_STAR", star)..lang("UI_HERO_STAGE", stage)
    end
    self.star_txt_.text = str
    self.hint_txt_.text = lang("UI_HERO_HINT_NEXT_STAGE", cur.."/"..all)
    self.chip_cnt_.text = self.general_chip_cnt_

    self.star_up_btn_.interactable = enable_stage
    GameUtil.SetImageGrey(self.star_up_btn_:GetComponent(Image), not enable_stage)

    HeroManager:show_hero_star_comp(self.star_group_, star)
    if stage then
    	for i = 1, 5 do
    		local obj = self.stage_group_.transform:Find("Item"..i)
    		if obj then
    			local img = obj.transform:Find("Image")
    			if i <= stage then
    				img.gameObject:SetActive(true)
    			else
    				img.gameObject:SetActive(false)
    			end
    		end
    	end
    end
    
end

--升星操作
function on_star_up_btn_handler(self, event_data)
    --已经最大星级后，不可升星
    if not self.hero_data_ then return end
    local star = self.hero_data_:get_star_and_stage()

    if star >= self.hero_data_:get_max_star() then return end
	--检查碎片是否足够
    if not self.hero_data_:enable_stage() then return end
    local star, stage = self.hero_data_:get_star_and_stage()
    local chip_num = self.hero_data_:get_chip_num()
    local cost = 0
    local target
    for i = stage, 4 do
        local key = self.hero_data_.id_ * 100 + (star - 1) * 5 + i + 1 
        local star = HeroManager.star_prop_map_[key]
        if star then
            cost = cost + star.cost[3]
            --拥有的碎片小于 花费的时候 选择上一个阶段
            if chip_num < cost then
                local star = HeroManager.star_prop_map_[key]
                target = star.star_level
                break
            end
        end
    end

    --如果拥有的碎片已经超过升级一星的了，直接选择下一星级
    if not target then
        local key = self.hero_data_.id_ * 100 + star * 5 + 1
        local star = HeroManager.star_prop_map_[key]
        target = star.star_level
    end
    local req_msg = {}
    req_msg.id = self.hero_data_.id_
    req_msg.tar_star = target

    self.hero_data_:set_attrs_snapshot()
    Net.send("hero_starup", req_msg, function(result)
        if result.e == 0 then
            ----打开弹窗
            local hero = result.hero
            self.hero_data_.star_ = hero.star or self.hero_data_.star_
            self.hero_data_.lv_ = hero.level or self.hero_data_.lv_
            self.hero_data_.cur_exp_ = hero.level_exp or self.hero_data_.cur_exp_
            local hero = HeroManager:get_active_hero_by_id(self.hero_data_.id_)
            self:set_data(hero)
            UIManager.open_window("HeroAnimeWindow", nil, self.hero_data_.id_)
        end
    end)
end

--兑换
function on_exchange_btn_handler(self, event_data)
    if not self.hero_data_ then return end
    local star = self.hero_data_:get_star_and_stage()
    if star >= self.hero_data_:get_max_star() then return end

	if not self.general_chip_cnt_ or self.general_chip_cnt_ <= 0 then
		MsgCenter.send_message(Msg.SHOW_HINT, lang("ITEM_NOT_ENOUGH"))
        log("you are missing this item by id=%d", self.hero_data_:get_prop().trade_item[2])
		return
	end
	if self.hero_data_ and self.hero_data_.id_ then
		UIManager.open_window("HeroChipExchangeWindow", nil, self.hero_data_.id_)
	end
end

function on_source_btn_handler(self, event_data)    
    log("you are missing this item by id=%d", self.hero_data_:get_chip_id())
	MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_MAIN_UNOPEN"))
end