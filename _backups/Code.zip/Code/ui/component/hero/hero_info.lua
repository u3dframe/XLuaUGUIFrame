module("HeroInfo", package.seeall)
setmetatable(HeroInfo, {__index = BaseComponent})

function on_awake(self)
    
end

function init(self)
	self.test_btn_ = self.transform:Find("DescGroup/AddDesc"):GetComponent(Button)
    self:add_event_handler(self.test_btn_.onClick, desc_btn_handler)

    self.star_group_ = self.transform:Find("StarGroup")
    self.lv_txt_ = self.transform:Find("DescGroup/LvPanel/Text"):GetComponent(Text)
    self.exp_bar_ = self.transform:Find("DescGroup/BarPanel/Bar"):GetComponent(Image)
    self.exp_txt_ = self.transform:Find("DescGroup/BarPanel/Text"):GetComponent(Text)
    self.arrt_panel_ = self.transform:Find("BottomGroup/AttrPanel")

end

function desc_btn_handler(self, event)
	if self.hero_data_ and self.hero_data_.id_ then
    	UIManager.open_window("HeroDetailsWindow", nil, self.hero_data_.id_)
    end
end


function set_data(self, hero)
	if not hero then return end
    self.hero_data_ = hero
    local star = self.hero_data_:get_star_and_stage()

    HeroManager:show_hero_star_comp(self.star_group_, star)
    self.lv_txt_.text = lang("UI_HERO_LV1", self.hero_data_.lv_)

    local fill_amount = self.hero_data_.cur_exp_ / self.hero_data_.max_exp_
    self.exp_bar_.fillAmount = fill_amount >= 1 and 0 or fill_amount
    self.exp_txt_.text = self.hero_data_.cur_exp_.."/"..self.hero_data_.max_exp_
    local attr_name = {
    	lang("UI_HERO_TYPE1"),
    	lang("UI_HERO_TYPE2"),
    	lang("UI_HERO_TYPE3"),
    }
    for i = 1, 3 do
    	local attr_obj = self.arrt_panel_.transform:Find("AttrItem"..i)
    	if attr_obj then
    		local txt = attr_obj.transform:Find("Text"):GetComponent(Text)
    		local value = self.hero_data_:get_attr(i)
    		txt.text = attr_name[i].."                              "..lang("UI_BASIC_COLOR", config.FONT_COLOR.WHITE,value)
    	end
    end
end