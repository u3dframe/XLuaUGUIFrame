module("HeroLevel", package.seeall)
setmetatable(HeroLevel, {__index = BaseComponent})

local BasicConfig = _G.Database.BasicConfig


function on_awake(self)
	local list = {
        "Common/ItemCard"
    }

    Yield(UIUtil.load_component(list, function(prefabs) 
        self.item_prefab_ = prefabs[1]
    end))
end

function init(self)

	self.lv_txt_ = self.transform:Find("DescGroup/LvPanel/Text"):GetComponent(Text)
	self.exp_bar_ = self.transform:Find("DescGroup/BarPanel/Bar"):GetComponent(Image)
    self.exp_txt_ = self.transform:Find("DescGroup/BarPanel/Text"):GetComponent(Text)
   
    self.effect_prefab_ = self.transform:Find("DescGroup/BarPanel/EffectTxt")
    self.effect_prefab_.gameObject:SetActive(false)
    self.max_lv_txt_ = self.transform:Find("DescGroup/Hint")

    self.exp_group_ = self.transform:Find("PropGroup")
    self.effect_group_ = self.transform:Find("DescGroup/BarPanel/EffectGroup")

    self.lvup_btn_ = self.transform:Find("DescGroup/AddDesc"):GetComponent(Button)

    self:add_event_handler(self.lvup_btn_.onClick, lvup_btn_handler)

    self.high_speed_ = 10   --最快速度
    self.acc_ = 4           --加速度
    self.interval_ = 2   --时间间隔

    self.curr_speed_ = 0   --当前速度
    self.curr_time_ = 0    --当前时间

    self.effect_txt_tb_ = {}  --字体缓存
    self.max_effect_cnt_ = 5

    self.exp_anime_speed_ = 0.3  --经验值播放动画速度

    self.anime_finshed_ = true
end

function on_dispose(self)
    self.point_event_ = nil
    if self.end_tween_ then
    	self.end_tween_:Kill(false)
    	self.end_tween_ = nil
    end

    if self.lvup_tween_ then
    	self.lvup_tween_:Kill(false)
    	self.lvup_tween_ = nil
    end

    if self.effect_txt_tb_ then
    	for k, v in pairs(self.effect_txt_tb_) do
    		if v.tween then
    			v.tween:Kill(false)
    		end
    	end
    	self.effect_txt_tb_ = nil
    end
end

function set_data(self, hero)
	local new_hero = HeroManager:get_active_hero_by_id(hero.id_)
	if not hero then return end
    self.hero_data_ = hero

    self.lv_txt_.text = lang("UI_HERO_LV1", self.hero_data_.lv_)
    local fill_amount = self.hero_data_.cur_exp_ / self.hero_data_.max_exp_
    self.exp_bar_.fillAmount = fill_amount >= 1 and 0 or fill_amount
    self.exp_txt_.text = self.hero_data_.cur_exp_.."/"..self.hero_data_.max_exp_

    --是否超过等级上限
    local can_lvup = self.hero_data_:enable_lvup()
    local props = ItemManager:get_hero_exp_item()

    --显示提示
	
	if #props <= 0 then
		self.lvup_btn_.interactable = false
    	GameUtil.SetImageGrey(self.lvup_btn_:GetComponent(Image), true)
	else
		self.lvup_btn_.interactable = true
    	GameUtil.SetImageGrey(self.lvup_btn_:GetComponent(Image), false)
	end
	self.max_lv_txt_.gameObject:SetActive(not can_lvup)
	self.lvup_btn_.gameObject:SetActive(can_lvup)

    local basic = BasicConfig.BasicData
    --对道具进行排序
    local hero_props = {}
    for i, v in ipairs(props) do
    	for key, value in ipairs(basic.hero_items) do
    		if value[1] == v.id_ then
    			hero_props[key] = v
    		end
    	end
    end

    --90 150
    for i = 1, 5 do
    	local obj = self.exp_group_.transform:Find("obj"..i)
    	if not obj then
    		obj = self:create_obj(self.item_prefab_, self.exp_group_)
    		obj.name = "obj"..i
    	end
    	if obj then
    		local bg = obj.transform:Find("IconArea"):GetComponent(Image)
    		local icon = obj.transform:Find("IconArea/Icon"):GetComponent(Image)
    		local cnt_parent = obj.transform:Find("IconArea/Count")
    		local cnt = obj.transform:Find("IconArea/Count/Text"):GetComponent(Text)
    		local name = obj.transform:Find("NameTxt"):GetComponent(Text)
    		local des = obj.transform:Find("DesTxt"):GetComponent(Text)
    		local id = basic.hero_items[i][1]
			local exp = basic.hero_items[i][2]
			name.gameObject:SetActive(true)
    		if hero_props[i] and hero_props[i].id_ == id then
    			icon.gameObject:SetActive(true)
    			cnt.gameObject:SetActive(true)
    			cnt_parent.gameObject:SetActive(true)
    			cnt.text = hero_props[i].count_
    			local prop = hero_props[i].prop_

    			UIUtil.set_sprite(prop.icon, icon)
    			UIUtil.set_sprite("UI/Common/Quality/item_"..prop.quality, bg)
    			name.text = lang("UI_BASIC_COLOR", config.FONT_COLOR.WHITE,prop.name)
    			des.gameObject:SetActive(true)
    			des.text = string.format("(%s+%d)",lang("UI_BASIC_EXP"), exp)
    			--监听事件
    			if self.point_event_ and self.point_event_[i] then
    				self.point_event_[i]:dispose()
    			end

    			local data = {}
    			data[1] = obj
    			data[2] = hero_props[i]
    			data[3] = exp
    			local pointer = PluginPointer:new(self, icon.gameObject, use_prop_handler, data)
    			self.point_event_ = self.point_event_ or {}
    			self.point_event_[i] = pointer
    		else
    			local prop = ItemManager:get_item_prop_by_id(id)
    			local add_btn  = obj.transform:Find("IconArea/AddBtn"):GetComponent(Button)
    			add_btn.gameObject:SetActive(true)
    			UIUtil.set_sprite("UI/Common/Basic/icon_add", add_btn.gameObject:GetComponent(Image))
    			if prop then
    				name.text = lang("UI_BASIC_COLOR", config.FONT_COLOR.WHITE,prop.name)
    				UIUtil.set_sprite("UI/Common/Quality/item_"..prop.quality, bg)
    			end
    			add_btn.onClick:RemoveAllListeners()
    			self:add_event_handler(add_btn.onClick, des_btn_handler)
    			icon.gameObject:SetActive(false)
    			cnt_parent.gameObject:SetActive(false)
    			des.gameObject:SetActive(true)
    			des.text = string.format("(%s+%d)",lang("UI_BASIC_EXP"), exp)
    		end
    	end
    end
end

--使用升级道具  刷新界面
function level_up_refresh(self, data)
	if not data then return end
	self.index_ = self.index_ or 0
	self.index_ = self.index_ + 1

	local exp = data[3] or 0
	local cnt = data[1].transform:Find("IconArea/Count/Text"):GetComponent(Text)
	cnt.text = data[2].count_ - self.index_
	self.curr_prop_ = data[2]

	if self.exp_tween_ and self.exp_tween_:IsPlaying() then
		self.exp_tween_:Kill(true)
	end

	--self:play_exp_aninme(exp)

	--飘字动画
	if #self.effect_txt_tb_ >= self.max_effect_cnt_ then
		local obj = self:get_obj()
		obj.exp = exp
		self:play_txt_effect_anime(obj)
	else
		local go = self:create_obj(self.effect_prefab_, self.effect_group_)
		local obj = {object = go, tween = nil, exp = exp}
		self:play_txt_effect_anime(obj)
	end
end


function play_exp_aninme(self, exp)

	--经验值动画  (预算出来能升多少级 多少经验)
	local target_lv, curr_exp = HeroManager:get_lv_by_exp(self.hero_data_.id_, exp)

	--如果上个道具的 经验动画 还没播放完成，强制结束
	if self.exp_tween_ then
		self.exp_tween_:Kill(true)
		self.exp_tween_ = nil
		local max_exp = self.hero_data_:get_exp(self.target_lv_)
		self.lv_txt_.text = lang("UI_HERO_LV1", self.target_lv_)
		self.exp_bar_.fillAmount = self.end_exp_ / max_exp
		self.exp_txt_.text = self.end_exp_.."/"..max_exp
	end
	
	--获取总经验
	self.prop_exp_ = 0
	local curr_lv = self.target_lv_ or self.hero_data_.lv_

	for i = curr_lv, target_lv do
		local exp = self.hero_data_:get_exp(i)
		if exp then
			self.prop_exp_ = self.prop_exp_ + exp
		end
	end

	--当前等级
	self.curr_lv_ = self.curr_lv_ or self.hero_data_.lv_

	--获取当前经验值
	if not self.curr_exp_ then
		self.curr_exp_ = self.hero_data_.cur_exp_
	else
		self.curr_exp_ = self.target_exp_
	end

	self.end_lv_ = target_lv
	self.end_exp_ = curr_exp

	--播放动画
	self:exo_bar_aninme(self.curr_exp_, self.curr_lv_)

	--保存预算的等级  最后一级的当前经验（上一次的）
	self.target_lv_ = target_lv
	self.target_exp_ = curr_exp
end

-- 播放一个道具的经验动画
function exo_bar_aninme(self, curr_exp, lv)
	if self.exp_tween_ then
		self.exp_tween_:Kill(true)
		self.exp_tween_ = nil
	end
	local max_exp = self.hero_data_:get_exp(lv)

	
	-- 播放时间 增长的经验 / 总经验 * 总时长
	local add_exp = max_exp - curr_exp
	local time = add_exp / self.prop_exp_ * self.exp_anime_speed_
	--终止递归
	if lv == self.end_lv_ then
		time = (max_exp - self.end_exp_) / self.prop_exp_ * self.exp_anime_speed_
		self.exp_tween_ = GameTween.To(function(v)
			log("-------------------------------------->v = %s", v)
			self.exp_txt_.text = math.floor(v).."/"..max_exp
			self.exp_bar_.fillAmount = v / max_exp
		end, curr_exp, self.end_exp_, time):SetEase(7)

		self.exp_tween_:OnComplete(function()
			log("---------self.end_exp_-----max_exp--------> "..self.end_exp_.."         "..max_exp)
			-- if self.end_exp_ >=  max_exp then

			-- end
			self.lv_txt_.text = lang("UI_HERO_LV1", self.curr_lv_)
			self.exp_bar_.fillAmount = self.end_exp_ / max_exp
			self.hero_data_.cur_exp_ = self.end_exp_
			------------
		end)

		return
	end


	self.exp_tween_ = GameTween.To(function(v)
		self.exp_txt_.text = math.floor(v).."/"..max_exp
		self.exp_bar_.fillAmount = v / max_exp
	end, curr_exp, max_exp, time):SetEase(7)

	self.exp_tween_:OnComplete(function()
		self.curr_lv_ = self.curr_lv_ + 1
		self.lv_txt_.text = lang("UI_HERO_LV1", self.curr_lv_)
		-------------> 这里添加升级完成特效  暂时没加
		self.exp_bar_.fillAmount = 0
		self:exo_bar_aninme(0, self.curr_lv_)
	end)
end



function play_txt_effect_anime(self, obj)
	if not obj or not obj.object then return end
	local target_obj = obj.object.gameObject
	target_obj:GetComponent(Text).text = "+"..obj.exp
	--如果正在播放动画，停止动画
	if obj.tween and obj.tween:IsPlaying() then
		obj.tween:Kill(false)
		target_obj.transform.localPosition = Vector3(0, 0, 0)
		target_obj:GetComponent(Text).color = Color(225, 225, 225)
	end
	target_obj.gameObject:SetActive(true)
	local taget_v3 = Vector3(0, 40, 0)
	local t = XSequence()
	t:Insert(0, GameTween.DOLocalMove(target_obj.transform, taget_v3, 0.8, false):SetEase(1))
	 :Insert(0.3, GameTween.DOFade(target_obj:GetComponent(Text), 0, 0.5))
     :OnComplete(function()
				target_obj:GetComponent(Text).color = Color(225, 225, 225)
				target_obj.transform.localPosition = Vector3(0, 0, 0)
				target_obj.gameObject:SetActive(false)
			end)
	obj.tween = t
	--添加对象到队列中
	self:add_obj(obj)
end

function time_mgr(self, data, point_event)
	if point_event == PluginPointer.POINTER_CLICK then
		self:level_up_refresh(data)
		return
	end
	--到达最快速度  就匀速
	if self.curr_speed_ >= self.high_speed_ then
		self.curr_speed_ = self.high_speed_
	else
		self.curr_speed_ = self.curr_speed_ + self.acc_
	end
	self.curr_time_ = self.curr_time_ + Time.deltaTime * self.curr_speed_
	if self.curr_time_ >= self.interval_ then
		self.curr_time_ = 0
		self:level_up_refresh(data)
	end
end


function use_prop_handler(self, event, data)
	-- --如果在播放动画则不执行
	if not self.hero_data_:enable_lvup() then return end
	if not self.anime_finshed_ then return end
	if event == PluginPointer.POINTER_ALWAY_DOWN then
		--self:time_mgr(data)
	elseif event == PluginPointer.POINTER_CLICK then
		self.anime_finshed_ = false
		if self.exp_anime_ and self.exp_anime_:IsPlaying() then return end
		self:time_mgr(data, event)
		self:send_hero_levelup()
	elseif event == PluginPointer.POINTER_UP then
		--如果是长按的话
		if event == PluginPointer.POINTER_ALWAY_DOWN then
			--self:send_hero_levelup()
		end
	end
end

function send_hero_levelup(self)
	if not self.curr_prop_ then return end
    local cost_data = {
    	config.ITEM_ITEM,
    	self.curr_prop_.id_,
    	self.index_,
    }
    local obj = {
    	id = self.hero_data_.id_,
    	cost = {
    		{array = cost_data}
    	}
    }
	Net.send("hero_levelup", obj, function(result)
    	if result.e == 0 then
    		self.hero_data_:set_level(result.level)
    		self.hero_data_.cur_exp_ = result.exp or self.target_exp_
    		self.hero_data_.max_exp_ = self.hero_data_:get_exp()
    		local hero = HeroManager:get_active_hero_by_id(self.hero_data_.id_)
    		self:set_data(hero)
    		self.anime_finshed_ = true
    		self.index_ = 0
    		MsgCenter.send_message(Msg.CITY_HERO_LVUP)
    	end
    end)	
end

function lvup_btn_handler(self)
	local props = ItemManager:get_hero_exp_item()
	if #props <= 0 then return end
	if self.hero_data_ and self.hero_data_.id_ then
    	UIManager.open_window("HerolevelupdirWindow", nil, self.hero_data_.id_)
    end
end

-- 兵书来源界面
function des_btn_handler(self)
	log("-------------------------------> open exp prop source window")
end

--取出对象从队列
function get_obj(self)
	if self.effect_txt_tb_ and self.effect_txt_tb_[1] then
		local obj = self.effect_txt_tb_[1]
		table.remove(self.effect_txt_tb_, 1)
		return obj
	end
end

--添加对象到队列
function add_obj(self, obj)
	if self.effect_txt_tb_ then
		table.insert(self.effect_txt_tb_, obj)
	end
end

function create_obj(self, obj, parent)
	local go = GameObject.Instantiate(obj)
    go.transform:SetParent(parent, false)
    go.gameObject:SetActive(true)
    go.transform.localPosition = Vector3(0, 0, 0)
    return go
end