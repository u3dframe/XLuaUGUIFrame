-- 英雄列表的英雄卡牌
module("HeroCardList", package.seeall)
setmetatable(HeroCardList, {__index = BaseComponent})

function on_awake(self)
    self.parent_win_ = self.data[1]
end

function on_dispose(self)

end


function init(self)
    self.btn_ = self.transform:GetComponent(Button)
    self.rect_ = self.transform:GetComponent(RectTransform)
    
    self.head_bg_ = self.transform:Find("Background"):GetComponent(Image)
    self.head_tex_ = self.transform:Find("HeroMask/Texture"):GetComponent(Image)
    self.head_icon_ = self.transform:Find("HeroMask/HeadImage"):GetComponent(Image)
    self.occu_icon_ = self.transform:Find("Occu/Image"):GetComponent(Image)
    self.lv_txt_ = self.transform:Find("LvTxt"):GetComponent(Text)
    self.name_txt_ = self.transform:Find("NameTxt"):GetComponent(Text)
    self.bar_txt_ = self.transform:Find("BarGroup/Text"):GetComponent(Text)
    self.bar_img_ = self.transform:Find("BarGroup/Value"):GetComponent(Image)

    self.mark_group_ = self.transform:Find("MarkGroup")
    self.mark_defence_ = self.transform:Find("MarkGroup/Mark1")
    self.mark_out_ = self.transform:Find("MarkGroup/Mark2")
    self.star_group_ = self.transform:Find("StarGroup")

    self.tip_grop_ = self.transform:Find("TipsGroup")
    self.bar_grop_ = self.transform:Find("BarGroup")
end


function set_data_empty(self)
    self.mark_group_.gameObject:SetActive(false)
    self.bar_grop_.gameObject:SetActive(false)
    self.name_txt_.text = ""
    self.lv_txt_.text = ""
    self.star_group_.gameObject:SetActive(false)
    self.tip_grop_.gameObject:SetActive(false)
    self.occu_icon_.gameObject:SetActive(false)
    UIUtil.set_sprite("UI/Common/HerCard/card_2", self.head_bg_)
    UIUtil.set_sprite("UI/Common/VeryCommon/default", self.head_icon_)
end

function set_data(self, hero)
	if not hero then return end
    self.btn_.onClick:RemoveAllListeners()
    self:add_event_handler(self.btn_.onClick, on_click_head_handler, hero)
    self.name_txt_.text = hero:get_color_name()
    UIUtil.set_sprite(hero.head_icon_, self.head_icon_)
    UIUtil.set_sprite("UI/Common/HerCard/card_"..hero.quality_, self.head_bg_)
    UIUtil.set_sprite("UI/Common/HerCard/card_tex"..hero.quality_, self.head_tex_)
    UIUtil.set_sprite("UI/Common/HerCard/occu_0"..hero.type_, self.occu_icon_)
    if hero.is_active_  then
        self.head_icon_.color = Color(1, 1, 1, 1)
        self.bar_grop_.gameObject:SetActive(false)
        self.lv_txt_.text = hero.lv_.."级"
        self.tip_grop_.gameObject:SetActive(false)
        self.star_group_.gameObject:SetActive(true)
        HeroManager:show_hero_star_comp(self.star_group_, hero:get_star_lv())
        if hero.state_ == Hero.ST_OUT then
            self.mark_group_.gameObject:SetActive(true)
            self.mark_defence_.gameObject:SetActive(false)
            self.mark_out_.gameObject:SetActive(true)
        else
            self.mark_group_.gameObject:SetActive(false)
        end
        
    elseif hero:enable_awake() then
        self.head_icon_.color = Color(1, 1, 1, 1)
        self.bar_grop_.gameObject:SetActive(false)
        self.star_group_.gameObject:SetActive(false)
        self.tip_grop_.gameObject:SetActive(false)
        self.mark_group_.gameObject:SetActive(false)
        self.lv_txt_.text = "可激活"
    else
        self.head_icon_.color = Color(0.3, 0.3, 0.3, 1)
        self.tip_grop_.gameObject:SetActive(false)
        self.mark_group_.gameObject:SetActive(false)
        self.star_group_.gameObject:SetActive(false)
        self.bar_grop_.gameObject:SetActive(true)
        self.lv_txt_.text = ""
        local cur_num = hero:get_chip_num()
        local max_num = hero:get_prop().activate[3]
        self.bar_txt_.text = string.format("%d/%d", cur_num, max_num)
        self.bar_img_.fillAmount = cur_num / max_num
    end
end

function on_click_head_handler(self, event, hero)
    if not hero.is_active_ then
        if hero:enable_awake() then
            local data = {}
            data.id = hero.id_
            Net.send("hero_active", data, function(result)
                if result.e == 0 then
                    if self.parent_win_.tab_left_[self.parent_win_.tab_index_].isOn then
                       self.parent_win_.tab_left_[self.parent_win_.tab_index_].isOn = false 
                    end
                    self.parent_win_.tab_left_[self.parent_win_.tab_index_].isOn = true
                    MsgCenter.send_message(Msg.SHOW_HINT, "英雄激活成功")
                end
            end)
            return
        end
        log("you are missing this item by id=%d", hero:get_chip_id())
        MsgCenter.send_message(Msg.SHOW_HINT, "该英雄未激活")
        return
    end    
    UIManager.open_window("HeroGrowWindow", nil, hero)
end
