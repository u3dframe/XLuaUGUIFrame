module("HeroSkill", package.seeall)
setmetatable(HeroSkill, {__index = BaseComponent})

local HeroConfig = _G.Database.HeroConfig


function on_awake(self)
    
end

function init(self)
    self.skillItems = {}
    local skillPanel = self.transform:Find("BottomGroup/SkillPanel")
    for t in Slua.iter(skillPanel) do
        table.insert(self.skillItems, t)
    end

    self.bagBtn = self.transform:Find("BottomGroup/Button"):GetComponent(Button)
    self.desc = self.transform:Find("BottomGroup/Bg_desc")
    self.desc.gameObject:SetActive(false)
    self.pointers = {}
    self.pressIndex = nil

    self:add_event_handler(self.bagBtn.onClick, function()
        UIManager.open_window("SkillBag", nil, SkillBag.OperationTypes.Show)
    end)
end

function set_data(self, hero)
    local skillIDs = {
        [1] = hero.innate_skillID_
    }
    for _, skill in pairs(hero.skills_) do
        skillIDs[skill.pos + 1] = skill.skillid
    end
    for _, pointer in ipairs(self.pointers) do
        pointer:dispose()
    end
    self.pointers = {}
    for i, item in ipairs(self.skillItems) do
        local skillCfg = HeroConfig.SkillData[skillIDs[i]]
        local iconArea = item:Find("BgBox")
        local lock = iconArea:Find("NotLock")
        local icon = iconArea:Find("Icon")
        local flag = iconArea:Find("Image")
        local name = item:Find("Nametxt")
        local lv = iconArea:Find("LvBg")
        local btn = item:Find("Button")
        local desc = item:Find("skillsec")
        local ndesc = item:Find("skillnotsec")
        desc.gameObject:SetActive(i == 1)
        if skillCfg then
            lock.gameObject:SetActive(false)
            icon.gameObject:SetActive(true)
            UIUtil.set_sprite(skillCfg.icon, icon:GetComponent(Image))
            flag.gameObject:SetActive(true)
            UIUtil.set_sprite(string.format("UI/Common/HerCard/occu_%02d", skillCfg.type), flag:GetComponent(Image))
            name:GetComponent(Text).text = skillCfg.name
            local serverSkill = hero.skills_[i - 1]
            if i == 1 then
                lv.gameObject:SetActive(false)
            else
                lv.gameObject:SetActive(true)
                local txt = lv:GetComponentInChildren(Text)
                txt.text = serverSkill.level
            end
            ndesc.gameObject:SetActive(false)
            btn.gameObject:SetActive(i ~= 1)
            local btnTxt = btn:Find("Text"):GetComponent(Text)
            btnTxt.text = lang("SKILL_LEVEL")
            btn = btn:GetComponent(Button)
            btn.onClick:RemoveAllListeners()
            self:add_event_handler(btn.onClick, function()
                UIManager.open_window("SkillLevel", nil, i - 1, hero)
            end)
            local pointer = PluginPointer:new(self, iconArea.gameObject, function(self, event, index)
                if event == PluginPointer.POINTER_ALWAY_DOWN then
                    if not self.pressIndex then
                        self.pressIndex = index
                        local name
                        local desc
                        if index == 1 then
                            name = skillCfg.name
                            desc = skillCfg.desc
                        else
                            name = lang("SKILL_NAME", skillCfg.name, serverSkill.level)
                            desc = SkillManager:get_skill_buff_desc(skillIDs[i], serverSkill.level, hero.id_)
                        end
                        self.desc:Find("skillnametxt"):GetComponent(Text).text = name
                        self.desc:Find("skilldesctxt"):GetComponent(Text).text = desc
                        self.desc.gameObject:SetActive(true)
                        self.desc:SetParent(self.transform, false)
                        self.desc.position = iconArea.position
                    end
                elseif event == PluginPointer.POINTER_UP then
                    if self.pressIndex == index then
                        self.pressIndex = nil
                        self.desc.gameObject:SetActive(false)
                    end
                end
            end, i)
            table.insert(self.pointers, pointer)
        else
            local unlockLv = HeroConfig.ListData[hero.id_].skill_slot[i - 1]
            local unlocked = hero.lv_ >= unlockLv
            lock.gameObject:SetActive(not unlocked)
            icon.gameObject:SetActive(false)
            flag.gameObject:SetActive(false)
            name:GetComponent(Text).text = lang("SKILL_VACANCY")
            if lv then
                lv.gameObject:SetActive(false)
            end
            ndesc.gameObject:SetActive(not unlocked)
            if not unlocked then
                ndesc:GetComponent(Text).text = lang("SKILL_UNLOCK", unlockLv)
            end
            btn.gameObject:SetActive(unlocked)
            if unlocked then
                local btnTxt = btn:Find("Text"):GetComponent(Text)
                btnTxt.text = lang("SKILL_STUDY")
                btn = btn:GetComponent(Button)
                btn.onClick:RemoveAllListeners()
                self:add_event_handler(btn.onClick, function()
                    UIManager.open_window("SkillBag", nil, SkillBag.OperationTypes.Learn, hero, i - 1)
                end)
            end
        end
    end
end
