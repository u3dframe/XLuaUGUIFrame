-- 非英雄列表的英雄卡牌（出征、战斗、资源田、势力据点）
module("HeroCard", package.seeall)
setmetatable(HeroCard, {__index = BaseComponent})

function on_awake(self)

end

function on_dispose(self)

end


function init(self)
    self.btn_ = self.transform:GetComponent(Button)
    self.rect_ = self.transform:GetComponent(RectTransform)
    
    self.head_bg_ = self.transform:Find("Background"):GetComponent(Image)    
    self.head_tex_ = self.transform:Find("HeroMask/Texture"):GetComponent(Image)
    self.head_icon_ = self.transform:Find("HeroMask/HeadImage"):GetComponent(Image)
    
    self.occu_icon_ = self.transform:Find("Occu/Image"):GetComponent(Image)
    self.lv_txt_ = self.transform:Find("LvGroup/LvTxt"):GetComponent(Text)
    self.lv_go_ = self.transform:Find("LvGroup")
    self.bottom_go_ = self.transform:Find("BottomBg")
    self.name_txt_ = self.transform:Find("NameTxt"):GetComponent(Text)
    self.mark1_ = self.transform:Find("MarkGroup/Mark1"):GetComponent(Image)
    self.mark2_ = self.transform:Find("MarkGroup/Mark2"):GetComponent(Image)
    self.star_group_ = self.transform:Find("StarGroup")
end


function set_data_empty(self)
    self:show_index()
    self.lv_txt_.text = ""
    self.name_txt_.text = ""
    UIUtil.set_sprite("UI/Common/HerCard/card_2", self.head_bg_)
    UIUtil.set_sprite("UI/Common/HerCard/card_tex2", self.head_tex_)
    HeroManager:show_hero_star_comp(self.star_group_, 0)
end

function show_index(self)
    if self.index_ then
        if self.index_ == 1 then
            self.mark1_.color = Color(1, 1, 1, 1)
            self.mark2_.color = Color(1, 1, 1, 0)
        else
            self.mark1_.color = Color(1, 1, 1, 0)
            self.mark2_.color = Color(1, 1, 1, 1)
        end
    else
        self.mark1_.color = Color(1, 1, 1, 0)
        self.mark2_.color = Color(1, 1, 1, 0)
    end
end

function set_data_troops_ex(self, hero, index)
    self:set_data_troops(hero, index)
    if  hero then
        self.head_bg_.gameObject:SetActive(true)
        self.head_tex_.gameObject:SetActive(true)
        self.occu_icon_.gameObject:SetActive(true)
        self.head_icon_.gameObject:SetActive(true)
        self.star_group_.gameObject:SetActive(true)
        self.lv_go_.gameObject:SetActive(true)
        self.bottom_go_.gameObject:SetActive(true)
    else
        self.head_icon_.gameObject:SetActive(false)
        self.head_bg_.gameObject:SetActive(false)
        self.head_tex_.gameObject:SetActive(false)
        self.occu_icon_.gameObject:SetActive(false)
        self.star_group_.gameObject:SetActive(false)
        self.lv_go_.gameObject:SetActive(false)
        self.bottom_go_.gameObject:SetActive(false)
        if index == 1 then
            self.mark1_.color = Color(1, 1, 1, 1)
            self.mark2_.color = Color(1, 1, 1, 0)
        else
            self.mark1_.color = Color(1, 1, 1, 0)
            self.mark2_.color = Color(1, 1, 1, 1)
        end
    end
end

function set_data_troops(self, hero, index)
    self.index_ = index
	if not hero then 
        self:set_data_empty(index)
        return 
    end
    self.lv_txt_.text = hero.lv_.."级"
    self.name_txt_.text = hero:get_color_name()
    UIUtil.set_sprite(hero.head_icon_, self.head_icon_)
    UIUtil.set_sprite("UI/Common/HerCard/card_"..hero.quality_, self.head_bg_)
    UIUtil.set_sprite("UI/Common/HerCard/card_tex"..hero.quality_, self.head_tex_)
    UIUtil.set_sprite("UI/Common/HerCard/occu_0"..hero.type_, self.occu_icon_)
    HeroManager:show_hero_star_comp(self.star_group_, hero:get_star_lv())
    self:show_index()
end

function set_data_troops_hero(self, hero, index)
    self:set_data_troops(hero, index)
    self.name_txt_.text = ""
end

function set_data_troops_list(self, hero, index)
    self.index_ = index
	if not hero then 
        self:set_data_empty(index)
        return 
    end
    self.lv_txt_.text = hero.lv_.."级"
    self.name_txt_.text = hero:get_color_name()
    UIUtil.set_sprite(hero.head_icon_, self.head_icon_)
    UIUtil.set_sprite("UI/Common/HerCard/card_"..hero.quality_, self.head_bg_)
    UIUtil.set_sprite("UI/Common/HerCard/card_tex"..hero.quality_, self.head_tex_)
    UIUtil.set_sprite("UI/Common/HerCard/occu_0"..hero.type_, self.occu_icon_)
    HeroManager:show_hero_star_comp(self.star_group_, hero:get_star_lv())
    self:show_index()
end

function SetHeroStar(self, hero)
    if not hero then 
        self:set_data_empty()
        return 
    end
    self.lv_txt_.text = hero.lv_.."级"
    self.name_txt_.text = hero:get_color_name()
    UIUtil.set_sprite(hero.head_icon_, self.head_icon_)
    UIUtil.set_sprite("UI/Common/HerCard/card_"..hero.quality_, self.head_bg_)
    UIUtil.set_sprite("UI/Common/HerCard/card_tex"..hero.quality_, self.head_tex_)
    UIUtil.set_sprite("UI/Common/HerCard/occu_0"..hero.type_, self.occu_icon_)
    HeroManager:show_hero_star_comp(self.star_group_, hero:get_star_lv())
end