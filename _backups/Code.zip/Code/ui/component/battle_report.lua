module("BattleReport",package.seeall)
setmetatable( BattleReport, {__index = BaseComponent} )


function init(self)
    self.report_rect_ = self.transform:GetComponent(RectTransform)
    self.battle_item_ = self.transform:Find("BattleItem").gameObject
    self.victory_ = self.transform:Find("TitlePanel/Victory").gameObject
    self.failded_ = self.transform:Find("TitlePanel/Failded").gameObject
    self.desc_txt_ = self.transform:Find("DescTxt"):GetComponent(Text)
    
    self.battle_btn_ = self.transform:GetComponent(Button)
    self.battle_btn_.onClick:RemoveAllListeners()
    self:add_event_handler(self.battle_btn_.onClick, on_click_report_handler)
    -- item
    self.item_panel_ = self.transform:Find("BattleItem/ItemPanel")
    
    -- battle info
    self.info_panel_ = self.transform:Find("BattleInfo")
end

function on_start(self)
    
end

function on_dispose(self)
    
end

function set_data(self, data)
    self.report_data_ = data
    self.desc_txt_.text = data.text or lang("EXPEDITION_43", data.target_lv, data.target_name)
    self.result_ = data.result  
    if self.result_ == 1 then
        self.battle_item_:SetActive(false)
        self.victory_:SetActive(true)
        self.failded_:SetActive(false)
        self.item_panel_.gameObject:SetActive(false)
        local out = data.rewards
        if false then
            for i=1,4 do
                local item = self.item_panel_:Find("item"..i)
                if out[i] then
                    local reward = out[i]
                    item.gameObject:SetActive(true)
                    local icon = item:Find("Icon"):GetComponent(Image)
                    local num = item:Find("CornerPanel/Text"):GetComponent(Text)
                    local name = item:Find("Name"):GetComponent(Text)
                    UIUtil.set_sprite("UI/Common/item/"..reward[1], icon)
                    num.text = reward[3]
                    name.text = lang("ITEM"..reward[1])
                else
                    item.gameObject:SetActive(false)
                end
            end
        end
    else
        self.battle_item_:SetActive(false)
        self.victory_:SetActive(false)
        self.failded_:SetActive(true)
        self.item_panel_.gameObject:SetActive(false)
    end
    if true then return end
    local all_num = 0
    local soldiers_lose = 0
    local soldiers_lose_power = 0
    local soldiers_live = 0
    -- array[1]是士兵id  array[2]是士兵数量
    for i,v in ipairs(data.soldiers_lose) do
        local tmp_data = v.array or {}
        if tmp_data[1] then
            local soldier = SoldierManager:get_soldier_info_by_id(tmp_data[1])
            soldiers_lose = soldiers_lose + tmp_data[2]
            soldiers_lose_power = soldiers_lose_power + tmp_data[2] * soldier:get_power()/100
        end
    end
    soldiers_lose_power = math.floor(soldiers_lose_power)
    for i,v in ipairs(data.soldiers_keep) do
        local tmp_data = v.array or {}
        if tmp_data[1] then
            soldiers_live = soldiers_live + (tmp_data[2] or 0)
        end
    end
    all_num = soldiers_lose + soldiers_live
    local str = {lang("UI_BATTLEREPORT_DESC1"), lang("UI_BATTLEREPORT_DESC2"),
        lang("UI_BATTLEREPORT_DESC3"), lang("UI_BATTLEREPORT_DESC4")}
    local info_data = {soldiers_lose_power, all_num, soldiers_lose, soldiers_live}
    for i=1,4 do
        local item = self.info_panel_:Find("InfoGroup"..i)
        local desc_txt = item:Find("Desc"):GetComponent(Text)
        local value_txt = item:Find("Value"):GetComponent(Text)
        desc_txt.text = str[i]
        value_txt.text = info_data[i]
    end
end

function on_click_report_handler(self)
    local data = self.report_data_
    local report_type = config.MAIL_MODULE_TYPES.REPORT
    local _type = config.MAIL_TYPES[report_type].WILD_BATTLE
    if data.module_type ~= report_type or data.type ~= _type then
        MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_MAIN_UNOPEN"))
        return
    end
    self.battle_btn_.enabled = false
    UIManager.open_window("MailListWindow", nil, report_type, _type)
end