module("TopBanner", package.seeall)
setmetatable(TopBanner, {__index = BaseComponent})


local back_functions = {}

CollectAnimationInterval = 0.2
TopAnimationInterval = 0.2
MaxRewardsAnimations = 5


local TopbannerConfig = _G.Database.TopbannerConfig


function init(self)
    self.ui_camera_ = UIManager.get_camera()
    self.title_banner_ = self.transform:Find("TitleBanner")
    self.back_ = self.title_banner_:Find("Back")
    local back_btn = self.back_:GetComponent(Button)
    back_btn.onClick:RemoveAllListeners()
    self:add_event_handler(back_btn.onClick, function() self:on_click_back_btn() end)
    self.close_ = self.title_banner_:Find("Close")
    local close_btn = self.close_:GetComponent(Button)
    close_btn.onClick:RemoveAllListeners()
    self:add_event_handler(close_btn.onClick, function() self:on_click_close_btn() end)
    self.title_ = self.title_banner_:Find("Title")
    self.main_title_text_ = self.title_:Find("MainTitle"):GetComponent(Text)
    self.sub_title_text_ = self.title_banner_:Find("SubTitle"):GetComponent(Text)
    self.info_btn_ = self.title_:Find("InfoBtn"):GetComponent(Button)
    self.info_callbacks = {}
    self:add_event_handler(self.info_btn_.onClick, function()
        if not self.window_ then return end
        local name = self:_get_window_name()
        if self.info_callbacks[name] then
            self.info_callbacks[name]()
        end
    end)
    
    local res_bar = self.transform:Find("ResPanel/ResBar")

    self.res_item_prefab_ = self.transform:Find("ResPanel/ResItem").gameObject
    self.res_item_prefab_:SetActive(false)
    self.res_item_go_ = {}

    for _, v in pairs(config.RES_ITEMS) do 
        if not self.res_item_go_[v] then
            self.res_item_go_[v] = GameObject.Instantiate(self.res_item_prefab_)
            self.res_item_go_[v].transform:SetParent(res_bar, false)
            self.res_item_go_[v].name = "item"..v
        end
        self.res_item_go_[v]:SetActive(true)
        local icon = self.res_item_go_[v].transform:Find("Icon"):GetComponent(Image)
        local num = self.res_item_go_[v].transform:Find("NumTxt"):GetComponent(Text)
        local btn = self.res_item_go_[v].transform:GetComponent(Button)
        btn.onClick:RemoveAllListeners()
        self:add_event_handler(btn.onClick, on_click_item_handler, v)
        UIUtil.set_sprite("UI/Common/ItemSmall/"..v, icon)
        num.text = UIUtil.res_num_to_str(ItemManager:get_resource(v))
    end

    self.res_coin_prefab_ = self.transform:Find("ResPanel/CoinItem").gameObject
    self.res_coin_prefab_:SetActive(false)
    self.res_coin_go_ = {}
    
    for _, v in pairs(config.RES_COINS) do
        if not self.res_coin_go_[v] then
            self.res_coin_go_[v] = GameObject.Instantiate(self.res_coin_prefab_)
            self.res_coin_go_[v].transform:SetParent(res_bar.transform, false)
            self.res_coin_go_[v].name = "coin"..v
        end
        self.res_coin_go_[v]:SetActive(true)
        local icon = self.res_coin_go_[v].transform:Find("Icon"):GetComponent(Image)
        local num = self.res_coin_go_[v].transform:Find("NumTxt"):GetComponent(Text)
        local btn = self.res_coin_go_[v].transform:GetComponent(Button)
        btn.onClick:RemoveAllListeners()
        self:add_event_handler(btn.onClick, on_click_coin_handler, v)
        UIUtil.set_sprite("UI/Common/ItemSmall/"..v, icon)
        num.text = UIUtil.res_num_to_str(ItemManager:get_coin(v))
    end

    self.collect_obj_ = self.transform:Find("CollectObj").gameObject
    self.collect_obj_:SetActive(false)
    self.last_anim_arrive_ = {}

    self.change_obj_ = self.transform:Find("ChangeText").gameObject
    self.change_obj_:SetActive(false)

    self.rewards_panel_ = self.transform:Find("RewardsPanel")
    self.rewards_panel_pos_ = self.rewards_panel_.localPosition
    self.reward_obj_ = self.rewards_panel_:Find("Item").gameObject
    self.reward_obj_:SetActive(false)
    self.rewards_panel_.gameObject:SetActive(false)

    self.to_play_rewards = {}   --等待播放动画的奖励
    self.palying_reward_objs_ = {}   --正在播放动画的物体
    self.rewards_tween_ = nil

    self.gameObject:SetActive(false)
end

function _get_window_name(self, window)
    window = window or self.window_
    if not window then return end
    return window.window_name_ or "UIMain"
end

function set_window(self, now_window)
    local window_name = self:_get_window_name(now_window)
    local cfg = TopbannerConfig.TopbannerData[window_name]
    if not cfg then return end
    self.window_ = now_window
    if window_name == "UIMain" then
        self.transform:SetParent(self.window_.transform:Find("SharePanel"), false)
    else
        self.transform:SetParent(self.window_.transform, false)
    end

    --根据窗口配置更新属性
    if cfg.show_all ~= 0 then
        self.gameObject:SetActive(true)
        if cfg.show_back ~= 0 or cfg.show_close ~= 0 or cfg.show_title ~= 0 then
            self.title_banner_.gameObject:SetActive(true)
            self.back_.gameObject:SetActive(cfg.show_back ~= 0)
            self.close_.gameObject:SetActive(cfg.show_close ~= 0)
            self:refresh_title(cfg)
        else
            self.title_banner_.gameObject:SetActive(false)
        end
    else
        self.gameObject:SetActive(false)
    end

    --更新info按钮
    self.info_btn_.gameObject:SetActive(self.info_callbacks[window_name] ~= nil)
end

function set_info_callback(self, window, callback)
    local name = self:_get_window_name(window)
    self.info_callbacks[name] = callback
    if self:_get_window_name() == name then
        self.info_btn_.gameObject:SetActive(callback ~= nil)
    end
end

function remove_info_callback(self, window)
    self:set_info_callback(window)
end

--将top banner维持在最上层
function maintain_top(self)
    self.transform:SetAsLastSibling()
end

function refresh_title(self, cfg)
    if not cfg then
        local window_name = self.window_.window_name_ or "UIMain"
        cfg = TopbannerConfig.TopbannerData[window_name]
    end
    if not cfg then return end
    if cfg.show_title ~= 0 then
        self.title_.gameObject:SetActive(true)
        --优先使用窗口对象提供的标题接口，其次使用配置
        local main_title
        if type(self.window_.main_title) == "string" then
            main_title = self.window_.main_title
        elseif type(self.window_.main_title) == "function" then
            main_title = self.window_:main_title()
        else
            main_title = cfg.main_title_text and tostring(cfg.main_title_text) or ""
        end
        self.main_title_text_.text = main_title
        -- local sub_title
        -- if type(self.window_.sub_title) == "string" then
        --     sub_title = self.window_.sub_title
        -- elseif type(self.window_.sub_title) == "function" then
        --     sub_title = self.window_:sub_title()
        -- else
        --     sub_title = cfg.sub_title_text and tostring(cfg.sub_title_text) or ""
        -- end
        -- self.sub_title_text_.text = sub_title
        self.sub_title_text_.text = ""
    else
        self.title_.gameObject:SetActive(false)
    end
end

function on_res_change(self, data)
    for _, v in pairs(config.RES_ITEMS) do
        local num = self.res_item_go_[v].transform:Find("NumTxt"):GetComponent(Text)
        num.text = UIUtil.res_num_to_str(ItemManager:get_resource(v))
    end
    for _, v in pairs(config.RES_COINS) do
        local num = self.res_coin_go_[v].transform:Find("NumTxt"):GetComponent(Text)
        num.text = UIUtil.res_num_to_str(ItemManager:get_coin(v))
    end
    local changes = {}
    for _, v in pairs(data) do
        local change = v.change or 0
        if type(change) == "table" then
            change = (change[1] or 0) + (change[2] or 0)
        end
        changes[v.id] = changes[v.id] or 0
        changes[v.id] = changes[v.id] + change
    end
    if self.dontPlay then
        return
    end
    for t, c in pairs(changes) do
        self:play_res_change_ani(t, c)
    end
end

--不播放动画
function NoAnimation(self)
    self.dontPlay = true
end

--恢复动画
function RecoverAnimation(self)
    self.dontPlay = nil
end

function play_res_change_ani(self, resType, num)
    local target
    if ItemManager.is_resource_type(resType) then
        target = self.res_item_go_[resType]
    elseif ItemManager.is_coin_type(resType) then
        target = self.res_coin_go_[resType]
    end
    if not target then return end
    target = target.transform.position
    local obj = GameObject.Instantiate(self.change_obj_)
    obj.transform:SetParent(self.transform, false)
    obj:SetActive(true)
    local txt = obj:GetComponent(Text)
    --txt.text = UIUtil.res_num_to_str(num)
    txt.text = tostring(num)
    if num > 0 then
        txt.color = UIUtil.get_color(config.FONT_COLOR.GREEN)
        obj.transform.position = target + Vector3(0, -5, 0)
        GameTween.DOMove(obj.transform, target, 0.8, false):OnComplete(
            function() GameObject.Destroy(obj) end
        )
    elseif num < 0 then
        txt.color = UIUtil.get_color(config.FONT_COLOR.ORANGE)
        obj.transform.position = target
        GameTween.DOMove(obj.transform, target + Vector3(0, -5, 0), 0.8, false):OnComplete(
            function() GameObject.Destroy(obj) end
        )
    end
end

function on_click_item_handler(self, event, itemID)
    UIManager.open_window("TestWindow1", nil, itemID)
end

function on_click_coin_handler(self, event, coinID)
    UIManager.open_window("TestWindow1", nil, coinID)
end


function on_click_back_btn(self)
    AudioManager.Play("SOUND_BUTTON_BACK")
    if back_functions[self.window_.window_name_] then
        back_functions[self.window_.window_name_]()
    else
        UIManager.back()
    end
end

function set_back_function(self, func)
    back_functions[self.window_.window_name_] = func
end

function remove_back_function(self)
    back_functions[self.window_.window_name_] = nil
end

function on_click_close_btn(self)
    self.window_:close_all()
end

function on_res_animation_end(self, res_type)
    if self.last_anim_arrive_[res_type] and 
        Time.time - self.last_anim_arrive_[res_type] < TopAnimationInterval then
        return
    end
    self.last_anim_arrive_[res_type] = Time.time
    --资源图标缩放
    local icon = self.res_item_go_[res_type].transform:Find("Icon")
    local seq = XSequence()
    local duration = TopAnimationInterval / 2
    seq:Append(GameTween.DOScale(icon, 1.2, duration))
    seq:Append(GameTween.DOScale(icon, 1, duration))
end

--播放资源采集动画
function play_res_collection(self, build_id, res_type, res_num)
    if _G.SceneManager.City_Scene then
        local space = SceneManager.City_Scene:get_space_by_build_id(build_id)
    end
    local start_pos = Camera.main:WorldToScreenPoint(space.transform.position)
    local delta = Vector3(Screen.width * 0.04, 0, 0)
    start_pos = {start_pos + delta, start_pos - delta}
    local target = self.res_item_go_[res_type]:GetComponent(RectTransform).position
    local objs = {}
    local icon = "UI/Common/ItemSmall/"..res_type
    local rect = self.transform:GetComponent(RectTransform)
    local pos = 1
    local waves = math.min(10, math.ceil(res_num / 2000))
    for i = 1, waves do
        local obj = GameObject.Instantiate(self.collect_obj_)
        obj:SetActive(false)
        obj.transform:SetParent(self.transform, false)
        local start = start_pos[pos]
        pos = pos % 2 + 1
        local b, p = RectTransformUtility.ScreenPointToLocalPointInRectangle(rect, start, self.ui_camera_)
        obj:GetComponent(RectTransform).anchoredPosition = p
        local img = obj:GetComponent(Image)
        UIUtil.set_sprite(icon, img)
        table.insert(objs, obj)
    end
    for i, obj in ipairs(objs) do
        local rotation = math.random() > 0.5 and 360 or -360
        local rotate_tween = GameTween.DORotate(obj.transform, Vector3(0, 0, rotation), 0.6, 2)
        rotate_tween:SetLoops(-1, 0)
        rotate_tween:SetEase(XEase.Linear)
        local move_tween = GameTween.DOMove(obj.transform, target, 1, false)
        move_tween:SetEase(XEase.InSine)
        move_tween:OnStart(function()
            obj:SetActive(true)
        end)
        move_tween:OnComplete(function()
            self:on_res_animation_end(res_type)
            rotate_tween:Kill(false)
            GameObject.Destroy(obj)
        end)
        local delay = (i - 1) * CollectAnimationInterval
        delta = CollectAnimationInterval * 0.8
        delta = delta * 2 * math.random() - delta
        delay = delay + delta
        rotate_tween:SetDelay(delay)
        move_tween:SetDelay(delay)
    end
end

function on_city_collect(self, build_id, count, res_type)
    self:play_res_collection(build_id, res_type, count)
end

function play_rewards_animation(self, rewards)
    if not rewards or #rewards == 0 then return end
    if self.rewards_tween_ then
        table.insert(self.to_play_rewards, rewards)
        return
    end
    --物品数量统计
    local rs = {}
    for _, r in pairs(rewards) do
        local ty, id, num = unpack(r)
        rs[ty] = rs[ty] or {}
        if not rs[ty][id] then
            rs[ty][id] = 0
        end
        rs[ty][id] = rs[ty][id] + num
    end
    local list = {}
    for ty, r in pairs(rs) do
        for id, num in pairs(r) do
            local tmp = ItemManager:get_ui_info({ty, id, num})
            if tmp and tmp.quality then
                local cfg = {}
                for k, v in pairs(tmp) do
                    cfg[k] = v
                end
                cfg.id = ItemManager.is_item_type(ty) and id or ty
                cfg.type = ty
                cfg.__num = num
                table.insert(list, cfg)
            end
        end
    end
    table.sort(list, function(a, b)
        if a.quality ~= b.quality then return a.quality > b.quality end
        return a.id < b.id
    end)
    
    local m = 0
    for _, cfg in pairs(list) do
        local obj = GameObject.Instantiate(self.reward_obj_)
        obj.transform:SetParent(self.rewards_panel_, false)
        obj:SetActive(true)
        table.insert(self.palying_reward_objs_, obj)
        local card
        if ItemManager.is_item_type(cfg.type) then
            card = obj.transform:Find("ItemCard")
            UIUtil.set_sprite("UI/Common/Quality/item_"..cfg.quality, card:GetComponent(Image))
        else
            card = obj.transform:Find("ResCard")
        end
        card.gameObject:SetActive(true)
        local icon = card:Find("Icon"):GetComponent(Image)
        UIUtil.set_sprite(cfg.icon, icon)
        local num_txt = obj.transform:Find("Num"):GetComponent(Text)
        num_txt.text = "+"..UIUtil.res_num_to_str(cfg.__num)
        m = m + 1
        if m >= MaxRewardsAnimations then
            break
        end
    end

    self.rewards_panel_.gameObject:SetActive(true)
    self.rewards_panel_.localPosition = self.rewards_panel_pos_
    self.rewards_tween_ = GameTween.DOLocalMoveY(self.rewards_panel_,
                                                self.rewards_panel_pos_.y + Screen.height * 0.1,
                                                1.5, false)
    self.rewards_tween_:OnComplete(function()
        self.rewards_tween_ = nil
        self.rewards_panel_.gameObject:SetActive(false)
        for _, obj in pairs(self.palying_reward_objs_) do
            GameObject.Destroy(obj)
        end
        self.palying_reward_objs_ = {}
        if #self.to_play_rewards == 0 then return end
        local r = self.to_play_rewards[1]
        table.remove(self.to_play_rewards, 1)
        return self:play_rewards_animation(r)
    end)
end
