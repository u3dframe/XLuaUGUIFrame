module("WorldMenu",package.seeall)
setmetatable( WorldMenu, {__index = BaseComponent} )

Menu_Pos = {
    {{-175,-57}},
    {{-175,-57},{175,-57}},
    {{-175,-57},{175,-57},{0,90}},
    {{-175,-57},{175,-57},{-108,80},{108,80}},
    {{-175,-90},{175,-90},{-130,45},{130,45},{0,90}},
}
function on_awake(self)
    self.axis_txt_ = self.transform:Find("WindowObj/Panel/AxisPanel/AxisTxt"):GetComponent(Text)
    self.name_txt_ = self.transform:Find("WindowObj/Panel/InfoPanel/DescTxt"):GetComponent(Text)
    self.info_icon_ = self.transform:Find("WindowObj/Panel/InfoPanel/Icon"):GetComponent(Image)
    self.desc_txt1_ = self.transform:Find("WindowObj/Panel/DescPanel/Desc1"):GetComponent(Text)
    self.desc_txt2_ = self.transform:Find("WindowObj/Panel/DescPanel/Desc2"):GetComponent(Text)
    self.bar_timer_txt_ = self.transform:Find("WindowObj/Panel/BarPanel/BarDesc"):GetComponent(Text)
    self.bar_img_ = self.transform:Find("WindowObj/Panel/BarPanel/BarGroup/Mask"):GetComponent(Image)
    self.bar_gray_ = self.transform:Find("WindowObj/Panel/BarPanel/BarGroup/Mask/Image1").gameObject
    
    self.menu_bg_ = self.transform:Find("WindowObj/Background").gameObject
    self.axis_panel_ = self.transform:Find("WindowObj/Panel/AxisPanel").gameObject
    self.info_panel_ = self.transform:Find("WindowObj/Panel/InfoPanel").gameObject
    self.bar_panel_ = self.transform:Find("WindowObj/Panel/BarPanel").gameObject
    self.desc_panel_ = self.transform:Find("WindowObj/Panel/DescPanel").gameObject
    self.axis_txt_.text = ""
    self.info_btn_ = self.transform:Find("WindowObj/Btns/Button1"):GetComponent(Button)
    self:add_event_handler(self.info_btn_.onClick, on_click_info_handle)
    self.back_btn_ = self.transform:Find("WindowObj/Btns/Button2"):GetComponent(Button)
    self:add_event_handler(self.back_btn_.onClick, on_click_back_handle)
    
    self.goto_march_btn_ = self.transform:Find("WindowObj/Btns/Button3"):GetComponent(Button)
    self:add_event_handler(self.goto_march_btn_.onClick, on_click_goto_march_handle)    
    self.goto_start_btn_ = self.transform:Find("WindowObj/Btns/Button4"):GetComponent(Button)
    self:add_event_handler(self.goto_start_btn_.onClick, on_click_goto_start_handle)    
    self.goto_end_btn_ = self.transform:Find("WindowObj/Btns/Button5"):GetComponent(Button)
    self:add_event_handler(self.goto_end_btn_.onClick, on_click_goto_end_handle)    
    self.quick_btn_ = self.transform:Find("WindowObj/Btns/Button6"):GetComponent(Button)
    self:add_event_handler(self.quick_btn_.onClick, on_click_quick_handle)
    self.call_btn_ = self.transform:Find("WindowObj/Btns/Button7"):GetComponent(Button)
    self:add_event_handler(self.call_btn_.onClick, on_click_call_handle)
    self.journey_btn_ = self.transform:Find("WindowObj/Btns/Button8"):GetComponent(Button)
    self:add_event_handler(self.journey_btn_.onClick, on_click_journey_info_handle)

    
    self.fort_info_btn_ = self.transform:Find("WindowObj/Btns/Button9"):GetComponent(Button)
    self:add_event_handler(self.fort_info_btn_.onClick, on_click_fort_info)
    self.fort_res_btn_ = self.transform:Find("WindowObj/Btns/Button10"):GetComponent(Button)
    self:add_event_handler(self.fort_res_btn_.onClick, on_click_fort_res)
    self.fort_attack_btn_ = self.transform:Find("WindowObj/Btns/Button11"):GetComponent(Button)
    self:add_event_handler(self.fort_attack_btn_.onClick, on_click_fort_attack)
    self.fort_cancel_btn_ = self.transform:Find("WindowObj/Btns/Button12"):GetComponent(Button)
    self:add_event_handler(self.fort_cancel_btn_.onClick, on_click_fort_cancel)
    self.respoint_btn_ = self.transform:Find("WindowObj/Btns/Button13"):GetComponent(Button)
    self:add_event_handler(self.respoint_btn_.onClick, on_click_respoint)
    self.detect_btn_ = self.transform:Find("WindowObj/Btns/Button14"):GetComponent(Button)
    self:add_event_handler(self.detect_btn_.onClick, on_click_detect)
    self.btns_ = {self.info_btn_, self.back_btn_, self.goto_march_btn_, 
        self.goto_start_btn_, self.goto_end_btn_, self.quick_btn_,
        self.call_btn_, self.journey_btn_, self.fort_info_btn_,
        self.fort_res_btn_, self.fort_attack_btn_, self.fort_cancel_btn_,
        self.respoint_btn_, self.detect_btn_}
end

function on_start(self)
    
end

function on_dispose(self)
    self:clear_data()
end

function clear_data(self)
    self.obj_ = nil
    self:delete_bar_timer()
end

function set_data_by_journey(self, strID)    
    if not strID then return end
    self.obj_ = WorldManager:get_march_by_str(strID)    
    if not self.obj_ then return end
    self:set_active(self.info_panel_, true)
    self:set_active(self.menu_bg_, true)
    self:set_active(self.axis_panel_, true)
    self:set_active(self.bar_panel_, false)
    self:set_active(self.desc_panel_, false)
    self.info_icon_.gameObject:SetActive(false)   
    self.name_txt_.text = lang("EXPEDITION_44", self.obj_.owner_)
    if self.obj_.army_type_ == ArmyInfo.TO_MONSTER or 
        self.obj_.army_type_ == ArmyInfo.TO_FORTIFIED or 
        self.obj_.army_type_ == ArmyInfo.TO_RESPOINT then
        self:load_btn_list({8,6,7})
        self.axis_txt_.text = lang("EXPEDITION_45", self.obj_.finish_.x, self.obj_.finish_.y)
    elseif self.obj_.army_type_ == ArmyInfo.RET_CITY then
        self:load_btn_list({8,6})
        self.axis_txt_.text = lang("EXPEDITION_46", self.obj_.finish_.x, self.obj_.finish_.y)
    end
    MsgCenter.send_message(Msg.WORLD_MENU_SHOW_UPDATE)
end

function set_data_by_arrow(self, id)
    if not id then return end
    if type(id) == "string" then
        self.obj_ = WorldManager:get_march_by_str(id)
    else
        self.obj_ = WorldManager:get_march_by_idx(id)
    end
    if not self.obj_ then return end
    self:set_active(self.info_panel_, true)
    self:set_active(self.menu_bg_, true)
    self:set_active(self.axis_panel_, true)
    self:set_active(self.bar_panel_, false)
    self:set_active(self.desc_panel_, false)
    self.info_icon_.gameObject:SetActive(false)   
    self.name_txt_.text = lang("EXPEDITION_44", self.obj_.owner_)
    self:load_btn_list({4,5,3})
    if self.obj_.army_type_ == ArmyInfo.TO_MONSTER then
        self.axis_txt_.text = lang("EXPEDITION_45", self.obj_.finish_.x, self.obj_.finish_.y)
    elseif self.obj_.army_type_ == ArmyInfo.RET_CITY then
        self.axis_txt_.text = lang("EXPEDITION_46", self.obj_.finish_.x, self.obj_.finish_.y)
    end
    MsgCenter.send_message(Msg.WORLD_MENU_SHOW_UPDATE)
end

function set_axis_value(self, x, z)
    local obj = WorldManager:get_world_obj(x, z)
    if obj and obj.obj_type_ == config.WORLD_MAIN_JUMP then
        self.world_x_, self.world_z_ = obj:get_main()
        obj = WorldManager:get_world_obj(self.world_x_, self.world_z_)
    else
        self.world_x_ = x
        self.world_z_ = z
    end
    if obj and obj.obj_type_ == config.WORLD_MAIN then
        self:set_active(self.info_panel_, true)
        self.name_txt_.text = obj:get_name()
    else
        self:set_active(self.info_panel_, false)
    end
    self.axis_txt_.text = lang("EXPEDITION_47", self.world_x_, self.world_z_)
end

function on_click_info_handle(self)
    self.gameObject:SetActive(false)
    if self.obj_ and self.obj_.obj_type_ == config.WORLD_RESPOINT then
        if self.obj_:has_troop() then
           -- UIManager.open_window("WorldRespointWindow", nil, self.obj_)
           _G.WorldManager:GetTroops(self.obj_,
                 function(troops)
                _G.UIController:ShowUI("UICollectDetails",{obj=self.obj_,soldierList= troops.soldiers,
                HeroList=troops.heroes})
             end)          
        else
            if _G.FairyGUI then
                _G.UIController:ShowUI("UICollectionInstructions",{obj=self.obj_})
            else
                UIManager.open_window("WorldRespointDescWindow")
            end
        end
    else
        MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_MAIN_UNOPEN"))
    end
end

 
function on_click_back_handle(self)
    if _G.GRichTextField then
        self.gameObject:SetActive(false)
        _G.SceneController:EnterCity()
    else
        self.gameObject:SetActive(false)
        SceneManager.enter_city(function() end)
    end
end

function on_click_goto_march_handle(self)
    self.gameObject:SetActive(false)
    if not self.obj_ then return end
    local march_id = self.obj_.idx_
    MsgCenter.send_message(Msg.WORLD_CLEAR_MARCH_MENU, march_id)
    MsgCenter.send_message(Msg.WORLD_JUMP_JOURNEY, march_id)
end

function on_click_goto_start_handle(self)
    self.gameObject:SetActive(false)
    if not self.obj_ then return end
    local x,z = self.obj_.start_.x, self.obj_.start_.y
    local idx = self.obj_.idx_
    SceneManager.World_Scene:goto_axis(x, z)
    MsgCenter.send_message(Msg.WORLD_CLEAR_MARCH_MENU, idx)
end

function on_click_goto_end_handle(self)
    self.gameObject:SetActive(false)
    if not self.obj_ then return end
    local x,z = self.obj_.finish_.x, self.obj_.finish_.y
    local idx = self.obj_.idx_
    SceneManager.World_Scene:goto_axis(x, z)
    MsgCenter.send_message(Msg.WORLD_CLEAR_MARCH_MENU, idx)
end
 
function on_click_journey_info_handle(self)
    self.gameObject:SetActive(false)
     if not self.obj_ then return end
    MsgCenter.send_message(Msg.WORLD_CLEAR_JOURNEY_MENU)
    local marchInfo= WorldManager:get_march_by_idx(self.obj_.idx_)
   _G.UIController:ShowUI("UISoldierdetail",{marchInfo=marchInfo})
end

local UIMarchSpeedMode = {
    Speed = 0,
    Back  = 1
}

function on_click_call_handle(self)
    self.gameObject:SetActive(false)
    if not self.obj_ then return end
    local idx = self.obj_.idx_
    MsgCenter.send_message(Msg.WORLD_CLEAR_JOURNEY_MENU)
    if _G.FairyGUI then
        _G.UIController:ShowUI("UIMarchSpeedUp", {mode = UIMarchSpeedMode.Back,data = idx})
        return
    end
    UIManager.open_window("ItemJourneyReturnWindow", nil, idx)
end

function on_click_quick_handle(self)
    self.gameObject:SetActive(false)
    if not self.obj_ then return end
    local idx = self.obj_.idx_
    MsgCenter.send_message(Msg.WORLD_CLEAR_JOURNEY_MENU)
    if _G.FairyGUI then
        _G.UIController:ShowUI("UIMarchSpeedUp", {mode = UIMarchSpeedMode.Speed,data = idx})
        return
    end
    UIManager.open_window("ItemJourneySpeedWindow", nil, idx)
end

function on_click_fort_info(self, event)
    self.gameObject:SetActive(false)
    if _G.FairyGUI then
        _G.UIController:ShowUI("UIFortTroops", {fortObj = self.obj_})
    else
        UIManager.open_window("WorldFortInfoWindow", function()
            MsgCenter.send_message(Msg.WORLD_CLEAR_MARCH_MENU)
            MsgCenter.send_message(Msg.WORLD_MENU_SHOW_UPDATE)
        end, self.obj_)
    end
end

function on_click_fort_res(self, event)
    self.gameObject:SetActive(false)
    if _G.FairyGUI then
        _G.UIController:ShowUI("UIFortBenefit", {data = self.obj_}, function()
            MsgCenter.send_message(Msg.WORLD_CLEAR_MARCH_MENU)
            MsgCenter.send_message(Msg.WORLD_MENU_SHOW_UPDATE)
        end)
        return
    end
    UIManager.open_window("WorldFortRewardWindow", function()
        MsgCenter.send_message(Msg.WORLD_CLEAR_MARCH_MENU)
        MsgCenter.send_message(Msg.WORLD_MENU_SHOW_UPDATE)
    end, self.obj_)
end

function on_click_fort_attack(self, event)
    self.gameObject:SetActive(false)
    if not self.obj_ then return end
    if _G.FairyGUI then
        _G.UIController:ShowUI("UIStrike", {obj = self.obj_}, function()
            MsgCenter.send_message(Msg.WORLD_CLEAR_MARCH_MENU)
            MsgCenter.send_message(Msg.WORLD_MENU_SHOW_UPDATE)
        end)
		return
	end
    UIManager.open_window("WorldTroopsWindow", function()
        MsgCenter.send_message(Msg.WORLD_CLEAR_MARCH_MENU)
        MsgCenter.send_message(Msg.WORLD_MENU_SHOW_UPDATE)
    end, self.obj_)
end

function on_click_respoint(self)
    self.gameObject:SetActive(false)
    if not self.obj_ then return end
    if _G.FairyGUI then
        _G.UIController:ShowUI("UIStrike", {obj = self.obj_})
		return
	end
    UIManager.open_window("WorldTroopsWindow", nil, self.obj_)
end

function on_click_detect(self)
    self.gameObject:SetActive(false)
    if not self.obj_ then return end
    _G.UIController:ShowUI("UIReportPop", {obj = self.obj_})
end

function on_click_fort_cancel(self, event)
    self.gameObject:SetActive(false)
    if not self.obj_ then return end
    if not self.obj_:has_troop() then return end
    local msg_ = {}
    msg_.mode=0
    msg_.title = lang("UI_BASIC_HINT")
    msg_.content = lang("UI_FORT_06")
   -- msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
    msg_.callback = function() 
      --  if index == 2 then
            local data = {}
            data.id = self.obj_.idx_
            local net_str = self.obj_:get_cancel_msg()
            Net.send(net_str, data, function(result)
                if result.e == 0 then
                end
            end)
      --  end
    end
    _G.UIController:ShowUI('UICommonPop', msg_)
   -- MsgCenter.send_message(Msg.SHOW_NOTIFY,msg_)
end

function delete_bar_timer(self, show)
    if self.bar_timer_ then
        LuaTimer.Delete(self.bar_timer_)
        self.bar_timer_ = nil
    end
    if show then return end
    self:set_active(self.bar_panel_, false)
end


function set_data(self, obj)
    self.obj_ = nil
    self:set_active(self.menu_bg_, true)
    self:set_active(self.axis_panel_, true)
    self:set_active(self.bar_panel_, true)
    self:set_active(self.info_panel_, true)
    self:set_active(self.desc_panel_, true)
    self.info_icon_.gameObject:SetActive(false)    
    if not obj then
        self:clear_data()
        self:set_active(self.info_panel_, false)
        self:set_active(self.bar_panel_, false)
        self:set_active(self.desc_panel_, false)
        self:load_btn_list({1})
        MsgCenter.send_message(Msg.WORLD_MENU_SHOW_UPDATE)
        return 
    end
    self.obj_ = obj
    -- WORLD_MENU_SHOW_UPDATE 此消息放这里
    MsgCenter.send_message(Msg.WORLD_MENU_SHOW_UPDATE)
    if obj.obj_type_ == config.WORLD_MAIN or obj.obj_type_ == config.WORLD_MAIN_JUMP then
        self:set_active(self.info_panel_, false)
        self:set_active(self.bar_panel_, false)
        self:set_active(self.desc_panel_, false)
        self:load_btn_list({1, 2})
    elseif obj.obj_type_ == config.WORLD_FORT then
        self:set_data_for_fort(obj)
    elseif obj.obj_type_ == config.WORLD_RESPOINT then
        self:set_active(self.bar_panel_, false)
        self:set_active(self.desc_panel_, false)
        local prop = obj:get_prop()
        self.info_icon_.gameObject:SetActive(true)
        UIUtil.set_sprite(prop.icon, self.info_icon_)
        self:delete_bar_timer(true)
        if obj:has_troop() then
            self:load_btn_list({1, 12})
            self.name_txt_.text = prop.reward - obj.cnt_            
            self.bar_timer_ = LuaTimer.Add( 0, 100, function()
                self.name_txt_.text = obj:get_res_num()
            end)
        else
            self.name_txt_.text = obj:get_res_num()
            self:load_btn_list({1, 13})
        end
    elseif obj.obj_type_ == config.WORLD_MONSTER then
        self:set_active(self.desc_panel_, false)
        self:set_active(self.bar_panel_, false)
        self:set_active(self.info_panel_, false)
        self:load_btn_list({}) 
        self:set_active(self.menu_bg_, false)
        self:set_active(self.axis_panel_, false)
        if _G.FairyGUI then
        _G.UIController:ShowUI("UIMonsterDrop", {obj=obj})
    else
        UIManager.open_window("WorldMonsterInfoWindow", nil, obj)
    end
    else
        self:set_active(self.desc_panel_, false)
        self:set_active(self.info_panel_, false)
        self:set_active(self.bar_panel_, false)
        self:load_btn_list({1})
    end
    
end

function set_data_for_fort(self, obj)
    if obj:has_troop() then
        self:set_active(self.desc_panel_, false)
        self:delete_bar_timer(true)
        self.bar_gray_:SetActive(false)
        self.bar_timer_ = LuaTimer.Add( 0, 100, function()
            if self.bar_img_ and obj then
                self.bar_img_.fillAmount = obj:get_one_time_bar()
                self.bar_timer_txt_.text = UIUtil.format_time(obj:get_one_time())
                self.name_txt_.text = lang("UI_FORT_05")..obj.cnt_
            end
            if not obj:has_troop() then
                self:delete_bar_timer()
            end
            if obj.cnt_ <= 0 then
                self:delete_bar_timer()
            end
        end)
        self:load_btn_list({9, 12, 10})
    else
        if obj:get_frozen_state() then
            self:load_btn_list({10, 11})
            self:set_active(self.desc_panel_, false)
            self.bar_gray_:SetActive(true)
            self.bar_img_.fillAmount = obj:get_frozen_state()
            self.bar_timer_txt_.text = lang("UI_TROOPS_FROZEN")
        else
            self:load_btn_list({9, 11, 10})
            self:set_active(self.bar_panel_, false)
            local prop = obj:get_prop()
            self.desc_txt1_.text = lang("UI_FORT_08", prop.level, obj:get_hero_name())
            obj:get_prop_power(function(power)
                self.desc_txt2_.text = lang("UI_TROOPS_POWER", power)
            end)
        end
    end
    self.name_txt_.text = lang("UI_FORT_05")..obj.cnt_
    MsgCenter.send_message(Msg.WORLD_FORT_OWNER_HIDE, obj.x_, obj.z_)
end

function load_btn_list(self, list)
    if self.obj_ then
        if self.obj_.owner_ and not MasterManager:is_master(self.obj_.owner_) then
            list = {1}
        end
    end
    if self.obj_ then
        local objType = self.obj_.obj_type_
        --TODO:判断是否是同盟
        if (objType == config.WORLD_MAIN or objType == config.WORLD_RESPOINT or objType == config.WORLD_FORT)
            and self.obj_.owner_ and not MasterManager:is_master(self.obj_.owner_) then
            table.insert(list, 11)
            table.insert(list, 14)
        end
    end
    for i,v in ipairs(self.btns_) do
        self:set_active(v.gameObject, false)
    end
    local num = #list
    for i,v in ipairs(list) do
        self:set_active(self.btns_[v].gameObject, true)
        local rect = self.btns_[v].transform:GetComponent(RectTransform)
        rect.anchoredPosition = Vector2(unpack(Menu_Pos[num][i]))
    end
end

function set_active(self, go, value)
    if not go then return end
    if value then
        if not go.activeSelf then
            go:SetActive(value)
        end        
    else
        if go.activeSelf then
            go:SetActive(value)
        end 
    end    
end


