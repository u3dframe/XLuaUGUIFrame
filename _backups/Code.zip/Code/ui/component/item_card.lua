module("ItemCard",package.seeall)
setmetatable( ItemCard, {__index = BaseComponent} )

local UI = _G.UnityEngine.UI
local UIUtil = _G.UIUtil
local lang = _G.lang

function init(self)
    self.icon_area_ = self.transform:Find("IconArea")
    self.icon_ = self.icon_area_:Find("Icon")
    self.count_ = self.icon_area_:Find("Count/Text")
    self.label_ = self.icon_area_:Find("Label")
    self.new_tag_ = self.icon_area_:Find("NewTag")
    self.name_ = self.transform:Find("NameTxt")
    self.rebate = self.icon_area_.transform:Find("Rebate")
    self.rebateTxt = self.icon_area_.transform:Find("Rebate/Text")
    self.buyBtn = self.transform:Find("BuyBtn")
    self.buyBox = self.transform:Find("BuyBtn/Icon")
    self.buyImg = self.transform:Find("BuyBtn/Icon/Image")
    self.buyTxt = self.buyBtn.transform:Find("Text")
    self.buyHintTxt = self.buyBtn.transform:Find("Hint")
end

function on_start(self)
    
end

function on_dispose(self)

end

function set_item_prop(self, prop)
    self:set_item(prop[1], prop[2], prop[3])
    self:add_tips_handler(self.icon_.transform, prop, TipsCard.TIPS_ITEM)
end

function set_item(self, _type, id, count)
    local cfg = ItemManager:get_ui_info({_type, id})
    if not cfg then
        return elog(string.format("Can't find config of item: %s,%s", _type, id))
    end
    UIUtil.set_sprite("UI/Common/Quality/item_"..cfg.quality, self.icon_area_:GetComponent(Image))
    UIUtil.set_sprite(cfg.icon, self.icon_:GetComponent(Image))
    self.count_:GetComponent(Text).text = count
    self:set_label(cfg.label)
    self.name_:GetComponent(Text).text = cfg.name
end

function set_icon_only(self, _type, id)
    local cfg = ItemManager:get_ui_info({_type, id})
    if not cfg then
        return elog(string.format("Can't find config of item: %s,%s", _type, id))
    end
    UIUtil.set_sprite("UI/Common/Quality/item_"..cfg.quality, self.icon_area_:GetComponent(Image))
    UIUtil.set_sprite(cfg.icon, self.icon_:GetComponent(Image))
    self.count_.gameObject:SetActive(false)
    self.name_.gameObject:SetActive(false)
end

function set_count(self, count)
    if type(count) ~= "number" then return end
    self.count_:GetComponent(Text).text = count
end

function set_new_tag(self, show)
    self.new_tag_.gameObject:SetActive(show)
end

function set_label(self, label)
    if label then
        self.label_.gameObject:SetActive(true)
        local label_txt = self.label_:Find("LabelText"):GetComponent(Text)
        label_txt.text = label
    else
        self.label_.gameObject:SetActive(false)
    end
end

function SetRebate(self, rebate)
    if not rebate then
        self.rebate.gameObject:SetActive(false)
        return
    end
    self.rebate.gameObject:SetActive(true)
    self.rebateTxt:GetComponent(UI.Text).text = rebate..lang("UI_BASIC_REBATE")
end

function SetBuyBtn(self, prop, callback)
    if not prop then
        self.buyBtn.gameObject:SetActive(false)
        return
    end
    self.buyBtn.gameObject:SetActive(true)
    self.buyTxt:GetComponent(UI.Text).text = prop[3]
    UIUtil.set_sprite("UI/Common/ItemSmall/"..prop[1], self.buyImg:GetComponent(UI.Image))
    if not self.buyBtn:GetComponent(UI.Button).onClick then
        return
    end
    self.buyBtn:GetComponent(UI.Button).onClick:RemoveAllListeners()
    if not callback then
        return
    end
    self:add_event_handler(self.buyBtn:GetComponent(UI.Button).onClick, callback)
end
