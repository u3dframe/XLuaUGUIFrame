module("TipsCard",package.seeall)
setmetatable( TipsCard, {__index = BaseComponent} )

TIPS_ITEM  = 1      -- 道具tips

function on_awake(self)
    self.screen_size_ = UIManager.get_canvas_size()
    self.ui_camera_ = UIManager.get_camera()   
    self.obj_panel_ = self.transform:Find("Common").gameObject
    
    self.obj_name_ = self.transform:Find("Common/Name"):GetComponent(Text) 
    self.obj_desc_ = self.transform:Find("Common/Desc"):GetComponent(Text)
end

-- tips外部需要实现接口
function show_content(self, trans, data, tipsType)
    if self.cur_trans_ == trans then return end
    self.cur_trans_ = trans
    if check_show_func[tipsType] then
        self.obj_panel_:SetActive(true)
        check_show_func[tipsType](self, data)
    else
        self.obj_panel_:SetActive(false)
        elog("tips findn't the type = "..tostring(tipsType))
    end    
    self:process_position(trans)
end

function show_item_tips(self, data)
    local cfg = ItemManager:get_ui_info(data)
    self:set_name_content(cfg.name)
    local desc = cfg.desc
    if not desc and type(data[3]) == "number" then
        desc = string.format("%s*%d", cfg.name, data[3])
    end
    self:set_desc_content(desc)
end

check_show_func = {
	[TIPS_ITEM]  = show_item_tips,      -- 道具tips
}
---------------------------------- ↓计算坐标和高度↓ ------------------------------------------------------------
function process_position(self, trans)
    if not trans then return end
    if Slua.IsNull(trans.transform) then return end
    local target = trans.gameObject:GetComponent(RectTransform)
    local src_pos = trans.position
    local screenPos = self.ui_camera_:WorldToScreenPoint(src_pos) 
    local b,p = RectTransformUtility.ScreenPointToLocalPointInRectangle(self.screen_size_, screenPos, self.ui_camera_)
    local self_rect = self.transform:GetComponent(RectTransform)
    local target_height = target.rect.height*trans.localScale.y*(1-target.pivot.y)
    local target_width = target.rect.width*trans.localScale.x*(1-target.pivot.x)
    local pos_x = p.x+target_width/2
    local pos_y = p.y+target_height
    local self_height = self_rect.rect.height
    local self_width = self_rect.rect.width
    local self_pivot = self_rect.pivot
    local min_posx = self_pivot.x * self_width-self.screen_size_.sizeDelta.x/2
    local min_posy = self_height-self.screen_size_.sizeDelta.y/2
    if pos_x < min_posx then
        -- 超左
        pos_x = min_posx
    end
    if (pos_x + self_width*self_pivot.x) > self.screen_size_.sizeDelta.x/2 then
        -- 超右
        pos_x = self.screen_size_.sizeDelta.x/2 - self_width*self_pivot.x
    end
    if (pos_y+self_height) > self.screen_size_.sizeDelta.y/2 then 
        pos_y = pos_y - self_rect.rect.height/2-target.rect.height*trans.localScale.y
    else
        pos_y = pos_y + self_rect.rect.height/2
    end
    self_rect.anchoredPosition = Vector2(pos_x, pos_y)   
end

function set_desc_content(self, desc)
    if desc then
        self.obj_desc_.text = desc
        self.obj_desc_.gameObject:SetActive(true)
    else
        self.obj_desc_.gameObject:SetActive(false)
    end
end

function set_name_content(self, name)
    if name then
        self.obj_name_.text = name
        self.obj_name_.gameObject:SetActive(true)
    else
        self.obj_name_.gameObject:SetActive(false)
    end
end

function on_dispose(self)
    self.screen_size_ = nil
    self.ui_camera_ = nil     
    self.obj_panel_ = nil
    self.cur_trans_ = nil
end