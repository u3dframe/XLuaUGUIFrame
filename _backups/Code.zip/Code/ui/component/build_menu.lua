module("BuildMenu", package.seeall)
setmetatable(BuildMenu, {__index = BaseComponent})

local config = _G.config
local UIController

--最大数量
Max_Count = 6
-- value 只与UI相关
Menu = {
    --通用按钮
    LV_UP = 1, --升级按钮
    DES = 2,   --详情按钮
    GOLD_LV_UP = 3,     --金币加速(建造升级)
    LV_UP_SPEED_UP = 4, --建造加速按钮（道具）

    --非通用按钮
    DIRLL = 20,          --训练按钮
    DRILL_SPEED_UP = 21, --训练加速按钮（道具）
    COLL_ITEM = 22,      --道具增产
    COLL_GOLD = 23,      --金币增产
    CURE = 24,           --治疗菜单
    CURE_SPEED_UP = 25,  --治疗

    ITEM_SPEED_UP = 26,  --道具加速（目前只用于建筑拆除）
    FETE = 27,           --祭祀按钮
    WALL = 28,           --城墙防御
    TRAP = 29,           --陷阱作坊
    TRAP_SPEED_UP = 30,  --陷阱建造加速（道具）
    WATERWHEEL=31,        --水车详情
    WAREHOUSE=32,        --仓库资源
}

--加速道具类型
Item_Type = config.SPEEDUP_ITEM

--菜单位置Y轴偏移量
local OffsetY = Screen.height * 0.08
--local OffsetY = Screen.height * 0.06
----------------------------mono function-------------------

function init(self)
    UIController = _G.UIController
    self.city_canvas_ = GameObject.Find("CityCanvas").transform
    self.ui_camera_ = UIManager.get_camera()
    self.screen_size_ = UIManager.get_canvas_size()
    self.rect_ = self.transform:GetComponent(RectTransform)
    self.btn_tb_ = {}--btn表
    self.panel_tb_ = {} -- panel表
    self.date_tb_ = {}--数据表
    self.pos_tb_ = {}--位置表
    for i=1, Max_Count do
        local btn = self.transform:Find("btn"..i)
        local panel = btn.transform:Find("btn/Panel").gameObject
        table.insert(self.panel_tb_, panel)
        table.insert(self.btn_tb_, btn)
    end
    self.desc_txt_ = self.transform:Find("DescTxt"):GetComponent(Text)
    self.desc_txt_.gameObject:SetActive(false)
    --初始化菜单item位置 5个的/4个的
    self:init_pos_tb()
    self:init_animation()
end

function on_dispose(self)
    
end


----------------------------animation function-------------------
-- 显示动画结束后
function animation_show_start(self)
    self.desc_txt_.gameObject:SetActive(true)
end

-- 关闭动画开始前
function animation_show_end(self)
    self.desc_txt_.gameObject:SetActive(false)
end

--初始化动画
function init_animation(self)
    self.tween_show_ = XSequence() --show 动画序列
    self.tween_hide_ = XSequence() --hide 动画序列

    self.tween_show_:SetAutoKill(false)
    self.tween_hide_:SetAutoKill(false)
    
    for k, v in ipairs(self.btn_tb_) do
        v.transform.localScale = Vector3.zero
        self.tween_show_:Insert(0, GameTween.DOScale(v.transform, 1, 0.2)):SetEase(2):OnComplete(function()
            self:animation_show_start()
        end)
        self.tween_hide_:Insert(0, GameTween.DOScale(v.transform, 0, 0.2)):SetEase(2):OnComplete(function()
            if self.is_play_show_ then
                self:set_active(true)
                self.is_play_show_ = false
            else
                self:set_active(false)
            end
        end)
    end
    self.tween_hide_:AppendCallback(function()
        if self.is_play_show_ then
            self:set_active(true)
            self.tween_show_:Restart(true)
        end
    end)
    self.tween_hide_:Pause()
    self.tween_show_:Pause()
end

function animation_show(self)
    if self.tween_show_:IsPlaying() then
        return
    end
    if self.tween_hide_:IsPlaying() then
        self.is_play_show_ = true
    else
        self:set_active(true)
        self.tween_show_:Restart(true)
    end
end

function set_active(self, value)
    if value then
        local index = self.transform:GetSiblingIndex()
        local num = self.transform.parent.childCount
        if index ~= num - 1 then
            self.transform:SetSiblingIndex(num - 1) 
        end
    end
    self.gameObject:SetActive(value)
end


function animation_hide(self)
    if not self.gameObject.activeSelf then return end
    if self.tween_hide_:IsPlaying() or self.tween_show_:IsPlaying() then
        return
    end
    self:animation_show_end()
    self.tween_hide_:Restart(true)
end

----------------------------logic function-------------------

--数据大小 对应 需要显示的菜单index
--key 数据大小，value 要显示的菜单index
Menu_Show_Tb = {[1] = {3},
                [2] = {3, 4},
                [3] = {2, 3, 4},
                [4] = {2, 3, 4, 5},
                [5] = {1, 2, 3, 4, 5},
                [6] = {1, 2, 3, 4, 5, 6}
               }

function update_menu(self)
    local menu_data = {}
    for i, v in ipairs(self.date_tb_) do
        table.insert(menu_data, v)
    end
    local length = #menu_data
    --设置菜单按钮坐标
    self:set_child_axis(length)
    self:set_child_pivot()

    local need_show_tb = Menu_Show_Tb[length]
    for i = 1, Max_Count do
        self.btn_tb_[i].gameObject:SetActive(false)
    end
    local index = 1
    for _, v in pairs(need_show_tb) do
        self.btn_tb_[v].gameObject:SetActive(true)
        if self.check_func[menu_data[index]]["onShow"] then
            self.panel_tb_[v].gameObject:SetActive(true)
            self.check_func[menu_data[index]]["onShow"](self, self.panel_tb_[v].transform)
        else
            self.panel_tb_[v].gameObject:SetActive(false)
        end
        if self:is_alive() then
            local btn_img = self.btn_tb_[v]:GetComponent(Image)
            local path = self:get_btn_path_by_index(menu_data[index])
            UIUtil.set_sprite(path, btn_img)
            local btn = self.btn_tb_[v]:Find("btn")
            UIUtil.set_sprite(path, btn:GetComponent(Image))
            btn = btn:GetComponent(Button)
            btn.onClick:RemoveAllListeners()
            self:add_event_handler(btn.onClick, callback, menu_data[index])--添加点击事件
        end
        index = index + 1
    end
end

function refresh_menu(self)
     --获取数据
    self.build_info_ = self.space_class_.build_info_
    local data = self.build_info_:GetMenu()
    self.date_tb_ = {}
    for _, v in ipairs(data) do
        table.insert(self.date_tb_, v)
    end
    --根据状态来屏蔽按钮
    self:check_state()
    --根据建筑初始化描述
    self:init_other_content()
    --刷新菜单位置和逻辑
    self:update_menu()
end

function check_state(self)
    for _, v in ipairs(self.date_tb_) do
        if self.check_func[v]["onCheck"] then
            self.check_func[v]["onCheck"](self)
        end
    end

    --对通用菜单管理
    if self.build_info_:is_lvup() then
        self:remove_by_value(self.date_tb_, Menu.LV_UP)
    else
        --拆除的时候显示金币菜单按钮
        if not self.build_info_:is_removing() then
            self:remove_by_value(self.date_tb_, Menu.GOLD_LV_UP)
        end
        self:remove_by_value(self.date_tb_, Menu.LV_UP_SPEED_UP)
    end
end

function init_other_content(self)
    if self.build_info_:is_collect_build() then
        local collect = CollectManager:get_collect(self.build_info_.id_)
        if collect:has_buff() then
            self.desc_txt_.text = lang("RESOURCE_BUILDING_2", collect:get_buff_time())
        else
            self.desc_txt_.text = ""
        end    
    else
        self.desc_txt_.text = ""
    end
end

--根据value删除元素
function remove_by_value(self, tb, value)
    if not tb or #tb == 0 then return end
    local index
    for k, v in pairs(tb) do
        if v == value then
            index = k
            break
        end
    end
    if not index then return end
    table.remove(tb, index)
end

function get_show_btn_count(self)
    local count = 0
    for k, v in pairs(self.btn_tb_) do
        if v.gameObject.activeSelf then
            count = count + 1
        end
    end
    return count
end

function get_btn_path_by_index(self, index)
    return "UI/Window/main/city/menu_"..index
end
    
--判断是否重复点击
function is_redo_click(self, id)
    if id == nil then
        elog("id is nil")
        return
    end
    if id == self.last_id then
        return true
    else
        self.last_id = id
        return false 
    end
end

--设置菜单位置
function set_menu_axis(self)
    local menu_world_pos
    local timer_slider
    if self.current_timer_slider_2_ and self.current_timer_slider_2_.gameObject.activeSelf then
        timer_slider = self.current_timer_slider_2_
    elseif self.current_timer_slider_1_ and self.current_timer_slider_1_.gameObject.activeSelf then
        timer_slider = self.current_timer_slider_1_
    end
    if timer_slider then
        local pos = timer_slider.position
        pos.y = pos.y + 0.18 * Camera.main.orthographicSize
        menu_world_pos = pos
    else
        --置于建筑的RectTransform的下边界中心
        if _G.GRichTextField then
            local buildTrans = self.current_build_.transform:Find("Build/BuildCollider").transform
            menu_world_pos = buildTrans.position
        else
            local rect = self.current_build_:GetComponent(RectTransform)
            local c = Vector2((rect.offsetMin.x + rect.offsetMax.x) / 2, rect.offsetMin.y + OffsetY)
            local scale = self.city_canvas_.localScale
            menu_world_pos = Vector3(c.x * scale.x, c.y * scale.y, 0) + self.city_canvas_.position
        end
    end
    local screenPos = Camera.main:WorldToScreenPoint(menu_world_pos)
    local b,p = RectTransformUtility.ScreenPointToLocalPointInRectangle(self.screen_size_, screenPos, self.ui_camera_)
    self.rect_.anchoredPosition = Vector2(math.floor(p.x), math.floor(p.y))
end

--设置子物体的位置
function set_child_axis(self, count)
    --偶数的时候最下面俩个
    for i = 1,Max_Count do
        if count % 2 == 0 then
            self.btn_tb_[i].transform.localPosition =  self.pos_tb_[2][i]
        else--奇数的时候最下面1个
            self.btn_tb_[i].transform.localPosition =  self.pos_tb_[1][i]
        end
    end    
end

--设置子物体中心点
function set_child_pivot(self)
    local o = Vector2(0, OffsetY * 0.8)
    for k, v in pairs(self.btn_tb_) do
        local rect = v:GetComponent(RectTransform)
        local dir = o - rect.anchoredPosition
        local angle = math.rad(Vector2.SignedAngle(dir, Vector2.up))
        --乘1.8是为了让pivot更偏离物体中心，放大菜单缩放效果
        local x = 0.5 * (1 + math.sin(angle) * 1.8)
        local y = 0.5 * (1 + math.cos(angle) * 1.8)
        rect.pivot = Vector2(x, y)
    end
end

--利用三角函数获取菜单按钮的坐标位置
function init_pos_tb(self)
    self.pos_tb_[1] = self.pos_tb_[1] or {}
    self.pos_tb_[2] = self.pos_tb_[2] or {}
    local o = Vector2(0 , -0.3)
    local r = OffsetY
    local angle = 30
    for i = 1, Max_Count do
        --公式:   (x - r * cos(弧度), y - r * sin(弧度))
        local pos = Vector2(o.x - r * math.cos(math.rad(angle * i - 15)), o.y - r * math.sin(math.rad (angle * i - 15)) + OffsetY)
        table.insert(self.pos_tb_[2], pos)
        local pos = Vector2(o.x - r * math.cos(math.rad(angle * i)), o.y - r * math.sin(math.rad(angle * i)) + OffsetY)
        table.insert(self.pos_tb_[1], pos)
    end
end

function callback_listerent(self, space_class)
    if not space_class.build_info_ or space_class.build_info_.lv_ <= 0 then
        return
    end
    self.space_id_ = space_class.id_
    self.space_class_ = space_class
    self.is_redo_ = self:is_redo_click(self.space_id_)  --判断是否重新点击
    self:refresh_menu() --刷新菜单
    --固定位置
    self.current_build_ = space_class.gameObject
    self.current_timer_slider_1_ = self.current_build_.transform:Find("TimerSlider/Timer_1")
    self.current_timer_slider_2_ = self.current_build_.transform:Find("TimerSlider/Timer_2")
    --点击不同动画时，先做隐藏动画。再切换菜单位置，做显示动画操作
    if not self.is_redo_ then
         local tween = XSequence() 
        for k, v in pairs(self.btn_tb_) do
            tween:Insert(0, GameTween.DOScale(v.transform, 0, 0.1))
        end
        tween:AppendCallback(function() 
                self:set_menu_axis() 
                self:animation_show()
            end)
    else
        self:set_menu_axis()
        self:animation_show()
    end
    
end

--按钮回调
function callback(self, eventData, index)
    self:set_active(false)
    if self.check_func[index]["onClick"] then
        self.check_func[index]["onClick"](self, eventData, index)
    end
end


-----------------------------------------------------LV_UP--------------------------------------------------------------

function on_check_lvup_handler(self, event)
    if self.build_info_:is_curing() then
        self:remove_by_value(self.date_tb_, Menu.LV_UP)
    end
end

function on_click_lvup_handler(self, event, index)
    if _G.FairyGUI then
        _G.SceneController.currentScene:GetCameraController():FocusOn(self.space_class_.virtualCamera)
        _G.UIController:ShowUI("UIBuildUpdate",{space=self.space_class_,
            buildType = self.space_class_.build_info_.build_type_,level=self.space_class_.build_info_.lv_})
        return
    end
    UIManager.open_window("BuildSpendWindow", function()
        if _G.SceneManager.City_Scene then
            SceneManager.City_Scene:map_move_to_upper(self.current_build_)
        end
    end, self.space_class_, nil, config.Build_State.LV_UP)
end
-----------------------------------------------------Gold_LV_UP--------------------------------------------------------------

function on_click_gold_lvup_handler(self, event, index)
    local msg_ = {}
    msg_.mode=0
    msg_.title = ""
    msg_.content = lang("UI_BUILDSPEND_SPEEDUP_HINE")
    msg_.callback = function() 
        local req_msg = {}
        req_msg.id = self.build_info_.id_
        Net.send("build_levelup_dectime", req_msg, function(result)
            if result.e == 5 then
                MsgCenter.send_message(Msg.SHOW_HINT, lang("ITEM_NOT_ENOUGH"))
            elseif result.e == 3 then
            --self:close()
            elseif result.e == 0 then
                if self.build_info_ and self.build_info_.id_ then                    
                    MsgCenter.send_message(Msg.CITY_UP_LV_UPDATE, self.build_info_.id_)
                end
            end
        end)
    end
    _G.UIController:ShowUI('UICommonPop', msg_)
end

-----------------------------------------------------COLL_ITEM\COLL_GOLD--------------------------------------------------------------
function on_click_collect_item_handler(self, event)
    local collect = CollectManager:get_collect(self.build_info_.id_)
    if not ItemManager:check_item_count(collect.buff_item_) then
        local prop = ItemManager:get_item_prop_by_id(collect.buff_item_)
        local str = lang("RESOURCE_BUILDING_3", prop.name)
        MsgCenter.send_message(Msg.SHOW_HINT, str)
        return
    end
    local item = ItemManager:get_item_by_id(collect.buff_item_)
    item.use_build_id_ = self.build_info_.id_
    item.use_collect_ = collect
    item:use()
end

function on_click_collect_gold_handler(self, event)
    local collect = CollectManager:get_collect(self.build_info_.id_)
    local prop = collect:get_prop()
    local item = { config.ITEM_GOLD, 0, prop.gold}    
    if not ItemManager:check(item) then
        MsgCenter.send_message(Msg.SHOW_HINT, lang("RESOURCE_BUILDING_6"))
        return
    end
    local msg_ = {}
    msg_.mode=0
    msg_.title = lang("UI_BASIC_HINT")
    msg_.content = lang("RESOURCE_BUILDING_7")
   -- msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
    msg_.callback = function() 
       -- if index == 2 then
            local func = function()
                local data = {}
                data.id = self.build_info_.id_
                data.money = 1
                Net.send("build_collect_buffadd", data, function(result)
                    if result.e == 0 then
                        MsgCenter.send_message(Msg.CITY_COLLECT_REFRESH, self.build_info_.id_)
                    end
                end)
            end
            if not collect:has_buff() then
                func()
                return
            end          
            local msg_1 = {}
            msg_1.mode=0
            msg_1.title = lang("UI_BASIC_HINT")
            local str = lang("RESOURCE_BUILDING_5", collect.name_, collect:get_buff_time())
            msg_1.content = str
            msg_1.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
            msg_1.callback = function() 
               -- if index == 2 then
                    func()
              --  end                
            end
          --  MsgCenter.send_message(Msg.SHOW_NOTIFY,msg_1)
            _G.UIController:ShowUI('UICommonPop', msg_1)
      --  end
    end
  --  MsgCenter.send_message(Msg.SHOW_NOTIFY,msg_)
    _G.UIController:ShowUI('UICommonPop', msg_)
end

function on_click_collect_showgold_handler(self, tran)
    local icon = tran:Find("Icon"):GetComponent(Image)
    local num = tran:Find("Num"):GetComponent(Text)
    local collect = CollectManager:get_collect(self.build_info_.id_)
    local prop = collect:get_prop()
    num.text = prop.gold
    UIUtil.set_sprite("UI/Common/ItemSmall/7", icon)
end

function on_click_collect_showitem_handler(self, tran)
    local icon = tran:Find("Icon"):GetComponent(Image)
    local num = tran:Find("Num"):GetComponent(Text)
    
    local collect = CollectManager:get_collect(self.build_info_.id_)
    local prop = collect:get_prop()
    local item = ItemManager:get_item_by_id(collect.buff_item_)
    local item_prop = ItemManager:get_item_prop_by_id(collect.buff_item_)
    if item then
        num.text = item.count_
    else
        num.text = 0
    end
    UIUtil.set_sprite(item_prop.icon, icon)
end
-----------------------------------------------------DIRLL--------------------------------------------------------------

function on_check_dirll_handler(self, event)
    if self.build_info_:is_soldier_build() then
        self.timer_exis_ = SoldierManager:check_soldier_state(self.build_info_.build_type_)
        if not self.timer_exis_ then
            self:remove_by_value(self.date_tb_, Menu.DRILL_SPEED_UP)
        else
            self:remove_by_value(self.date_tb_, Menu.GOLD_LV_UP)
        end
    end
end

function on_click_dirll_handler(self, event, index)
    if _G.FairyGUI then
        _G.UIController:ShowUI("UITrainMain", {space = self.space_class_})
        return
    end
    UIManager.open_window("CitySoldierWindow", nil, self.space_class_)
end
-----------------------------------------------------DES--------------------------------------------------------------
function on_click_des_handler(self, event, index)
    if _G.UIController then
        _G.SceneController.currentScene:GetCameraController():FocusOn(self.space_class_.virtualCamera)
        _G.UIController:ShowUI("UIBuildDetail", {buildID = self.build_info_.id_})
        return
    end
    UIManager.open_window("BuildDetailsWindow", function()
        if _G.SceneManager.City_Scene then
            SceneManager.City_Scene:map_move_to_upper(self.current_build_)
        end
    end, self.space_class_)
end
-----------------------------------------------------LV_UP_SPEED_UP--------------------------------------------------------------
function on_click_lvup_speed_up_handler(self, event, index)
    --升级加速按钮
    if not self.build_info_:is_lvup() then
        return
    end
    local buildId = self.build_info_.id_
    if UIController then
        UIController:ShowUI("UISpeedUp", {type = 0, buildID = buildId})
        return
    end

    UIManager.open_window("SpeedUpWindow", nil, config.SPEEDUP_LVUP, buildId)
end
-----------------------------------------------------DRILL_SPEED_UP--------------------------------------------------------------
function on_click_dirll_speed_ip_handler(self, event, index)
    --训练加速按钮
    if not self.timer_exis_ then
        return
    end

    local buildId = self.build_info_.id_
    if UIController then
        UIController:ShowUI("UISpeedUp", {type = 1, buildID = buildId})
        return
    end

    UIManager.open_window("SpeedUpWindow", nil, config.SPEEDUP_DRILL, buildId)
end

-----------------------------------------------------Hospital--------------------------------------------------------------

function on_check_hospital_handler(self, event)
    if not self.build_info_:is_curing() then
        self:remove_by_value(self.date_tb_, Menu.CURE_SPEED_UP)
    end
    if self.build_info_:is_curing() then
        self:remove_by_value(self.date_tb_, Menu.CURE)
    end
end

function on_click_hospital_handler(self, event)
    if self.build_info_:is_curing() then
        return
    end
    local build_id = self.build_info_.id_
    if UIController then
        UIController:ShowUI("UIHospital", {buildID = self.build_info_.id_})
        return
    end
    UIManager.open_window("CityHospitalWindow", nil, build_id)
end

---------------------------------------------------cure speedup-------------------------------------------------------------------

function on_check_cure_speedup_handler(self, event)
    if not self.build_info_:is_curing() then
        self:remove_by_value(self.date_tb_, Menu.CURE_SPEED_UP)
    else
        self:remove_by_value(self.date_tb_, Menu.CURE)
    end
end

function on_click_cure_speedup_handler(self, event)
    local buildId = self.build_info_.id_
    if UIController then
        UIController:ShowUI("UISpeedUp", {buildID = buildId})
        return
    end

    UIManager.open_window("SpeedUpWindow", nil, config.SPEEDUP_CURE, buildId)
end

---------------------------------------------------------dismantle(拆除加速)-----------------------------------------------

function on_check_item_speedup_handler(self, event)
    --如果在拆除中
    if self.build_info_:is_outside_build() and self.build_info_:is_removing() then
        --拆除中不显示升级按钮
        self:remove_by_value(self.date_tb_, Menu.LV_UP)
        return
    end
    --陷阱作坊
    if self.build_info_:is_soldier_build() then
        local timer, _, soldierID, soldierClass = SoldierManager:check_soldier_state(self.build_info_.build_type_)
		local soldier = SoldierManager:get_soldier_info_by_id(soldierID, soldierClass)
        if soldier and soldier.class_ and timer then
            return
        end
    end
    self:remove_by_value(self.date_tb_, Menu.ITEM_SPEED_UP)
end

function on_click_item_speedup_handler(self, event)
    local buildId = self.build_info_.id_
    if UIController then
        UIController:ShowUI("UISpeedUp", {buildID = buildId})
        return
    end
    UIManager.open_window("SpeedUpWindow", nil, config.SPEEDUP_DISMANTLE, buildId)
end

---------------------------------------------------------祭祀--------------------------------------------------------------
function OnClickFeteHandle(self, event)
    dump("------------------------------------------------>")
    if UIController then
        UIController:ShowUI("UISacrifice")
        return
    end
    UIManager.open_window("CityFeteWindow", nil)
end

---------------------------------------------------------瓮城（城墙）-------------------------------------------------------
function OnClickWallHandle(self, event)
    if _G.UIController then
        _G.UIController:ShowUI("UIWall", {buildID = self.build_info_.id_})
    end
end

---------------------------------------------------------陷阱作坊------------------------------------
function OnClickTrapHandle(self, event)
    if _G.FairyGUI then
        _G.UIController:ShowUI("UITrainMain", {space = self.space_class_, soldierClass = config.SOLDIER_CLASS.TRAP})
        return
    end
end
---------------------------------------------------------水车------------------------------------
function OnClickWaterWheelHandle(self,event)
    if _G.UIController then
        local args={}
        Net.send("produce_info", {},
        function(result)
           if result.e == 0 then
               local info=result.info
               if info then
                 args.increaseInfo=info  
                 _G.UIController:ShowUI("UIWaterYield",args)
               end
           end
       end)
    end
end
---------------------------------------------------------仓库------------------------------------
function OnClickwareHouseHandle(self,event)
    if _G.UIController then
        local args={}
    --     Net.send("produce_info", {},
    --     function(result)
    --        if result.e == 0 then
    --            local info=result.info
    --            if info then
    --              args.increaseInfo=info  
    --              _G.UIController:ShowUI("UIWaterYield",args)
    --            end
    --        end
    --    end)
    _G.UIController:ShowUI("UIWareroom",args)
    end
end
check_func =
{
    [Menu.LV_UP] =
    {   ["onCheck"] = on_check_lvup_handler,
        ["onClick"] = on_click_lvup_handler,
    },
    [Menu.GOLD_LV_UP] = {
        ["onClick"] = on_click_gold_lvup_handler,
    },
    [Menu.DIRLL] = 
    {   ["onCheck"] = on_check_dirll_handler,
        ["onClick"] = on_click_dirll_handler,
    },
    [Menu.DES] = 
    {
        ["onClick"] = on_click_des_handler,
    },
    [Menu.COLL_ITEM] = 
    {
        ["onClick"] = on_click_collect_item_handler,
        ["onShow"] = on_click_collect_showitem_handler,
    },
    [Menu.COLL_GOLD] = 
    {
        ["onClick"] = on_click_collect_gold_handler,
        ["onShow"] = on_click_collect_showgold_handler,
    },
    [Menu.LV_UP_SPEED_UP] = 
    {
        ["onClick"] = on_click_lvup_speed_up_handler,
    },
    [Menu.DRILL_SPEED_UP] = 
    {
        ["onClick"] = on_click_dirll_speed_ip_handler,
    },
    [Menu.CURE] = {
        ["onCheck"] = on_check_hospital_handler,
        ["onClick"] = on_click_hospital_handler,
    },
    [Menu.CURE_SPEED_UP] = {
        ["onCheck"] = on_check_cure_speedup_handler,
        ["onClick"] = on_click_cure_speedup_handler,
    },
    [Menu.ITEM_SPEED_UP] = {
        ["onCheck"] = on_check_item_speedup_handler,
        ["onClick"] = on_click_item_speedup_handler,
    },
    [Menu.FETE] = {
        ["onClick"] = OnClickFeteHandle,
    },
    [Menu.WALL] = {
        ["onClick"] = OnClickWallHandle,
    },
    [Menu.TRAP] = {
        ["onClick"] = OnClickTrapHandle,
    },    
    [Menu.WATERWHEEL] = {
        ["onClick"] = OnClickWaterWheelHandle,
    },
    [Menu.WAREHOUSE] = {
       ["onClick"] = OnClickwareHouseHandle,
    }
}