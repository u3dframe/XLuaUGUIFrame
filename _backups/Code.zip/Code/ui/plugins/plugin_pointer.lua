-- 点击事件
module("PluginPointer", package.seeall)

POINTER_UP = 1
POINTER_ALWAY_DOWN = 2
POINTER_CLICK = 3
POINTER_DOWN = 4
POINTER_ENTER = 5
POINTER_EXIT = 6

-- component 点击对象
function new(self, win, component, callback, parameter, time)
    local obj = {}
    setmetatable(obj, {__index = self})
    obj.win_ = win
    obj.component_ = component
    obj.callback_ = callback
    obj.parameter_ = parameter
    obj.time_count_ = time or 5
    obj:init()
    return obj
end

function init(self)
    self.tool_ = self.component_:GetComponent(PointerEventListener)
    if not self.tool_ then
        self.tool_ = self.component_:AddComponent(PointerEventListener)
    end
    self.is_update_ = false
    self.is_down_ = false
    self.is_click_ = true
    self.timer_second_ = Time.time
    self.speed_ = 0.2
    self.first_down_ = true
    self.enter_state_ = false
    self.exit_state_ = false

    self.messager_ = Messager:new(self)

    self.tool_.onPointerEnter = function(event)
        self.timer_ = Time.time
        self.is_update_ = true
        if self.enter_state_ then
            self.callback_(self.win_, POINTER_ENTER, self.parameter_)
        end
    end

    self.tool_.onPointerExit = function(event)
        self.is_update_ = false
        if self.exit_state_ then
            self.callback_(self.win_, POINTER_EXIT, self.parameter_)
        end
    end

    self.tool_.onPointerDown = function(event)
        self.timer_ = Time.time
        self.timer_second_ = Time.time
        self.speed_ = 0.2
        self.is_down_ = true
        self.is_update_ = true
        self.is_click_ = true
        self.first_down_ = true
    end
    
    self.tool_.onPointerUp = function(event)
        self.is_update_ = false
        self.is_down_ = false
        if self.callback_ then
            self.callback_(self.win_, POINTER_UP, self.parameter_)
        end
    end    
    
    self.tool_.onPointerClick = function(event)
        -- 如果长按，则不响应clikc
        if self.callback_ and self.is_click_ then
            self.callback_(self.win_, POINTER_CLICK, self.parameter_)
        end
    end
    
    self.tool_.onUpdate = function(event)
        if not self.is_update_ then
            return
        end
        if self.is_down_ and self.is_update_ then
            if self.first_down_ then
                self.callback_(self.win_, POINTER_DOWN, self.parameter_)
                self.first_down_ = false
            end
            if self.callback_ and Time.time - self.timer_second_ > self.speed_ then
                self.is_click_ = false
                self.callback_(self.win_, POINTER_ALWAY_DOWN, self.parameter_)                
                self.timer_second_ = Time.time
                self.speed_ = (self.speed_ - 0.01) < 0.05 and 0.05 or (self.speed_ - 0.01)
            end
        end
    end
end

function on_application_focus(self, isFocus)
    if isFocus and self.tool_ then
        self.is_update_ = false
        self.is_down_ = false
    end
end

function dispose(self)
    self.win_ = nil
    self.component_ = nil
    self.callback_ = nil
    self.parameter_ = nil
    self.time_count_ = nil
    self.is_update_ = nil
    self.is_down_ = nil
    self.is_click_ = nil
    self.timer_second_ = nil
    self.speed_ = nil
    self.first_down_ = nil
    self.messager_ = nil
end

-- 开启移入 和 移出状态
function set_enter_exit_enable(self, enter, exit)
    self.enter_state_ = enter
    self.exit_state_ = exit
end
