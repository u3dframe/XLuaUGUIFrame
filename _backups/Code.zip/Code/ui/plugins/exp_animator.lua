module("ExpAnimator", package.seeall)


local MaxAnimationDuration = 1
local MinAnimationDuration = 0.2
local AnimDurationChangeRate = 0.7


function new(self)
    local obj = {}
    setmetatable(obj, {__index = self})
    obj:init()
    return obj
end

function init(self)
    
    ------------------↓以下属性由调用者设定↓------------------

    --单次动画的持续时间/连续动画的最大持续时间
    self.maxAnimationDuration = MaxAnimationDuration

    --连续动画的最小持续时间
    self.minAnimationDuration = MinAnimationDuration

    --连续动画持续时间的变化率，范围(0, 1)
    --连续动画中每一段的持续时间按此比率缩短至最小时间
    self.animDurationChangeRate = AnimDurationChangeRate

    --获取等级值
    self.getLv = function(self) return 1 end

    --设置等级值
    self.setLv = function(self, value) end

    --获取经验值
    self.getExp = function(self) return 0 end

    --设置经验值
    self.setExp = function(self, value) end

    --判断某个等级是否还可以继续升级。不能升级时，经验值会继续增长
    self.canLevelUp = function(self, lv) return true end

    --获取传入等级需要的升级经验值
    self.getTotalExpOfLv = function(self, lv) return 0 end

    --在play一段动画前调用，返回true/false来决定执行这段动画
    self.checkBeforePlaying = function(self, exp) return true end

    --当开始一段完整的变化(对应一次play()调用)时调用
    self.onStartPlaying = function(self) end

    --当结束一段完整的变化(对应一次play()调用)时调用
    --若需要播放连续动画，调用play()的时机不能晚于此函数
    self.onEndPlaying = function(self) end

    ------------------↑以上属性由调用者设定↑------------------

    self._expAnimation = nil
    self._currAnimDuration = nil
    self._expAnimQueue = {}
    self._expAnimBuffer = nil
end

function isPlaying(self)
    return self._expAnimation ~= nil
end

function killAll(self)
    if self._expAnimation then
        self._expAnimation:Kill(false)
        self._expAnimation = nil
    end
    self._expAnimBuffer = nil
    self._expAnimQueue = {}
end

function _resetDuration(self)
    self._currAnimDuration = nil
end

function _playNextInQueue(self)
    if #self._expAnimQueue > 0 then
        local data = self._expAnimQueue[1]
        table.remove(self._expAnimQueue, 1)
        return self:play(unpack(data))
    end
    self:_resetDuration()
end

function play(self, exp, successive)
    if exp <= 0 then return end
    if self.checkBeforePlaying and not self:checkBeforePlaying(exp) then
        return self:_playNextInQueue()
    end
    if self:isPlaying() then
        table.insert(self._expAnimQueue, {exp, successive})
        return
    end
    if successive then
        if not self._currAnimDuration then
            self._currAnimDuration = self.maxAnimationDuration
        else
            self._currAnimDuration = self._currAnimDuration * self.animDurationChangeRate
            if self._currAnimDuration < self.minAnimationDuration then
                self._currAnimDuration = self.minAnimationDuration
            end
        end
    else
        self._currAnimDuration = self.maxAnimationDuration
    end
    self:_playBuffer(exp, self._currAnimDuration / exp)
    if self.onStartPlaying then
        self:onStartPlaying()
    end
end

function _playBuffer(self, exp, speed)
    local currLv = self:getLv()
    local canLvUp = self:canLevelUp(currLv)
    local currExp = self:getExp()
    local changeExp
    local totalExp
    if canLvUp then
        totalExp = self:getTotalExpOfLv(currLv)
        changeExp = math.min(exp, totalExp - currExp)
    else
        changeExp = exp
    end
    local restExp = exp - changeExp
    if restExp > 0 then
        self._expAnimBuffer = {restExp, speed}
    end
    self._expAnimation = GameTween.To(function(v)
        self:setExp(currExp + math.floor(v))
    end, 0, changeExp, speed * changeExp):SetEase(XEase.Linear):OnComplete(function()
        local newExp = currExp + changeExp
        if canLvUp and newExp - totalExp >= 0 then
            self:setLv(currLv + 1)
            self:setExp(newExp - totalExp)
        else
            self:setExp(newExp)
        end
        if self._expAnimBuffer then
            local data = self._expAnimBuffer
            self._expAnimBuffer = nil
            return self:_playBuffer(unpack(data))
        else
            if self.onEndPlaying then
                self:onEndPlaying()
            end
            self._expAnimation = nil
            return self:_playNextInQueue()
        end
    end)
end
