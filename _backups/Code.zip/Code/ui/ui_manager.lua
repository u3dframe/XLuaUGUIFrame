module("UIManager", package.seeall)

--窗口序列栈
OrderStacks = OrderStacks or {}
--窗口缓存栈
CacheStacks = CacheStacks or {}
--窗口加载栈
AwaitStacks = AwaitStacks or {}
--窗口Prefab栈
PrefabCache = PrefabCache or {}

MAX_CACHE_STACK_SIZE = 5
--Prefab最高缓存栈
MAX_PREFAB_CACHE_SIZE = 5

CacheLayer = nil
HintLayer = nil
-- BoardLayer = nil
MaskLayer = nil

UICanvas = nil
UIRect = nil
UICamera = nil
UIMessager = nil

--UI适配模式  Expand全拉伸 ExpandX横向拉伸 ExpandY纵向拉伸
FixMode = "Expand"

IgnoreWindowInStack = {"LoadSceneWindow"}


-- UI弹屏类控件
hint_box = hint_box
battle_report = battle_report
level_up = level_up

-- UI常驻型控件
top_banner = top_banner     --TopBanner Prefab
ui_tips = ui_tips

top_bar = nil

--IPHONEX 刘海偏移开关
IPHONEX_OFFSET_TOGGLE = false
IPHONEX_OFFSET_LEFT = 54
IPHONEX_OFFSET_RIGHT = 54
IPHONEX_OFFSET_TOP = 0
IPHONEX_OFFSET_BOTTOM = 0

function init(on_progress)
	local ui = GameObject.Find("UI")
    
	local ui_canvas = get_canvas().gameObject

	-- 创建UI分层容器
	local layer
	for i = 1, #UIConfig.Layers do
		layer = GameObject(UIConfig.Layers[i])
        layer:AddComponent(UnityEngine.RectTransform)
        layer.transform:SetParent(ui_canvas.transform, false)
        layer.transform.localPosition = Vector3.zero
        layer.transform.localScale = Vector3.one
        layer.transform.anchorMin = Vector2.zero
        layer.transform.anchorMax = Vector2.one
        layer.transform.offsetMax = Vector2.zero
        layer.transform.offsetMin = Vector2.zero
        layer.layer = ui_canvas.layer

        local layer_canvas = layer:AddComponent(Canvas)
        layer:AddComponent(GraphicRaycaster)
        layer_canvas.overrideSorting = true
        layer_canvas.sortingLayerName = UIConfig.Layers[i]
	end

	CacheLayer = ui_canvas.transform:Find(UIConfig.Layers[UIConfig.LayerType.Pool]).gameObject
    HintLayer = ui_canvas.transform:Find(UIConfig.Layers[UIConfig.LayerType.Hints]).gameObject
    BoardLayer = ui_canvas.transform:Find(UIConfig.Layers[UIConfig.LayerType.Board]).gameObject
    MaskLayer = ui_canvas.transform:Find(UIConfig.Layers[UIConfig.LayerType.Mask]).gameObject
    

    -- HINT
    local list_com = {
        "Common/HintBox",
        "Common/BattleReport",
        "Common/BuildLevelUp",
        "Common/TopBanner",
        "Common/TipsCard"
    }
    UIUtil.load_component(list_com, function(prefabs) 
        dump(prefabs, "prefabs : ", 99)
        hint_box = prefabs[1] 
        battle_report = prefabs[2]
        level_up = prefabs[3]
        top_banner = prefabs[4]
        ui_tips_prefab = prefabs[5]
    end)

	--UI全局监听事件
	UIMessager = Messager:new(UIManager)
    UIMessager:add_listener(Msg.SHOW_HINT, on_show_hint)
    UIMessager:add_listener(Msg.SHOW_NOTIFY, on_show_notify)
    UIMessager:add_listener(Msg.SHOW_GOLD_NOTIFY, on_show_gold_notify)
    UIMessager:add_listener(Msg.SHOW_BUILD_LV_UP, on_show_build_lv_up)
    UIMessager:add_listener(Msg.WORLD_MARCH_RESULT, on_world_march_result)
    --UIMessager:add_listener(Msg.RESOURCE_OR_COIN_CHANGE, on_res_change)
    UIMessager:add_listener(Msg.CITY_COLLECT_ANI, on_city_collect_ani)
    UIMessager:add_listener(Msg.SHOW_UI_TIPS, on_show_ui_tips)
    UIMessager:add_listener(Msg.TOP_BANNER_REWARDS_ANI, on_top_banner_rewards_ani)
end

function get_camera()
    if UICamera then return UICamera end
    UICamera = GameObject.Find("UI/UICamera"):GetComponent(Camera)
    return UICamera
end

function get_canvas()
    -- if UICanvas then return UICanvas end
    UICanvas = GameObject.Find("UI/Canvas"):GetComponent(Canvas)
    return UICanvas
end

function get_canvas_size()
    -- if UIRect then return UIRect end
    local ui_canvas = get_canvas()
    UIRect = ui_canvas.transform:GetComponent(RectTransform)
    return UIRect
end

--------------------------------------------------↓窗口逻辑↓--------------------------------------------------------
function open_window(window_name, on_complete, ...)
    if _G.GRichTextField then
        UIManager:init_top_banner()
    end
    local data = {...}
    local set = UIConfig.Settings[window_name]

    _open_window(window_name, on_complete, data)
end

--打开指定Window
function _open_window(window_name, on_complete, data)
	local set = UIConfig.Settings[window_name]
	if not set then
        elog("opening a non-existent window = "..window_name)
        return nil 
    end
	local count = #OrderStacks
	local layer_path = string.format("UI/Canvas/%s", UIConfig.Layers[set.layer])
	local layer_canvas_ = GameObject.Find(layer_path)
    -- 检查当前是否存在，存在则置顶层
    for i = count, 1, -1 do
        local win = OrderStacks[i]
        if win and win.window_name_ == window_name then
            elog("break same window = "..window_name..", It has been opened.")
            return
		end
	end
	--检查当前是否存在于缓存池，存在移至对应显示层
	local cur_target = nil
	for i = #CacheStacks, 1, -1 do
		if CacheStacks[i].window_name_ == window_name then
            cur_target = CacheStacks[i]
            if cur_target.transform.parent ~= layer_canvas_.transform then
                cur_target.transform:SetParent(layer_canvas_.transform, false)
            end
			cur_target.data = data
            cur_target.moved_to_pool_ = false
            table.insert(OrderStacks, cur_target)
			table.remove(CacheStacks, i)
			break
		end
    end
    
	--都不存在则加载UI
	if not cur_target then
		for _,v in ipairs(AwaitStacks) do
            local break_open = false
            if v.name == window_name then
                break_open = true
            elseif v.layer == set.layer then
                break_open = true
            end
            if break_open then return end
        end
		table.insert(AwaitStacks, set)
        local url_ = string.format("UI/Window/%s", window_name)
        local prefab = get_prefab_cache(window_name)
        log("try to load window = "..url_)
        if prefab then
            _load_window_resouce_coroutine(prefab, set, data, layer_canvas_, on_complete, window_name)
        else
            ResourcesManager.LoadObjectAsync(url_, function(obj)
                _load_window_resouce_coroutine(obj, set, data, layer_canvas_, on_complete, window_name)
                add_prefab_cache(window_name, obj)
            end)
        end
	else
        if cur_target.init_complete_ then
            cur_target.on_open_function_ = on_complete
            cur_target.on_open_parameter_ = cur_target
            cur_target:show()
            lock_lower_window(cur_target.window_name_)
        end
    end
end

--封装窗口加载回调函数
function _load_window_resouce_coroutine(obj, set, data, layer_canvas_, on_complete, window_name)
    if obj then
        --实例化Window Prefab
        local winobj = GameObject.Instantiate(obj)
        local canvas = winobj:GetComponent(UnityEngine.Canvas)
        if not canvas then
            canvas = winobj:AddComponent(UnityEngine.Canvas)
        end

        if not winobj:GetComponent(GraphicRaycaster) then
            winobj:AddComponent(GraphicRaycaster)
        end        
        local canvas_group = winobj:GetComponent(CanvasGroup)
        if not canvas_group then
            canvas_group = winobj:AddComponent(CanvasGroup)
        end

        --实例化Window控制器
        local wincpn = set.class:new(data)
        winobj.transform:SetParent(layer_canvas_.transform, false)
        winobj.name = set.name        
        wincpn.window_name_ = set.name
        wincpn.window_layer_ = set.layer
        wincpn.Config = set
        wincpn.on_open_function_ = on_complete
        wincpn.on_open_parameter_ = wincpn
        wincpn.win_depth_ = 0  -- uidepth,暂时保留
        wincpn.canvas_ = get_canvas()
        wincpn.canvas_.overrideSorting = true
        wincpn.canvas_.sortingLayerName = UIConfig.Layers[set.layer]
        wincpn.canvas_group_ = canvas_group

        -- 在去掉等待堆栈（AwaitStacks）的同时必须要加入逻辑堆栈（OrderStacks）里
        for i,v in ipairs(AwaitStacks) do
            if v.name == window_name then
                table.remove(AwaitStacks, i)
                break
            end
        end
        table.insert(OrderStacks, wincpn)
        lock_lower_window(set.name)
        wincpn:AddLuaComponent(winobj)
    else
        -- 加载失败则移除此界面
        for i,v in ipairs(AwaitStacks or {}) do
            if v.name == window_name then
                table.remove(AwaitStacks, i)
                elog("ResourcesManager.LoadObjectMultiAsync is loading failed for window’s name : %s", window_name)
                break
            end
        end
    end
end

function get_prefab_cache(window_name)
    for _, data in ipairs(PrefabCache) do
        if data[1] == window_name then
            return data[2]
        end
    end
end

function add_prefab_cache(window_name, prefab)
    local set = UIConfig.Settings[window_name]
    if set.cache then return end
    local size = #PrefabCache
    if size >= MAX_PREFAB_CACHE_SIZE then
        local cache = PrefabCache[1]
        cache[2] = nil
        table.remove(PrefabCache, 1)
    end
    table.insert(PrefabCache, {window_name, prefab})
end


function hide_active_window(win)
    local set = win.Config
    local layer = set.layer
    local count = #OrderStacks
    for i = count, 1, -1 do
        if OrderStacks[i].Config.layer == layer then
            if OrderStacks[i].window_name_ ~= set.name then
                OrderStacks[i]:hide()
                OrderStacks[i].gameObject:SetActive(false)
            end
        end
    end
    if win.on_open_function_ then
        win.on_open_function_(win.on_open_parameter_)
        win.on_open_function_ = nil
        win.on_open_parameter_ = nil
    end
end

--关闭指定Window
function close_window(window_name, window_layer, on_complete)
	local count = #OrderStacks
    if count == 0 then return end
    local layer_count = 0
    for i=count,1,-1 do
        local window = OrderStacks[i]
        if window and window.window_layer_ == window_layer then
            layer_count = layer_count + 1
        end
    end
    if layer_count == 1 then
        for i=count,1,-1 do
            local window = OrderStacks[i]
            if window and window.window_name_ == window_name then
                table.remove(OrderStacks, i)
                to_close_window(window)
                _move_to_pool(window)
                -- 恢复上层的canvasgroup
                local top_window = OrderStacks[i-1]
                lock_window(top_window, true)
                if top_window and not top_window.activeSelf then
                    top_window:show()
                else
                    if GameManager.UI_Main then
                        GameManager.UI_Main:set_top_banner()
                    end
                end
                
                if on_complete then
                    on_complete()
                end
            end
        end
    else
        back(on_complete)
    end
end

function to_close_window(window)
    if not window then
        elog("to_close_window window = nil, why? pls check data!")
    end
    window:to_close()
end

--移动window到缓存池
function _move_to_pool(window)
    window:hide()
    if window.Config.cache then
        window.transform.localScale = Vector3.one
        if window.gameObject then
            window.gameObject:SetActive(false)
        end
        window.moved_to_pool_ = true
        table.insert(CacheStacks, window)
        
        if #CacheStacks > MAX_CACHE_STACK_SIZE then
            local window = CacheStacks[1]
            Object.Destroy(window.gameObject)
            window:_dispose()
            table.remove(CacheStacks, 1)
        end
	else
        Object.Destroy(window.gameObject)
        window:_dispose()
	end
end

--后退
function back(on_complete)
	local count = #OrderStacks
    local idx=1
	for i = count, 1, -1 do
		local win = OrderStacks[i]
		if win and win.gameObject and win.gameObject.activeSelf and win.gameObject.name ~= "LoadSceneWindow" then
            local config = win.Config
            idx = i
            break
        end
    end

    local win = OrderStacks[idx]
    do_back(win, idx, on_complete)
end

function do_back(window, idx, on_complete)
    to_close_window(window)
    table.remove(OrderStacks, idx)

    _move_to_pool(window)

    local top = idx-1
    local top_window = OrderStacks[top]
    lock_window(top_window, true)
    if top_window and not top_window.activeSelf then
        top_window:show()
    else
        if GameManager.UI_Main then
            GameManager.UI_Main:set_top_banner()
        end
    end

    if on_complete then
        on_complete()
    end
end

function close_window_all(self, on_complete)
    local count = #OrderStacks
	for i = count, 1, -1 do
		local window = OrderStacks[i]
        to_close_window(window)
        table.remove(OrderStacks, i)
        _move_to_pool(window)
    end
    if GameManager.UI_Main then
        GameManager.UI_Main:set_top_banner()
    end
end

--锁定uiname下层所有Window
function lock_lower_window(window_name)
	local count = #OrderStacks
	for i=count,1,-1 do
		if OrderStacks[i] then
			if OrderStacks[i].window_name_ ~= window_name then
				lock_window(OrderStacks[i], false)
			else
				lock_window(OrderStacks[i], true)
			end
		end
	end
end

--锁定Window
function lock_window(window, lock)
	if window then
        if LuaUtils.table_find(IgnoreWindowInStack, window.Config.name) then
            return
        end
		local cpn = window.canvas_group_
		if cpn then
            if window.Config.layer == UIConfig.LayerType.Screen then
                cpn.blocksRaycasts = lock
            end
		end
	end
    local count = #OrderStacks
end

function get_window(window_name)
	local count = #OrderStacks
    for i = count, 1, -1 do
        local window = OrderStacks[i]
		if window and window.window_name_ == window_name and window.gameObject then
			return window
		end
	end
	return nil
end

function clear_cached_resource()
    clear_pool()
    clear_prefab_cache()
end

--清空UI缓存池(根据UI资源集划分考虑何时清空，如主场景和战斗)
function clear_pool()
    for _, window in ipairs(CacheStacks) do
        Object.Destroy(window.gameObject)
        window:_dispose()
	end
	CacheStacks = {}
    log("CLEAR UI POOL!!")
end
function clear_prefab_cache()
    for _, data in ipairs(PrefabCache) do
        data[2] = nil
    end
    PrefabCache = {}
    log("CLEAR UI PREFAB CACHE!!")
end
--------------------------------------------------↑窗口逻辑↑--------------------------------------------------------

------------------------------------------------↓battle_report↓------------------------------------------------------
function init_battle_report()
    local go = GameObject.Instantiate(battle_report)
    go.transform:SetParent(HintLayer.transform, false)
    go:SetActive(true)
    local br = BattleReport:new(self)
    br:AddLuaComponent(go)
    br:init()
    br.gameObject:SetActive(false)
    return br
end

function on_world_march_result(self, data)
    if not battle_report_list then
        battle_report_list = {}
    end
    table.insert(battle_report_list, data)
    if battle_report_play then return end
    local data_tmp = battle_report_list[1]
    table.remove(battle_report_list, 1)
    play_battle_result(data_tmp)    
end

function play_battle_result(data)
    battle_report_play = true
    local br_go = init_battle_report()
    local rect = br_go.transform:GetComponent(RectTransform)
    local canvas_group = br_go.transform:GetComponent(CanvasGroup)
    canvas_group.alpha = 1
    rect.anchoredPosition = Vector2(rect.sizeDelta.x, rect.anchoredPosition.y)
    br_go.gameObject:SetActive(true)
    br_go:set_data(data)
    GameTween.DOAnchorPosX(rect, 0, 0.3, true)
    GameTween.DOFade(canvas_group, 0, 1):SetDelay(3):OnComplete(function() 
        battle_report_play = false
        GameObject.Destroy(br_go.gameObject)
        if #battle_report_list >= 1 then
            local data_tmp = battle_report_list[1]
            table.remove(battle_report_list, 1)
            play_battle_result(data_tmp)
        end
    end)
end
--------------------------------------------------↓hint_box↓--------------------------------------------------------
function on_show_hint(self, content, horizontal, fix_pos)
	local obj = GameObject.Instantiate(hint_box)
    obj.transform:SetParent(HintLayer.transform, false)
    local hint = HintBox:new()
    hint:AddLuaComponent(obj) 
    hint:set_data(content, horizontal, fix_pos)
end

function on_show_notify(self, obj)
    local win = UIManager.get_window("NotifyWindow")
    if win then
        NotifyWindow.push_data(obj)
    else
        UIManager.open_window("NotifyWindow", nil, obj)
    end
end

function on_show_gold_notify(self, obj)
    local win = UIManager.get_window("NotifyGoldWindow")
    if win then
        --NotifyGoldWindow.push_data(obj)
    else
        UIManager.open_window("NotifyGoldWindow", nil, obj)
    end
end

--------------------------------------------------↓level_up↓--------------------------------------------------------
function on_show_build_lv_up(self, id)
    local obj = GameObject.Instantiate(level_up)
    obj.transform:SetParent(HintLayer.transform, false)
    local lv_up = BuildLevelUp:new()
    lv_up:AddLuaComponent(obj)
    lv_up:set_data(id)
end


--------------------------------------------------↓top_banner↓--------------------------------------------------------
function init_top_banner(self)
    self.top_bar = TopBanner:new()    
    _G.dump(top_banner, "top_banner : ", 99)
    self.top_bar:AddLuaComponent(GameObject.Instantiate(top_banner))
    self.top_bar:init()
end

function on_res_change(self, data)
    if _G.FairyGUI then
        return
    end
    if self.top_bar then
        self.top_bar:on_res_change(data)
    end
end

function on_city_collect_ani(self, build_id, count, res_type)
    if self.top_bar then
        self.top_bar:on_city_collect(build_id, count, res_type)
    end
end

function on_top_banner_rewards_ani(self, rewards)
    if self.top_bar then
        self.top_bar:play_rewards_animation(rewards)
    end
end

function refresh_current_window_title(self)
    if self.top_bar then
        self.top_bar:refresh_title()
    end
end

function maintain_top_banner(self)
    if self.top_bar then
        self.top_bar:maintain_top()
    end
end

function set_back_function(self, func)
    if self.top_bar then
        self.top_bar:set_back_function(func)
    end
end

function remove_back_function(self)
    if self.top_bar then
        self.top_bar:remove_back_function()
    end
end

function set_info_callback(self, window, func)
    if self.top_bar then
        self.top_bar:set_info_callback(window, func)
    end
end

function remove_info_callback(self, window)
    if self.top_bar then
        self.top_bar:remove_info_callback(window)
    end
end

--------------------------------------------------↓tips_cards↓--------------------------------------------------------
function on_show_ui_tips(self, isshow, trans, data, tipsType)
    local func = function()
        if isshow then
            ui_tips:show_content(trans, data, tipsType)
        end
        if ui_tips.gameObject.activeSelf ~= isshow then
            ui_tips.gameObject:SetActive(isshow)
        end
    end
    if ui_tips then
        func()
    else
        if isshow then
            load_tips_card(func)
        end
    end
end

function load_tips_card(callback)
    local tips_card = GameObject.Instantiate(ui_tips_prefab)
    tips_card.transform:SetParent(MaskLayer.transform, false)
    tips_card:SetActive(true)
    ui_tips = TipsCard:new()
    ui_tips:AddLuaComponent(tips_card)
    ui_tips.gameObject:SetActive(false)
    if callback then
        callback()
    end
end
