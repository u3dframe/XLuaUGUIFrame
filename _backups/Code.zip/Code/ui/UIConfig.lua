module("UIConfig", package.seeall)

require("ui/window/login_window")
require("ui/window/test_window1")
require("ui/window/test_window2")
require("ui/window/test_window3")
require("ui/window/test_battle_data_window")
require("ui/window/world_axis_window")
require("ui/window/world_monster_info_window")
require("ui/window/world_troops_window")
require("ui/window/build_create_window")
local BuildCreateWindow = require("ui/window/build_create_window")
local BuildSpendWindow = require("ui/window/build_spend_window")
local BuildDetailsWindow = require("ui/window/build_details_window")
require("ui/window/notify_window")
require("ui/window/city_soldier_window")
require("ui/window/city_hospital_window")
require("ui/window/soldier_promote_window")
require("ui/window/soldier_details_window")
require("ui/window/soldier_kick_window")
require("ui/window/speedup_window")
require("ui/window/load_scene_window")
require("ui/window/hero_grow_window")
require("ui/window/hero_list_window")
require("ui/window/item_list_window")
require("ui/window/popup_window")
require("ui/window/item_journey_speed_window")
require("ui/window/item_journey_return_window")
require("ui/window/item_respoint_window")
require("ui/window/notify_item_window")
require("ui/window/item_use_count_window")
require("ui/window/item_use_select_window")
require("ui/window/item_gain_reward_window")
require("ui/window/world_journey_info_window")
require("ui/window/notify_glod_window")
require("ui/window/world_fort_info_window")
require("ui/window/world_fort_reward_window")
require("ui/window/world_respoint_window")
require("ui/window/world_respoint_desc_window")
require("ui/window/mail_window")
require("ui/window/mail_list_window")
require("ui/window/hero_details_window")
local HeroChipExchangeWindow = require("ui/window/hero_chip_exchange_window")
local HeroAnimeWindow = require("ui/window/hero_anime_window")
local HerolevelupdirWindow = require("ui/window/hero_levelupdir_window")
require("ui/window/hero_troops_window")
local ComponentModeWindow = require("ui/window/component_mode_window")
local CityRandomShopWindow = require("ui/window/city_random_shop_window")
local RandomShopRewardWindow = require("ui/window/random_shop_reward_window")

require("ui/component/world_menu")
require("ui/component/battle_report")
require("ui/component/build_menu")
require("ui/component/city_space")
require("ui/component/hint_box")
require("ui/component/bill_board")
require("ui/component/top_banner")
require("ui/component/build_level_up")
require("ui/component/tips_card")
require("ui/component/item_card")
require("ui/component/hero/hero_info")
require("ui/component/hero/hero_card")
require("ui/component/hero/hero_card_list")
require("ui/component/hero/hero_star")
require("ui/component/hero/hero_level")


require("ui/plugins/plugin_pointer")

LayerType = {
    Pool = 1,           -- 缓存池
    Board = 2,          -- 广告牌
    Main = 3,           -- 常驻UI    
    Screen = 4,         -- 全屏窗口UI
    Window = 5,         -- 弹出窗口UI
    Popup = 6,          -- 局部弹出框
    Hints = 7,          -- 小提示
    Mask = 8,           -- 遮罩层
    Guide = 9,          -- 引导层
}


Layers = {
    "pool",
    "board",
    "main",    
    "screen",
    "window",
    "popup",
    "hints",
    "mask",
    "guide",
}

-- UI设置
Settings = Settings or {}

--------------------------------------
-- @FuncName：add_setting
-- @Function：添加界面关系映射表
-- @param：window_name   窗口名字
-- @param：window_class  窗口类名
-- @param：window_layer  窗口所在层
-- @param：winCache      窗口是否被缓存
-- @param：winMask       窗口背景可点击关闭
--------------------------------------
function add_setting(window_name, window_class, window_layer, winCache, winMask)
    Settings[window_name] = {}
    local set = Settings[window_name]
    --UI Prefab名称
    set.name = window_name
    --UI控制类
    set.class = window_class
    --所在层次
    set.layer = window_layer
    --是否缓存UI
    set.cache = winCache
    --是否Mask可点击
    set.mask = winMask
end

function init_setting()
    -- 全屏窗口
    add_setting("LoginWindow", LoginWindow, LayerType.Screen, false)
    add_setting("TestWindow1", TestWindow1, LayerType.Screen, false)
    add_setting("TestWindow2", TestWindow2, LayerType.Screen, false)
    add_setting("TestBattleDataWindow", TestBattleDataWindow, LayerType.Screen, false)
    add_setting("WorldTroopsWindow", WorldTroopsWindow, LayerType.Screen, false)
    add_setting("BuildCreateWindow", BuildCreateWindow, LayerType.Screen, false)
    add_setting("BuildSpendWindow", BuildSpendWindow, LayerType.Screen, false)
    add_setting("BuildDetailsWindow", BuildDetailsWindow, LayerType.Screen, false)
    add_setting("CitySoldierWindow", CitySoldierWindow, LayerType.Screen, false) 
    add_setting("CityHospitalWindow", CityHospitalWindow, LayerType.Screen, false)
    add_setting("HeroGrowWindow", HeroGrowWindow, LayerType.Screen, false)
    add_setting("HeroListWindow", HeroListWindow, LayerType.Screen, false) 
    add_setting("ItemListWindow", ItemListWindow, LayerType.Screen, false) 
    add_setting("MailWindow", MailWindow, LayerType.Screen, false)
    add_setting("MailListWindow", MailListWindow, LayerType.Screen, false)
    add_setting("ComponentModeWindow", ComponentModeWindow, LayerType.Screen, false)
    add_setting("CityRandomShopWindow", CityRandomShopWindow, LayerType.Screen, false)
    -- 弹出窗口
    add_setting("TestWindow3", TestWindow3, LayerType.Window, false, true)
    add_setting("WorldAxisWindow", WorldAxisWindow, LayerType.Window, false, true)
    add_setting("WorldMonsterInfoWindow", WorldMonsterInfoWindow, LayerType.Window, false, true)
    add_setting("NotifyWindow", NotifyWindow, LayerType.Window, false, true)
    add_setting("LoadSceneWindow", LoadSceneWindow, LayerType.Mask, false, false)
    add_setting("PopupWindow", PopupWindow, LayerType.Popup, false, false)
    add_setting("ItemJourneySpeedWindow", ItemJourneySpeedWindow, LayerType.Window, false, true)
    add_setting("ItemJourneyReturnWindow", ItemJourneyReturnWindow, LayerType.Window, false, true)
    add_setting("ItemRespointWindow", ItemRespointWindow, LayerType.Window, false, true)
    add_setting("WorldJourneyInfoWindow", WorldJourneyInfoWindow, LayerType.Window, false, true)
    add_setting("SpeedUpWindow", SpeedUpWindow, LayerType.Window, false, true)
    add_setting("NotifyItemWindow", NotifyItemWindow, LayerType.Window, false, true)
    add_setting("SoldierPromoteWindow", SoldierPromoteWindow, LayerType.Window, false, true)
    add_setting("SoldierDetailsWindow", SoldierDetailsWindow, LayerType.Window, false, true)
    add_setting("SoldierKickWindow", SoldierKickWindow, LayerType.Window, false, true)
    add_setting("ItemUseCountWindow", ItemUseCountWindow, LayerType.Window, false, true)
    add_setting("ItemUseSelectWindow", ItemUseSelectWindow, LayerType.Window, false, true)
    add_setting("ItemGainRewardWindow", ItemGainRewardWindow, LayerType.Window, false, true)
    add_setting("NotifyGoldWindow", NotifyGoldWindow, LayerType.Window, false, true)
    add_setting("WorldFortInfoWindow", WorldFortInfoWindow, LayerType.Window, false, true)
    add_setting("WorldFortRewardWindow", WorldFortRewardWindow, LayerType.Window, false, true)
    add_setting("WorldRespointWindow", WorldRespointWindow, LayerType.Window, false, true)
    add_setting("WorldRespointDescWindow", WorldRespointDescWindow, LayerType.Window, false, true)
    add_setting("HeroDetailsWindow", HeroDetailsWindow, LayerType.Window, false, true)
    add_setting("HeroChipExchangeWindow", HeroChipExchangeWindow, LayerType.Window, false, true)
    add_setting("HeroAnimeWindow", HeroAnimeWindow, LayerType.Window, false, true)
    add_setting("HerolevelupdirWindow", HerolevelupdirWindow, LayerType.Window, false, true)
    add_setting("HeroTroopsWindow", HeroTroopsWindow, LayerType.Window, false, true)
    add_setting("RandomShopRewardWindow", RandomShopRewardWindow, LayerType.Window, false, true)
    add_setting("RandomShopInfoWindow", RandomShopInfoWindow, LayerType.Window, false, true)
end

function init(on_progress)
    init_setting()
    UIManager.init(on_progress)
end
