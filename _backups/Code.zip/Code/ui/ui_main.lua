module("UIMain",package.seeall)
local BasicConfig = _G.Database.BasicConfig
local Role =_G.Model.GetModel("Role")
setmetatable( UIMain, {__index = BaseComponent} )

function on_awake(self)
	self.messager_ = Messager:new(self)
end

function init(self)
    self.city_panel_ = self.transform:Find("CitydPanel")
    self.world_panel_ = self.transform:Find("WorldPanel")
    
    -- world
    self.world_axis_txt_ = self.transform:Find("WorldPanel/AxisPanel/WorldAxisTxt"):GetComponent(Text)
    self:set_axis_value()
    self.btn_zoom_ = self.transform:Find("WorldPanel/AxisPanel"):GetComponent(Button)
    self:add_event_handler(self.btn_zoom_.onClick, on_click_zoom_handler)
    self.menu_panel_ = self.transform:Find("WorldPanel/MenuPanel")
    self.battle_queue_ = self.transform:Find("WorldPanel/BattleQueue")
    self.battle_energy_txt_ = self.transform:Find("WorldPanel/BattleQueue/EnergyTxt"):GetComponent(Text)
    self.battle_queue_go_ = {}
    self.bar_timer_ = {}
    self.bar_ani_ = {}
    self.battle_queue_desc_ = self.transform:Find("WorldPanel/BattleQueue/TitlePanel/Text"):GetComponent(Text)
    local cur_queue = WorldManager:get_march_queue_num()
    self.battle_queue_desc_.text = lang("UI_MAIN_MARCH_QUEUE",
        cur_queue, WorldManager:get_army_num() - cur_queue)
    self.track_ = self.transform:Find("WorldPanelTop/TrackPanel/Track").gameObject
    self.track_rect_ = self.transform:Find("WorldPanelTop/TrackPanel/Track"):GetComponent(RectTransform)
    self.track_arrow_ = self.transform:Find("WorldPanelTop/TrackPanel/Track/ArrowImg")
    self.track_txt_ = self.transform:Find("WorldPanelTop/TrackPanel/Track/Text"):GetComponent(Text)
    self.track_btn_ = self.transform:Find("WorldPanelTop/TrackPanel/Track"):GetComponent(Button)
    self:add_event_handler(self.track_btn_.onClick, on_click_main_city)
    self.screen_size_ = UIManager.get_canvas_size()
    
    -- city
    self.timer_obj_1_ = self.transform:Find("CitydPanel/BuildQueue/Build01/TimeBg")
    self.timer_obj_1_.gameObject:SetActive(false)
    self.timer_obj_2_ = self.transform:Find("CitydPanel/BuildQueue/Build02/TimeBg")
    self.timer_obj_2_.gameObject:SetActive(false)
    self.timer_img_1_ = self.timer_obj_1_:Find("Bar"):GetComponent(Image)
    self.timer_img_1_.gameObject:SetActive(false)
    self.timer_img_2_ = self.timer_obj_2_:Find("Bar"):GetComponent(Image)
    self.timer_img_2_.gameObject:SetActive(false)
    self.timer_txt_1_ = self.timer_obj_1_:Find("Text"):GetComponent(Text)
    self.timer_txt_2_ = self.timer_obj_2_:Find("Text"):GetComponent(Text)
    self.queue_1_ = self.transform:Find("CitydPanel/BuildQueue/Build01/Background/Image")
    self.queue_2_ = self.transform:Find("CitydPanel/BuildQueue/Build02/Background/Image")
    self.queue1_btn_ = self.transform:Find("CitydPanel/BuildQueue/Build01/Background"):GetComponent(Button)
    self.queue2_btn_ = self.transform:Find("CitydPanel/BuildQueue/Build02/Background"):GetComponent(Button)
    self.activity_parent_ = self.transform:Find("CitydPanel/ActivityPanel/ActivityGroup")
    self.activity_down_ = self.transform:Find("CitydPanel/ActivityPanel/ActivityGroup/ArrowDown"):GetComponent(Button)
    self.activity_up_ = self.transform:Find("CitydPanel/ActivityPanel/ActivityGroup/ArrowUp"):GetComponent(Button)
    self:add_event_handler(self.activity_down_.onClick, on_activity_arrow_handler, false)
    self:add_event_handler(self.activity_up_.onClick, on_activity_arrow_handler, true)
    self.activity_down_.gameObject:SetActive(false)

    self:add_event_handler(self.queue1_btn_.onClick, on_click_queue_handler, config.BUILDING_QUEUE_FIRST)
    self:add_event_handler(self.queue2_btn_.onClick, on_click_queue_handler, config.BUILDING_QUEUE_SECOND)
    self.quest_btn_ = self.transform:Find("CitydPanel/BottomPanel/QuestBtn"):GetComponent(Button)
    self:add_event_handler(self.quest_btn_.onClick, on_click_quest_handler)
    self.shop_btn_ = self.transform:Find("CitydPanel/ActivityPanel/ShopBtn"):GetComponent(Button)
    self:add_event_handler(self.shop_btn_.onClick, on_click_show_unopen)
    self.activity_btn_ = self.transform:Find("CitydPanel/ActivityPanel/ActivityGroup/ActivityBtn"):GetComponent(Button)
    self:add_event_handler(self.activity_btn_.onClick, on_click_show_unopen)
    self.welfare_btn_ = self.transform:Find("CitydPanel/ActivityPanel/ActivityGroup/WelfareBtn"):GetComponent(Button)
    self:add_event_handler(self.welfare_btn_.onClick, on_click_show_unopen)
    
    -- share
    self.player_panel_ = self.transform:Find("SharePanel/PlayerPanel")
    self.player_btn_ = self.player_panel_:Find("HeadGroup"):GetComponent(Button)
    self:add_event_handler(self.player_btn_.onClick, on_click_player_head)    
    self.exp_bar_ = self.player_panel_:Find("HeadGroup/BarGroup/Exp"):GetComponent(Image)
    self.energy_bar_ = self.player_panel_:Find("HeadGroup/BarGroup/Energy"):GetComponent(Image)
    self.energy_txt_ = self.player_panel_:Find("HeadGroup/BarGroup/EnergyTxt"):GetComponent(Text)
    
    self.hero_btn_ = self.transform:Find("SharePanel/Bottom/BtnGroup/HeroBtn"):GetComponent(Button)
	self:add_event_handler(self.hero_btn_.onClick, on_click_hero_handler)
    self.mail_btn_ = self.transform:Find("SharePanel/Bottom/BtnGroup/MailBtn"):GetComponent(Button)
    self:add_event_handler(self.mail_btn_.onClick, on_click_mail_handler)
    self.item_btn_ = self.transform:Find("SharePanel/Bottom/BtnGroup/ItemBtn"):GetComponent(Button)
    self.league_btn_ = self.transform:Find("SharePanel/Bottom/BtnGroup/LeagueBtn"):GetComponent(Button)
    self.more_btn_ = self.transform:Find("SharePanel/Bottom/BtnGroup/MoreBtn"):GetComponent(Button)
    self:add_event_handler(self.item_btn_.onClick, on_click_bag_handler)
    self:add_event_handler(self.league_btn_.onClick, on_click_show_unopen)
    
    self:add_event_handler(self.more_btn_.onClick, on_click_relogin)
    
    -- share top_banner
    UIManager:init_top_banner()
    self:set_top_banner()
    
    self.enter_btn_ = self.transform:Find("SharePanel/Bottom/BackBtn"):GetComponent(Button)
    self.out_btn_ = self.transform:Find("SharePanel/Bottom/OutBtn"):GetComponent(Button)
    self:add_event_handler(self.enter_btn_.onClick, on_click_enter_city)
    self:add_event_handler(self.out_btn_.onClick, on_click_enter_world)
	self.messager_:add_listener(Msg.SCENE_UPDATE, on_update_scene)
    self.messager_:add_listener(Msg.WORLD_MARCH_BAR, on_world_march_bar)
    self.messager_:add_listener(Msg.WORLD_MARCH_END, on_world_march_end)
    self.messager_:add_listener(Msg.CITY_HIDE_UI_ALL, on_hide_ui_all)
    self.messager_:add_listener(Msg.CITY_UP_LV_FINISHED, on_up_lv_finished)
    self.messager_:add_listener(Msg.ENERGY_REFRESH, on_refresh_energy)
    self.messager_:add_listener(Msg.ENERGY_CHANGE, on_refresh_change)
    self.messager_:add_listener(Msg.CITY_QUEUE_UPDATE, on_updata_build_queue)
    self.messager_:add_listener(Msg.CITY_BUILD_REMOVED_CANCEL, on_build_removed_finish)
    self.messager_:add_listener(Msg.CITY_BUILD_REMOVED_FINISHED, on_build_removed_finish)
    self.messager_:add_listener(Msg.CITY_OVER, OnCityOver)
    self.messager_:add_listener(Msg.CITY_REBUILD, OnCityRebuild)
    self:on_open()
end

function set_top_banner(self)
    UIManager.top_bar:set_window(self)
end

function on_open(self)
    self:set_player_data()
    self:on_refresh_energy()
    self:on_update_scene()
    self:on_updata_build_queue()
end

function on_dispose(self)
    if self.bar_timer_ then
        for k,v in pairs(self.bar_timer_) do
            LuaTimer.Delete(v)
        end
    end
    --卸载动画
    for k, v in pairs(self.tween_tb_) do
        if v.tween_scale_ then
            v.tween_scale_:Kill(false)
        end
        if v.tween_rotate_ then
            v.tween_rotate_:Kill(false)
        end
    end
    self.tween_tb_ = nil
    --取消监听
    self.messager_:remove_listener(Msg.CITY_UP_LV_FINISHED)
end

function set_player_data(self)
    self.exp_bar_.fillAmount = 0.5
end

function on_refresh_energy(self)
    self.energy_bar_.fillAmount = MasterManager:get_energy_percent()
    self.energy_txt_.text = string.format("%d/%d", MasterManager.user_.energy_,
        BasicConfig.BasicData.emergy_full[1])
end

function on_refresh_change(self, data)
    -- 自然恢复的体力，这里不坐显示
    if data == 1 then return end
    if self.energy_tween1_ then
        self.energy_tween1_:Kill(false)
    end
    if self.energy_tween2_ then
        self.energy_tween2_:Kill(false)
    end 
    local rect = self.battle_energy_txt_.transform:GetComponent(RectTransform)
    rect.anchoredPosition = Vector2(0, 0)
    if data > 0 then
        self.battle_energy_txt_.text = "+"..data
        self.battle_energy_txt_.color = Color(0, 1, 0, 1)
    else
        self.battle_energy_txt_.text = "-"..data
        self.battle_energy_txt_.color = Color(1, 0, 0, 1)
    end
    
    
    self.energy_tween1_ = GameTween.DOFade(self.battle_energy_txt_, 0, 0.5):SetDelay(2)
    self.energy_tween2_ = GameTween.DOAnchorPosX(rect, 100, 3, true)
end

function on_update_scene(self)
    if not self:is_alive() then return end
    if SceneManager.Scene_Tags.City==SceneManager.Local_Scene then
        BgmManager.Play("Audio/Bgm/city")
        self.track_:SetActive(false)
    elseif SceneManager.Scene_Tags.World==SceneManager.Local_Scene then
        BgmManager.Play("Audio/Bgm/world")
    end
    self.enter_btn_.gameObject:SetActive(SceneManager.Scene_Tags.World==SceneManager.Local_Scene)
    self.out_btn_.gameObject:SetActive(SceneManager.Scene_Tags.City==SceneManager.Local_Scene)
    self.city_panel_.gameObject:SetActive(SceneManager.Scene_Tags.City==SceneManager.Local_Scene)
	self.world_panel_.gameObject:SetActive(SceneManager.Scene_Tags.World==SceneManager.Local_Scene)
end

function on_updata_build_queue(self)
    self.tween_tb_ = self.tween_tb_ or {}
    for i = 1, config.BUILDING_QUEUE_MAX do
        --初始化动画
        self.tween_tb_[i] = self.tween_tb_[i] or {}
        local bg_obj = self.transform:Find("CitydPanel/BuildQueue/Build0"..i.."/Background"):GetComponent(Image)
        local icon_obj = self.transform:Find("CitydPanel/BuildQueue/Build0"..i.."/Background/Image"):GetComponent(Image)
        local timer_obj = self.transform:Find("CitydPanel/BuildQueue/Build0"..i.."/TimeBg")
        if not self.tween_tb_[i].tween_scale_ then
            self.tween_tb_[i].tween_scale_ =  GameTween.DOScale(icon_obj.transform, 0.9, 2):SetLoops(-1, 1)
        end
        if not self.tween_tb_[i].tween_rotate_ then
            self.tween_tb_[i].tween_rotate_ = XSequence()
            self.tween_tb_[i].tween_rotate_
                :Append(GameTween.DOLocalRotate(icon_obj.transform, Vector3(0, 0, -10), 0.15, 0):SetEase(8):SetLoops(4, 1))
                :AppendInterval(1)
                :SetLoops(-1, 0)
            self.tween_tb_[i].tween_rotate_:Pause()
        end
        --刷新队列
        if BuildManager:is_unlock_queue(i) then
            -- if bg_obj.gameObject.activeInHierarchy and icon_obj.gameObject.activeInHierarchy then
            --     UIUtil.set_sprite("UI/Window/main/city/queue_board_free", bg_obj)
            --     UIUtil.set_sprite("UI/Window/main/city/queue_icon_free", icon_obj)
            -- end
            if BuildManager:is_free_queue(i) then
                timer_obj.gameObject:SetActive(false)
                self.tween_tb_[i].tween_scale_:Play()
                self.tween_tb_[i].tween_rotate_:Pause()
                icon_obj.transform.localRotation = Vector3.zero
            elseif BuildManager:is_busy_queue(i) then
                timer_obj.gameObject:SetActive(true)
                self.tween_tb_[i].tween_scale_:Pause()
                icon_obj.transform.localScale = Vector3.one
                self.tween_tb_[i].tween_rotate_:Play()
            end
        else
            -- if bg_obj.gameObject.activeInHierarchy and icon_obj.gameObject.activeInHierarchy then
            --     UIUtil.set_sprite("UI/Window/main/city/queue_board_busy", bg_obj)
            --     UIUtil.set_sprite("UI/Window/main/city/queue_icon_busy", icon_obj)
            -- end
            timer_obj.gameObject:SetActive(false)
            self.tween_tb_[i].tween_scale_:Pause()
            self.tween_tb_[i].tween_rotate_:Pause()
            icon_obj.transform.localScale = Vector3.one
            icon_obj.transform.localRotation = Vector3.zero
        end
    end
end

--队列
Check_Queue = {
    [config.BUILDING_QUEUE_FIRST] = function(self)
        return self.queue_1_, self.timer_obj_1_, self.timer_img_1_, self.timer_txt_1_
    end,

    [config.BUILDING_QUEUE_SECOND] = function(self)
        return self.queue_2_, self.timer_obj_2_, self.timer_img_2_, self.timer_txt_2_
    end,
}

function on_update_queue_timer(self, curr_time, img_vlaue, queue_id)
    if not self.Check_Queue[queue_id] then return end
    local obj, timer_obj, timer_img, timer_txt = self.Check_Queue[queue_id](self)
    if self.tween_tb_[queue_id].tween_scale_:IsPlaying() then
        self.tween_tb_[queue_id].tween_scale_:Pause()
        obj.transform.localScale = Vector3.one
    end
    if not self.tween_tb_[queue_id].tween_rotate_:IsPlaying() then
        self.tween_tb_[queue_id].tween_rotate_:Play()
    end

    timer_obj.gameObject:SetActive(curr_time >= 0)
    timer_img.gameObject:SetActive(curr_time >= 0)
    timer_img.fillAmount = img_vlaue
    timer_txt.text = UIUtil.format_time(curr_time)
end

function on_up_lv_finished(self, id)
    self:on_updata_build_queue()
end

function on_build_removed_finish(self)
    self:on_updata_build_queue()
end

function OnCityOver(self)
    UIManager.open_window("RebuildHintWindow")
end

function on_click_queue_handler(self, event_data, queue_id)
    -- 定位到建筑视角
    if BuildManager:is_free_queue(queue_id) then
        local build = BuildManager:get_build_by_priority()
        if build and build.id_ then
            if _G.SceneManager.City_Scene then
                local space = SceneManager.City_Scene:get_space_by_build_id(build.id_)
                SceneManager.City_Scene:locate_obj_to_screen_center(space)
            end
            space:show_build_menu()
            return
        end
    elseif BuildManager:is_busy_queue(queue_id) then
        local build_id = BuildManager:get_build_id_by_queue_id(queue_id)
        if build_id then
            if _G.SceneManager.City_Scene then
                local space = SceneManager.City_Scene:get_space_by_build_id(build_id)
                SceneManager.City_Scene:locate_obj_to_screen_center(space)
            end
            space:show_build_menu()
            return
        end
    end
    if queue_id == config.BUILDING_QUEUE_SECOND then
        local is_unlock = BuildManager:is_unlock_queue(queue_id)
        if not is_unlock then
            local queue_info = BasicConfig.BasicData.goldcoin_queue

            -- 如果有道具先使用道具 其次使用金币
            local content
            local queue_item = ItemManager:get_queue_item()

            local button_info

            if queue_item then
                button_info = lang("UI_BASIC_SURE") -- 有道具不显示金币
                content = lang("UI_MAIN_UNLOCK_QUEUE_BY_ITEM", queue_item.prop_.name)
            else
                local days = BuildManager:get_days_by_gold(queue_info[1])
                button_info = {lang("UI_BASIC_SURE"), queue_info[1]}  -- 无道具显示金币
                content = lang("UI_MAIN_UNLOCK_QUEUE_BY_GOLD", queue_info[1], days)
            end
            local msg_ = {}
            msg_.content = content
            msg_.buttons = {
                lang("UI_BASIC_CANCEL"),
                button_info,
            }
            msg_.callback = function(index)
                if index == 2 then
                    Net.send("mainqueue_single_add", nil, function(result)
                        if result.e == 0 then
                            self:on_updata_build_queue()
                        elseif result.e == 2 then
                            MsgCenter.send_message(Msg.SHOW_HINT, lang("ITEM_NOT_ENOUGH"))
                        end
                    end)
                end
            end
            MsgCenter.send_message(Msg.SHOW_GOLD_NOTIFY, msg_)
        end
    end
end

function on_click_enter_city(self)
    AudioManager.Play("SOUND_BUTTON_CHANGE")
    SceneManager.enter_city(function() 
        self:on_open()
    end)
end

function on_click_enter_world(self)
    AudioManager.Play("SOUND_BUTTON_CHANGE")
    SceneManager.enter_world(function()
        WorldManager:build_world_obj()
        WorldManager:init_watch_pos()
    end)
end

--重建城池
function OnCityRebuild()
    AudioManager.Play("SOUND_BUTTON_CHANGE")
    SceneManager.enter_world(function()
        WorldManager:build_world_obj()
        WorldManager:init_watch_pos()
    end)
end

function on_click_zoom_handler(self)
    AudioManager.Play("SOUND_BUTTON_COMMON")
    UIManager.open_window("WorldAxisWindow", nil, self.world_x_ or 0, self.world_z_ or 0)
end

function updata_track_position_ex(self)
    if not self.track_.activeSelf then return end
    if not WorldManager.main_position_ then return end
    local width = self.screen_size_.sizeDelta.x/2
    local height = self.screen_size_.sizeDelta.y/2
    local world_pos = WorldManager.main_position_
    local pos_tmp = Camera.main:ScreenToWorldPoint(Vector3(width, height, 30/math.sin(math.rad(30))))
    local pos = Vector3(UIUtil.get_precise_decimal(pos_tmp.x, 2), 
        UIUtil.get_precise_decimal(pos_tmp.y, 2), UIUtil.get_precise_decimal(pos_tmp.z, 2))
    local a = Vector2(0, 1)
    local b = Vector2(world_pos.x - pos.x, world_pos.z - pos.z)
    local vec = math.floor(Vector2.SignedAngle(b.normalized, a.normalized))
    self.track_arrow_.transform.rotation = Quaternion.Euler(0, 0, -vec)
    local screen_width = width - 60
    local screen_hight = height - 100
    -- WORLD_CAMERA_ANGLE 这里计算了摄像机角度
    local vec_tmp = 1.732
    if math.abs(vec) > 90 then vec_tmp = -1.732 end
    local xx = math.tan(math.rad(vec)) * screen_hight * vec_tmp
    if xx > screen_width then xx = screen_width end
    if xx < -screen_width then xx = -screen_width end
    vec_tmp = 0.577
    if vec > 0 then vec_tmp = -0.577 end
    local zz = math.tan(math.rad(vec+90)) * screen_width * vec_tmp
    if zz > screen_hight then zz = screen_hight end
    if zz < -screen_hight then zz = -screen_hight end
    self.track_rect_.anchoredPosition = Vector2(xx, zz)
end

function set_axis_value(self, x, z)
    if not x then return end
    if not z then return end
    self.world_x_ = x
    self.world_z_ = z
    local value = string.format("(%d, %d)", x, z)
    if not value then
        self.world_axis_txt_.text = ""
        return 
    end
    self.world_axis_txt_.text = value
    -- 算坐标跟踪箭头
    if self:is_main_city_in_screen() then
        self.track_:SetActive(false)
    else
        self.track_:SetActive(true)
        local distance = math.floor(math.sqrt(math.pow(WorldManager.main_logic_x_ - x,2) + math.pow(WorldManager.main_logic_z_ - z,2)))
        self.track_txt_.text = lang("UI_MONSTERINFO_DISTANE", distance)  
    end
end

function is_main_city_in_screen(self)
    local x, z = WorldManager.main_logic_x_, WorldManager.main_logic_z_
    local build = WorldBuildTmp:get_build(x, z)
    if not build then
        local obj = WorldManager:get_world_obj(x, z)
        -- 如果未加载完成，切距离很近，则表示在屏幕内
        local distance = math.floor(math.sqrt(math.pow(x - self.world_x_,2) + math.pow(z - self.world_z_,2)))
        if distance < 10 then return true end
        return false 
    end
    local world_pos = build.transform.position
    local screen_pos = Camera.main:WorldToScreenPoint(world_pos)
    return screen_pos.x >= -50 and screen_pos.x <= (self.screen_size_.sizeDelta.x + 50) and 
        screen_pos.y >= 70 and screen_pos.y <= self.screen_size_.sizeDelta.y
end

function on_click_main_city(self)
    if SceneManager.World_Scene.move_camera_ then
        StartCoroutine(function()
            MsgCenter.send_message(Msg.WORLD_CLEAR_JOURNEY_MENU)
            Yield()
            SceneManager.World_Scene:goto_axis(WorldManager.main_logic_x_, WorldManager.main_logic_z_)
        end)
    else
        SceneManager.World_Scene:goto_axis(WorldManager.main_logic_x_, WorldManager.main_logic_z_)
    end
end

function on_world_march_end(self)
    local cur_queue = WorldManager:get_march_queue_num()
    self.battle_queue_desc_.text = lang("UI_MAIN_MARCH_QUEUE",
        cur_queue, WorldManager:get_army_num() - cur_queue)
end

function on_hide_ui_all(self, isHide)
    self.city_panel_.gameObject:SetActive(not isHide)
    self.player_panel_.gameObject:SetActive(not isHide)
end

function on_world_march_bar(self, armyID)
    local data = WorldManager:get_army_info(armyID)
    local cur_queue = WorldManager:get_march_queue_num()
    self.battle_queue_desc_.text = lang("UI_MAIN_MARCH_QUEUE",
        cur_queue, WorldManager:get_army_num() - cur_queue)
    local battle_bar = self:get_battle_bar_go(armyID)
    battle_bar:SetActive(true)
    local bar_btn = battle_bar.transform:GetComponent(Button)
    bar_btn.onClick:RemoveAllListeners()
    self:add_event_handler(bar_btn.onClick, on_click_army_info, armyID)
    local name = battle_bar.transform:Find("Desc"):GetComponent(Text)
    local bar = battle_bar.transform:Find("Timebar"):GetComponent(Image)
    local timer = battle_bar.transform:Find("Timer"):GetComponent(Text)
    local icon = battle_bar.transform:Find("Icon"):GetComponent(Image)
    local btn_txt = battle_bar.transform:Find("Button/Text"):GetComponent(Text)
    local btn = battle_bar.transform:Find("Button"):GetComponent(Button)
    btn_txt.text = data:get_btn_desc()
    UIUtil.set_sprite(data:get_icon(), icon)
    btn.onClick:RemoveAllListeners()
    self:add_event_handler(btn.onClick, on_click_army_info_btn, armyID)
    name.text = data:get_bar_desc() --
    data.is_play_ = true
    -- 进度条
    if self.bar_ani_[armyID] then
        self.bar_ani_[armyID]:Kill(false)
    end
    bar.fillAmount = data:get_start_percent()
    self.bar_ani_[armyID] = GameTween.DOFillAmount(bar, 1, data:GetLastTime()):SetEase(XEase.Linear):OnComplete(function()
        battle_bar:SetActive(false)
        if self.bar_timer_[armyID] then
            LuaTimer.Delete(self.bar_timer_[armyID])
            self.bar_timer_[armyID] = nil
        end 
    end)
    -- 时间轴
    if self.bar_timer_[armyID] then
        LuaTimer.Delete(self.bar_timer_[armyID])
        self.bar_timer_[armyID] = nil
    end
    
	self.bar_timer_[armyID] = LuaTimer.Add(0, 1000, function()
        local delta = data:GetLastTime()
        local lt = delta
        local hour = math.floor(lt / 3600)
        local min = math.floor((lt - hour * 3600) / 60)
        local sec = lt - hour * 3600 - min * 60
        timer.text = string.format("%.2d:%.2d:%.2d", hour, min, sec)        
        delta = delta - 1 < 0 and 0 or delta - 1
	end)
end

function on_click_army_info(self, event, armyID)
    local data = WorldManager:get_army_info(armyID)
    if not data then
        elog("army info = nill, armyID = "..tostring(armyID))
        return 
    end

    local func = function()
        local state = data:get_bar_state()
        if state == ArmyInfo.SPEED then
            MsgCenter.send_message(Msg.WORLD_JUMP_JOURNEY, armyID)
        elseif state == ArmyInfo.RETURN then
            if self.world_x_ == data.finish_.x and
                data.finish_.z == self.world_z_ then
                return
            end
            SceneManager.World_Scene:goto_axis(data.finish_.x, data.finish_.z, true)
        end
    end
    if SceneManager.World_Scene.move_camera_ then
        StartCoroutine(function()
            MsgCenter.send_message(Msg.WORLD_CLEAR_JOURNEY_MENU)
            Yield()
            func()
        end)
    else
        func()
    end
end

function on_click_army_info_btn(self, event, armyID)
    local data = WorldManager:get_army_info(armyID)
    if not data then return end
    local state = data:get_bar_state()
    if state == ArmyInfo.SPEED then
        MsgCenter.send_message(Msg.WORLD_CLEAR_JOURNEY_MENU)
        UIManager.open_window("ItemJourneySpeedWindow", nil, armyID)
    elseif state == ArmyInfo.RETURN then
        local msg_ = {}
        msg_.mode=0
        msg_.title = lang("UI_BASIC_HINT")
        msg_.content = lang("UI_FORT_06")
       -- msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
        msg_.callback = function() 
           -- if index == 2 then
                local data1 = {}
                data1.id = data.finish_.id
                local obj = WorldManager:get_world_obj(data.finish_.x, data.finish_.z)
                local net_str = obj:get_cancel_msg()
                Net.send(net_str, data1, function(result)
                    if result.e == 0 then
                    end
                end)
         --   end
        end
        _G.UIController:ShowUI('UICommonPop', msg_)
        --MsgCenter.send_message(Msg.SHOW_NOTIFY,msg_)
    end
end

function get_battle_bar_go(self, armyID)
    local battle_bar = self.battle_queue_.transform:Find(armyID)
    if battle_bar then
        battle_bar = battle_bar.gameObject
    end

    if not battle_bar then
        local bar_prefab = self.battle_queue_.transform:Find("BattleBar").gameObject
        self.battle_queue_go_[armyID] = GameObject.Instantiate(bar_prefab)
        self.battle_queue_go_[armyID].transform:SetParent(self.battle_queue_, false)
        self.battle_queue_go_[armyID].gameObject.name = armyID
        battle_bar = self.battle_queue_go_[armyID]
    end
    return battle_bar
end

function on_click_player_head(self, event)
    local result = MasterManager:buy_energy()
    if  result then
        AudioManager.Play("SOUND_BUTTON_COMMON")
    end
end

function on_click_show_unopen(self, event)    
    MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_MAIN_UNOPEN"))
end

function on_click_hero_handler(self, event)
    AudioManager.Play("SOUND_BUTTON_COMMON")
    UIManager.open_window("HeroListWindow")
end

function on_click_quest_handler(self, event)
   MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_MAIN_UNOPEN"))
end

function on_click_bag_handler(self, event)
    AudioManager.Play("SOUND_BUTTON_COMMON")
    UIManager.open_window("ItemListWindow")
end

function on_click_mail_handler(self, event)
    UIManager.open_window("MailWindow")
end

function on_click_relogin(self)
    AudioManager.Play("SOUND_BUTTON_COMMON")
    local msg_ = {}
    msg_.mode=0
    msg_.title = lang("UI_BASIC_HINT")
    msg_.content = lang("EXPEDITION_41")
   -- msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
    msg_.callback = function() 
       -- if index == 2 then
            StartCoroutine(function ()
                Yield(WaitForSeconds(1))
                GameManager:exit_to_clean()
            end)
      --  end
    end
  --  MsgCenter.send_message(Msg.SHOW_NOTIFY,msg_)
    _G.UIController:ShowUI('UICommonPop', msg_)
end

function on_activity_arrow_handler(self, event, up)
    local welfare_go = self.activity_parent_:Find("WelfareBtn").gameObject
    local act_rect = self.activity_parent_:GetComponent(RectTransform)
    local max=240   
    local min=130
    if up then
        GameTween.To(function(v)
            act_rect.sizeDelta = Vector2(act_rect.sizeDelta.x, v)
            if v < 200 and welfare_go.activeSelf then
                welfare_go:SetActive(false)
            end
        end, max, min, 0.3):OnComplete(function() 
            self.activity_down_.gameObject:SetActive(true)
            self.activity_up_.gameObject:SetActive(false)
		end)
    else
        GameTween.To(function(v)
            act_rect.sizeDelta = Vector2(act_rect.sizeDelta.x, v)
            if v > 200 and not welfare_go.activeSelf then
                welfare_go:SetActive(true)
            end
        end, min, max, 0.3):OnComplete(function() 
            self.activity_down_.gameObject:SetActive(false)
            self.activity_up_.gameObject:SetActive(true)
		end)
    end
    
end