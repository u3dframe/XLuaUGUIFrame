module("NotifyItemWindow",package.seeall)
setmetatable( NotifyItemWindow, {__index = BaseWindow} )


function on_resource(self)

end

function on_init(self)
    self.title_ = self.transform:Find("WindowObj/Title"):GetComponent(Text)
    self.content_ = self.transform:Find("WindowObj/Panel/Content"):GetComponent(Text)
    self.cancel_btn_ = self.transform:Find("WindowObj/BtnGroup/CancelBtn"):GetComponent(Button)
    self:add_event_handler(self.cancel_btn_.onClick, function()
        self:close()
    end)
    self.close_btn_ = self.transform:Find("WindowObj/Close"):GetComponent(Button)
    self:add_event_handler(self.close_btn_.onClick, function()
        self:close()
    end)
    self.sure_btn_ = self.transform:Find("WindowObj/BtnGroup/SureBtn"):GetComponent(Button)
    self:add_event_handler(self.sure_btn_.onClick, function()
        for i,v in ipairs(self.item_list_) do
           if not ItemManager:check(v) then
                MsgCenter.send_message(Msg.SHOW_HINT, lang("ITEM_NOT_ENOUGH"))
                return
            end
        end
        if self.data[2] then
            self.data[2]()
        end 
        self:close()
    end)

    self.item_panel_ = self.transform:Find("WindowObj/ItemGroup/ItemPanel")
    self.item_prefab_ = self.transform:Find("WindowObj/ItemGroup/ItemPanel/item1").gameObject
    self.item_prefab_:SetActive(false)
    self.item_go_ = {}
end

function on_open(self)
    self.item_list_ = self.data[1].items
    self.title_.text = self.data[1].title
    self.content_.text = self.data[1].content
    self:init_item_panel()
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
    for k,v in pairs(self.item_go_) do
        if v then
            Object.Destroy(v)
        end
    end
end

function init_item_panel(self)
    for i,v in ipairs(self.item_list_) do
        if not self.item_go_[i] then
            self.item_go_[i] = GameObject.Instantiate(self.item_prefab_)
            self.item_go_[i].name = "item"..i
            self.item_go_[i].transform:SetParent(self.item_panel_, false)
        end
        self.item_go_[i]:SetActive(true)
        local item_prop = ItemManager:get_ui_info(v)
        local background = self.item_go_[i].transform:Find("Background"):GetComponent(Image)
        local icon = self.item_go_[i].transform:Find("Mask/Icon"):GetComponent(Image)
        local name = self.item_go_[i].transform:Find("Name"):GetComponent(Text)
        local count = self.item_go_[i].transform:Find("CornerPanel/Text"):GetComponent(Text)
        UIUtil.set_sprite(item_prop.icon, icon)
        count.text = v[3]
        self:add_tips_handler(icon.transform, v, TipsCard.TIPS_ITEM)
        name.text = item_prop.name
        UIUtil.set_sprite("UI/Common/Quality/item_"..item_prop.quality, background)
    end

end
