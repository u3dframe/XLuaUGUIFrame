module("PopupWindow", package.seeall)
setmetatable(PopupWindow, {__index=BaseWindow})



--1.准备UI（UI美术资源加载）
function on_resource(self)
    self.key_ = self.data[1]
    self.data_ = self.data[2]
    self.prop_ = PopupManager:get_popup_prop(self.key_)
    
    self.panel_ = self.transform:Find("Panel")
    UIUtil.load_component(self.prop_.path, function(prefabs) 
        self.prefab_ = GameObject.Instantiate(prefabs)
        self.prefab_.name = self.prop_.id
        self.prefab_.transform:SetParent(self.panel_.transform, false)
        self.prefab_.transform.localScale = Vector3.one
        if not _G[self.prop_.component] then
            elog("PopupWindow open failed, pls check data, component = "..self.prop_.component)
            return
        end
        self.com_= _G[self.prop_.component](self.key_, self.prefab_)
        self.com_:on_resource()
    end)
end


--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self) 
    self.btn_close_ = self.transform:Find("Background"):GetComponent(Button)
    self:add_event_handler(self.btn_close_.onClick, function()
        self:close(function()
            PopupManager:next_window()
        end)
    end)
    if self.com_ then
        self.com_:on_init()
    end
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
	    if self.com_ then
        self.com_:on_init()
    end
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
    if self.prefab_ then
        Object.Destroy(self.prefab_)
    end
end