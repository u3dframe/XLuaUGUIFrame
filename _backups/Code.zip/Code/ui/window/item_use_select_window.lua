module("ItemUseSelectWindow", package.seeall)
setmetatable(ItemUseSelectWindow, {__index = BaseWindow})


SLIDER_MIN_VALUE = 1


--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
local ItemConfig = _G.Database.ItemConfig


function on_init(self)
	--data
	self.item_ = self.data[1]
	self.on_success_ = self.data[3]
	self.max_use_count_ = self.item_.count_
	self.selected_index_ = -1
	self.use_count_ = 1

	local selectable = self.data[2]

	local close_btn = self.transform:Find("Panel/Top/CloseBtn"):GetComponent(Button)
	self:add_event_handler(close_btn.onClick, on_close_click)
	use_btn = self.transform:Find("Panel/UseBtn")
	confirm_btn = self.transform:Find("Panel/ConfirmBtn")
	if selectable then
		use_btn.gameObject:SetActive(true)
		confirm_btn.gameObject:SetActive(false)
		self.use_btn_ = use_btn:GetComponent(Button)
		self:add_event_handler(self.use_btn_.onClick, on_use_click)
		self.use_btn_.interactable = false
		GameUtil.SetImageGrey(self.use_btn_:GetComponent(Image), true)
	else
		use_btn.gameObject:SetActive(false)
		confirm_btn.gameObject:SetActive(true)
		self:add_event_handler(confirm_btn:GetComponent(Button).onClick, on_close_click)
	end

	local scroll_content = self.transform:Find("Panel/Inside/ItemListPanel/Content")
	local item_info_prefab = scroll_content:Find("ItemInfo").gameObject
	local toggle = item_info_prefab.transform:Find("Toggle")
	toggle.gameObject:SetActive(selectable)
	item_info_prefab:SetActive(false)
	local usepara = ItemConfig.ItemData[self.item_.id_].usepara
	self.num_para_ = #usepara
	for i, prop in ipairs(usepara) do
		local cfg = ItemManager:get_reward_cfg(prop)
		if cfg then
			local obj = GameObject.Instantiate(item_info_prefab)
			obj.transform:SetParent(scroll_content, false)
			obj:SetActive(true)
			local card = obj.transform:Find("ItemCard")
			UIUtil.set_sprite("UI/Common/Quality/item_"..cfg.quality, card:GetComponent(Image))
			UIUtil.set_sprite(cfg.icon, card:Find("Icon"):GetComponent(Image))
			local name_txt = obj.transform:Find("ItemName"):GetComponent(Text)
			name_txt.text = string.format("%s * %s", cfg.name, prop[3])
			if selectable then
				local toggle = obj.transform:Find("Toggle"):GetComponent(Toggle)
				self:add_event_handler(toggle.onValueChanged, on_select_one, i)
			end
		end
	end

	local slider_bar = self.transform:Find("Panel/SliderBar")
	if selectable then
		slider_bar.gameObject:SetActive(true)
		self.num_txt_ = slider_bar:Find("Num/Text"):GetComponent(Text)
		local add_btn = slider_bar:Find("Slider/AddBtn"):GetComponent(Button)
		self:add_event_handler(add_btn.onClick, on_add_click)
		local sub_btn = slider_bar:Find("Slider/SubBtn"):GetComponent(Button)
		self:add_event_handler(sub_btn.onClick, on_sub_click)
		self.slider_ = slider_bar:Find("Slider/NumberSlider"):GetComponent(Slider)
		self:add_event_handler(self.slider_.onValueChanged, on_value_changed)
		self.slider_.maxValue = self.max_use_count_
		self.slider_.minValue = 0
		self.num_txt_.text = string.format("%s/%s", self.use_count_, self.max_use_count_)
		self.slider_.value = self.use_count_
	else
		slider_bar.gameObject:SetActive(false)
	end
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
	
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)

end

function on_value_changed(self, event_data)
	if self.slider_.value < SLIDER_MIN_VALUE then
		self.slider_.value = SLIDER_MIN_VALUE
	end
	self.use_count_ = self.slider_.value
	self.num_txt_.text = string.format("%s/%s", self.use_count_, self.max_use_count_)
end

function on_add_click(self, event_data)
	if self.slider_.value >= self.slider_.maxValue then
		return
	end
	self.slider_.value = self.slider_.value + 1
end

function on_sub_click(self, event_data)
	if self.slider_.value <= SLIDER_MIN_VALUE then
		return
	end
	self.slider_.value = self.slider_.value - 1
end

function on_close_click(self, event_data)
	self:close() 
end

function on_use_click(self, event_data)
	if self.selected_index_ >= 1 and self.selected_index_ <= self.num_para_ then
		self.item_:confirm_to_use(self.use_count_, self.on_success_, self.selected_index_)
	end
	self:close()
end

function on_select_one(self, isOn, index)
	if isOn then
		self.selected_index_ = index
		self.use_btn_.interactable = true
		GameUtil.SetImageGrey(self.use_btn_:GetComponent(Image), false)
    end
end
