module("SoldierDetailsWindow", package.seeall)
setmetatable(SoldierDetailsWindow, {__index = BaseWindow})

Attribute = config.SOLDIER_ATTR --需要显示的属性ID

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self) 
	self.soldier_lv_ = self.data[1]
	local build_id = self.data[2]
	self.build_info_ = BuildManager:get_build_info_by_id(build_id)
	self.soldier_info_all_ = SoldierManager:get_soldier_info_by_build_type(self.build_info_.build_type_)
	--
	self.top_ = self.transform:Find("WindowObj/Top")
	self.center_ = self.transform:Find("WindowObj/Center")
	self.buttom_ = self.transform:Find("WindowObj/Buttom")
	-- Top
	self.title_ = self.top_.transform:Find("Title/Text"):GetComponent(Text)
	self.close_btn_ = self.top_.transform:Find("CloseBtn"):GetComponent(Button)
	--center
	self.attr_rect_ = self.center_.transform:Find("Part1/Right")
	self.power_ = self.attr_rect_.transform:Find("PowerAndCount/Power"):GetComponent(Text)
	self.number_ = self.attr_rect_.transform:Find("PowerAndCount/Number"):GetComponent(Text)
	-- self.skill_prefab_ = self.center_.transform:Find("Part2/ScrollRect/Cache/Skill")
	-- self.skill_prefab_.gameObject:SetActive(false)
	-- self.skill_content_ = self.center_.transform:Find("Part2/ScrollRect/Content")
	self.dismissa_btn_ = self.transform:Find("WindowObj/Buttom/DismissaBtn"):GetComponent(Button)
	self.preson_name_ = self.center_.transform:Find("Part1/ScrollRect/Person/NameAndLv/Name"):GetComponent(Image)
	self.preson_lv_ = self.center_.transform:Find("Part1/ScrollRect/Person/NameAndLv/Lv"):GetComponent(Text)
	self.preson_img_ = self.center_.transform:Find("Part1/ScrollRect/Person/Image")
	self.left_arrow_ = self.center_.transform:Find("Part1/LeftArrow")
	self.right_arrow_ = self.center_.transform:Find("Part1/RightArrow")
	--buttom
	self.hint1_ = self.buttom_.transform:Find("Hint1"):GetComponent(Text)
	self.hint2_ = self.buttom_.transform:Find("Hint2"):GetComponent(Text)
	self.hint3_ = self.buttom_.transform:Find("Hint3"):GetComponent(Text)
	self.promote_ = self.buttom_.transform:Find("Button"):GetComponent(Button)
	-- event
	self:add_event_handler(self.close_btn_.onClick, on_close_click)
	self:add_event_handler(self.promote_.onClick, on_promote_click)
	self:add_event_handler(self.dismissa_btn_.onClick, on_dismissa_click)

	--初始 scroll rect
	self.auto_scroll_rect_script_ = self.center_.transform:Find("Part1/ScrollRect"):GetComponent(AutoScrollRect)
	self.auto_scroll_rect_script_.OnLocate = function(i) self:on_select_click(i) end
	--self.preson_tb_ = {}
    self.auto_scroll_rect_script_:InitItems(#self.soldier_info_all_, function(i, obj)
    	--self.preson_tb_[i] = obj
    end, true, true)
	self.title_.text = lang("UI_SOLDIERDES_TITLE")
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
	self:get_unlock_soldier()
	self.auto_scroll_rect_script_:Locate(self.soldier_lv_)
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
     
end

--获取已经解锁的士兵们
function get_unlock_soldier(self)
	self.soldier_unlock_ = {}
	for k, v in pairs(self.soldier_info_all_) do
		local is_meet, build_info = self:is_unlock(v)
		if is_meet then
			table.insert(self.soldier_unlock_, v)
		end
	end
	table.sort(self.soldier_unlock_, function(x, y)
		return x.lv_ > y.lv_
	end)
end

--选中某个兵种
function on_select_click(self, index)
	local soldier_info = self:find_item_by_level(index)
	if not soldier_info then return end
	--设置箭头显示
	local left_show = soldier_info.id_ > self.soldier_info_all_[1].id_
	local right_show = soldier_info.id_ < self.soldier_info_all_[#self.soldier_info_all_].id_
	self.left_arrow_.gameObject:SetActive(left_show)
	self.right_arrow_.gameObject:SetActive(right_show)

	self.soldier_info_ = soldier_info
	--设置士兵icon name
	self:set_preson(soldier_info)
	--设置属性
	self:set_attribute(soldier_info)
	--设置技能
	self:set_skill_info(soldier_info)
	--设置Buttom
	self:set_buttom(soldier_info)
end

function set_preson(self, soldier_info)
	UIUtil.set_sprite("UI/Window/Solider/soldier_name_"..self.soldier_info_.soldier_type_, self.preson_name_)
	self.preson_lv_.text = lang("UI_SOLDIER_NAME_LV", soldier_info.lv_)
	--local path = soldier_info.path_
	--if not self:is_alive() then return end
	--UIUtil.set_sprite(path, self.preson_img_)

	local draw_go = self.preson_img_.gameObject
	local draw_go_skeleton = self.preson_img_:GetComponent(Spine.Unity.SkeletonGraphic)
	local soldier_type = 2
	local lv = 3

	if not draw_go_skeleton then
		GameUtil.BuildSkeletonDataAsset_Soldier(soldier_type, lv, draw_go, function()
	            draw_go.transform.localScale = Vector3(0.05, 0.05, 0.05)
	            --local draw_go_skeleton = draw_go.transform:GetComponent(Spine.Unity.SkeletonGraphic)
	            --draw_go_skeleton.color = Color(1, 1, 1, 0.5)
	    end)
	end
end

function set_buttom(self, soldier_info_)
	self.hint2_.gameObject:SetActive(false)
	self.promote_.gameObject:SetActive(false)
	self.hint1_.gameObject:SetActive(false)
	self.hint3_.gameObject:SetActive(false)

	--self.hint1_.text = "空闲数量："..self.soldier_info_.number_
	self.hint1_.text = lang("UI_SOLDIERDES_NUMBER", self.soldier_info_.number_)

	local is_unlock = SoldierManager:is_unlock(soldier_info_)
	self.hint1_.gameObject:SetActive(is_unlock)

	local have_nmber = self.soldier_info_.number_ > 0
	self.dismissa_btn_.interactable = have_nmber
	self.dismissa_btn_.gameObject:SetActive(is_unlock)
	GameUtil.SetImageGrey(self.dismissa_btn_:GetComponent(Image), not have_nmber)

	--如果是最大等级
	local lenth = #self.soldier_info_all_
	local not_max_lv = self.soldier_info_all_[lenth - 1].lv_ > self.soldier_info_.lv_
	if not not_max_lv then
		self.dismissa_btn_.gameObject:SetActive(false)
		self.hint2_.gameObject:SetActive(true)
		--self.hint2_.text = string.format("<color=%s>%s</color>", Txt_Color.Yellow,"当前兵种已到最大等级，无法继续晋升")
		self.hint2_.text = lang("UI_BASIC_COLOR", config.FONT_COLOR.YELLOW, lang("UI_SOLDIERDES_HINT1"))
		return
	end
	--如果不能晋升（可能是因为当前士兵或者是所要晋升的士兵还未解锁）
	local no_promote = self.soldier_unlock_[1].lv_ - 1 <= self.soldier_info_.lv_
	if no_promote then
		--local str = string.format("<color=%s>%s</color>", config.FONT_COLOR.GREEN, self:show_hint_not_lock())
		local str = lang("UI_BASIC_COLOR", config.FONT_COLOR.GREEN, self:show_hint_not_lock())
		self:grays_the_button(str)
		return
	end

	--如果数量为0
	if soldier_info_.number_ <= 0 then
		--local str = string.format("<color=%s>%s</color>", config.FONT_COLOR.RED,"该兵种的数量为0，无法晋升")

		local str = lang("UI_BASIC_COLOR", config.FONT_COLOR.RED, lang("UI_SOLDIERDES_HINT2"))
		self:grays_the_button(str)
		return
	end
	--是否在训练中
	local timer_exis = SoldierManager:check_soldier_state(self.build_info_.build_type_)
	if timer_exis then
		-- local txt = self.build_info_.name_.."正在训练士兵，暂时无法晋升"
		-- local str = string.format("<color=%s>%s</color>", Txt_Color.Red, txt)

		local txt = lang("UI_SOLDIERDES_HINT3", self.build_info_.name_)
		local str = lang("UI_BASIC_COLOR", config.FONT_COLOR.RED, txt)
		self:grays_the_button(str)
		return
	end
	--如果可以晋升 不显示hint3
	self.promote_.interactable = true
	self.promote_.gameObject:SetActive(true)
	GameUtil.SetImageGrey(self.promote_:GetComponent(Image), false)
end

function grays_the_button(self, str)
	self.promote_.interactable = false
	self.promote_.gameObject:SetActive(true)
	GameUtil.SetImageGrey(self.promote_:GetComponent(Image), true)
	self.hint3_.gameObject:SetActive(true)
	self.hint3_.text = str
end

--显示当前士兵或者晋升士兵未解锁 情况下的提示
function show_hint_not_lock(self)
	local soldier = SoldierManager:get_soldier_info_by_id(self.soldier_info_.id_ + 2)
	if soldier then
		local build_type = soldier.build_type_
		local lv = soldier.unlock_
		local build = BuildManager:get_build_info_by_build_type(build_type)
		--local str = build.name_.."达到"..lv.."级时可晋升"..soldier.lv_.."级"..soldier.name_
		local str = lang("UI_SOLDIER_PROMOTE_HINT", build.name_, lv, soldier.lv_, soldier.name_)
		return str
	end
end

--设置属性
function set_attribute(self, soldier_info_)
	--属性
	self.power_.text = soldier_info_.fighting_power_
	self.number_.text = soldier_info_.number_
	local attr = soldier_info_.attribute_
	local max_value = soldier_info_.max_value_
	for k, v in ipairs(Attribute) do
		if k <= 3 then
			self:set_attr_part1(k, attr[v], max_value[k], self.attr_rect_)
		else
			self:set_attr_part2(k, attr[v], self.attr_rect_)
		end
	end
end

function set_skill_info(self, soldier_info)
	if not soldier_info then return end
	--self.skill_tb_ = self.skill_tb_ or {}
	local skill_info = soldier_info.skill_info_

	for i = 1, config.SOLDIER_SKILL_MAX do
		local go = self.center_:Find("Skill"..i)
		if skill_info[i] then
			go.gameObject:SetActive(true)
			local sk_img = go.transform:Find("IconBox/Icon"):GetComponent(Image)
			local name = go.transform:Find("Name"):GetComponent(Text)
			local des = go.transform:Find("Desc"):GetComponent(Text)

			name.text = skill_info[i].name_
			des.text = skill_info[i].des_

			if not self:is_alive() then return end
 			UIUtil.set_sprite(skill_info[i].path_, sk_img)
		else
			if go then go.gameObject:SetActive(false) end
		end
	end
end

function set_attr_part1(self, index, value, max_value, parent)
	local path = "Attributes/Attribute"..index
	local value_txt = parent.transform:Find(path.."/Text"):GetComponent(Text)
	local mask = parent.transform:Find(path.."/Slider/Mask")
	value_txt.text = value
	mask.localScale = Vector3(value / max_value, 1, 1)
end

function set_attr_part2(self, index, value, parent)
	local path = "Attributes/Attribute"..index.."/Value"
	local txt = parent.transform:Find(path):GetComponent(Text)
	txt.text = value
end

function find_item_by_level(self, lv)
	if not self.soldier_info_all_ then return end
	local obj
	for _, v in pairs(self.soldier_info_all_) do
		if v.lv_ == lv then
			obj = v
			break
		end
	end
	if not obj then elog("not found value in table. lv = %s", lv) end
	return obj
end

--是否解锁
function is_unlock(self, soldier_info)
	local build_type = soldier_info.build_type_
	local build_info = BuildManager:get_build_info_by_build_type(build_type)
	if not build_info then
		build_info = BuildManager:get_build_data(build_type)
		return false, build_info
	end
	local depend_lv = soldier_info.unlock_
	return depend_lv <= build_info.lv_, build_info
end

function get_next_soldier_id(self)
	local next_soldier
	for k, v in ipairs(self.soldier_unlock_) do
		if v.soldier_type_ == self.soldier_info_.soldier_type_ then
			next_soldier = v
			break
		end
	end
	return next_soldier.id_
end

function set_max_count(self)
	local count
	local build_type = self.build_info_.build_type_
	local soldier_type = self.soldier_info_.soldier_type_
	local att = {
		"train_num", "train_num_camp"..build_type, "train_speed_soldier"..soldier_type
	}
	local train_num = AttrsManager:get_attrs_value_by_name(att[1])
	local train_num_camp = AttrsManager:get_attrs_value_by_name(att[2])
	local train_speed_soldier = AttrsManager:get_attrs_value_by_name(att[3])

	count = train_num + train_num_camp + train_speed_soldier
	return count
end

--解雇按钮
function on_dismissa_click(self, event_data)
	--if not self.soldier_info_ then return end
	--UIManager.open_window("SoldierKickWindow", nil, self.soldier_info_.id_)
end

function on_promote_click(self, event_data)

	if self.soldier_info_ and self.build_info_ then
	--士兵id，将要晋升的士兵id，晋升最大数量，建造id
		local next_soldier_id = self:get_next_soldier_id()
		local max_count = self:set_max_count()
		UIManager.open_window("SoldierPromoteWindow", nil,  self.soldier_info_.id_, 
							  next_soldier_id, max_count, self.build_info_.id_)
	end
end

function on_close_click(self, event_data)
	self:close()
end