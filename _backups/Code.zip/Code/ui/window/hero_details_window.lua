module("HeroDetailsWindow", package.seeall)
setmetatable(HeroDetailsWindow, {__index = BaseWindow})

function on_resource(self)

end

function on_init(self)
	local hero_id = self.data[1]
	self.hero_data_ = HeroManager:get_active_hero_by_id(hero_id)
	self.title_ = self.transform:Find("Panel/Top/Text"):GetComponent(Text)
	self.title_.text = lang("UI_HERO_DETAILS_TITLE")

	self.hero_ = self.transform:Find("Panel/HeroInfo/Hero")
	self.type_ = self.transform	:Find("Panel/HeroInfo/Type/AttrPanel")
	self.hero_name_lv_ = self.hero_.transform:Find("NameLV"):GetComponent(Text)
	self.hero_start_ = self.hero_.transform:Find("Start"):GetComponent(Text)
	self.start_group_ = self.hero_.transform:Find("StarGroup")


	self.close_btn_ = self.transform:Find("Panel/Top/CloseBtn"):GetComponent(Button)
	self.sure_btn_ = self.transform:Find("Panel/Buttom/SureButton"):GetComponent(Button)

	self:add_event_handler(self.close_btn_.onClick, on_close_handler)
	self:add_event_handler(self.sure_btn_.onClick, on_close_handler)
end

function on_open(self)
	if not self.hero_data_ then return end
    self:set_data()
end

function on_close(self)
end

function set_data(self)
	local name = self.hero_data_.name_
	local lv = lang("UI_HERO_LV2", self.hero_data_.lv_)
	local start = self.hero_data_:get_star_and_stage()

	HeroManager:show_hero_star_comp(self.start_group_, start)
	self.hero_name_lv_.text = name.."    "..lv
	self.hero_start_.text = lang("UI_HERO_STAR", start)

	--类型文字
	local attr_name = {
    	lang("UI_HERO_TYPE1"),
    	lang("UI_HERO_TYPE2"),
    	lang("UI_HERO_TYPE3"),
    }

	for i = 1, 3 do
    	local attr_obj = self.type_.transform:Find("AttrItem"..i)
    	if attr_obj then
    		local txt = attr_obj.transform:Find("Text"):GetComponent(Text)
    		local value = self.hero_data_:get_attr(i)
    		txt.text = lang("UI_BASIC_COLOR", config.FONT_COLOR.GREY, attr_name[i]).."    "..value
    	end
    end
end

function on_close_handler(self)
	self:close()
end