-- 守军详情
module("WorldFortRewardWindow",package.seeall)
setmetatable( WorldFortRewardWindow, {__index = BaseWindow} )

--1.准备UI（UI美术资源加载）
function on_resource(self)
    Yield(UIUtil.load_component("Common/ItemCard", function(prefab)
        self.item_prefab_ = prefab
    end))
end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self) 
    self.btn_llose_ = self.transform:Find("WindowObj/Close"):GetComponent(Button)
    self:add_event_handler(self.btn_llose_.onClick, function()
            self:close()
        end)

    self.item_panel1_ = self.transform:Find("WindowObj/ItemPanel1/Contents/ItemList")
--    self.item_prefab1_ = self.transform:Find("WindowObj/ItemPanel1/Contents/ItemList/Item").gameObject
--    self.item_prefab1_:SetActive(false)
    

    self.item_panel2_ = self.transform:Find("WindowObj/ItemPanel2/Contents/ItemList")
--    self.item_prefab2_ = self.transform:Find("WindowObj/ItemPanel2/Contents/ItemList/Item").gameObject
--    self.item_prefab2_:SetActive(false)
    self.item_go2_ = {}

    self.info_desc_ = {}
    self.info_value_ = {}
    for i=1,3 do
        self.info_desc_[i] = self.transform:Find(string.format("WindowObj/InfoPanel/InfoItem%d/Desc", i)):GetComponent(Text)
        self.info_value_[i] = self.transform:Find(string.format("WindowObj/InfoPanel/InfoItem%d/Value", i)):GetComponent(Text)
    end
    
    self.bar_group_ = self.transform:Find("WindowObj/BarPanel/BarGroup").gameObject
    self.bar_empty_go_ = self.transform:Find("WindowObj/BarPanel/EmptyTxt").gameObject
    self.bar_group_:SetActive(false)
    self.bar_empty_go_:SetActive(true)    
    self.bar_timer_txt_ = self.transform:Find("WindowObj/BarPanel/BarGroup/Timer"):GetComponent(Text)
    self.bar_img_ = self.transform:Find("WindowObj/BarPanel/BarGroup/Mask"):GetComponent(Image)
    
    self.messager_:add_listener(Msg.WORLD_FORT_DELETE, on_fort_delete) 
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
    self.obj_ = self.data[1]
    local prop = self.obj_:get_prop()
    self.fixed_reward_ = prop.reward_show1
    self.random_reward_ = prop.reward_show2
    self:init_info_txt()
    self:init_fixed_reward()
    self:init_random_reward()
    self:init_bar_state()
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
    self:delete_bar_timer()
    if self.item_go1_ then
        for k,v in pairs(self.item_go1_) do
            if v then
                Object.Destroy(v.gameObject)
            end
        end  
    end
    self.item_go1_ = nil
    if self.item_go2_ then
        for k,v in pairs(self.item_go2_) do
            if v then
                Object.Destroy(v.gameObject)
            end
        end  
    end
    self.item_go2_ = nil
end

function init_fixed_reward(self)
    UIUtil.destroy_all_children(self.item_panel1_)
    self.item_go1_ = {}
    for i,v in ipairs(self.fixed_reward_) do
        local itemobj = GameObject.Instantiate(self.item_prefab_)
        itemobj.name = tostring(i)
        itemobj:SetActive(true)
        itemobj.transform:SetParent(self.item_panel1_, false)
        itemobj.transform.localScale = Vector3(1,1,1)
        self.item_go1_[i] = ItemCard:new()
        self.item_go1_[i]:AddLuaComponent(itemobj)
        self.item_go1_[i]:init()
        self.item_go1_[i]:set_item_prop(v)
    end
end

function init_random_reward(self)
    UIUtil.destroy_all_children(self.item_panel2_)
    self.item_go2_ = {}
    for i,v in ipairs(self.random_reward_) do
        local itemobj = GameObject.Instantiate(self.item_prefab_)
        itemobj.name = tostring(i)
        itemobj:SetActive(true)
        itemobj.transform:SetParent(self.item_panel2_, false)
        itemobj.transform.localScale = Vector3(1,1,1)
        self.item_go2_[i] = ItemCard:new()
        self.item_go2_[i]:AddLuaComponent(itemobj)
        self.item_go2_[i]:init()
        self.item_go2_[i]:set_item_prop(v)
    end
end

function init_info_txt(self)
    local prop = self.obj_:get_prop()
    local desc_list = {lang("UI_FORT_12"), lang("UI_FORT_13"), lang("UI_FORT_14")}
    local time = UIUtil.get_format_time_sec(prop.tribute_time)
    local value_list = {prop.tribute_num, self.obj_.cnt_, time}
    for i=1,3 do
        self.info_desc_[i].text = desc_list[i]
        self.info_value_[i].text = value_list[i]
    end
end

function init_bar_state(self)
    if self.obj_:has_troop() then
        self.bar_group_:SetActive(true)
        self.bar_empty_go_:SetActive(false)
        self:delete_bar_timer()
        self.bar_timer_ = LuaTimer.Add( 0, 100, function()
            if self.bar_img_ and self.obj_ then
                self.bar_img_.fillAmount = self.obj_:get_one_time_bar()
                self.bar_timer_txt_.text = UIUtil.format_time(self.obj_:get_one_time())
            end
            if self.obj_.cnt_ <= 0 then
                self:delete_bar_timer()
            end
            self:init_info_txt()
        end)
    else
        self.bar_group_:SetActive(false)
        self.bar_empty_go_:SetActive(true)
    end
end

function delete_bar_timer(self, show)
    if self.bar_timer_ then
        LuaTimer.Delete(self.bar_timer_)
        self.bar_timer_ = nil
    end
end

function on_fort_delete(self, id)
    if self.obj_.idx_ ~= id then return end
    self:close()
end