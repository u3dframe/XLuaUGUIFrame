local HeroChipExchangeWindow = {}
setmetatable(HeroChipExchangeWindow, {__index = _G.BaseWindow})

local UI =_G.UnityEngine.UI
local lang = _G.lang
local MsgCenter = _G.MsgCenter
local Msg = _G.Msg
local ItemManager = _G.ItemManager
local UIUtil = _G.UIUtil

--1.准备UI（UI美术资源加载）
function HeroChipExchangeWindow:on_resource()

end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function HeroChipExchangeWindow:on_init()
	local hero_id = self.data[1]
	self.hero_data_ = _G.HeroManager:get_active_hero_by_id(hero_id)

	self.title_ = self.transform:Find("Panel/Top/Text"):GetComponent(UI.Text)
	self.title_ = lang("UI_HERO_CHIP_EXCHANGE_TITLE")
	self.close_btn_ = self.transform:Find("Panel/Top/CloseBtn"):GetComponent(UI.Button)

	self.center_ = self.transform:Find("Panel/Center")
	--万能碎片
	self.chipBg = self.center_.transform:Find("ChipIcon/Chip"):GetComponent(UI.Image)
	self.chip_icon_ = self.center_.transform:Find("ChipIcon/Chip/Icon"):GetComponent(UI.Image)
	self.chip_number_ = self.center_.transform:Find("ChipIcon/Chip/Board/Text"):GetComponent(UI.Text)
	self.chip_name_ = self.center_.transform:Find("ChipIcon/Chip/Name"):GetComponent(UI.Text)
	--目标将魂
	self.targetHeroChipBg = self.center_.transform:Find("ChipIcon/TargetChip"):GetComponent(UI.Image)
	self.target_hero_chip_icon_ = self.center_.transform:Find("ChipIcon/TargetChip/Icon"):GetComponent(UI.Image)
	self.target_hero_chip_number_ = self.center_.transform:Find("ChipIcon/TargetChip/Board/Text"):GetComponent(UI.Text)
	self.target_hero_chip_name_ = self.center_.transform:Find("ChipIcon/TargetChip/Name"):GetComponent(UI.Text)

	--选择模块
	self.select_mode_ = self.center_.transform:Find("SelectMode")
	self.hint_txt_ = self.select_mode_.transform:Find("Hint"):GetComponent(UI.Text)
	self.hint_txt_.text = lang("UI_HERO_EXCHANGE_CEN")
	self.sub_btn_ = self.select_mode_.transform:Find("Buttons/SubBtn"):GetComponent(UI.Button)
	self.add_btn_ = self.select_mode_.transform:Find("Buttons/AddBtn"):GetComponent(UI.Button)
	self.add_cnt_btn_ = self.select_mode_.transform:Find("Buttons/AddCntBtn"):GetComponent(UI.Button)
	self.max_btn_ = self.select_mode_.transform:Find("Buttons/MaxBtn"):GetComponent(UI.Button)
	self.input_filed_ = self.select_mode_.transform:Find("Buttons/InputField"):GetComponent(UI.InputField)
	self.hint1_ = self.select_mode_.transform:Find("FastChoose/Hint1")
	self.hint2_ = self.select_mode_.transform:Find("FastChoose/Hint2")

	self.toggle1_ = self.select_mode_.transform:Find("FastChoose/chooseitem1"):GetComponent(UI.Toggle)
	self.toggle2_ = self.select_mode_.transform:Find("FastChoose/chooseitem2"):GetComponent(UI.Toggle)
	self.toggle_img1_ = self.toggle1_.gameObject.transform:Find("Box/Image")
	self.toggle_img2_ = self.toggle2_.gameObject.transform:Find("Box/Image")

	self.toggle1_.isOn = false
	self.toggle2_.isOn = false

	self.stage_up_hint_ = self.select_mode_.transform:Find("FastChoose/chooseitem1/Text"):GetComponent(UI.Text)
	self.star_up_hint_ = self.select_mode_.transform:Find("FastChoose/chooseitem2/Text"):GetComponent(UI.Text)

	--Buttom
	self.agree_exchange_btn_ = self.transform:Find("Panel/Buttom/SureButton"):GetComponent(UI.Button)

	--Button
	self:add_event_handler(self.close_btn_.onClick, self.on_close_handler)
	self:add_event_handler(self.sub_btn_.onClick, self.on_sub_handler)
	self:add_event_handler(self.add_btn_.onClick, self.on_add_handler)
	self:add_event_handler(self.add_cnt_btn_.onClick, self.on_add_cnt_handler)
	self:add_event_handler(self.max_btn_.onClick, self.on_max_handler)
	self:add_event_handler(self.agree_exchange_btn_.onClick, self.on_agree_exchange_handler)
	--toggle
	self:add_event_handler(self.toggle1_.onValueChanged, self.on_toggle1_value_changeed)
	self:add_event_handler(self.toggle2_.onValueChanged, self.on_toggle2_value_changeed)
	--InputFiel
	self:add_event_handler(self.input_filed_.onEndEdit, self.on_end_edit)
end

--3.打开UI（打开/刷新UI处理）
function HeroChipExchangeWindow:on_open()
	if not self.hero_data_ then return end
	self:set_data()
end

--5.关闭UI（UIManager销毁UI前处理）
function HeroChipExchangeWindow:on_close()
end

function HeroChipExchangeWindow:set_data()
	--设置万能碎片和将魂 默认显示1
	local prop = self.hero_data_:get_prop()
	local item1 = ItemManager:get_item_prop_by_id(prop.activate[2]) --将魂
    local item2 = ItemManager:get_item_prop_by_id(prop.trade_item[2]) --万能碎片道具
    self.hero_chip_cnt_ = self.hero_data_:get_chip_num()  --已经有的将魂数量

    --已经拥有的万能碎片道具
    local chip_item = ItemManager:get_item_by_id(prop.trade_item[2])
    local name = chip_item.prop_ and chip_item.prop_.name or ""
	self.max_count_ = chip_item.count_ --万能碎片总数
    self:on_end_edit(1)
    self.chip_name_.text = name
    self.target_hero_chip_number_.text = 1
    self.target_hero_chip_name_.text = item1 and item1.name or ""
    self.input_filed_.text = 1

    --升阶
    if self.hero_data_:enable_stage() then
		self.toggle1_.gameObject:SetActive(false)
		self.hint1_.gameObject:SetActive(true)
    else
		self.toggle1_.gameObject:SetActive(true)
		self.hint1_.gameObject:SetActive(false)
		local offset = self.hero_data_:get_stage_up_cost() - self.hero_chip_cnt_ --需要的将魂
		self.stage_up_hint_.text = lang("UI_HERO_CHIP_EXCHANGE_UP_STAGE", offset)
    end

    --升星
    if self.hero_data_:enable_star() then
		self.toggle2_.gameObject:SetActive(false)
		self.hint2_.gameObject:SetActive(true)
    else
		self.toggle2_.gameObject:SetActive(true)
		self.hint2_.gameObject:SetActive(false)
		local offset = self.hero_data_:get_star_up_cost() - self.hero_chip_cnt_ --需要的将魂
		self.star_up_hint_.text = lang("UI_HERO_CHIP_EXCHANGE_UP_STAR", offset)
    end

	if not self:is_alive() then return end
	--目标道具
	UIUtil.set_sprite("UI/Common/Quality/Item_"..item1.quality, self.targetHeroChipBg)
	UIUtil.set_sprite(item1.icon, self.target_hero_chip_icon_)

	--万能碎片道具
	UIUtil.set_sprite("UI/Common/Quality/Item_"..item2.quality, self.chipBg)
    UIUtil.set_sprite(item2.icon, self.chip_icon_)
end

function HeroChipExchangeWindow:on_end_edit(event_data)
	local input = tonumber(event_data)
	if not input then return end
	if input <= 0 then
		input = 1
	elseif input >= self.max_count_ then
		input = self.max_count_
	end
	self.input_cnt_ = input
	self.input_filed_.text = input
	local prop = self.hero_data_:get_prop()
	local hero_chip_cnt = input / prop.trade_item[3] --可以兑换多少个将魂
	self.chip_number_.text = input .."/"..self.max_count_
	self.target_hero_chip_number_.text = hero_chip_cnt
end

function HeroChipExchangeWindow:on_sub_handler()
	if not self.input_cnt_ then return end
	if self.input_cnt_ <= 1 then
		return
	end
	local result = self.input_cnt_ - 1
	self:on_end_edit(result)
end

function HeroChipExchangeWindow:on_add_handler()
	if not self.input_cnt_ then return end
	if self.input_cnt_ >= self.max_count_ then
		return
	end
	local result = self.input_cnt_ + 1
	self:on_end_edit(result)
end

function HeroChipExchangeWindow:on_add_cnt_handler()
	if not self.input_cnt_ then return end
	if self.input_cnt_ >= self.max_count_ then
		return
	end
	local result = self.input_cnt_ + 10
	self:on_end_edit(result)
end

function HeroChipExchangeWindow:on_max_handler()
	if not self.input_cnt_ then return end
	if self.input_cnt_ < self.max_count_ then
		self:on_end_edit(self.max_count_)
	end
end

function HeroChipExchangeWindow:on_toggle1_value_changeed(event_data)
	if not event_data then return end
	local total_stage_cnt = self.hero_data_:get_stage_up_cost()
	local chip_own = self.hero_data_:get_chip_num()

	local prop = self.hero_data_:get_prop()
	local hero_chip_cnt = self.max_count_ / prop.trade_item[3] --可以兑换多少个将魂

	if hero_chip_cnt < total_stage_cnt - chip_own then
		self.toggle_img1_.gameObject:SetActive(false)
		MsgCenter.send_message(Msg.SHOW_HINT, lang("ITEM_NOT_ENOUGH"))
		return
	end
	self.need_cnt_ = total_stage_cnt - chip_own
	self:on_end_edit(self.need_cnt_)
end

function HeroChipExchangeWindow:on_toggle2_value_changeed(event_data)
	if not event_data then return end
	local total_star_cnt = self.hero_data_:get_star_up_cost()
	local chip_own = self.hero_data_:get_chip_num()

	local prop = self.hero_data_:get_prop()
	local hero_chip_cnt = self.max_count_ / prop.trade_item[3] --可以兑换多少个将魂

	if hero_chip_cnt < total_star_cnt - chip_own then
		self.toggle_img2_.gameObject:SetActive(false)
		MsgCenter.send_message(Msg.SHOW_HINT, lang("ITEM_NOT_ENOUGH"))
		return
	end
	self.need_cnt_ = total_star_cnt - chip_own
	self:on_end_edit(self.need_cnt_)
end

function HeroChipExchangeWindow:on_agree_exchange_handler()
	if not self.input_cnt_ or not self.hero_data_ then return end
	local req_msg = {}
	req_msg.id = self.hero_data_.id_
	req_msg.cnt = self.input_cnt_
	_G.dump(req_msg, "hero_chip_conversion.  req_msg = ")
	_G.Net.send("hero_chip_conversion", req_msg, function(result)
		if result.e == 0 then
			MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_HINT_CHIP_EXCHANGE_SUCCEED"))
			self:close()
		end
	end)
end

function HeroChipExchangeWindow:on_close_handler()
	self:close()
end

return HeroChipExchangeWindow