-- 武将升级界面
module("HeroListWindow",package.seeall)
setmetatable( HeroListWindow, {__index = BaseWindow} )

--1.准备UI（UI美术资源加载）
function on_resource(self)
    local list = {
        "hero/HeroCardList"
    }

    Yield(UIUtil.load_component(list, function(prefabs) 
        self.hero_card_list_prefab_ = prefabs[1]
    end))
end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self) 
    self.active_panel_ = self.transform:Find("InfoPanel/ScrollView/ActivePanel")
    self.active_go_ = {}
--    self.hero_card_prefab_ = self.transform:Find("InfoPanel/Cache/HeroCard").gameObject
--    self.hero_card_prefab_:SetActive(false)
    
    
        
    self.tab_left_ = {}
    for i=1,4 do
        self.tab_left_[i] = self.transform:Find("InfoPanel/ToggleGroup/Toggle0"..i):GetComponent(Toggle)
        self:add_event_handler(self.tab_left_[i].onValueChanged, select_tab_handler, i)
    end
end



--3.打开UI（打开/刷新UI处理）
function on_open(self)
    self.tab_index_ =  1
    if self.tab_left_[self.tab_index_].isOn then
       self.tab_left_[self.tab_index_].isOn = false 
    end
    self.tab_left_[self.tab_index_].isOn = true
end


--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
    for i=1,#self.active_go_ do
        if self.active_go_[i] then
            self.active_go_[i]:on_dispose()
            Object.Destroy(self.active_go_[i].gameObject)
        end
    end
    self.active_go_ = nil
end

function select_tab_handler(self, event, index)
    if event then
        self.tab_index_ = index
        self:sort_panel_list()
        self:init_list_panel()
    end
end



function init_list_panel(self)
    local hero_num = #self.hero_list_
    for i=1,#self.active_go_ do
        if hero_num < i and self.active_go_[i].gameObject.activeSelf then
            self.active_go_[i].gameObject:SetActive(false)
        end
    end
    for i=1,hero_num do
        local v = self.hero_list_[i]
        if not self.active_go_[i] then
            local card = GameObject.Instantiate(self.hero_card_list_prefab_)
            card.transform:SetParent(self.active_panel_, false)
            card:SetActive(true)
            self.active_go_[i] = HeroCardList:new(self)
            self.active_go_[i]:AddLuaComponent(card)
            self.active_go_[i]:init()
        end
        self.active_go_[i].gameObject:SetActive(true)
        self.active_go_[i]:set_data(v)
    end
end


function sort_panel_list(self)
    local heroes = {}
    -- 转为有序table -- 
    for k,v in pairs(HeroManager.hero_cards_) do
        if self.tab_index_ == 1 then
            table.insert(heroes, v) 
        else
            if v.type_ == (self.tab_index_ - 1) then
                table.insert(heroes, v) 
            end
        end
    end
    self.hero_list_ = {}
    -- 需要召唤的 --
    table.sort(heroes, function(a, b) return b.quality_ < a.quality_ end)
    for k,v in ipairs(heroes) do        
        if v:enable_awake() then
            table.insert(self.hero_list_, v)
        end
    end
    
    -- 已经激活的 --
    for k,v in ipairs(heroes) do
        if v.is_active_ then
            table.insert(self.hero_list_, v)
        end
    end
    
    -- 未激活且不能激活的 --
    for k,v in ipairs(heroes) do
        if not v.is_active_ and not v:enable_awake() then
            table.insert(self.hero_list_, v)
        end
    end
end