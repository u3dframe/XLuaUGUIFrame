local CityRandomShopWindow = {}
setmetatable(CityRandomShopWindow, {__index = _G.BaseWindow})

local UI = _G.UnityEngine.UI
local lang = _G.lang
local Net = _G.Net
local BuildManager = _G.BuildManager
local UIUtil = _G.UIUtil
local dump = _G.dump
local GameUtil = _G.GameUtil
local Msg = _G.Msg
local UIManager

--1.准备UI（UI美术资源加载）
function CityRandomShopWindow:on_resource()
    
end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function CityRandomShopWindow:on_init()
    UIManager = _G.UIManager
    self.randomShop = _G.BuildManager:GetRandomShop()
    --- unopen ---
    self.panelUnopen = self.transform:Find("PanelUnopen")
    self.hintTxt = self.panelUnopen.transform:Find("HintGroup/Hint"):GetComponent(UI.Text)
    self.hintTxt.text = lang("UI_RANDOMSHOP_UNOPEN_HINT")
    self.todayGoodsHint = self.panelUnopen.transform:Find("HintGroup/Tody"):GetComponent(UI.Text)  --上货提示
    self.todayGoodsHint.text = lang("UI_RANDOMSHOP_ADD_GOODS_HINT")..":"
    self.todayGoodsCnt = self.panelUnopen.transform:Find("HintGroup/Num"):GetComponent(UI.Text)  --上货比  0/5 外
    --- open ---
    self.panelOpen = self.transform:Find("PanelOpen")
    self.infoBtn = self.transform:Find("InfoBtn"):GetComponent(UI.Button)
    --self.scrollPoolGrid = self.transform:Find("PanelOpen/ShopInfo/ScrollView"):GetComponent(_G.ScrollPoolVertical)
    --属性
    self.intimacyTxt = self.panelOpen.transform:Find("Message/Intimacy_data/Text5"):GetComponent(UI.Text)      --好感度
    self.consumeTxt = self.panelOpen.transform:Find("Message/Text1"):GetComponent(UI.Text)                     --消耗比
    self.todayGoodsCntInside = self.panelOpen.transform:Find("Message/Text4"):GetComponent(UI.Text)   --上货比 0/5 内
    self.refreshTxt = self.panelOpen.transform:Find("Message/Text3"):GetComponent(UI.Text)          --刷新次数
    --剩余时间
    self.timerTxt = self.panelOpen.transform:Find("Message/Text2"):GetComponent(UI.Text)
    self.timerTxt.text = lang("UI_RANDOMSHOP_REMAINNING_TIME")
    self.timer = self.panelOpen.transform:Find("Message/Text2_time"):GetComponent(UI.Text)

    self.refreshBtn = self.panelOpen.transform:Find("RefreshBtn"):GetComponent(UI.Button)  --刷新按钮
    self.refreshTopTxt = self.panelOpen.transform:Find("RefreshBtn/Text") :GetComponent(UI.Text) --刷新按钮上排文字
    self.refreshButtomTxt = self.panelOpen.transform:Find("RefreshBtn/RefreshTxt") :GetComponent(UI.Text)--刷新按钮下排文字
    self.rewardBtn = self.panelOpen.transform:Find("Message/Intimacy_icon/Heart/Intimacy_light"):GetComponent(UI.Button)
    self.rewardImg = self.rewardBtn.gameObject:GetComponent(UI.Image)
    --self.rewardGlass = self.panelOpen.transform:Find("Message/Reward/PreviewBtn/Image")
    self:add_event_handler(self.rewardBtn.onClick, self.OnRewardClick)   --奖励按钮
    self:add_event_handler(self.refreshBtn.onClick, self.OnRefreshClick) --刷新
    self:add_event_handler(self.infoBtn.onClick, self.OnInfoBtn)         --商店信息按钮

    self.messager_:add_listener(Msg.CITY_RANDOM_SHOP_UPDATE, function(self, isClose)
        if isClose == 1 then
            self:close_all()
            return
        end
        self:on_open()
    end)
end

function CityRandomShopWindow:on_after_top()
    self.infoBtn.transform:SetSiblingIndex(self.transform.childCount)
end

--3.打开UI（打开/刷新UI处理）
function CityRandomShopWindow:on_open()
    if not self.randomShop then
        return
    end
    self:SetData()
end

--5.关闭UI（UIManager销毁UI前处理）
function CityRandomShopWindow:on_close()
    BuildManager:close_timer("random_shop")
    self.messager_:remove_listener(Msg.CITY_RANDOM_SHOP_UPDATE)
end

function CityRandomShopWindow:SetData()
    local basic = self.randomShop:GetBasic()
    self.todayGoodsCnt.text = self.StrFormat(self.randomShop.currTimes, basic.times)

    local isOpen = self.randomShop:IsOpen()
    self.panelUnopen.gameObject:SetActive(not isOpen)
    self.panelOpen.gameObject:SetActive(isOpen)
    --如果不在上货时间内 不执行下面
    if not isOpen then
        return
    end

    -- 亲密度 今日上货 消耗比 刷新次数
    local intimacy = self.StrFormat(self.randomShop.currIntimacy, basic.intimacy_limit)
    local times = self.StrFormat(self.randomShop.currTimes, basic.times)
    local cost =  self.StrFormat(self.randomShop.currConsume, basic.cost_limit)
    local refresh = self.StrFormat(self.randomShop.currRefresh, basic.refresh_limit)
    self.intimacyTxt.text = lang("UI_RANDOMSHOP_INTIMACY") .." "..intimacy
    self.todayGoodsCntInside.text = lang("UI_RANDOMSHOP_TODYGOODS").." "..times
    self.consumeTxt.text = lang("UI_RANDOMSHOP_CONSUME").." "..cost
    self.refreshTxt.text = lang("UI_RANDOMSHOP_REFRESH_TIMES").." "..refresh

    self.rewardImg.fillAmount = self.randomShop.currIntimacy / basic.intimacy_limit
    --刷新按钮
    self:RefreshBtn()

    --道具刷新
    self:RefreshPropList()
    --播放倒计时
    self:PlayTimer()
end

--刷新亲密度
function CityRandomShopWindow:RefreshIntimacy()
    local basic = self.randomShop:GetBasic()
    self.rewardImg.fillAmount = self.randomShop.currIntimacy / basic.intimacy_limit
    local intimacy = self.StrFormat(self.randomShop.currIntimacy, basic.intimacy_limit)
    self.intimacyTxt.text = lang("UI_RANDOMSHOP_INTIMACY").." "..intimacy
end

--刷新剩余刷新次数
function CityRandomShopWindow:RefreshTimes()
    local basic = self.randomShop:GetBasic()
    local refresh = self.StrFormat(self.randomShop.currRefresh, basic.refresh_limit)
    self.refreshTxt.text = lang("UI_RANDOMSHOP_REFRESH_TIMES")..""..refresh
end

--刷新按钮显示
function CityRandomShopWindow:RefreshBtn()
    self.refreshBtn.interactable = self.randomShop:EnableRefresh()
    GameUtil.SetImageGrey(self.refreshBtn:GetComponent(UI.Image), not self.randomShop:EnableRefresh())
    local num, txt = self.randomShop:GetRefreshPrice()
    self.refreshTopTxt.text = num
    self.refreshButtomTxt.text = txt
end

--刷新道具列表
function CityRandomShopWindow:RefreshPropList()
    local list = self.randomShop:GetPropList()
    if not list then
        dump(list, "callback can not nil")
    end
    local labels = self.randomShop:GetItemdLabel()
    for j = 1, 4 do
        local tradmod = self.panelOpen.transform:Find("ShopInfo/Tradmod"..j)
        local label = tradmod.transform:Find("title/TitleTxt"):GetComponent(UI.Text)
        label.text = labels[j]
        for i = 1, 4 do
            local v = list[j][i]
            local prop = v.prop --道具配置
            local itemCardObj = tradmod.transform:Find("ItemGroup/ItemCard"..i)
            local item = _G.ItemCard:new()
            item:AddLuaComponent(itemCardObj.gameObject)
            item:init()
            item:set_item_prop(prop.items)
            item:SetRebate(prop.discount)
            --设置按钮
            local buyBtn = itemCardObj.transform:Find("BuyBtn"):GetComponent(UI.Button)
            buyBtn.interactable = v.enable
            GameUtil.SetImageGrey(buyBtn:GetComponent(UI.Image), not v.enable)
            item:SetBuyBtn(prop.price, function()
                local req = {}
                req.type = prop.type
                req.pos = v.pos
                self:SetButtonEvent(req, buyBtn)
            end)
        end
    end
end

function CityRandomShopWindow:SetButtonEvent(req, btnObj)
    Net.send("merchant_buy", req, function(result) --favorability
        if result.e == 0 then
            if result.favorability then
                --刷新亲密度
                self.randomShop:SetIntimacy(result.favorability)
                self:RefreshIntimacy()
            end
            --刷新道具
            btnObj.interactable = false
            GameUtil.SetImageGrey(btnObj:GetComponent(UI.Image), true)
            self.randomShop:SetItemEnable({req.type, req.pos})
            --刷新消耗
            self.randomShop:SetCost(result.expense)

            local basic = self.randomShop:GetBasic()
            local cost =  self.StrFormat(self.randomShop.currConsume, basic.cost_limit)
            self.consumeTxt.text = lang("UI_RANDOMSHOP_CONSUME").." "..cost
        end
    end)
end

function CityRandomShopWindow:PlayTimer()
    BuildManager:close_timer("random_shop")
    local timeObj = self.randomShop:GetTimeStamp()
    local startTime = timeObj.startTime
    local totalTime = timeObj.totalTime
    local endTime = timeObj.endTime
    --开启倒计时
    local obj = {}
    obj.key = "random_shop" --倒计时类型
    obj.end_time = endTime
    obj.need_scene = "City"
    local time
    self.timer.gameObject:SetActive(true)
    obj.on_per_second = function()
        time = totalTime - (Net.server_time() - startTime)
        self.timer.text = UIUtil.format_time(time)
    end
    obj.on_complete = function()
        self.timer.gameObject:SetActive(false)
        self:close()
    end
    BuildManager:register_timer(obj)
end

--格式化字符串 "0/5"
function CityRandomShopWindow.StrFormat(num1, num2)
    if num1 > num2 then
        num1 = num2
    end
    return num1.."/"..num2
end

--刷新按钮
function CityRandomShopWindow:OnRefreshClick()
    if not self.randomShop:EnableRefresh() then
        return
    end
    Net.send("merchant_refresh", {}, function(result)
        if result.e == 0 then
            --刷新UI
            self:RefreshTimes()
            self:RefreshPropList()
            self:RefreshBtn()
        end
    end)
end

--获取奖励
function CityRandomShopWindow:OnGetReward()
    if not self.randomShop:EnableReward() then
        return
    end

end

function CityRandomShopWindow:OnInfoBtn()
    local title = lang("UI_RANDOMSHOP_INFO_TITLE")
    local rules = lang("UI_RANDOMSHOP_INFO_HINT")
    _G.UIManager.open_window("CityRulesWindow", nil, title, rules)
end

function CityRandomShopWindow:OnRewardClick()
    local enableReward = self.randomShop:EnableReward()
    if not enableReward then
        UIManager.open_window("RandomShopRewardWindow")
        return
    end
    Net.send("merchant_get", {}, function(result)
        if result.e == 0 then
            if result.favorability then
                --刷新亲密度
                self.randomShop:SetIntimacy(result.favorability)
                self:RefreshIntimacy()
            end
            --show reward window
            if result.items then
                local itemData = {}
                for _, v in ipairs(result.items) do
                    table.insert(itemData, v.array)
                end
                UIManager.open_window("ItemGainRewardWindow", nil, nil, itemData)
            end
        end
    end)
end

return CityRandomShopWindow