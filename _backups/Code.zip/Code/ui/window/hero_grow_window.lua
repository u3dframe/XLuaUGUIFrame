-- 武将升级界面
module("HeroGrowWindow",package.seeall)
setmetatable( HeroGrowWindow, {__index = BaseWindow} )

HERO_INFO = 1       --属性
HERO_LEVEL = 2      --升级
HERO_STAR = 3       --升星
HERO_SKILL = 4      --技能

--1.准备UI（UI美术资源加载）
function on_resource(self)
    local list = {
        "hero/HeroInfo",
        "hero/HeroStar",
        "hero/HeroLevel",
        "hero/HeroSkill",
    }

    Yield(UIUtil.load_component(list, function(prefabs) 
        self.hero_info_prefab_ = prefabs[1]
        self.hero_start_prefab_ = prefabs[2]
        self.hero_level_prefab_ = prefabs[3]
        self.hero_skill_prefab_ = prefabs[4]
    end))
end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self) 
    self.hero_scrollrect_ = self.transform:Find("Panel/ScrollView"):GetComponent(HeroScrollRect)
    self.hero_scrollrect_.userInitFinishCb = function(i) self:on_locate_scroll(i) end
    
    self.grade_ = {}
    for i=1,4 do
        self.grade_[i] = self.transform:Find("Panel/ScrollView/Grade/Grade0"..i):GetComponent(Image)
    end
    self.power_txt_ = self.transform:Find("Panel/ScrollView/ContentTop/PowerGroup/Text"):GetComponent(Text)
    self.name_txt_ = self.transform:Find("Panel/ScrollView/ContentTop/NameGroup/Name"):GetComponent(Text)
    self.desc_txt_ = self.transform:Find("Panel/ScrollView/ContentTop/NameGroup/Desc"):GetComponent(Text)   
    self.occu_icon_ = self.transform:Find("Panel/ScrollView/ContentTop/NameGroup/Icon"):GetComponent(Image)     

    self.tab_left_ = {}
    for i=1,4 do
        self.tab_left_[i] = self.transform:Find("Panel/InfoPanel/ToggleGroup/Toggle0"..i):GetComponent(Toggle)
        self:add_event_handler(self.tab_left_[i].onValueChanged, select_tab_handler, i)
    end
    
    self.hero_info_parent_ = self.transform:Find("Panel/InfoPanel/HeroInfo")
    self.hero_level_parent_ = self.transform:Find("Panel/InfoPanel/HeroLevel")
    self.hero_star_parent_ = self.transform:Find("Panel/InfoPanel/HeroStar")
    self.hero_skill_parent_ = self.transform:Find("Panel/InfoPanel/HeroSkill")

    self.messager_:add_listener(Msg.CITY_HERO_LVUP, on_hero_lvup)
    self.messager_:add_listener(Msg.UI_SKILL_CHANGE, on_skill_change)
    self.messager_:add_listener(Msg.UI_HERO_INFO, on_hero_info)
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
    self:init_hero_info()
    self:init_hero_start()
    self:init_hero_level()
    self:init_hero_skill()
    -- 等数据有了再刷模型
    self:init_drawing_comp()
    self.tab_index_ =  self.tab_index_ or 1
    if self.tab_left_[self.tab_index_].isOn then
       self.tab_left_[self.tab_index_].isOn = false 
    end
    self.tab_left_[self.tab_index_].isOn = true
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
    self.messager_:remove_listener(Msg.CITY_HERO_LVUP)
end


function on_hero_lvup(self)
    --武将升级更新战斗力
    if not self.hero_ then return end
    self.power_txt_.text = self.hero_:get_power()
end

function on_hero_info(self, list)
    if not self.gameObject.activeSelf or not self.hero_ then return end
    for _, v in ipairs(list) do
        if v.id == self.hero_.id_ then
            if self.hero_skill_ then
                self.hero_skill_:set_data(self.hero_)
            end
            if self.hero_info_ then
                self.hero_info_:set_data(self.hero_)
            end
            if self.hero_level_ then
                self.hero_level_:set_data(self.hero_)
            end
            if self.hero_star_ then
                self.hero_star_:set_data(self.hero_)
            end
            return
        end
    end
end

function init_hero_info(self)
    if self.hero_info_ then
        return
    end
    UIUtil.destroy_active_children(self.hero_info_parent_)
    local info = GameObject.Instantiate(self.hero_info_prefab_)
    info.transform:SetParent(self.hero_info_parent_, false)
    info:SetActive(true)
    self.hero_info_ = HeroInfo:new()
    self.hero_info_:AddLuaComponent(info)
    self.hero_info_:init()
end

function init_hero_start(self)
    if self.hero_star_ then
        return
    end
    UIUtil.destroy_active_children(self.hero_star_parent_)
    local info = GameObject.Instantiate(self.hero_start_prefab_)
    info.transform:SetParent(self.hero_star_parent_, false)
    info:SetActive(true)
    self.hero_star_ = HeroStar:new()
    self.hero_star_:AddLuaComponent(info)
    self.hero_star_:init()
end

function init_hero_level(self)
    if self.hero_level_ then
        return
    end
    UIUtil.destroy_active_children(self.hero_level_parent_)
    local info = GameObject.Instantiate(self.hero_level_prefab_)
    info.transform:SetParent(self.hero_level_parent_, false)
    info:SetActive(true)
    self.hero_level_ = HeroLevel:new()
    self.hero_level_:AddLuaComponent(info)
    self.hero_level_:init()
end

function init_hero_skill(self)
    if self.hero_skill_ then
        return
    end
    UIUtil.destroy_active_children(self.hero_skill_parent_)
    local info = GameObject.Instantiate(self.hero_skill_prefab_)
    info.transform:SetParent(self.hero_skill_parent_, false)
    info:SetActive(true)
    self.hero_skill_ = HeroSkill:new()
    self.hero_skill_:AddLuaComponent(info)
    self.hero_skill_:init()
end

function select_tab_handler(self, event, index)
    local tab = self.tab_left_[index]
    if event then
        self.tab_index_ = index
        if index == HERO_INFO then
            self.hero_info_parent_.gameObject:SetActive(true)
            self.hero_level_parent_.gameObject:SetActive(false)
            self.hero_star_parent_.gameObject:SetActive(false)
            self.hero_skill_parent_.gameObject:SetActive(false)
        elseif index == HERO_LEVEL then
            self.hero_info_parent_.gameObject:SetActive(false)
            self.hero_level_parent_.gameObject:SetActive(true)
            self.hero_star_parent_.gameObject:SetActive(false)
            self.hero_skill_parent_.gameObject:SetActive(false)
        elseif index == HERO_STAR then
            self.hero_info_parent_.gameObject:SetActive(false)
            self.hero_level_parent_.gameObject:SetActive(false)
            self.hero_star_parent_.gameObject:SetActive(true)
            self.hero_skill_parent_.gameObject:SetActive(false)
        elseif index == HERO_SKILL then
            self.hero_info_parent_.gameObject:SetActive(false)
            self.hero_level_parent_.gameObject:SetActive(false)
            self.hero_star_parent_.gameObject:SetActive(false)
            self.hero_skill_parent_.gameObject:SetActive(true)
        end
        self:on_locate_scroll(self.select_index_)        
    end
end

function init_drawing_comp(self)
    self.drawing_data_ = HeroManager:get_heroes()
    for i,v in ipairs(self.drawing_data_) do
        if v.id_ == self.data[1].id_ then
            self.select_index_ = i
            break
        end
    end
    self.hero_scrollrect_:InitItems(#self.drawing_data_, function(i, obj)
        local v = self.drawing_data_[i]
        local draw_go = obj.transform:Find("Image").gameObject
        local draw_go_skeleton = obj.transform:Find("Image"):GetComponent(Spine.Unity.SkeletonGraphic)
   
        local rect = obj.transform:Find("Image"):GetComponent(RectTransform)
   
        local prop = v:get_prop()
      
        local rect_data = prop.scale
        rect.anchoredPosition = Vector2(rect_data[2][1], rect_data[2][2])

        if not draw_go_skeleton then
            GameUtil.BuildSkeletonDataAsset(prop.path, draw_go, function()
                draw_go.transform.localScale = Vector3(rect_data[1], rect_data[1], rect_data[1])
            end)
        end
    end, self.select_index_)
end

function on_skill_change(self, hero_id)
    if self.gameObject.activeSelf and self.hero_.id_ == hero_id and self.tab_index_ == HERO_SKILL then
        self.hero_skill_:set_data(self.hero_)
    end
end

function on_locate_scroll(self, index)
    self.select_index_ = index
    local hero = self.drawing_data_[index]
    self.hero_ = hero
    self.data[1] = hero
    if self.tab_index_ == HERO_INFO then
        self.hero_info_:set_data(hero)
    elseif self.tab_index_ == HERO_LEVEL then
        self.hero_level_:set_data(hero)
    elseif self.tab_index_ == HERO_STAR then
        self.hero_star_:set_data(hero)
    elseif self.tab_index_ == HERO_SKILL then
        self.hero_skill_:set_data(hero)
    end
    self:show_grade(hero)
    UIUtil.set_sprite("UI/Common/HerCard/occu_0"..hero.type_, self.occu_icon_)  
    self.name_txt_.text = hero:get_color_name()
    self.desc_txt_.text = hero:get_prop().title or ""
    self.power_txt_.text = hero:get_power()
end

function show_grade(self, hero)
    local grade = hero.quality_ - 1
    if self.cur_color_ == grade then return end
    self.cur_color_ = grade
    self.grade_[grade].color = Color(1, 1, 1, 0)
    for i=1,4 do
        if i == grade then
            GameTween.DOFade(self.grade_[i], 1, 0.3)
        else
            GameTween.DOFade(self.grade_[i], 0, 0.3)
        end
    end
end
