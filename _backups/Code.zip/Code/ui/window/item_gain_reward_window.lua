module("ItemGainRewardWindow", package.seeall)
setmetatable(ItemGainRewardWindow, {__index = BaseWindow})


--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self)
	local inherent_rewards, random_rewards = self.data[1], self.data[2]
	local rewards = {}
	if inherent_rewards and #inherent_rewards > 0 then
		table.insert(rewards, inherent_rewards)
	end
	if random_rewards and #random_rewards > 0 then
		table.insert(rewards, random_rewards)
	end

	local item_prefab = self.transform:Find("Cache/ItemCard").gameObject
	item_prefab:SetActive(false)

	local title
	local title_obj = self.transform:Find("Panel/RewardPanel1/Title/Text"):GetComponent(Text)
	local content = self.transform:Find("Panel/RewardPanel1/InfoBar/Viewport/Content")
	if rewards[1] == inherent_rewards then
		title = lang("UI_BASE_GAIN_REWARDS")
	else
		title = lang("UI_BASE_RANDOM_REWARDS")
	end
	title_obj.text = title
	for _, r in pairs(rewards[1]) do
		local obj = GameObject.Instantiate(item_prefab)
		obj.transform:SetParent(content, false)
		obj:SetActive(true)
		self:set_reward_info(obj, r)
	end

	local panel2 = self.transform:Find("Panel/RewardPanel2")
	if rewards[2] then
		panel2.gameObject:SetActive(true)
		title_obj = panel2:Find("Title/Text"):GetComponent(Text)
		title_obj.text = lang("UI_BASE_RANDOM_REWARDS")
		content = panel2:Find("InfoBar/Viewport/Content")
		for _, r in pairs(rewards[2]) do
			local obj = GameObject.Instantiate(item_prefab)
			obj.transform:SetParent(content, false)
			obj:SetActive(true)
			self:set_reward_info(obj, r)
		end
	else
		panel2.gameObject:SetActive(false)
	end
end

function set_reward_info(self, obj, reward)
	local cfg = ItemManager:get_ui_info(reward)
	if not cfg then return end
	local card = obj:GetComponent(Image)
	UIUtil.set_sprite("UI/Common/Quality/item_"..cfg.quality, card)
	UIUtil.set_sprite(cfg.icon, obj.transform:Find("Icon"):GetComponent(Image))
	local cnt = obj.transform:Find("Count/Text"):GetComponent(Text)
	cnt.text = reward[3]
end
