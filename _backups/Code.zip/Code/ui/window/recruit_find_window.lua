
local RecruitFindWindow = {}
setmetatable(RecruitFindWindow, {__index = _G.BaseWindow})


local RecruitConfig = _G.Database.RecruitConfig
local RecruitManager = _G.RecruitManager
local HeroManager = _G.HeroManager
local UIUtil = _G.UIUtil
local lang = _G.lang


local Type2Page = {
    [config.HERO_TYPE1] = 2,
    [config.HERO_TYPE2] = 3,
    [config.HERO_TYPE3] = 4,
}

local Page2Type = {}
for k, v in pairs(Type2Page) do
    Page2Type[v] = k
end


local function get_page_by_type(ty)
    return Type2Page[ty] or 1
end


local function get_type_by_page(page)
    return Page2Type[page]
end


function RecruitFindWindow:on_init()
    local recruitType = self.data[1]
    self.findCfgList = {}
    for _, v in pairs(RecruitConfig.Re_selectData) do
        if v.type == recruitType then
            table.insert(self.findCfgList, v)
        end
    end

    self.cardObj = self.transform:Find("Cache/HeroCardList").gameObject
    self.cardObj:SetActive(false)
    self.selectedObj = self.transform:Find("Cache/Selected")
    self.selectedObj.gameObject:SetActive(false)
    self.scrollPanel = self.transform:Find("InfoPanel/ScrollView/Panel")
    self.gainedTitle = self.scrollPanel:Find("GainedTitle")
    self.gainedContent = self.scrollPanel:Find("GainedList")
    self.ungainedTitle = self.scrollPanel:Find("UngainedTitle")
    self.ungainedContent = self.scrollPanel:Find("UngainedList")

    local btn = self.transform:Find("InfoPanel/Button"):GetComponent(Button)
    self:add_event_handler(btn.onClick, function()
        if self.selectedID then
            RecruitManager:set_mark_target(recruitType, self.selectedID)
            self:close()
        end
    end)
    
    local toggleGroup = self.transform:Find("InfoPanel/ToggleGroup")
    local toggles = toggleGroup:GetComponentsInChildren(Toggle).Table
    for i, t in ipairs(toggles) do
        self:add_event_handler(t.onValueChanged, self.on_toggle_on, i)
    end

    self.objs = {}
    self.currentPage = 1
    self.selectedID = nil
end


function RecruitFindWindow:on_open()
    self:refresh(self.currentPage)
end


function RecruitFindWindow:on_toggle_on(isOn, page)
    if isOn then
        self.currentPage = page
        self:refresh(page)
    end
end


function RecruitFindWindow:refresh(page)
    local heroType = get_type_by_page(page)
    local findCfgList = {}
    local heroCfgs = {}
    for _, findCfg in ipairs(self.findCfgList) do
        local id = findCfg.heros
        local cfg = HeroManager:get_config(id)
        heroCfgs[id] = cfg
        if cfg then
            if not heroType or cfg.type == heroType then
                table.insert(findCfgList, findCfg)
            end
        end
    end
    table.sort(findCfgList, function(a, b)
        if heroCfgs[a.heros].quality ~= heroCfgs[b.heros].quality then
            return heroCfgs[a.heros].quality > heroCfgs[b.heros].quality
        end
        return a.heros < b.heros
    end)
    for i = #self.objs + 1, #findCfgList do
        self.objs[i] = GameObject.Instantiate(self.cardObj)
    end
    self.gainedContent:DetachChildren()
    self.ungainedContent:DetachChildren()
    local hasSelected = false
    for i, v in ipairs(findCfgList) do
        local id = v.heros
        local cfg = heroCfgs[id]
        local obj = self.objs[i]
        obj:SetActive(true)
        local btn = obj:GetComponent(Button)
        btn.onClick:RemoveAllListeners()
        self:add_event_handler(btn.onClick, function()
            self.selectedID = id
            self.selectedObj.gameObject:SetActive(true)
            self.selectedObj:SetParent(obj.transform, false)
        end)
        local bg = obj.transform:Find("Background"):GetComponent(Image)
        UIUtil.set_sprite("UI/Common/HerCard/card_"..cfg.quality, bg)
        local tex = obj.transform:Find("HeroMask/Texture"):GetComponent(Image)
        UIUtil.set_sprite("UI/Common/HerCard/card_tex"..cfg.quality, tex)
        local head = obj.transform:Find("HeroMask/HeadImage"):GetComponent(Image)
        UIUtil.set_sprite(cfg.icon, head)
        local occu = obj.transform:Find("Occu/Image"):GetComponent(Image)
        UIUtil.set_sprite("UI/Common/HerCard/occu_0"..cfg.type, occu)
        local name = obj.transform:Find("NameTxt"):GetComponent(Text)
        name.text = cfg.name
        name.color = UIUtil.get_color(config.GROW_COLOR[cfg.quality])
        local prob = obj.transform:Find("BottomBg/Prob")
        prob.gameObject:SetActive(true)
        prob:GetComponent(Text).text = lang("RECRUIT_RATE", v.up)
        if HeroManager:is_hero_active(id) then
            obj.transform:SetParent(self.gainedContent, false)
            head.color = Color.white
        else
            obj.transform:SetParent(self.ungainedContent, false)
            head.color = Color(0.3, 0.3, 0.3, 1)
        end
        local pos = obj.transform.localPosition
        pos.z = 0
        obj.transform.localPosition = pos
        obj.transform.localScale = Vector3.one
        if self.selectedID == id then
            hasSelected = true
            self.selectedObj:SetParent(obj.transform, false)
            self.selectedObj.gameObject:SetActive(true)
        end
    end
    if not hasSelected then self.selectedObj.gameObject:SetActive(false) end
    self.gainedContent.gameObject:SetActive(self.gainedContent.childCount > 0)
    self.gainedTitle.gameObject:SetActive(self.gainedContent.childCount > 0)
    self.ungainedContent.gameObject:SetActive(self.ungainedContent.childCount > 0)
    self.ungainedTitle.gameObject:SetActive(self.ungainedContent.childCount > 0)
    for i = #findCfgList + 1, #self.objs do
        self.objs[i]:SetActive(false)
    end
    LayoutRebuilder.ForceRebuildLayoutImmediate(self.scrollPanel:GetComponent(RectTransform))
end


return RecruitFindWindow
