--规则描述界面（通用）
local CityRulesWindow = {}
setmetatable(CityRulesWindow, {__index = _G.BaseWindow})

local UI = _G.UnityEngine.UI
local elog = _G.elog

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function CityRulesWindow:on_init()
    local title = self.data[1]
    local rules = self.data[2]
    if not title then
        elog("Error: parameter 'title' is nil in CityRulesWindow")
    end
    if not rules then
        elog("Error: parameter 'rules' is nil in CityRulesWindow")
    end
    self.title = self.transform:Find("Panel/Top/Text"):GetComponent(UI.Text)
    self.title.text = title or ""
    self.hintTxt = self.transform:Find("Panel/Bg/ScrollRect/Content/Text"):GetComponent(_G.Text)
    self.hintTxt.text = rules or ""
    self.closeBtn = self.transform:Find("Panel/Top/CloseBtn"):GetComponent(UI.Button)
    self:add_event_handler(self.closeBtn.onClick, function()
        self:close()
    end)
end

return CityRulesWindow