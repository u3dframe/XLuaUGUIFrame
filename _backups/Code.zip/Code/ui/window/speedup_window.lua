module("SpeedUpWindow", package.seeall)
setmetatable(SpeedUpWindow, {__index = BaseWindow})

Slider_MinCount = 1 --slider最小值
SPEEDUP_TYPE = config.SPEEDUP_ITEM --加速道具类型

Gold_Speedup_Btn = 1 --选择金币加速按钮
Prop_SpeedIp_Btn = 2 --选择道具加速按钮

Can_OverFlow = 5 * 60 -- 5分钟以前的计时器可超出剩余时间

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
local BasicConfig = _G.Database.BasicConfig


function on_init(self)
	--data
	self.type_ = self.data[1]
	self.build_id_ = self.data[2]
	--top
	self.title_ = self.transform:Find("Panel/Top/Title/Text"):GetComponent(Text)
	self.close_btn_ = self.transform:Find("Panel/Top/CloseBtn"):GetComponent(Button)
	--center
	self.center_ = self.transform:Find("Panel/Center")
	self.items_rect_ = self.center_.transform:Find("Inside/Scroll View")
	self.slider_trs_ = self.transform:Find("Panel/Center/SliderBar")
	self.content_ = self.items_rect_:Find("Viewport/Content")
	self.prefab_ = self.content_:Find("Item").gameObject
	self.prefab_:SetActive(false)

	self.timer_txt_ = self.center_.transform:Find("Timer/TimeTxt/Text"):GetComponent(Text)
	self.timer_hint_txt_ = self.center_.transform:Find("SliderBar/Slider/TimeHint/Text"):GetComponent(Text)
	self.speed_gold_txt_ = self.transform:Find("Panel/Buttom/GoldSpeedUpBtn/Number"):GetComponent(Text)
	self.no_item_hint_ = self.transform:Find("Panel/Center/NoItemHint")
	self.no_item_hint_.gameObject:SetActive(not have_prop)
	self.timer_img_ = self.center_.transform:Find("Timer/Slider"):GetComponent(Slider)

	self.slider_ = self.center_.transform:Find("SliderBar/Slider/NumberSlider"):GetComponent(Slider)
	self.number_ = self.transform:Find("Panel/Center/SliderBar/Num/Text"):GetComponent(Text)
	self.get_path_btn_ = self.center_.transform:Find("Timer/GetPathBtn"):GetComponent(Button)
	self.add_btn_ = self.center_.transform:Find("SliderBar/Slider/AddBtn"):GetComponent(Button)
	self.sub_btn_ = self.center_.transform:Find("SliderBar/Slider/SubBtn"):GetComponent(Button)
	--buttom
	self.gold_speedup_btn_ = self.transform:Find("Panel/Buttom/GoldSpeedUpBtn"):GetComponent(Button)
	self.prop_speedup_btn_ = self.transform:Find("Panel/Buttom/PropSpeedUpBtn"):GetComponent(Button)

	self.gold_number_txt_ =self.gold_speedup_btn_.transform:Find("Number")

	self.prefab_width_ = self.prefab_:GetComponent(RectTransform).sizeDelta.x
	self.prefab_hight_ = self.prefab_:GetComponent(RectTransform).sizeDelta.y
	--self.spacing_ = self.content_:GetComponent(HorizontalLayoutGroup).spacing
	--event
	self:add_event_handler(self.gold_speedup_btn_.onClick, on_gold_speedup_click)
	self:add_event_handler(self.prop_speedup_btn_.onClick, on_prop_speedup_click)
	self:add_event_handler(self.get_path_btn_.onClick, on_get_path_click)
	self:add_event_handler(self.slider_.onValueChanged, on_value_changed)
	--self:add_event_handler(self.input_field_.onEndEdit, on_end_edit_click)
	self:add_event_handler(self.add_btn_.onClick, on_add_click)
	self:add_event_handler(self.sub_btn_.onClick, on_sub_click)
	self:add_event_handler(self.close_btn_.onClick, on_close_click)

	--训练完成
    self.messager_:add_listener(Msg.CITY_SOIDIER_FINISHED, on_soldier_drill_finished)
    self.messager_:add_listener(Msg.CITY_UP_LV_FINISHED, on_uplv_finished)
    self.messager_:add_listener(Msg.CITY_SOLDIER_CURE_FINISHED, on_soldier_cure_finished)
    self.messager_:add_listener(Msg.CITY_BUILD_REMOVED_FINISHED, on_build_removed_finish)

	--暂未开放的功能
	self.get_path_btn_.interactable = false
	GameUtil.SetImageGrey(self.get_path_btn_:GetComponent(Image), true)

	self.basic_ = BasicConfig.BasicData
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
	self:set_view_by_type()
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
    self:stop_timer()
    self.messager_:remove_listener(Msg.CITY_SOIDIER_FINISHED)
    self.messager_:remove_listener(Msg.CITY_UP_LV_FINISHED)
    self.messager_:remove_listener(Msg.CITY_SOLDIER_CURE_FINISHED)
    self.messager_:remove_listener(Msg.CITY_BUILD_REMOVED_FINISHED)
end

function stop_timer(self)
	if self.lua_timer_ then
    	LuaTimer.Delete(self.lua_timer_)
    	self.lua_timer_ = nil
    end
end

function set_view_by_type(self)
	self.build_info_ = BuildManager:get_build_info_by_id(self.build_id_)
	if not self.build_info_ then elog("build info is nil") end
	--获取data（加速道具类型  时间信息）
	self:get_data_by_type()
	local item1, item2 = self:check_owned_item()
	--播放时间动画
	self:stop_timer()
	self:play_timer(self.time_obj_) 
	--设置道具UI
	self:set_scroll_rect(item1, item2)
end

----------------------------------------lvup------------------------------------------
--获取升级加速需要的数据
function get_lvup_data(self)
	self.title_.text = lang("UI_BUILD_UPGRADE")
	self.speedup_type_ = SPEEDUP_TYPE.UP
	self.time_obj_ = self:get_time_obj(self.build_info_)	     --时间对象
	local number = self.basic_.build_gold1 * self:get_remaining_time() ^ self.basic_.build_gold2 - self.basic_.build_gold3
	self.speed_gold_txt_.text = self:set_gold_number(number) --设置金币数量
end

--请求
function on_lv_up_net_send(self, req_msg)
	Net.send("build_levelup_dectime", req_msg, function(result)
		if result.e == 5 then
			MsgCenter.send_message(Msg.SHOW_HINT, lang("ITEM_NOT_ENOUGH"))
		elseif result.e == 3 then
			self:close()
		elseif result.e == 0 then
			if self.build_info_ and self.build_info_.id_ then
				MsgCenter.send_message(Msg.CITY_UP_LV_UPDATE, self.build_info_.id_)
			end
			self:on_open()
		end
	end)
end
----------------------------------------drill------------------------------------------

function get_drill_data(self)
	self.title_.text = lang("UI_SOLDIER_IN_ARMY_TRAINING")
	self.speedup_type_ = SPEEDUP_TYPE.DIRLL
	local build_type = self.build_info_.build_type_
	local _, _, soldier_id, soldier_class = SoldierManager:check_soldier_state(build_type)
	self.soldier_ = SoldierManager:get_soldier_info_by_id(soldier_id, soldier_class)
	self.time_obj_ = self:get_time_obj(self.soldier_)	              --时间对象
	
	local number = self.basic_.train_gold1 * self:get_remaining_time() ^ self.basic_.train_gold2 - self.basic_.train_gold3
	self.speed_gold_txt_.text = self:set_gold_number(number) --设置金币数量
end

function on_drill_net_send(self, req_msg)
	Net.send("build_soldier_dectime", req_msg, function(result)
		if result.e == 5 then
			MsgCenter.send_message(Msg.SHOW_HINT, lang("ITEM_NOT_ENOUGH"))
		elseif result.e == 3 then
			self:close()
		elseif result.e == 0 then
			if self.soldier_ and self.build_info_ then
				MsgCenter.send_message(Msg.CITY_SOIDIER_UPDATE, self.build_info_.id_, self.soldier_.id_)
			end
			self:on_open()
		end
	end)
end
-------------------------------------------Cure-----------------------------------------

function get_cure_data(self)
	self.title_.text = lang("UI_SPEEDUP_CURING")
	self.speedup_type_ = SPEEDUP_TYPE.CURE
	self.time_obj_ = self:get_time_obj(self.build_info_.cure_timer_)  --时间对象
	local time = self:get_remaining_time()
	local number = SoldierManager:get_glod_hurts_recover(time)
	self.speed_gold_txt_.text = self:set_gold_number(number) --设置金币数量
end

function on_cure_net_send(self, req_msg)
	Net.send("soldier_cure_dectime", req_msg, function(result)
		if result.e == 5 then
			MsgCenter.send_message(Msg.SHOW_HINT, lang("ITEM_NOT_ENOUGH"))
		elseif result.e == 3 then
			self:close()
		elseif result.e == 0 then
			MsgCenter.send_message(Msg.CITY_SOLDIER_CURE_UPDATE, self.build_info_.build_type_)
			self:on_open()
		end
	end)
end

---------------------------------------dismantle-----------------------------------------

function get_dismantle_data(self)
	self.title_.text = lang("UI_SPEEDUP_BUILDING_DISMANTLE")
	self.time_obj_ = self:get_time_obj(self.build_info_)	     --时间对象
	local number = self.basic_.build_gold1 * self:get_remaining_time() ^ self.basic_.build_gold2 - self.basic_.build_gold3
	self.speed_gold_txt_.text = self:set_gold_number(number) --设置金币数量
end

function on_dismantle_net_send(self, req_msg)
	
	Net.send("build_levelup_dectime", req_msg, function(result)
	--Net.send("build_dismantle_dectime", req_msg, function(result)
		if result.e == 0 then
			MsgCenter.send_message(Msg.CITY_UP_LV_UPDATE, self.build_info_.id_)
			self:on_open()
		elseif result.e == 3 then
			self:close()
		elseif result.e == 5 then
			MsgCenter.send_message(Msg.SHOW_HINT, lang("ITEM_NOT_ENOUGH"))
		end
	end)
end

---------------------------------------------------------------------------------------
function get_data_by_type(self)
	if self.check_func[self.type_]["get_data"] then
		self.check_func[self.type_]["get_data"](self)
	end
end

function net_send(self, res_msg)
	if self.check_func[self.type_]["net_send"] then
		self.check_func[self.type_]["net_send"](self, res_msg)
	end
end

check_func = {
	--升级加速
	[config.SPEEDUP_LVUP] = {
		["get_data"] = get_lvup_data,
		["net_send"] = on_lv_up_net_send,
	},
	--训练加速
	[config.SPEEDUP_DRILL] = {
		["get_data"] = get_drill_data,
		["net_send"] = on_drill_net_send,
	},
	--治疗加速
	[config.SPEEDUP_CURE] = {
		["get_data"] = get_cure_data,
		["net_send"] = on_cure_net_send,
	},
	--拆除加速
	[config.SPEEDUP_DISMANTLE] = {
		["get_data"] = get_dismantle_data,
		["net_send"] = on_dismantle_net_send,
	}
}
---------------------------------------------------------------------------------------


--设置金币数量
function set_gold_number(self, number)
	-- 金币=系数1*（训练时间）^系数2-系数3
	-- 结果四舍五入，最小值为1
	if not number then elog("number is nil") number = 1 end
	local integer_num = math.floor(number + 0.5)
	if integer_num <= 0 then integer_num = 1 end
	return integer_num
end

--获取已经拥有的加速道具  type: 加速道具类型
function check_owned_item(self)
	local common_item, special_item = {}, {}
	local items = ItemManager:GetSpeedupItems(self.speedup_type_, true)
	for _, v in ipairs(items) do
		if v:get_prop_expedite().type == config.SPEEDUP_ITEM.COMMON then
			table.insert(common_item, v)
		else
			table.insert(special_item, v)
		end
	end
	if not special_item and not common_item then
		elog("Error: Not Found speenup props")
	end
	self.specialty_len_ = special_item and #special_item or 0 --专用道具数量
	self.common_len_ = common_item and #common_item or 0  	  --通用道具数量
	return special_item, common_item
end

function set_scroll_rect(self, item1, item2)
	local items_all = {}
	--排序 专用>通用 时间长的>时间短的
	local order_items1 = self:sort_items(item1, items_all)
	local order_items2 = self:sort_items(item2, items_all)
	--设置选中优先级
	self.select_item_id_ = self:set_priority(order_items1, order_items2)

	--有道具设置view
	local have_prop = #items_all > 0
	if have_prop then self:set_items(items_all) end
	
	--没有道具则隐藏view

	self.no_item_hint_.gameObject:SetActive(not have_prop)
	self.items_rect_.gameObject:SetActive(have_prop)
	self.slider_trs_.gameObject:SetActive(have_prop)
	self.prop_speedup_btn_.interactable = have_prop
    GameUtil.SetImageGrey(self.prop_speedup_btn_:GetComponent(Image), not have_prop)
end

function set_priority(self, items1, items2)
	--优先选择专用道具
	--优先选择单个道具时间小于 计时器剩余时间的
	local id
	local a, b, time1 = self:find_best_item(items1)
	local x, y, time2 = self:find_best_item(items2)
	if self.specialty_len_ > 0 and self.common_len_ > 0 then
		if a then return a
		elseif x then return x
		elseif b and y then
			if time1 <= time2 then return b end
			return y
		end
	elseif self.specialty_len_ > 0 or self.common_len_ > 0 then
		if self.specialty_len_ > 0 then
			if a then return a
			elseif b then return b
			end
		else
			if x then return x
			elseif y then return y
			end
		end
	end
	return 0
end

--在同一类型道具中获取最优选择
function find_best_item(self, items)
	if not items then return end
	local less_item, beyond_item, time
	local remaining_time = self:get_remaining_time()
	for k, v in ipairs(items) do
		local prop_time = v:get_prop_expedite().time / 1000
		if prop_time <= remaining_time then
			if not less_item then less_item = v.id_ end
		else
			beyond_item = v.id_
			time = prop_time
		end
	end
	--道具有可能小于倒计时，或者大于倒计时。
	--less_item   小于倒计时 的最佳选择
	--beyond_item 大于倒计时 的最佳选择
	--time        道具时间(大于倒计时时候的时间)
	return less_item, beyond_item, time
end

--加速道具排序
function sort_items(self, items, items_all)
	if not items then return end
	table.sort(items, function(a, b)
		local a_time = 0
		local b_time = 0
		if a:get_prop_expedite() then
			a_time = a:get_prop_expedite().time
		end
		if b:get_prop_expedite() then
			b_time = b:get_prop_expedite().time
		end
		return a_time > b_time
	end)
	for _, v in pairs(items) do
		table.insert(items_all, v)
	end
	return items
end

function set_items(self, items)
	self.content_:GetComponent(ToggleGroup).allowSwitchOff = true
	--道具prefab缓存池
	self.item_tb_ = self.item_tb_ or {}
	self.key_ = nil    --优先选中的索引
	for k, v in pairs(self.item_tb_) do
		v.gameObject:SetActive(false)
	end
	for k, v in pairs(items) do
		if v.id_ == self.select_item_id_ then self.key_ = k end
		local item_obj = self.content_.transform:Find("obj_"..k)
		if not item_obj then
			item_obj = GameObject.Instantiate(self.prefab_)
			item_obj.name = "obj_"..k
        	item_obj.transform:SetParent(self.content_.transform, false)
        	item_obj.transform.localScale = Vector3.one
			table.insert(self.item_tb_, item_obj)
		end
		item_obj.gameObject:SetActive(true)
        local btn = item_obj.gameObject:GetComponent(Toggle)
		local icon_bg = item_obj:GetComponent(Image)
		UIUtil.set_sprite("UI/Common/Quality/item_"..v.prop_.quality, icon_bg)
		local icon = item_obj.transform:Find("Icon"):GetComponent(Image)
		UIUtil.set_sprite(v.prop_.icon, icon)
        local remain_cnt = item_obj.transform:Find("Count/Text"):GetComponent(Text)
        local label = item_obj.transform:Find("Label/Text"):GetComponent(Text)
        btn.onValueChanged:RemoveAllListeners()
        self:add_event_handler(btn.onValueChanged, on_toggle_changed, item_obj, v, k)
		btn.isOn = false
        remain_cnt.text = UIUtil.res_num_to_str(v.count_)
        label.text = v.prop_.label
	end
	if not self.key_ then elog("self.key_ is nil") end
	if not self.item_tb_ and not self.item_tb_[self.key_] then return end

	--代码设置content的矩阵大小。 如果用content size fitter 组件，则第一次加载item之后。对content的anchoredPosition 设置会无效果
	--local width = self.prefab_width_ * #items + self.spacing_ * (#items -1)
	--self.content_.transform.sizeDelta = Vector2(width, self.prefab_hight_)

	self.content_:GetComponent(ToggleGroup).allowSwitchOff = false
	local toggle = self.item_tb_[self.key_].gameObject:GetComponent(Toggle)
	toggle.isOn = true
end

function on_toggle_changed(self, event_data, obj, data, index)
	if not data then return end
	--local select_img = obj.transform:Find("IconArea/Selected")
	if event_data then
		--self:beyond_border(index) --超出边界处理
		--获取数据
		self.curr_prop_item_ = data
		self.item_id_ = data.id_
		self:set_slider_value(self.curr_prop_item_)
		local count = self.slider_.maxValue
		if self.slider_.value == count then 
			self:on_value_changed(count)
		else
			self.slider_.value = count
		end
	end
end

function set_slider_value(self, prop)
	local max_value, min_value
	--max_value
	local remaining_time = self:get_remaining_time() --剩余时间 
	local time = prop:get_prop_expedite().time / 1000
	if time <= Can_OverFlow then
		max_value = math.ceil(remaining_time / time)
	else
		max_value = math.floor(remaining_time / time)
	end
	max_value = max_value == 0 and 1 or max_value

	if max_value > prop.count_ then max_value = prop.count_ end
	--min_value
	if max_value == 1 then
		min_value = 0
	else
		min_value = Slider_MinCount
	end
	self.slider_.maxValue = max_value
	self.slider_.minValue = min_value
end

function play_timer(self, obj)
	if not obj then return end
	if not obj.start_time_ or not obj.end_time_ then return end
	local start_time = obj.start_time_
	local end_time = obj.end_time_
	local total_time = math.floor(obj.total_time_)
	local curr_second = total_time - (math.floor(end_time - Net.server_time()))
	if curr_second < 0 then curr_second = 0 end

 	local last_time = Net.server_time()
 	self.lua_timer_ = LuaTimer.Add(0, 1000, function()
 		--时间不精确处理
        if Net.server_time() - last_time > 1 then
            curr_second = curr_second + 1
        end
        last_time = Net.server_time()

        if curr_second > total_time then
            return false
        end
        self.timer_txt_.text = UIUtil.format_time(total_time - curr_second)
		self.timer_img_.value = curr_second / total_time
        curr_second = curr_second + 1
 	end)
end


--格式化道具总时长
function props_total_time(self, count)
	if not self.curr_prop_item_ then
		return "00:00:00"
	end
	local time = self.curr_prop_item_:get_prop_expedite().time / 1000
	return UIUtil.format_time(count * time)
end

--获取计时器剩余时间
function get_remaining_time(self)
	if not self.time_obj_ then return end
	return self.time_obj_.end_time_ - Net.server_time()
end

function get_time_obj(self, data)
	if not data then return end
	if not data.start_time_ or not data.end_time_ or not data.total_time_ then
		return
	end
	local obj = {}
	obj.start_time_ = data.start_time_
	obj.end_time_ = data.end_time_
	obj.total_time_ = data.total_time_
	return obj
end

function on_value_changed(self, event_data)
	--只能使用一个的情况下
	if self.slider_.maxValue == 1 then
		event_data = 1
	end
	self.select_cnt_ = event_data
	--self.input_field_.text = event_data
	self.number_.text = event_data.."/"..self.slider_.maxValue
	local str = lang("UI_SPEEDUP_SUB_TIME", self:props_total_time(event_data))
	self.timer_hint_txt_.text = str
end

function on_end_edit_click(self, event_data)
	local input = tonumber(event_data)
	if not input then return end
	if input <= 0 then
		input = 1
	elseif input >= self.slider_.maxValue then
		input = self.slider_.maxValue
	end
	if input == self.slider_.value then
		self:on_value_changed(input)
	end
	self.slider_.value = tonumber(input)
end

function on_add_click(self, event_data)
	if self.slider_.value >= self.slider_.maxValue then
		return
	end
	self.slider_.value = self.slider_.value + 1
end

function on_sub_click(self, event_data)
	if self.slider_.value <= Slider_MinCount then
		return
	end
	self.slider_.value = self.slider_.value - 1
end

function on_get_path_click(self, event_data)

end

function on_left_btn(self, event_data)
	if not self.item_tb_ then return end
	if not self.item_tb_[self.key_ - 1] then return end
	self.key_  = self.key_ - 1
	self.item_tb_[self.key_]:GetComponent(Toggle).isOn = true
end

function ob_right_btn(self, event_data)
	if not self.item_tb_ then return end
	if not self.item_tb_[self.key_ + 1] then return end
	if not self.item_tb_[self.key_ + 1].gameObject.activeSelf then return end
	self.key_  = self.key_ + 1
	self.item_tb_[self.key_]:GetComponent(Toggle).isOn = true
end

--金币加速按钮
function on_gold_speedup_click(self, event_data)
	local req_msg = {}
	req_msg.id = self.build_info_.id_
	self:show_tips_view(Gold_Speedup_Btn, req_msg)
end

--道具加速按钮
function on_prop_speedup_click(self, event_data)
	local req_msg = {}
	req_msg.id = self.build_info_.id_
	req_msg.itemid = self.item_id_
	req_msg.itemcnt = self.select_cnt_
	--道具的时间
	local prop_time = self.curr_prop_item_:get_prop_expedite().time / 1000 * self.select_cnt_
	local remaining_time = self:get_remaining_time()
	if prop_time > remaining_time then
		self:show_tips_view(Prop_SpeedIp_Btn, req_msg)
	else
		self:net_send(req_msg)
	end
end

function show_tips_view(self, btn_type, req_msg)
	local msg_ = {}
	msg_.title = ""
	if btn_type == Gold_Speedup_Btn then
		msg_.content = lang("UI_SPEEDUP_HINT2")
		msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_SPEEDUP_BTN1")}
	elseif btn_type == Prop_SpeedIp_Btn then
		msg_.content = lang("UI_SPEEDUP_HINT3")
		msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
	end
	msg_.callback = function(index)
		if index == 2 then
			self:net_send(req_msg)
		end
    end
    MsgCenter.send_message(Msg.SHOW_NOTIFY, msg_)
end

function on_soldier_drill_finished(self, build_id, soldier_id)
	if self.build_info_ and self.build_info_.id_ == build_id then
		self:close_all()
	end
end

function on_uplv_finished(self, build_id)
	if self.build_info_ and self.build_info_.id_ == build_id then
		self:close_all()
	end
end

function on_soldier_cure_finished(self)
	if self.build_info_.build_type_ == config.BUILD_TYPE.HOSPITAL then
		self:close_all()
	end
end

function on_build_removed_finish(self, sapce_id, build_id)
	if self.build_info_ and self.build_info_.id_ and self.build_info_.id_ == build_id then
		self:close()
	end
end

function on_close_click(self, event_data)
	self:close() 
end



