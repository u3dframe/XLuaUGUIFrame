local HeroRecruitWindow = {}
setmetatable(HeroRecruitWindow, {__index = _G.BaseWindow})


local RecruitConfig = _G.Database.RecruitConfig
local UI = _G.UnityEngine.UI
local lang = _G.lang
local RecruitManager = _G.RecruitManager
local ItemManager = _G.ItemManager
local BuildManager = _G.BuildManager
local UIUtil = _G.UIUtil
local GameUtil = _G.GameUtil
local Msg = _G.Msg


local TimerKey = "FREE_COOLDOWN_"


--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function HeroRecruitWindow:on_init()
    local panels = {
        [config.RECRUIT_TYPES.COMMON] = self.transform:Find("Panel/RecruitInfo/Normalbg"),
        [config.RECRUIT_TYPES.HIGH] = self.transform:Find("Panel/RecruitInfo/Higherbg"),
    }
    self.components = {}
    self.originFontColor = {}
    for _, ty in pairs(config.RECRUIT_TYPES) do
        local components = {}
        self.components[ty] = components
        local panel = panels[ty]
        local previewBtn = panel:Find("Preview1"):GetComponent(Button)
        self:add_event_handler(previewBtn.onClick, function()
            UIManager.open_window("HeroRecruitPopWindow", nil, ty)
        end)

        local costProp = RecruitManager.costProp[ty].onePrice
        local costCfg = ItemManager:get_ui_info(costProp)
        local board = panel:Find("board1")
        UIUtil.set_sprite(costCfg.icon, board:Find("item1"):GetComponent(Image))
        board:Find("Text"):GetComponent(Text).text = ItemManager:get_count_by_prop(costProp)
        -- self:add_event_handler(board:Find("addBtn"):GetComponent(Button).onClick, function()
        --     --TODO
        -- end)

        components.find = panel:Find("Find1")
        local findIcon = components.find:Find("Icon")
        self:add_event_handler(findIcon:GetComponent(Button).onClick, function()
            if RecruitManager:is_mark_available(ty) then
                UIManager.open_window("RecruitFindWindow", nil, ty)
            else
                MsgCenter.send_message(Msg.SHOW_NOTIFY, {
                    title = "",
                    content = lang("RECRUIT_HINT"),
                    buttons = {lang("UI_BASIC_SURE")},
                })
            end
        end)
        local delFindBtn = components.find:Find("deleteBtn"):GetComponent(Button)
        self:add_event_handler(delFindBtn.onClick, function()
            if RecruitManager:is_mark_available(ty) and RecruitManager:get_mark(ty) then
                RecruitManager:set_mark_target(ty)
            end
        end)

        components.hint = panel:Find("Hint")

        local oneBtn = panel:Find("recruit1Btn")
        components.oneBtn = oneBtn
        self:add_event_handler(oneBtn:GetComponent(Button).onClick, function()
            local send = RecruitManager:recruit_free(ty)
            if not send then
                RecruitManager:recruit_one(ty)
            end
        end)

        local countDown = panel:Find("countdown")
        local cdText = countDown:Find("Text"):GetComponent(Text)
        local cdIcon = countDown:Find("Image")
        UIUtil.set_sprite(costCfg.icon, cdIcon:GetComponent(Image))
        components.cdText = cdText
        components.cdIcon = cdIcon

        local tenBtn = panel:Find("recruit2Btn")
        components.tenBtn = tenBtn
        self:add_event_handler(tenBtn:GetComponent(Button).onClick, function()
            RecruitManager:recruit_ten(ty)
        end)

        local cost2 = panel:Find("Cost")
        UIUtil.set_sprite(costCfg.icon, cost2:Find("Image"):GetComponent(Image))
        local cost2text = cost2:Find("Text"):GetComponent(Text)
        cost2text.text = RecruitManager.costProp[ty].tenPrice[3]
        self.originFontColor[ty] = cost2text.color

        local on_item_change = function()
            local cnt = ItemManager:get_count_by_prop(costProp)
            board:Find("Text"):GetComponent(Text).text = cnt
            local red = UIUtil.get_color(config.FONT_COLOR.RED)
            if cnt < RecruitManager.costProp[ty].tenPrice[3] then
                cost2text.color = red
            else
                cost2text.color = self.originFontColor[ty]
            end
            if RecruitManager:get_unused_free_count(ty) <= 0 and cnt < RecruitManager.costProp[ty].onePrice[3] then
                cdText.color = red
            else
                cdText.color = self.originFontColor[ty]
            end
        end
        self.messager_:add_listener(Msg.ITEM_CHANGE, on_item_change)
        on_item_change()
        self:play_timer(ty)
    end

    UIManager:set_info_callback(self, function()
        UIManager.open_window("CityRulesWindow", nil, lang("RECRUIT_RULE_TITLE"), lang("RECRUIT_RULE_INFO"))
    end)

    self.messager_:add_listener(Msg.RECRUIT_INFO_ALL, function(self)
        for _, ty in pairs(config.RECRUIT_TYPES) do
            self:refresh(ty)
            self:play_timer(ty)
        end
    end)
    self.messager_:add_listener(Msg.RECRUIT_FREE_SUCCESS, function(slf, ty)
        slf:refresh(ty)
        slf:play_timer(ty)
    end)
    self.messager_:add_listener(Msg.RECRUIT_ONE_SUCCESS, self.refresh)
    self.messager_:add_listener(Msg.RECRUIT_TEN_SUCCESS, self.refresh)
    self.messager_:add_listener(Msg.RECRUIT_SET_MARK, self.refresh)
end


function HeroRecruitWindow:on_open()
    for _, ty in pairs(config.RECRUIT_TYPES) do
        self:refresh(ty)
    end
end


function HeroRecruitWindow:on_close()
    for _, ty in pairs(config.RECRUIT_TYPES) do
        BuildManager:close_timer(TimerKey..ty)
    end
end


function HeroRecruitWindow:refresh(_type)
    if not self.gameObject.activeSelf then return end
    local coms = self.components[_type]

    local findAvailable = RecruitManager:is_mark_available(_type)
    local mark = RecruitManager:get_mark(_type)
    coms.find:Find("Lock").gameObject:SetActive(not findAvailable)
    local findDeletable = false

    if findAvailable then
        local head = coms.find:Find("Icon/Head"):GetComponent(Image)
        if mark then
            findDeletable = true
            local hero = HeroManager:get_config(mark)
            UIUtil.set_sprite(hero.icon, head)
        else
            UIUtil.set_sprite("UI/Common/VeryCommon/default", head)
        end
    else
        local findTxt = coms.find:Find("Lock/bg/amount"):GetComponent(Text)
        findTxt.text = RecruitManager:get_total_count(_type).."/"..RecruitConfig.Re_listData[_type].find_time
    end
    coms.find:Find("deleteBtn").gameObject:SetActive(findDeletable)
    
    local ubc = RecruitManager:get_unused_buy_count(_type)
    coms.hint:Find("HintamountTxt"):GetComponent(Text).text = ubc
    local hint2 = coms.hint:Find("HintTxt2"):GetComponent(Text)
    if findAvailable then
        if mark then
            hint2.text = lang("RECRUIT_EXCHANGE_HINT")
        else
            hint2.text = lang("RECRUIT_SELECT_HINT")
        end
    else
        hint2.text = lang("RECRUIT_FIND_UNLOCK", RecruitManager:get_rest_mark_count(_type))
    end

    local oneBtn = coms.oneBtn:GetComponent(Button)
    GameUtil.SetImageGrey(oneBtn.gameObject:GetComponent(Image), ubc < 1)
    oneBtn.interactable = ubc >= 1
    local tenBtn = coms.tenBtn:GetComponent(Button)
    GameUtil.SetImageGrey(tenBtn.gameObject:GetComponent(Image), ubc < 10)
    tenBtn.interactable = ubc >= 10
end


function HeroRecruitWindow:play_timer(_type)
    local key = TimerKey.._type
    BuildManager:close_timer(key)
    local cdText = self.components[_type].cdText
    local cdIcon = self.components[_type].cdIcon
    local oneBtnText = self.components[_type].oneBtn:GetComponentInChildren(Text)

    local cd = RecruitManager:get_free_cooldown(_type)
    local cost = RecruitManager.costProp[_type].onePrice
    local on_complete = function()
        local ufc = RecruitManager:get_unused_free_count(_type)
        if ufc > 0 then
            oneBtnText.text = lang("RECRUIT_FREE_TIMES", ufc, RecruitConfig.Re_listData[_type].daily_free)
            cdIcon.gameObject:SetActive(false)
            cdText.text = ""
        else
            oneBtnText.text = lang("RECRUIT_SINGLE_DRAW")
            cdIcon.gameObject:SetActive(true)
            cdText.text = cost[3]
            if ItemManager:get_count_by_prop(cost) < cost[3] then
                cdText.color = UIUtil.get_color(config.FONT_COLOR.RED)
            else
                cdText.color = self.originFontColor[_type]
            end
        end
        LayoutRebuilder.ForceRebuildLayoutImmediate(cdText.gameObject:GetComponent(RectTransform))
    end

    if cd <= 0 or RecruitManager:get_unused_free_count(_type) <= 0 then
        return on_complete()
    else
        cdIcon.gameObject:SetActive(false)
        oneBtnText.text = lang("RECRUIT_SINGLE_DRAW")
        cdText.color = self.originFontColor[_type]
    end
    
    local obj = {}
    obj.key = key
    obj.end_time = Net.server_time() + cd
    local time
    obj.on_per_second = function()
        local cd = RecruitManager:get_free_cooldown(_type)
        cdText.text = lang("RECRUIT_FREE_COUNTDOWN", UIUtil.format_time(cd))
    end
    obj.on_complete = on_complete
    BuildManager:register_timer(obj)
end


return HeroRecruitWindow
