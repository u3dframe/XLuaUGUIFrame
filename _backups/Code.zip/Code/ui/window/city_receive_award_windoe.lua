--市舶司领取奖励窗口
local ReceiveAwardWindow = {}
setmetatable(ReceiveAwardWindow, {__index = _G.BaseWindow})

local UI = _G.UnityEngine.UI
local lang = _G.lang
local Net = _G.Net
local UIUtil = _G.UIUtil
local elog = _G.elog
local Msg = _G.Msg

function ReceiveAwardWindow:on_init()
    self.wharf = _G.BuildManager:GetWharfInfo()
    self.title = self.transform:Find("Panel/Top/Text"):GetComponent(UI.Text)
    --self.title.text = "恭喜获得"
    self.title.text = lang("UI_CITY_RECEIVE_AWARD")
    self.closeBtn = self.transform:Find("Panel/Top/CloseBtn"):GetComponent(UI.Button)

    self.itemObj = self.transform:Find("Panel/ItemCard")
    self.receiveBtn = self.transform:Find("Panel/Button"):GetComponent(UI.Button)
    self:add_event_handler(self.receiveBtn.onClick, self.OnReceiveClick)
    self:add_event_handler(self.closeBtn.onClick, function()
        self:close()
    end)

    self:SetData()
end

function ReceiveAwardWindow:SetData()
    local prop = self.wharf:GetReward()
    if not prop then
        return
    end
    local name = self.itemObj.transform:Find("NameTxt"):GetComponent(UI.Text)
    local des = self.itemObj.transform:Find("DesTxt"):GetComponent(UI.Text)
    local cnt = self.itemObj.transform:Find("Numtxt"):GetComponent(UI.Text)
    local bg = self.itemObj.transform:Find("ItemCard"):GetComponent(UI.Image)
    local icon = self.itemObj.transform:Find("ItemIcon"):GetComponent(UI.Image)

    local cfg = _G.ItemManager:get_ui_info({prop[1], prop[2]})
    if not cfg then
        return elog("get_ui_info. cfg is nil")
    end
    UIUtil.set_sprite("UI/Common/Quality/item_"..cfg.quality, bg)
    UIUtil.set_sprite(cfg.icon, icon)
    cnt.text = prop[3]
    name.text = cfg.name
    des.text = cfg.desc
end

function ReceiveAwardWindow:OnReceiveClick()
    local itemData = self.wharf:GetReward()
    Net.send("wharf_get_reward", {}, function(result)
        if result.e == 0 then
            self:close(function()
                _G.UIManager.open_window("ItemGainRewardWindow", nil, nil, {itemData})
            end)
        end
    end)
end

return ReceiveAwardWindow