-- 守军详情
module("WorldFortInfoWindow",package.seeall)
setmetatable( WorldFortInfoWindow, {__index = BaseWindow} )

--1.准备UI（UI美术资源加载）
function on_resource(self)
    
    local list = {
        "hero/HeroCard",
        "Common/ItemCard"
    }

    Yield(UIUtil.load_component(list, function(prefabs) 
        self.hero_card_prefab_ = prefabs[1]
        self.item_prefab_ = prefabs[2]
    end))

end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self) 
    self.btn_llose_ = self.transform:Find("WindowObj/Close"):GetComponent(Button)
	self:add_event_handler(self.btn_llose_.onClick, function()
        self:close()
    end)

    self.item_panel_ = self.transform:Find("WindowObj/ItemPanel/Contents/ItemList")
    
    
    self.soldier_panel_ = self.transform:Find("WindowObj/TroopPanel/Contents/SoldierList")
    self.soldier_prefab_ = self.transform:Find("WindowObj/Cache/Soldier").gameObject
    self.soldier_prefab_:SetActive(false)
    self.soldier_go_ = {}
    self.soldier_desc_ = self.transform:Find("WindowObj/ItemPanel/TitleGroup1/Num"):GetComponent(Text)
    
    -- hero panel
    self.hero_parent_ = {}
    self.hero_go_ = {}
    for i=1,2 do
        local str = string.format("WindowObj/ItemPanel/HeroContent/Hero%d/HeroCard", i)
        self.hero_parent_[i] = self.transform:Find(str)
    end
    self.messager_:add_listener(Msg.WORLD_FORT_DELETE, on_fort_delete) 
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
    self.obj_ = self.data[1]
    local prop = self.obj_:get_prop()
    self.first_reward_ = prop.first_reward
    self.hero_id_ = prop.general
    _G.WorldManager:GetTroops(self.obj_, function(troops)
        self.soldier_list_ = troops.soldiers
        self.heroesList = troops.heroes
        self:init_item_panel()
        self:init_monster_panel()
        self:set_show_result()
        self:init_hero_panel()
    end)
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
    if self.item_go_ then
        for k,v in pairs(self.item_go_) do
            if v then
                Object.Destroy(v.gameObject)
            end
        end  
    end
    if self.soldier_go_ then
        for k,v in pairs(self.soldier_go_) do
            if v then
                Object.Destroy(v)
            end
        end  
    end
    self.item_go_ = nil
    self.soldier_go_ = nil
end

function init_item_panel(self)
    UIUtil.destroy_all_children(self.item_panel_)
    self.item_go_ = {}
    for i,v in ipairs(self.first_reward_) do
        local itemobj = GameObject.Instantiate(self.item_prefab_)
        itemobj.name = tostring(i)
        itemobj:SetActive(true)
        itemobj.transform:SetParent(self.item_panel_, false)
        itemobj.transform.localScale = Vector3(0.8,0.8,0.8)
        self.item_go_[i] = ItemCard:new()
        self.item_go_[i]:AddLuaComponent(itemobj)
        self.item_go_[i]:init()
        self.item_go_[i]:set_item_prop(v)
    end
end

function init_monster_panel(self)
    UIUtil.destroy_all_children(self.soldier_panel_)
    local all_num = 0
    for i,v in ipairs(self.soldier_list_) do
        if not self.soldier_go_[i] then
            self.soldier_go_[i] = GameObject.Instantiate(self.soldier_prefab_)
            self.soldier_go_[i].transform:SetParent(self.soldier_panel_, false)
        end
        self.soldier_go_[i]:SetActive(true)
        local prop = SoldierManager:get_soldier_prop_by_id(v[1]) 
        local icon = self.soldier_go_[i].transform:Find("IconArea/Icon"):GetComponent(Image)
        local num = self.soldier_go_[i].transform:Find("UseCount/UseCount"):GetComponent(Text)
        local name = self.soldier_go_[i].transform:Find("Name"):GetComponent(Text)
        num.text = v[2]
        name.text = lang("RESPOINT_3", prop.lv, prop.name)
        UIUtil.set_sprite(prop.route, icon)
        all_num = all_num + v[2]
    end
    self.soldier_desc_.text = string.format("防守部队总数（%d）", all_num)
end

function on_fort_delete(self, id)
    if self.obj_.idx_ ~= id then return end
    self:close()
end

function set_show_result(self)
    local rect_troop = self.transform:Find("WindowObj/TroopPanel"):GetComponent(RectTransform)
    local item_go1 = self.transform:Find("WindowObj/ItemPanel/TitleGroup2").gameObject
    local item_go2 = self.transform:Find("WindowObj/ItemPanel/Contents").gameObject
    if self.obj_:has_troop() then
        item_go1:SetActive(false)
        item_go2:SetActive(false)
    else
        item_go1:SetActive(true)
        item_go2:SetActive(true)
    end
end

function init_hero_panel(self)
    for i=1,2 do
        local v = self.heroesList[i]
        if not self.hero_go_[i] then
            local card = GameObject.Instantiate(self.hero_card_prefab_)
            card.transform:SetParent(self.hero_parent_[i], false)
            card:SetActive(true)
            self.hero_go_[i] = HeroCard:new(self)
            self.hero_go_[i]:AddLuaComponent(card)
            self.hero_go_[i]:init()
        end
        if v then
            local i = v.pos_
            local bg = self.hero_parent_[i]:Find("../Background"):GetComponent(Image)
            local bg_btn = self.hero_parent_[i]:Find("../Background"):GetComponent(Button)

            

            self.hero_go_[i].gameObject:SetActive(true)        
            self.hero_go_[i]:set_data_troops_ex(v, i)  
        else
            self.hero_go_[i]:set_data_troops_ex(nil, i)  
        end
    end
end
