-- 坐标输入界面
module("WorldAxisWindow",package.seeall)
setmetatable( WorldAxisWindow, {__index = BaseWindow} )


--1.准备UI（UI美术资源加载）
function on_resource(self)

end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self) 
    self.btn_login_ = self.transform:Find("WindowObj/Close"):GetComponent(Button)
	self:add_event_handler(self.btn_login_.onClick, function()
        self:close()
    end)
    self.input_x_ = self.transform:Find("WindowObj/AxisPanel/InputFieldX"):GetComponent(InputField)
    self:add_event_handler(self.input_x_.onValueChanged, on_input_field_value, self.input_x_)    
    self.input_z_ = self.transform:Find("WindowObj/AxisPanel/InputFieldZ"):GetComponent(InputField)
    self:add_event_handler(self.input_z_.onValueChanged, on_input_field_value, self.input_z_)
    
    self.go_btn_ = self.transform:Find("WindowObj/GoBtn"):GetComponent(Button)
    self:add_event_handler(self.go_btn_.onClick, on_select_axis_go_handler)
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
	self.input_x_.text = self.data[1]
    self.input_z_.text = self.data[2]
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
     
end

function on_select_axis_go_handler(self, event)
    local x = tonumber(self.input_x_.text)
    local z = tonumber(self.input_z_.text)
    self:close()
    SceneManager.World_Scene:goto_axis(x, z)
end

function on_input_field_value(self, event, com)
    local num = tonumber(event)
    if type(num) ~= "number" then return end
    if num < 0 then
        com.text = 0
        return
    end
    if num <= config.WORLD_WIDTH then return end

    com.text = config.WORLD_WIDTH
    
    
end
