-- 邮件列表界面
module("MailListWindow",package.seeall)
setmetatable( MailListWindow, {__index = BaseWindow} )


--一次加载的邮件数
NUM_LOAD_ONCE = 8

--邮件时间刷新间隔
MAIL_TIME_REFRESH_INTERVAL = 60


local TypeInfo = {
    [config.MAIL_MODULE_TYPES.COMMON] = {
        [config.MAIL_TYPES[config.MAIL_MODULE_TYPES.COMMON].ALLIANCE] = {
            ListItemName = "ItemMsg",
            DetailPanelName = "DetailCommon",
            BatchReadable = true,
            BatchDeletable = true,
            IconPreName = "default",
            NeedRefreshTime = true,
        },
        [config.MAIL_TYPES[config.MAIL_MODULE_TYPES.COMMON].ACTIVITY] = {
            ListItemName = "ItemMsg",
            DetailPanelName = "DetailCommon",
            BatchReadable = true,
            BatchDeletable = true,
            IconPreName = "default",
            NeedRefreshTime = true,
        },
        [config.MAIL_TYPES[config.MAIL_MODULE_TYPES.COMMON].SYSTEM] = {
            ListItemName = "ItemMsg",
            DetailPanelName = "DetailCommon",
            BatchReadable = true,
            BatchDeletable = true,
            IconPreName = "default",
            NeedRefreshTime = true,
        },
    },
    [config.MAIL_MODULE_TYPES.REPORT] = {
        [config.MAIL_TYPES[config.MAIL_MODULE_TYPES.REPORT].BATTLE] = {
            ListItemName = "ItemMsg",
            BatchReadable = true,
            BatchDeletable = true,
            IconPreName = "battle",
        },
        [config.MAIL_TYPES[config.MAIL_MODULE_TYPES.REPORT].RESOURCE] = {
            ListItemName = "ItemResource",
            BatchDeletable = true,
            ReadOnOpenList = true,
        },
        [config.MAIL_TYPES[config.MAIL_MODULE_TYPES.REPORT].WILD_BATTLE] = {
            ListItemName = "ItemWildBattle",
            BatchDeletable = true,
            ReadOnOpenList = true,
        },
    }
}


--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
local ItemConfig = _G.Database.ItemConfig
local MonsterConfig = _G.Database.MonsterConfig
local RespointConfig = _G.Database.RespointConfig
local FortifiedConfig = _G.Database.FortifiedConfig


function on_init(self)
    self.module_type_ = self.data[1]
    self.type_ = self.data[2]
    if not TypeInfo[self.module_type_] or not TypeInfo[self.module_type_][self.type_] then
        elog(string.format("Fail to init MailListWindow: %s,%s", self.module_type_, self.type_))
        return
    end
    self.all_subtypes_ = MailManager:get_all_subtypes(self.module_type_, self.type_)

    local item_name = TypeInfo[self.module_type_][self.type_].ListItemName
    self.item_prefab_ = self.transform:Find("Cache/"..item_name).gameObject
    local grid = self.item_prefab_.transform:Find("Rewards/Panel/Grids")
    if grid then
        self.grid_column_cnt_ = grid:GetComponent(GridLayoutGroup).constraintCount
    end
    self.set_item_func_ = self["Set"..item_name]
    local panel_name = TypeInfo[self.module_type_][self.type_].DetailPanelName
    if panel_name then
        self.detail_panel_prefab_ = self.transform:Find("Cache/"..panel_name).gameObject
        self.set_detail_func_ = self["Set"..panel_name]
    end
    self.mail_list_panel_cg_ = self.transform:Find("Panel"):GetComponent(CanvasGroup)
    self.scroll_rect_ = self.transform:Find("Panel/Scroll View"):GetComponent(ScrollRect)
    self.content_ = self.transform:Find("Panel/Scroll View/Viewport/Content")
    self.load_more_ = self.content_:Find("LoadMore")
    self:add_event_handler(self.load_more_:GetComponent(Button).onClick, function()
        self:load_mails()
    end)

    self.rotate_tweens_ = {}
    self.scale_tweens_ = {}
    self.last_refresh_time_ = Time.time - MAIL_TIME_REFRESH_INTERVAL

    self.mails_ = MailManager:get_sorted_mail_list_by_type(self.module_type_, self.type_)
    self.items_ = {}
    self.curr_subtype_ = nil
    self:load_mails()

    self.bottom_cg_ = self.transform:Find("Bottom"):GetComponent(CanvasGroup)
    local bottom_btns = self.transform:Find("Bottom/BtnGroup")
    --分类查看按钮
    local subtype_btn = bottom_btns:Find("SubTypeBtn")
    if self:has_subtypes() then
        subtype_btn.gameObject:SetActive(true)
        local menu = subtype_btn:Find("Menu")
        self:add_event_handler(subtype_btn:GetComponent(Button).onClick, function()
            menu.gameObject:SetActive(not menu.gameObject.activeSelf)
        end)
        local opt = menu:Find("Option")
        local selected = opt:Find("Selected")
        selected:SetParent(nil, false)
        local opts = {opt}
        for i = 1, #self.all_subtypes_ do
            local obj = GameObject.Instantiate(opt.gameObject)
            obj.transform:SetParent(menu, false)
            table.insert(opts, obj.transform)
        end
        for i, opt in ipairs(opts) do
            local txt = opt:Find("Text"):GetComponent(Text)
            txt.text = self:get_subtype_name(self.all_subtypes_[i])
            local btn = opt:GetComponent(Button)
            self:add_event_handler(btn.onClick, function()
                selected:SetParent(opts[i], false)
                selected:SetAsFirstSibling()
                menu.gameObject:SetActive(false)
                self:select_subtype(self.all_subtypes_[i])
            end)
        end
        selected:SetParent(opts[#opts], false)
        selected:SetAsFirstSibling()
        menu.gameObject:SetActive(false)
    else
        subtype_btn.gameObject:SetActive(false)
    end
    --一键删除按钮
    local del_btn = bottom_btns:Find("DeleteBtn")
    if TypeInfo[self.module_type_][self.type_].BatchDeletable then
        del_btn.gameObject:SetActive(true)
        self:add_event_handler(del_btn:GetComponent(Button).onClick, function()
            MailManager:delete_mails(self.module_type_, self.type_, self.curr_subtype_)
        end)
    else
        del_btn.gameObject:SetActive(false)
    end
    --一键已读按钮
    local read_btn = bottom_btns:Find("ReadBtn")
    if TypeInfo[self.module_type_][self.type_].BatchReadable then
        read_btn.gameObject:SetActive(true)
        self:add_event_handler(read_btn:GetComponent(Button).onClick, function()
            MailManager:read_mails(self.module_type_, self.type_, self.curr_subtype_)
        end)
    else
        read_btn.gameObject:SetActive(false)
    end

    self.messager_:add_listener(Msg.MAIL_ADD, on_add_mails)
    self.messager_:add_listener(Msg.MAIL_DEL, on_delete_mails)
    self.messager_:add_listener(Msg.MAIL_READ, on_read_mails)
    self.messager_:add_listener(Msg.MAIL_GAIN_REWARDS, on_gain_rewards)
end

function on_open(self)
    if MailManager:get_mails_count(self.module_type_, self.type_) == 0 then
        return self:close()
    end
    self:refresh_time()
    if TypeInfo[self.module_type_][self.type_].ReadOnOpenList then
        MailManager:read_mails(self.module_type_, self.type_, self.curr_subtype_)
    end
end

function on_close(self)
    self:remove_all_ani()
end

function is_showing_first(self)
    if self.detail_index_ then return self.detail_index_ == 1 end
    elog("There is no mail detail showing")
end

function is_showing_last(self)
    if self.detail_index_ then return self.detail_index_ == #self.items_ end
    elog("There is no mail detail showing")
end

function get_prev_index(self)
    if self.detail_index_ then
        if self.curr_subtype_ then
            for i = self.detail_index_ - 1, 1, -1 do
                if self.mails_[i].type_ == self.curr_subtype_ then
                    return i
                end
            end
        else
            if self.detail_index_ > 1 then return self.detail_index_ - 1 end
        end
    else
        elog("There is no mail detail showing")
    end
end

function get_next_index(self)
    if self.detail_index_ then
        if self.curr_subtype_ then
            for i = self.detail_index_ + 1, #self.items_ do
                if self.mails_[i].type_ == self.curr_subtype_ then
                    return i
                end
            end
        else
            if self.detail_index_ < #self.items_ then return self.detail_index_ + 1 end
        end
    else
        elog("There is no mail detail showing")
    end
end

function refresh_detail_prev_next_btn(self)
    if not self.detail_index_ then return end
    if self.detail_prev_btn_ then
        self.detail_prev_btn_.gameObject:SetActive(self:get_prev_index() ~= nil)
    end
    if self.detail_next_btn_ then
        self.detail_next_btn_.gameObject:SetActive(self:get_next_index() ~= nil)
    end
end

function show_detail_panel(self, index)
    local mail = self.mails_[index]
    if not mail then return end
    self.detail_index_ = index
    self:SetDetailPanel(mail)
    self:refresh_detail_prev_next_btn()
    self.detail_panel_.gameObject:SetActive(true)
    self.mail_list_panel_cg_.interactable = false
    self.mail_list_panel_cg_.blocksRaycasts = false
    self.bottom_cg_.interactable = false
    self.bottom_cg_.blocksRaycasts = false
    --播放详情面板入场动画
    local cg = self.detail_panel_:GetComponent(CanvasGroup)
    cg.alpha = 0
    cg.interactable = false
    cg.blocksRaycasts = false
    local duration = 0.2
    local rect = self.detail_panel_:GetComponent(RectTransform)
    rect.localPosition = Vector3(Screen.width / 2, 0, 0)
    self.detail_panel_tweens_ = {}
    self.detail_panel_tweens_[1] = GameTween.DOLocalMoveX(rect, 0, duration, false)
    self.detail_panel_tweens_[1]:OnComplete(function()
        cg.interactable = true
        cg.blocksRaycasts = true
    end)
    self.detail_panel_tweens_[2] = GameTween.To(function(v)
        cg.alpha = v
    end, 0, 1, duration)

    MailManager:read_mail(self.module_type_, self.type_, mail.id_)
    UIManager:refresh_current_window_title()
    UIManager:set_back_function(function()
        self:close_detail_panel()
    end)
end

function turn_to_prev_detail(self)
    local prev_index = self:get_prev_index()
    if prev_index then
        self:close_detail_panel(prev_index)
    end
end

function turn_to_next_detail(self)
    local next_index = self:get_next_index()
    if next_index then
        self:close_detail_panel(next_index)
    end
end

function close_detail_panel(self, new_index)
    self.detail_index_ = new_index
    if not new_index then
        UIManager:refresh_current_window_title()
        UIManager:remove_back_function()
    end
    if not self.detail_panel_ then return end
    --播放详情面板离场动画
    local cg = self.detail_panel_:GetComponent(CanvasGroup)
    cg.interactable = false
    cg.blocksRaycasts = false
    if self.detail_panel_tweens_ then
        for _, tween in pairs(self.detail_panel_tweens_) do
            tween:Kill(false)
        end
    end
    local duration = 0.2
    self.detail_panel_tweens_ = {}
    local rect = self.detail_panel_:GetComponent(RectTransform)
    self.detail_panel_tweens_[1] = GameTween.DOLocalMoveX(rect, Screen.width / 2, duration, false)
    self.detail_panel_tweens_[1]:OnComplete(function()
        if new_index then
            self:show_detail_panel(new_index)
        else
            self.mail_list_panel_cg_.interactable = true
            self.mail_list_panel_cg_.blocksRaycasts = true
            self.bottom_cg_.interactable = true
            self.bottom_cg_.blocksRaycasts = true
            self.detail_panel_.gameObject:SetActive(false)
        end
    end)
    self.detail_panel_tweens_[2] = GameTween.To(function(v)
        cg.alpha = v
    end, cg.alpha, 0, duration)
end

--------------------------------↓不同类型邮件UI初始化函数↓--------------------------------

function NewItem(self, mail, pos)
    if not pos then pos = #self.items_ + 1 end
    local obj = GameObject.Instantiate(self.item_prefab_)
    table.insert(self.items_, pos, obj)
    obj.transform:SetParent(self.content_, false)
    obj.transform:SetSiblingIndex(pos - 1)
    self:SetItem(obj, mail)
    return obj
end

function SetItem(self, obj, mail)
    self.set_item_func_(self, obj, mail)
end

function SetItemMsg(self, obj, mail)
    local icon = obj.transform:Find("Icon"):GetComponent(Image)
    UIUtil.set_sprite(self:get_icon_path(mail), icon)
    local btn = obj:GetComponent(Button)
    self:add_event_handler(btn.onClick, function()
        if mail:is_deleted() then return end
        local index
        for i, m in ipairs(self.mails_) do
            if m == mail then
                index = i
            end
        end
        if not index then return end
        self:show_detail_panel(index)
    end)
    local title = obj.transform:Find("Text/Title"):GetComponent(Text)
    title.text = mail.title_
    local c = obj.transform:Find("Text/Content"):GetComponent(Text)
    c.text = mail.content_
    local reward = obj.transform:Find("Reward")
    if mail:has_ungained_rewards() then
        reward.gameObject:SetActive(true)
        self:play_reward_ani(mail.id_, reward)
        local btn = reward:GetComponent(Button)
        btn.onClick:RemoveAllListeners()
        self:add_event_handler(btn.onClick, function()
            MailManager:gain_rewards_by_id(self.module_type_, self.type_, mail.id_)
        end)
    else
        reward.gameObject:SetActive(false)
    end
end

function SetItemResource(self, obj, mail)
    local build_name = ""
    local lv = 0
    if mail.args_.objtype == Mail.ResObjType.fortified then
        build_name = lang("UI_FORT_07")
        local cfg = FortifiedConfig.FortifiedData[mail.args_.defid]
        if cfg then lv = cfg.level end
    else
        local cfg = RespointConfig.RespointData[mail.args_.defid]
        if cfg then
            lv = cfg.level
            build_name = lang(cfg.name)
        end
    end
    local lv_txt = obj.transform:Find("Top/Lv"):GetComponent(Text)
    lv_txt.text = lang("UI_MONSTERINFO_LV")..lv
    local pos = obj.transform:Find("Top/Pos"):GetComponent(Text)
    pos.text = string.format("%s(%d,%d)", build_name, unpack(mail.args_.pos))
    local time = obj.transform:Find("Top/Time"):GetComponent(Text)
    time.text = os.date("%Y-%m-%d %H:%M:%S", mail.time_)
    local capture = obj.transform:Find("CaptureInfo")
    if mail.args_.starttime and mail.args_.endtime then
        local txt = capture:Find("Info/Title"):GetComponent(Text)
        txt.text = lang("MAIL_CAPTURE_INFO")
        txt = capture:Find("Info/Starttime"):GetComponent(Text)
        txt.text = lang("UI_BASE_START_TIME")..": "..os.date("%Y-%m-%d %H:%M:%S", mail.args_.starttime)
        txt = capture:Find("Info/Endtime"):GetComponent(Text)
        txt.text = lang("UI_BASE_END_TIME")..": "..os.date("%Y-%m-%d %H:%M:%S", mail.args_.endtime)
        txt = capture:Find("Duration/Text"):GetComponent(Text)
        local d = UIUtil.get_format_time_tidy(mail.args_.endtime - mail.args_.starttime)
        txt.text = lang("MAIL_CAPTURE_DURATION")..": "..d
    else
        capture.gameObject:SetActive(false)
    end
    local item_panel = obj.transform:Find("ItemPanel")
    if #mail.args_.rewards > 0 then
        local item = item_panel:Find("ItemInfo")
        local items = {item}
        for i = 2, #mail.args_.rewards do
            local obj = GameObject.Instantiate(item)
            obj.transform:SetParent(item_panel, false)
            table.insert(items, obj.transform)
        end
        for i, it in ipairs(items) do
            local reward = mail.args_.rewards[i]
            local cfg = ItemManager:get_ui_info(reward)
            local card = it:Find("ItemIcon")
            UIUtil.set_sprite("UI/Common/Quality/item_"..cfg.quality, card:GetComponent(Image))
            local icon = card:Find("Icon")
            UIUtil.set_sprite(cfg.icon, icon:GetComponent(Image))
            self:add_tips_handler(icon, reward, TipsCard.TIPS_ITEM)
            local name = it:Find("Name"):GetComponent(Text)
            name.text = cfg.name
            local num = it:Find("Num"):GetComponent(Text)
            num.text = "+"..reward[3]
        end
    else
        item_panel.gameObject:SetActive(false)
    end
end

function SetItemWildBattle(self, obj, mail)
    local monster_panel = obj.transform:Find("MonsterInfo")
    local top
    if mail.args_.result == 1 then
        local top_win = obj.transform:Find("TopWin")
        top = top_win
        top_win.gameObject:SetActive(true)
        local bg_win = monster_panel:Find("BgWin")
        bg_win.gameObject:SetActive(true)
    else
        local top_defeat = obj.transform:Find("TopDefeat")
        top = top_defeat
        top_defeat.gameObject:SetActive(true)
        local bg_defeat = monster_panel:Find("BgDefeat")
        bg_defeat.gameObject:SetActive(true)
    end
    local time = top:Find("Time"):GetComponent(Text)
    time.text = os.date("%Y-%m-%d %H:%M:%S", mail.time_)

    --设置怪物信息
    local monster = MonsterConfig.MonsterData[mail.args_.monsterid]
    if monster then
        local img = monster_panel:Find("Image"):GetComponent(Image)
        UIUtil.set_sprite(monster.drawpath, img)
        local name = monster_panel:Find("Info/Name"):GetComponent(Text)
        name.text = monster.name
        local lv = monster_panel:Find("Info/Lv"):GetComponent(Text)
        lv.text = lang("UI_MONSTERINFO_LV")..monster.lv
        local pos = monster_panel:Find("Info/Pos"):GetComponent(Text)
        pos.text = string.format("%s%s,%s", lang("EXPEDITION_1"), unpack(mail.args_.pos))
    else
        elog("Can't find config of monster id: "..tostring(mail.args_.monsterid))
    end

    local rewards = obj.transform:Find("Rewards")
    if mail.args_.rewards and #mail.args_.rewards > 0 then
        local title = rewards:Find("Title/Text"):GetComponent(Text)
        title.text = lang("UI_BATTLEREPORT_REWARD")
        if #mail.args_.rewards <= self.grid_column_cnt_ then
            local grid_sroll = rewards:Find("Panel"):GetComponent(ScrollRect)
            grid_sroll.enabled = false
        end
        --设置奖励信息
        local grids = rewards:Find("Panel/Grids")
        local item = grids:Find("ItemInfo").gameObject
        item:SetActive(false)
        for _, reward in pairs(mail.args_.rewards) do
            local info = GameObject.Instantiate(item)
            info.transform:SetParent(grids, false)
            info.gameObject:SetActive(true)
            local item_card = info.transform:Find("ItemCard")
            local res_card = info.transform:Find("ResCard")
            local name
            if ItemManager.is_item_type(reward[1]) then
                item_card.gameObject:SetActive(true)
                res_card.gameObject:SetActive(false)
                self:add_tips_handler(item_card, reward, TipsCard.TIPS_ITEM)
                local cfg = ItemManager:get_ui_info(reward)
                local item_quality = item_card:GetComponent(Image)
                UIUtil.set_sprite("UI/Common/Quality/item_"..cfg.quality, item_quality)
                local icon = item_card:Find("IconArea/Icon"):GetComponent(Image)
                UIUtil.set_sprite(cfg.icon, icon)
                local label = item_card:Find("IconArea/Label").gameObject
                if cfg.label then
                    label:SetActive(true)
                    local label_txt = label:GetComponentInChildren(Text)
                    label_txt.text = cfg.label
                else
                    label:SetActive(false)
                end
                name = cfg.name
            else
                item_card.gameObject:SetActive(false)
                res_card.gameObject:SetActive(true)
                self:add_tips_handler(res_card, reward, TipsCard.TIPS_ITEM)
                local icon = res_card:Find("Icon"):GetComponent(Image)
                UIUtil.set_sprite("UI/Common/Item/"..reward[1], icon)
                name = lang("ITEM"..reward[1])
            end
            local cnt_txt = info.transform:Find("Count"):GetComponent(Text)
            cnt_txt.text = UIUtil.res_num_to_str(reward[3])
            local name_txt = info.transform:Find("Name"):GetComponent(Text)
            name_txt.text = name
        end
    else
        rewards.gameObject:SetActive(false)
    end

    if mail.args_.tip then
        local tip = rewards:Find("Tip")
        tip.gameObject:SetActive(true)
        tip:GetComponent(Text).text = string.format(lang("MAIL_FIRST_KILL_TIP"), monster.lv, monster.lv + 1)
    end

    local battle_data = obj.transform:Find("BattleData")
    battle_data:Find("Text1"):GetComponent(Text).text = lang("UI_BATTLEREPORT_DESC1")..(mail.args_.lose_power or 0)
    battle_data:Find("Text2"):GetComponent(Text).text = lang("UI_BATTLEREPORT_DESC2")..(mail.args_.all or 0)
    battle_data:Find("Text3"):GetComponent(Text).text = lang("UI_BATTLEREPORT_DESC3")..(mail.args_.hurt or 0)
    battle_data:Find("Text4"):GetComponent(Text).text = lang("UI_BATTLEREPORT_DESC4")..(mail.args_.live or 0)
end

function SetDetailPanel(self, mail)
    if not self.detail_panel_prefab_ then return end
    local is_init = false
    if not self.detail_panel_ then
        is_init = true
        self.detail_panel_ = GameObject.Instantiate(self.detail_panel_prefab_).transform
        self.detail_panel_:SetParent(self.transform, false)
        local rt = self.detail_panel_:GetComponent(RectTransform)
        rt.offsetMax = Vector2.zero
        rt.offsetMin = Vector2.zero
        UIManager:maintain_top_banner()
    end
    if self.set_detail_func_ then
        self.set_detail_func_(self, mail, is_init)
    end
end

function SetDetailCommon(self, mail, is_init)
    if not self.detail_prev_btn_ then
        self.detail_prev_btn_ = self.detail_panel_:Find("Item/PrevBtn")
        self:add_event_handler(self.detail_prev_btn_:GetComponent(Button).onClick, function()
            self:turn_to_prev_detail()
        end)
    end
    if not self.detail_next_btn_ then
        self.detail_next_btn_ = self.detail_panel_:Find("Item/NextBtn")
        self:add_event_handler(self.detail_next_btn_:GetComponent(Button).onClick, function()
            self:turn_to_next_detail()
        end)
    end
    local title = self.detail_panel_:Find("Item/Top/Title"):GetComponent(Text)
    title.text = lang(self:get_mail_type_raw_str().."_SENDER")
    local time = self.detail_panel_:Find("Item/Top/Time"):GetComponent(Text)
    time.text = os.date("%Y-%m-%d %H:%M:%S", mail.time_)
    local content = self.detail_panel_:Find("Item/Panel/Content/Text")
    content:GetComponent(Text).text = mail.content_
    local reward_panel = self.detail_panel_:Find("Item/Panel/RewardPanel")
    local gain_btn = self.detail_panel_:Find("Item/GainBtn")
    local gain_btn_txt = gain_btn:Find("Text"):GetComponent(Text)
    local rc = reward_panel:Find("Scroll View/Viewport/Content")
    if is_init then
        self.detail_reward_item_obj_ = rc:GetChild(0).gameObject
        self.detail_reward_item_obj_:SetActive(false)
        self.on_gain_rewards_in_detail_ = function()
            gain_btn_txt.text = lang("MAIL_BUTTON_GAINED")
            gain_btn:GetComponent(Button).interactable = false
            GameUtil.SetImageGrey(gain_btn:GetComponent(Image), true)
        end
        self:add_event_handler(gain_btn:GetComponent(Button).onClick, function()
            if self.detail_index_ and self.mails_[self.detail_index_] then
                local m = self.mails_[self.detail_index_]
                MailManager:gain_rewards_by_id(self.module_type_, self.type_, m.id_)
            end
        end)
        local del_btn = self.detail_panel_:Find("Bottom/DeleteBtn"):GetComponent(Button)
        self:add_event_handler(del_btn.onClick, function()
            if self.detail_index_ and self.mails_[self.detail_index_] then
                local m = self.mails_[self.detail_index_]
                MailManager:delete_mail(self.module_type_, self.type_, m.id_)
            end
        end)
    end
    if self.detail_rewards_items_ then
        for _, item in pairs(self.detail_rewards_items_) do
            item.transform:SetParent(nil, false)
            GameObject.Destroy(item)
        end
    end
    self.detail_rewards_items_ = {}
    if mail:has_rewards() then
        local reward_scroll_rect = reward_panel:Find("Scroll View"):GetComponent(ScrollRect)
        reward_scroll_rect:StopMovement()
        reward_scroll_rect.verticalNormalizedPosition = 1
        local title = reward_panel:Find("Title/Text"):GetComponent(Text)
        title.text = lang("UI_BASE_GAIN_REWARDS")
        for _, reward in pairs(mail.rewards_) do
            local obj = GameObject.Instantiate(self.detail_reward_item_obj_)
            obj.transform:SetParent(rc, false)
            obj:SetActive(true)
            table.insert(self.detail_rewards_items_, obj)
            local name
            local icon_area
            if ItemManager.is_item_type(reward[1]) then
                local cfg = ItemConfig.ItemData[reward[2]]
                if cfg then
                    local icon_card = obj.transform:Find("Item/ItemIcon")
                    icon_card.gameObject:SetActive(true)
                    UIUtil.set_sprite("UI/Common/Quality/item_"..cfg.quality, icon_card:GetComponent(Image))
                    icon_area = icon_card:Find("Icon")
                    local icon = icon_area:GetComponent(Image)
                    UIUtil.set_sprite(cfg.icon, icon)
                    name = cfg.name
                end
            else
                local icon_card = obj.transform:Find("Item/ResIcon")
                icon_card.gameObject:SetActive(true)
                icon_area = icon_card:Find("Icon")
                local icon = icon_area:GetComponent(Image)
                UIUtil.set_sprite("UI/Common/Item/"..reward[1], icon)
                name = lang("ITEM"..reward[1])
            end
            self:add_tips_handler(icon_area, reward, TipsCard.TIPS_ITEM)
            local name_txt = obj.transform:Find("Item/Name"):GetComponent(Text)
            name_txt.text = name
            local num_txt = obj.transform:Find("Item/Num"):GetComponent(Text)
            num_txt.text = "x"..reward[3]
        end
        if mail:has_ungained_rewards() then
            gain_btn_txt.text = lang("MAIL_BUTTON_GAIN")
            gain_btn:GetComponent(Button).interactable = true
            GameUtil.SetImageGrey(gain_btn:GetComponent(Image), false)
        else
            gain_btn_txt.text = lang("MAIL_BUTTON_GAINED")
            gain_btn:GetComponent(Button).interactable = false
            GameUtil.SetImageGrey(gain_btn:GetComponent(Image), true)
        end
    else
        reward_panel.gameObject:SetActive(false)
        gain_btn.gameObject:SetActive(false)
    end
end

--------------------------------↑不同类型邮件UI初始化函数↑--------------------------------

function has_subtypes(self)
    return #self.all_subtypes_ > 1
end

function get_icon_path(self, mail)
    local str = "UI/Window/mail/mail_%s%s_%s"
    local read = mail:is_read() and "read" or "unread"
    local subtype = self:has_subtypes() and "_"..mail.type_ or ""
    return string.format(str, TypeInfo[mail.module_type_][mail.type_].IconPreName, subtype, read)
end

function play_reward_ani(self, mail_id, reward)
    local duration = 0.6
    local interval = 0.5
    local rotate_tween = XSequence()
    if self.rotate_tweens_[mail_id] then
        self.rotate_tweens_[mail_id]:Kill(false)
    end
    self.rotate_tweens_[mail_id] = rotate_tween
    rotate_tween:Append(GameTween.DORotate(reward, Vector3(0, 0, 15), duration / 6, 0))
    rotate_tween:Append(GameTween.DORotate(reward, Vector3(0, 0, -15), duration / 6, 0))
    rotate_tween:Append(GameTween.DORotate(reward, Vector3.zero, duration / 6, 0))
    rotate_tween:Append(GameTween.DORotate(reward, Vector3.zero, duration, 0))
    rotate_tween:SetDelay(duration * 0.5 + interval):SetLoops(-1, 0)
    local scale_tween = XSequence()
    if self.scale_tweens_[mail_id] then
        self.scale_tweens_[mail_id]:Kill(false)
    end
    self.scale_tweens_[mail_id] = scale_tween
    scale_tween:Append(GameTween.DOScale(reward, 1.2, duration))
    scale_tween:Append(GameTween.DOScale(reward, 1, duration))
    scale_tween:SetDelay(interval):SetLoops(-1, 0)
    --高光特效
    if not self.highlight_tween_ then
        self.highlight_tween_ = XSequence()
        local img = reward:GetComponent(Image)
        img:GetModifiedMaterial(img.material):SetFloat("_HighLightRate", 0)
        self.highlight_tween_:Append(GameTween.To(function(v)
            if not Slua.IsNull(img) then
                img:GetModifiedMaterial(img.material):SetFloat("_HighLightRate", v)
            end
        end, 0, 0.6, duration))
        self.highlight_tween_:Append(GameTween.To(function(v)
            if not Slua.IsNull(img) then
                img:GetModifiedMaterial(img.material):SetFloat("_HighLightRate", v)
            end
        end, 0.6, 0, duration * 0.5))
        self.highlight_tween_:Append(GameTween.To(function(v)
            if not Slua.IsNull(img) then
                img:GetModifiedMaterial(img.material):SetFloat("_HighLightRate", v)
            end
        end, 0, 0, duration * 0.5))
        self.highlight_tween_:SetDelay(interval):SetLoops(-1, 0)
    end
end

function remove_reward_ani(self, mail_id)
    if self.rotate_tweens_[mail_id] then
        self.rotate_tweens_[mail_id]:Kill(false)
        self.rotate_tweens_[mail_id] = nil
    end
    if self.scale_tweens_[mail_id] then
        self.scale_tweens_[mail_id]:Kill(false)
        self.scale_tweens_[mail_id] = nil
    end
    if self.highlight_tween_ and not next(self.rotate_tweens_) and not next(self.scale_tweens_) then
        self.highlight_tween_:Kill(false)
        self.highlight_tween_ = nil
    end
end

function remove_all_ani(self)
    for _, ani in pairs(self.rotate_tweens_) do
        ani:Kill(false)
    end
    for _, ani in pairs(self.scale_tweens_) do
        ani:Kill(false)
    end
    if self.highlight_tween_ then
        self.highlight_tween_:Kill(false)
    end
    self.rotate_tweens_ = {}
    self.scale_tweens_ = {}
    self.highlight_tween_ = nil
end

--刷新邮件时间显示
--@params: 
    --ignore_interval: 是否忽略刷新间隔，强制刷新
function refresh_time(self, ignore_interval)
    if not TypeInfo[self.module_type_][self.type_].NeedRefreshTime then return end
    if not ignore_interval and Time.time - self.last_refresh_time_ < MAIL_TIME_REFRESH_INTERVAL then
        return
    end
    for i, item in ipairs(self.items_) do
        local mail = self.mails_[i]
        local time = item.transform:Find("Time"):GetComponent(Text)
        time.text = UIUtil.time_str_from(mail.time_)
    end
    self.last_refresh_time_ = Time.time
end

function load_mails(self, num)
    if type(num) ~= "number" or num <= 0 or num > NUM_LOAD_ONCE then
        num = NUM_LOAD_ONCE
    end
    local n = 0
    for i = #self.items_ + 1, #self.mails_ do
        local mail = self.mails_[i]
        local obj = self:NewItem(mail)
        if self:is_mail_show(mail) then
            n = n + 1
            obj:SetActive(true)
        else
            obj:SetActive(false)
        end
        if n >= num then break end
    end
    self:set_load_more_btn()
    self:refresh_time(true)
end

function is_mail_show(self, mail)
    if not self.curr_subtype_ then return true end
    return self.curr_subtype_ == mail.type_
end

function set_load_more_btn(self)
    local has_more = false
    for i = #self.items_ + 1, #self.mails_ do
        if self:is_mail_show(self.mails_[i]) then
            has_more = true
            break
        end
    end
    self.load_more_:SetAsLastSibling()
    self.load_more_.gameObject:SetActive(has_more)
end

function get_mail_type_raw_str(self, ty)
    ty = ty or self.type_
    return string.upper(string.format("MAIL_TYPE_%s_%s", self.module_type_, ty))
end

function get_subtype_name(self, subtype)
    if not self:has_subtypes() then return "" end
    local src
    local ty = subtype or self.type_
    local src = self:get_mail_type_raw_str(ty)
    local str = lang(src)
    if src == str then return "" end
    if not subtype then
        str = lang("UI_BASE_ALL")..str
    end
    return str
end

function main_title(self)
    if self.detail_index_ then
        return self.mails_[self.detail_index_].title_
    end
    return lang(self:get_mail_type_raw_str())
end

function sub_title(self)
    if self.detail_index_ then return "" end
    return self:get_subtype_name(self.curr_subtype_)
end

function select_subtype(self, subtype)
    if self.curr_subtype_ == subtype then return end
    self.curr_subtype_ = subtype
    UIManager:refresh_current_window_title()
    self.scroll_rect_.movementType = ScrollRect.MovementType.Clamped
    for i, obj in ipairs(self.items_) do
        local show = self:is_mail_show(self.mails_[i])
        if obj.activeSelf and not show then
            obj:SetActive(false)
        elseif not obj.activeSelf and show then
            obj:SetActive(true)
        end
    end
    self:set_load_more_btn()
end

function on_add_mails(self, module_type, mail_type, mails)
    if module_type ~= self.module_type_ or 
        not MailManager:is_subtype(self.module_type_, self.type_, mail_type) then return end
    self.scroll_rect_.movementType = ScrollRect.MovementType.Clamped
    table.sort(mails, MailManager.mail_comparator)
    for i = #mails, 1, -1 do
        local mail = mails[i]
        table.insert(self.mails_, 1, mail)
        local obj = self:NewItem(mail, 1)
        obj:SetActive(self:is_mail_show(mail))
    end
    if self.gameObject.activeSelf then
        MailManager:read_mails(self.module_type_, self.type_, self.curr_subtype_)
    end
    if self.detail_index_ then
        self.detail_index_ = self.detail_index_ + #mails
        self:refresh_detail_prev_next_btn()
    end
    self:refresh_time(true)
end

function on_delete_mails(self, module_type, mail_type, mails)
    if module_type ~= self.module_type_ or 
        not MailManager:is_subtype(self.module_type_, self.type_, mail_type) then return end
    if MailManager:get_mails_count(self.module_type_, self.type_) == 0 then
        return self:close()
    end
    local n = 0
    self.scroll_rect_.movementType = ScrollRect.MovementType.Clamped
    for i = #self.mails_, 1, -1 do
        if self.mails_[i]:is_deleted() then
            self:remove_reward_ani(self.mails_[i].id_)
            table.remove(self.mails_, i)
            if self.items_[i] then
                n = n + 1
                self.items_[i].transform:SetParent(nil, false)
                local btn = self.items_[i]:GetComponent(Button)
                if btn then btn.onClick:RemoveAllListeners() end
                GameObject.Destroy(self.items_[i])
                table.remove(self.items_, i)
            end
            if self.detail_index_ == i then
                self:close_detail_panel()
            elseif self.detail_index_ and i < self.detail_index_ then
                self.detail_index_ = self.detail_index_ - 1
            end
        end
    end
    self:refresh_detail_prev_next_btn()
    self:load_mails(n)
end

function on_gain_rewards(self, module_type, mail_type, mails)
    if module_type ~= self.module_type_ or not 
        MailManager:is_subtype(self.module_type_, self.type_, mail_type) then return end
    if not TypeInfo[self.module_type_][self.type_].BatchReadable then return end
    local ids = {}
    for _, mail in pairs(mails) do
        ids[mail.id_] = true
        self:remove_reward_ani(mail.id_)
    end
    for i, item in ipairs(self.items_) do
        if ids[self.mails_[i].id_] then
            if self.detail_index_ == i then
                if self.on_gain_rewards_in_detail_ then
                    self.on_gain_rewards_in_detail_()
                end
            end
            local reward = item.transform:Find("Reward")
            if reward then
                reward.gameObject:SetActive(false)
            end
        end
    end
end

function on_read_mails(self, module_type, mail_type, mails)
    if module_type ~= self.module_type_ or 
        not MailManager:is_subtype(self.module_type_, self.type_, mail_type) then return end
    if not TypeInfo[self.module_type_][self.type_].BatchReadable then return end
    local ids = {}
    for _, mail in pairs(mails) do
        ids[mail.id_] = true
    end
    for i, item in ipairs(self.items_) do
        if ids[self.mails_[i].id_] then
            local icon = item.transform:Find("Icon")
            if icon then
                UIUtil.set_sprite(self:get_icon_path(self.mails_[i]), icon:GetComponent(Image))
            end
        end
    end
end
