local HeroRecruitPopWindow = {}
setmetatable(HeroRecruitPopWindow, {__index = _G.BaseWindow})


local ShowTypes = {
    Hero = 1,   --武将
    Item = 2,   --物品
}


local RecruitConfig = _G.Database.RecruitConfig
local ItemConfig = _G.Database.ItemConfig
local HeroConfig = _G.Database.HeroConfig


function HeroRecruitPopWindow:on_init()
    local ty = self.data[1]

    local closeBtn = self.transform:Find("Panel/CloseBtn"):GetComponent(Button)
    self:add_event_handler(closeBtn.onClick, function() self:close() end)

    local itemCardObj = self.transform:Find("Cache/ItemCard").gameObject
    itemCardObj:SetActive(false)
    local heroCardObj = self.transform:Find("Cache/HeroCard").gameObject
    heroCardObj:SetActive(false)
    local content = self.transform:Find("Panel/Inside/ScrollView/Content")
    local heroContent = content:Find("HeroList")
    local itemContent = content:Find("ItemList")

    local heroList = {}
    local itemList = {}
    for i, cfg in pairs(RecruitConfig.Re_showData) do
        if cfg.type == ty then
            local id = cfg.items[2]
            if cfg.show_type == ShowTypes.Hero then
                local hc = HeroConfig.ListData[id]
                if hc then
                    table.insert(heroList, {
                        id = id,
                        sortID = i,
                        name = hc.name,
                        icon = hc.icon,
                        quality = hc.quality,
                    })
                end
            elseif cfg.show_type == ShowTypes.Item then
                local ic = ItemConfig.ItemData[id]
                if ic then
                    table.insert(itemList, {
                        id = id,
                        sortID = i,
                        name = ic.name,
                        icon = ic.icon,
                        quality = ic.quality,
                    })
                end
            end
        end
    end
    table.sort(heroList, function(a, b) return a.sortID < b.sortID end)
    table.sort(itemList, function(a, b) return a.sortID < b.sortID end)

    for _, hero in ipairs(heroList) do
        local obj = GameObject.Instantiate(heroCardObj)
        obj:SetActive(true)
        obj.transform:SetParent(heroContent, false)
        local bg = obj.transform:Find("IconBg")
        UIUtil.set_sprite("UI/Common/Quality/hero_"..hero.quality, bg:GetComponent(Image))
        if hero.quality == 4 then
            elog(hero.id)
        end
        local head = bg:Find("Mask/Head")
        UIUtil.set_sprite(hero.icon, head:GetComponent(Image))
        local name = obj.transform:Find("Name"):GetComponent(Text)
        name.text = hero.name
        name.color = UIUtil.get_color(config.GROW_COLOR[hero.quality])
    end
    for _, item in ipairs(itemList) do
        local obj = GameObject.Instantiate(itemCardObj)
        obj:SetActive(true)
        obj.transform:SetParent(itemContent, false)
        local bg = obj.transform:Find("IconBg")
        UIUtil.set_sprite("UI/Common/Quality/item_"..item.quality, bg:GetComponent(Image))
        local head = bg:Find("Icon")
        UIUtil.set_sprite(item.icon, head:GetComponent(Image))
        local name = obj.transform:Find("Name"):GetComponent(Text)
        name.text = item.name
        name.color = UIUtil.get_color(config.GROW_COLOR[item.quality])
    end
end


return HeroRecruitPopWindow
