module("SkillLevel", package.seeall)
setmetatable(SkillLevel, {__index = BaseWindow})


local MaxItemCostInterval = 1
local MinItemCostInterval = 0.1
local ItemCostIntervalChangeRate = 0.5


local ItemConfig = _G.Database.ItemConfig
local BasicConfig = _G.Database.BasicConfig
local HeroConfig = _G.Database.HeroConfig


function on_init(self)
    self.pos = self.data[1]
    self.hero = self.data[2]
    self.serverSkill = nil
    self:refresh_server_skill()
    self.skillCfg = HeroConfig.SkillData[self.serverSkill.skillid]

    local closeBtn = self.transform:Find("Top/CloseBtn"):GetComponent(Button)
    self:add_event_handler(closeBtn.onClick, function() self:close() end)
    
    self.skillIcon = self.transform:Find("Image/skill_icon"):GetComponent(Image)
    self.skillInfo = self.transform:Find("Image/skill_title1")
    UIUtil.set_sprite(self.skillCfg.icon, self.skillIcon)
    local rare = self.skillInfo:Find("Name/Image")
    rare.gameObject:SetActive(self.skillCfg.rare > 0)
    local name = self.skillInfo:Find("Name/Text"):GetComponent(Text)
    name.text = self.skillCfg.name
    self.currLvDesc = self.skillInfo:Find("skillintroducetxt"):GetComponent(Text)
    self.nextLvDesc = self.skillInfo:Find("skillintroducetxt2"):GetComponent(Text)
    
    local forgetBtn = self.transform:Find("ForgetBtn"):GetComponent(Button)
    self:add_event_handler(forgetBtn.onClick, function()
        UIManager.open_window("SkillForget", nil, self)
    end)

    self.lvTxt = self.transform:Find("leveltxt"):GetComponent(Text)
    self.slider = self.transform:Find("Slider")
    self.expNum  = self.slider:Find("lvptxt"):GetComponent(Text)
    self.fillImg = self.slider:Find("Fill Area/Fill"):GetComponent(Image)
    self.expAddObj = self.slider:Find("ExpAddText").gameObject
    self.expAddObj:SetActive(false)
    
    self.lvUpBtn = self.transform:Find("LvpBtn"):GetComponent(Button)
    self:add_event_handler(self.lvUpBtn.onClick, function()
        local serverSkill = self.hero:get_skill_by_pos(self.pos)
        if not self:can_skill_lvup(serverSkill) then return end
        UIManager.open_window("SkillAutoLevel", nil, self, self.hero, self.pos)
    end)

    local itemContent = self.transform:Find("ScrollView/Viewport/Content")
    local itemObj = itemContent:Find("ItemCard").gameObject
    itemObj:SetActive(false)
    self.expObjs = {}
    self.expItemCnts = {}
    self.exps = {}
    self.pointEvents = {}
    for i, v in ipairs(BasicConfig.BasicData.hero_skill_items) do
        local cfg = ItemConfig.ItemData[v[1]]
        if cfg then
            table.insert(self.exps, v[2])
            local obj = GameObject.Instantiate(itemObj)
            obj:SetActive(true)
            obj.transform:SetParent(itemContent, false)
            table.insert(self.expObjs, obj)
            local name = obj.transform:Find("NameTxt"):GetComponent(Text)
            name.gameObject:SetActive(true)
            name.text = lang("UI_BASIC_EXP").."+"..v[2]
            local iconArea = obj.transform:Find("IconArea")
            UIUtil.set_sprite("UI/Common/Quality/item_"..cfg.quality, iconArea:GetComponent(Image))
            local icon = iconArea:Find("Icon"):GetComponent(Image)
            UIUtil.set_sprite(cfg.icon, icon)
            local data = {
                index = i,
                itemid = v[1],
            }
            self.pointEvents[i] = PluginPointer:new(self, icon.gameObject, use_prop_handler, data)
        end
    end

    self.pressIndex = nil
    self.pressItemCnt = 0
    self.expAnimator = ExpAnimator:new()

    self.expAnimator.getLv = function(slf) return self.serverSkill.level end
    self.expAnimator.setLv = function(slf, value)
        self.serverSkill.level = value
        self:refresh_ui_lv()
    end
    self.expAnimator.getExp = function(slf) return self.serverSkill.exp end
    self.expAnimator.setExp = function(slf, value)
        self.serverSkill.exp = value
        self:refresh_ui_exp()
    end
    self.expAnimator.getTotalExpOfLv = function(slf, lv)
        return SkillManager:get_skill_level_exp(self.serverSkill.skillid, lv)
    end
    self.expAnimator.canLevelUp = function(slf, lv)
        local isMax = SkillManager:is_skill_lv_max(lv)
        local isStarMax = SkillManager:is_skill_lv_max_by_star(lv, self.hero.id_, self.hero.star_)
        return not (isMax or isStarMax)
    end
    self.expAnimator.onStartPlaying = function(slf)
        if self.pressIndex then
            self.expItemCnts[self.pressIndex] = self.expItemCnts[self.pressIndex] - 1
            self.pressItemCnt = self.pressItemCnt + 1
            self:play_exp_add_text(self.exps[self.pressIndex])
        end
        self:refresh_ui_items()
    end
    self.expAnimator.onEndPlaying = function(slf)
        if self.pressIndex then
            self.expAnimator:play(self.exps[self.pressIndex], true)
        end
    end
    self.expAnimator.checkBeforePlaying = function(slf)
        if self.pressIndex and self.expItemCnts[self.pressIndex] <= 0 then return false end
        return self:can_skill_lvup()
    end

    --self.messager_:add_listener(Msg.UI_SKILL_CHANGE, on_skill_change)
end

function on_open(self)
    if not self.expAnimator or not self.expAnimator:isPlaying() then
        self:sync_item_cnts()
        self:refresh_all()
    else
        self:refresh_ui_items()
    end
end

function on_close(self)
    if self.pointEvents then
        for _, e in pairs(self.pointEvents) do
            e:dispose()
        end
    end
    if self.expAnimator then
        self.expAnimator:killAll()
    end
end

function on_skill_change(self)
    --self:refresh_all()
end

function can_skill_lvup(self, serverSkill)
    serverSkill = serverSkill or self.serverSkill
    local isMax = SkillManager:is_skill_lv_max(serverSkill.level)
    local isStarMax = SkillManager:is_skill_lv_max_by_star(serverSkill.level, self.hero.id_, self.hero.star_)
    return not (isMax or isStarMax)
end

function use_items(self, items)
    for i, cnt in pairs(items) do
        self.expItemCnts[i] = self.expItemCnts[i] - cnt
    end
end

function play_exp_add_text(self, exp)
    local obj = GameObject.Instantiate(self.expAddObj)
    obj.transform:SetParent(self.slider, false)
    obj:SetActive(true)
    obj:GetComponent(Text).text = lang("UI_BASIC_EXP").."+"..tostring(exp)
    local target = obj.transform.localPosition.y + 50
    GameTween.DOLocalMoveY(obj.transform, target, 1, false):OnComplete(function()
        GameObject.Destroy(obj)
    end)
end

function lvup_after_press(self, itemid)
    --elog("use totally: "..self.pressItemCnt)
    if self.pressItemCnt <= 0 then return end
    SkillManager:levelup_skill(self.hero.id_, self.pos, self.serverSkill.skillid, {{itemid, self.pressItemCnt}})
end

function use_prop_handler(self, event, data)
    if event == PluginPointer.POINTER_ALWAY_DOWN then
        if not self.pressIndex and self.expItemCnts[data.index] > 0 then
            self.pressIndex = data.index
            self.pressItemCnt = 0
            if self.expAnimator:isPlaying() then return end
            self.expAnimator:play(self.exps[data.index], true)
        end
    elseif event == PluginPointer.POINTER_CLICK then
        if self.pressIndex or self.expItemCnts[data.index] <= 0 then return end
        if not self:can_skill_lvup() then return end
        if self.expAnimator:isPlaying() then return end
        SkillManager:levelup_skill(self.hero.id_, self.pos, self.serverSkill.skillid, {{data.itemid, 1}})
        self.expItemCnts[data.index] = self.expItemCnts[data.index] - 1
        self.expAnimator:play(self.exps[data.index], false)
        self:play_exp_add_text(self.exps[data.index])
    elseif event == PluginPointer.POINTER_UP then
        if self.pressIndex and self.pressIndex == data.index then
            local iconArea = self.expObjs[self.pressIndex].transform:Find("IconArea")
            local cnt = self.expItemCnts[self.pressIndex]
            iconArea:Find("Mask").gameObject:SetActive(cnt == 0)
            iconArea:Find("AddBtn").gameObject:SetActive(cnt == 0)
            self.pressIndex = nil
            self:lvup_after_press(data.itemid)
        end
    end
end

function get_total_exp_of_lv(self, lv)
    return HeroConfig.Skill_upData[lv].exp * HeroConfig.SkillData[self.serverSkill.skillid].exp_para
end

function refresh_ui_exp(self)
    local isMax = SkillManager:is_skill_lv_max(self.serverSkill.level)
    if isMax then
        self.expNum.text = lang("SKILL_MAX")
        self.fillImg.fillAmount = 0
    else
        local needExp = SkillManager:get_skill_level_exp(self.serverSkill.skillid, self.serverSkill.level)
        self.expNum.text = string.format("%d/%d", self.serverSkill.exp, needExp)
        self.fillImg.fillAmount = self.serverSkill.exp / needExp
    end
end

function refresh_ui_items(self)
    local totalExp = 0
    for i, obj in ipairs(self.expObjs) do
        local cnt = self.expItemCnts[i]
        totalExp = totalExp + cnt * self.exps[i]
        local iconArea = obj.transform:Find("IconArea")
        iconArea:Find("Count/Text"):GetComponent(Text).text = cnt
        if self.pressIndex ~= i then
            iconArea:Find("Mask").gameObject:SetActive(cnt == 0)
            iconArea:Find("AddBtn").gameObject:SetActive(cnt == 0)
        end
    end
    if self.lvUpBtn.gameObject.activeSelf then
        self.lvUpBtn.gameObject:SetActive(self.serverSkill.exp + totalExp >= HeroConfig.Skill_upData[self.serverSkill.level].exp)
    end
end

function refresh_ui_lv(self)
    self.lvTxt.text = lang("UI_BASIC_LV")..self.serverSkill.level
    self.currLvDesc.text = SkillManager:get_skill_buff_desc(self.serverSkill.skillid, self.serverSkill.level, self.hero.id_)
    local isMax = SkillManager:is_skill_lv_max(self.serverSkill.level)
    local isStarMax = SkillManager:is_skill_lv_max_by_star(self.serverSkill.level, self.hero.id_, self.hero.star_)
    if self.lvUpBtn.gameObject.activeSelf then
        self.lvUpBtn.gameObject:SetActive(not (isMax or isStarMax))
    end
    if isMax then
        self.nextLvDesc.gameObject:SetActive(false)
    else
        self.nextLvDesc.text = SkillManager:get_skill_desc_next_lv(self.serverSkill.skillid, self.serverSkill.level)
    end
end

function refresh_server_skill(self)
    local serverSkill = self.hero:get_skill_by_pos(self.pos)
    if self.serverSkill then
        if serverSkill.skillid ~= self.serverSkill.skillid then
            elog("skill error")
            return
        end
    else
        self.serverSkill = {}
    end
    for k, v in pairs(serverSkill) do
        self.serverSkill[k] = v
    end
end

function sync_item_cnts(self)
    self.expItemCnts = {}
    local expItems = ItemManager:get_hero_skill_exp_items()
    for i, v in ipairs(BasicConfig.BasicData.hero_skill_items) do
        local cfg = ItemConfig.ItemData[v[1]]
        if cfg then
            local item = expItems[v[1]]
            local cnt = item and item.count_ or 0
            table.insert(self.expItemCnts, cnt)
        end
    end
end

function refresh_all(self)
    self:refresh_server_skill()
    self:refresh_ui_items()
    self:refresh_ui_exp()
    self:refresh_ui_lv()
end
