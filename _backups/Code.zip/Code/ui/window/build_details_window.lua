local BuildDetailsWindow = {}
setmetatable(BuildDetailsWindow, {__index = _G.BaseWindow})

local UnityEngine = _G.UnityEngine
local UI = _G.UnityEngine.UI
local config = _G.config
local lang = _G.lang
local MsgCenter = _G.MsgCenter
local Msg = _G.Msg
local BuildManager = _G.BuildManager
local Net = _G.Net
local UIUtil = _G.UIUtil
local Check_State

--1.准备UI（UI美术资源加载）
function BuildDetailsWindow.on_resource()
end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function BuildDetailsWindow:on_init()
    self.space_class_ = self.data[1]
    self.build_info_ = self.space_class_.build_info_

    self.backgroud_btn_ = self.transform:Find('Background'):GetComponent(UI.Button)
    --ScrollPoolWorld
    self.des_plane_ = self.transform:Find('WindowObj/RightBg/Plane/DesPlane'):GetComponent(_G.ScrollPoolVertical)
    self.more_des_plane_ = self.transform:Find('WindowObj/RightBg/Plane/MorePlane'):GetComponent(_G.ScrollPoolVertical)
    self.more_des_plane_.gameObject:SetActive(false)
    self.build_name_ = self.transform:Find('WindowObj/BuildInfo/Name'):GetComponent(UI.Text)
    self.build_lv_ = self.transform:Find('WindowObj/BuildInfo/Lv'):GetComponent(UI.Text)
    self.line_ = self.transform:Find('WindowObj/RightBg/Plane/Line')
    self.line_.gameObject:SetActive(false)
    --toggle
    self.toggle_01_ = self.transform:Find('WindowObj/RightBg/ToggleGroup/Toggle01'):GetComponent(UI.Toggle)
    self.toggle_02_ = self.transform:Find('WindowObj/RightBg/ToggleGroup/Toggle02'):GetComponent(UI.Toggle)
    --Button
    self.cancel_knock_btn_ = self.transform:Find('WindowObj/RightBg/Buttons/CancelBtn'):GetComponent(UI.Button)
    self.build_move_btn_ = self.transform:Find('WindowObj/RightBg/Buttons/BuildMoveBtn'):GetComponent(UI.Button)
    self.cancel_txt_ = self.cancel_knock_btn_.transform:Find('Text'):GetComponent(UI.Text)
    --top right
    -- self.target_desc_ = self.transform:Find("TargetPanel")
    -- self.target_txt_ = self.transform:Find("TargetPanel/Value"):GetComponent(Text)
    --
    self.des_title_ = self.transform:Find('WindowObj/RightBg/Plane/DesTitle')
    self.des_title_.gameObject:SetActive(false)
    self.des_txt_ = self.des_plane_.transform:Find('Txt'):GetComponent(UI.Text)
    self.details_txt_ = self.transform:Find('WindowObj/Details'):GetComponent(UI.Text)

    self.cache_ = self.transform:Find('WindowObj/RightBg/Plane/Cache')
    self.des_prefab_ = self.cache_.transform:Find('DesPrefab')
    self.des_prefab_.gameObject:SetActive(false)
    self.more_des_prefab_ = self.cache_.transform:Find('MoreDesPrefab')
    self.more_des_prefab_.gameObject:SetActive(false)
    self.txt_prefab_ = self.cache_.transform:Find('TextPrefab')
    self.txt_prefab_.gameObject:SetActive(false)

    self:init_pool() --初始化pool
    self:add_event_handler(self.toggle_01_.onValueChanged, self.on_select_toggle_changed, self.des_plane_)
    self:add_event_handler(self.toggle_02_.onValueChanged, self.on_select_toggle_changed, self.more_des_plane_, self.des_title_)
    self:add_event_handler(self.backgroud_btn_.onClick, self.on_back_click)
    self:add_event_handler(self.build_move_btn_.onClick, self.on_build_move_click)
    self.toggle_01_.isOn = true
end

--3.打开UI（打开/刷新UI处理）
function BuildDetailsWindow:on_open()
    if not self.build_info_ then
        return
    end
    --建筑名称 等级
    local name = lang('UI_BASIC_COLOR', config.FONT_COLOR.YELLOW, self.build_info_.name_)
    local lv = lang('UI_BASIC_COLOR', config.FONT_COLOR.GREY, lang('UI_BASIC_LV') .. self.build_info_.lv_)
    self.build_name_.text = name
    self.build_lv_.text = lv

    self:set_button_syle()
    self:check_build_state()
    self.details_txt_.text = self.build_info_.introduce_
    --self.target_txt_.text = lang("UI_BUILDSPEND_LVDES", self.build_info_.lv_)
    self:refresh_des_pool() --刷新详情界面显示
    MsgCenter.send_message(Msg.CITY_HIDE_UI_ALL, true)
end

--5.关闭UI（UIManager销毁UI前处理）
function BuildDetailsWindow:on_close()
    self.toggle_01_.onValueChanged:RemoveAllListeners()
    self.toggle_02_.onValueChanged:RemoveAllListeners()
    if _G.SceneManager.City_Scene then
        _G.SceneManager.City_Scene:back_play_animate()
    else
        _G.SceneController.currentScene:GetCameraController():FocusBack();
    end
    MsgCenter.send_message(Msg.CITY_HIDE_UI_ALL, false)
end

function BuildDetailsWindow.main_title()
    return lang('UI_BUILDDETAILS_TITLE')
end

function BuildDetailsWindow:on_after_top()
    --self.target_desc_:SetSiblingIndex(self.transform.childCount)
end
---------------------------------------------------------------------------------------------

function BuildDetailsWindow:check_build_state()
    --local state = self.build_info_:get_state()
    local state
    --如果正在拆除并且正在治疗中的时候  先显示取消拆除
    if self.build_info_:is_curing() and self.build_info_:is_removing() then
        state = config.Build_State.REMOVING
    elseif self.build_info_:is_curing() then
        state = config.Build_State.CURE
    elseif self.build_info_:is_removing() then
        state = config.Build_State.REMOVING
    elseif self.build_info_:is_lvup() then
        state = config.Build_State.LV_UP
    elseif self.build_info_:is_building() then
        state = config.Build_State.BUILDING
    elseif self.build_info_:is_trainning() then
        if self.build_info_:is_lvup() then
            state = config.Build_State.DRILL_AND_LV_UP
        else
            state = config.Build_State.DRILL
        end
    else
        state = config.Build_State.NONE
    end
    _G.printf('state = %s', state)
    if Check_State[state] then
        self.cancel_knock_btn_.onClick:RemoveAllListeners()
        Check_State[state](self)
    end
end

--打开一个提示窗口
function BuildDetailsWindow.ShowHintPop(content, callback)
    local msg_ = {}
    msg_.title = ''
    msg_.content = content
    msg_.buttons = {lang('UI_BASIC_CANCEL'), lang('UI_BASIC_SURE')}
    msg_.callback = function(index)
        if index == 2 then
            if callback then
                callback()
            end
        end
    end
    MsgCenter.send_message(Msg.SHOW_NOTIFY, msg_)
end

--发送请求
function BuildDetailsWindow.SendRequest(msg)
    if not msg then
        return
    end
    Net.send(msg.name, msg.data, function(result)
        if msg.callback then
            msg.callback(result)
        end
    end)
end

--打开一个提示窗口 发送消息
function BuildDetailsWindow:ShowPopAndSendMsg(eventData, hintStr, msg)
    self.ShowHintPop(hintStr, function()
        self.SendRequest(msg)
    end)
end

--设置拆除事件
function BuildDetailsWindow:set_removing_handler()
    self.cancel_txt_.text = lang('UI_BUILDDETAILS_REMOVED')
    local hint_str = lang('UI_HINT_BUILD_REMOVED')

    --设置按钮监听事件
    local msg = {}
    msg.name = "build_dismantle"
    msg.data = {id = self.build_info_.id_}
    msg.callback = function(result)
        if result.e == 0 then
            if result.e == 0 then
                local build_id = self.build_info_.id_
                MsgCenter.send_message(Msg.CITY_UP_LV_UPDATE, build_id)
                self:close()
            elseif result.e == 3 then
                MsgCenter.send_message(Msg.SHOW_HINT, lang('UI_BUILDSPEND_FULL'))
            end
        end
    end
    self:add_event_handler(self.cancel_knock_btn_.onClick, self.ShowPopAndSendMsg, hint_str, msg)
end

--设置取消拆除事件
function BuildDetailsWindow:set_cancel_removing_handler()
    self.cancel_txt_.text = lang('UI_BUILDDETAILS_CANCEL_REMOVED')
    local hint_str = lang('UI_HINT_BUILD_REMOVED_CANCEL')
        --设置按钮监听事件
        local msg = {}
        msg.name = "build_dismantle_cancel"
        msg.data = {id = self.build_info_.id_}
        msg.callback = function(result)
            if result.e == 0 then
                BuildManager:remove_queuq(self.build_info_.id_)
                self.build_info_:reset_dismantle() -- 清除状态
                MsgCenter.send_message(Msg.CITY_BUILD_REMOVED_CANCEL, self.build_info_.id_)
                self:close()
            end
        end

    self:add_event_handler(self.cancel_knock_btn_.onClick, self.ShowPopAndSendMsg, hint_str, msg)
end

--设置取消训练事件
function BuildDetailsWindow:set_cancel_drill_handler()
    --设置按钮文本pc
    self.cancel_txt_.text = lang('UI_SOLDIER_CANCEL_DRILL')
    local hint_str = lang('UI_HINT_DRILL_CANCEL')
    --设置按钮监听事件
    local msg = {}
    msg.name = "build_soldier_cancel"
    msg.data = {id = self.build_info_.id_}
    msg.callback = function(result)
        if result.e == 0 then
            self.space_class_:stop_timer_2()
            self:close()
        end
    end
    self:add_event_handler(self.cancel_knock_btn_.onClick, self.ShowPopAndSendMsg, hint_str, msg)
end


--打开提示窗口 发送消息
 function BuildDetailsWindow:cancel_building(content, msg)
    --取消升级比较特殊 俩个提示窗口
    self.ShowHintPop(content, function()
        --二级提示框
        local hint_str = lang('UI_HINT_LVUP_CANCEL_RES_RETURN')
        self.ShowHintPop(hint_str, function()
            self.SendRequest(msg)
        end)
    end)
end

--取消升级
function BuildDetailsWindow:set_cancel_building_handler()
    self.cancel_txt_.text = lang('UI_BUILDDETAILS_LVUP_CANCEL')
    local hint_str = lang('UI_HINT_LVUP_CANCEL')
    --设置按钮监听事件
    local msg = {}
    msg.name = "build_levelup_cancel"
    msg.data = {id = self.build_info_.id_}
    msg.callback = function(result)
        if result.e == 0 then
            self:close()
        end
    end
    self:add_event_handler(self.cancel_knock_btn_.onClick, self.cancel_building, hint_str, msg)
end

--设置取消治疗事件
function BuildDetailsWindow:set_cancel_cure_handler()
    --如果是在治疗中
    if self.build_info_:is_hospital_build() then
        self.cancel_txt_.text = lang('UI_BUILDDETAILS_CURE_CANCEL1')
        local hintStr = lang('UI_HINT_CURE_CANCEL')
        local msg = {}
        msg.name = "soldier_cure_cancel"
        msg.data = {}
        msg.callback = function(result)
            if result.e == 0 then
                -- 加参数 说明是取消 不需要飘字显示
                MsgCenter.send_message(Msg.CITY_SOLDIER_CURE_FINISHED, result.e)
                if _G.event then
                    _G.event.fire(_G.EventKey.CITY_SOLDIER_CURE_FINISHED, {result.e})
                end
                self:close()
            end
        end
        --设置按钮点击事件，以及打开提示窗口之后的 窗口确定按钮的事件
        self:add_event_handler(self.cancel_knock_btn_, self.ShowPopAndSendMsg, hintStr, msg)
    end
end
-------------------------------------------------------------------------------------------

function BuildDetailsWindow:set_button_syle()
    --是否可以移动
    local is_movable = self.build_info_:is_movable()
    self.build_move_btn_.gameObject:SetActive(is_movable)

    --拆除按钮和取消状态按钮（比如取消治疗） 都是用的一个按钮。 资源田有拆除按钮，建筑有状态的时候可以显示按钮
    local is_can_be_removing = self.build_info_:is_can_be_removed()
    --目前没有取消升级功能，训练的时候需要加上按钮显示
    if is_can_be_removing or self.build_info_:is_trainning() or self.build_info_:is_lvup() then
        self.cancel_knock_btn_.gameObject:SetActive(true)
    else
        self.cancel_knock_btn_.gameObject:SetActive(false)
    end
end

function BuildDetailsWindow:init_pool()
    if not self.build_info_ or #self.build_info_:get_build_more_details() <= 0 then
        return
    end
    local build_details_tb = self.build_info_:get_build_more_details()
    local mdetail_stitle = self.build_info_:GetMdetailsTitle()

    local up_info = self.build_info_:get_update_info_by_level(self.build_info_.lv_)
    if not up_info then
        return
    end

    --对数据进行封装 讲title文字，与宽度剔除出来
    local width_tb = {}
    local txet_tb = {}
    for k, v in pairs(mdetail_stitle) do
        txet_tb[k] = lang(v[1])
        width_tb[k] = v[2]
    end
    if not width_tb or not txet_tb then
        return
    end

    self:set_list_title(width_tb, txet_tb) --设置title
    --初始化更多详情
    self.more_des_plane_:InitPool(
        #build_details_tb,
        function(index, obj)
            local rect = obj:GetComponent(UnityEngine.RectTransform)
            rect.sizeDelta = UnityEngine.Vector2(self.title_size_.width, rect.sizeDelta.y)
            local size = rect.sizeDelta
            local bg1 = obj.transform:Find('Backage1')
            local bg2 = obj.transform:Find('Backage2')
            bg1.gameObject:SetActive(index % 2 ~= 0)
            bg2.gameObject:SetActive(index % 2 == 0)
            for k, _ in pairs(txet_tb) do
                local parent = obj.transform:Find('Content')
                local txt_obj = parent.transform:Find('obj' .. k)
                if not txt_obj then
                    txt_obj = self.create_gameobject(self.txt_prefab_, parent)
                    txt_obj.name = 'obj' .. k
                end
                local v2 = UnityEngine.Vector2(size.x * width_tb[k] / 100, size.y)
                txt_obj:GetComponent(UnityEngine.RectTransform).sizeDelta = v2

                local arg = lang(build_details_tb[index][k])
                if arg == 'undefine' then
                    arg = nil
                end
                txt_obj:GetComponent(UI.Text).text = arg

                if index == self.build_info_.lv_ then
                    txt_obj:GetComponent(UI.Text).color = UnityEngine.Color.white
                else
                    txt_obj:GetComponent(UI.Text).color = UnityEngine.Color(128 / 255, 141 / 255, 154 / 255)
                end
            end
        end,
        self.build_info_.lv_
    )
end

-- 详情
function BuildDetailsWindow:refresh_des_pool()
    local mdetail_stitle = self.build_info_:GetMdetailsTitle()
    local up_info = self.build_info_:get_update_info_by_level(self.build_info_.lv_)
    local details = lang(up_info.details)
    --path存在时候的显示处理
    if not up_info.detailsicon or #up_info.detailsicon == 0 then
        self.des_txt_.text = lang(details[1])
        self.des_txt_.gameObject:SetActive(true)
    else
        self.des_txt_.gameObject:SetActive(false)
        --初始化详情

        self.des_plane_:InitPool(
            #details,
            function(index, obj)
                local rect = obj:GetComponent(UnityEngine.RectTransform)
                rect.sizeDelta = UnityEngine.Vector2(self.title_size_.width, rect.sizeDelta.y)

                obj.gameObject:SetActive(true)
                local icon = obj.transform:Find('Icon/Image'):GetComponent(UI.Image)
                local des_txt = obj.transform:Find('DesTxt'):GetComponent(UI.Text)
                local number_txt = obj.transform:Find('ValueTxt'):GetComponent(UI.Text)

                UIUtil.set_sprite(up_info.detailsicon[index], icon)
                des_txt.text = lang(details[index])

                --城外的资源田 医馆 征兵处需要显示数值 / 城内
                local key
                for k, v in pairs(mdetail_stitle) do
                    if lang(v[1]) == lang(details[index]) then
                        key = k
                        break
                    end
                end
                local key_value = lang(up_info.moredetails[key])
                if key_value == 'undefine' then
                    key_value = nil
                end
                if not key_value then
                    key_value = self.build_info_:get_details_value(index)
                end

                local attrs_buf = self.build_info_:get_details_attrs(key_value, index)
                if attrs_buf == 0 then
                    number_txt.text = key_value
                else
                    local value = key_value
                    number_txt.text =
                        string.format('%d<color=%s>+%d</color>', value, config.FONT_COLOR.GREEN, attrs_buf)
                end
            end
        )
    end
end


function BuildDetailsWindow:SetFeteValue(numTxt, index)
    local fete = BuildManager:GetFete()
    local prop = fete:GetSacUpdate()
    if not fete or not prop then
        return
    end
    if index == 5 then
        numTxt.text = prop.free_times
    else
        numTxt.text = prop["point"..index][3]
    end
end

--设置列表title文字  宽度 颜色
function BuildDetailsWindow:set_list_title(width_tb, txet_tb)
    self.title_size_ = self.des_title_:GetComponent(UnityEngine.RectTransform).rect
    for k, v in pairs(txet_tb) do
        local go = self.create_gameobject(self.txt_prefab_, self.des_title_)
        local v2 = UnityEngine.Vector2(self.title_size_.width * width_tb[k] / 100, self.title_size_.height)
        go:GetComponent(UnityEngine.RectTransform).sizeDelta = v2
        go:GetComponent(UI.Text).text = lang('UI_BASIC_COLOR', config.FONT_COLOR.BLUE, v)
        go:GetComponent(UI.Text).fontSize = 21
    end
end

function BuildDetailsWindow.create_gameobject(prefab, parent)
    local go = UnityEngine.GameObject.Instantiate(prefab)
    go.transform:SetParent(parent.gameObject.transform, false)
    go.transform.localScale = UnityEngine.Vector3.one
    go.gameObject:SetActive(true)
    return go
end

function BuildDetailsWindow:on_select_toggle_changed(event_data, obj1, obj2)
    obj1.gameObject:SetActive(event_data)
    if not obj2 then
        self.des_title_.gameObject:SetActive(false)
        self.line_.gameObject:SetActive(false)
    else
        self.line_.gameObject:SetActive(true)
        self.des_title_.gameObject:SetActive(true)
    end
end

function BuildDetailsWindow:on_cancel_drill_click()
    local msg_ = {}
    msg_.title = ''
    msg_.content = lang('UI_HINT_DRILL_CANCEL')
    msg_.buttons = {lang('UI_BASIC_CANCEL'), lang('UI_BASIC_SURE')}
    msg_.callback = function(index)
        if index == 2 then
            Net.send(
                'build_soldier_cancel',
                {id = self.build_info_.id_},
                function(result)
                    if result.e == 0 then
                        self.space_class_:stop_timer_2()
                        self:close()
                    end
                end
            )
        end
    end
    MsgCenter.send_message(Msg.SHOW_NOTIFY, msg_)
end

function BuildDetailsWindow:on_build_move_click()
    local hint = lang('UI_HINT_BUILD_MOVE')
    self.ShowHintPop(hint, function()
        MsgCenter.send_message(Msg.CITY_SHOW_CAN_EXCHANGE_BUILD, self.build_info_.id_)
        self:close()
    end)
end

function BuildDetailsWindow:on_back_click()
    self:close()
end

Check_State = {
    [config.Build_State.CURE] = BuildDetailsWindow.set_cancel_cure_handler, --取消治疗
    [config.Build_State.NONE] = BuildDetailsWindow.set_removing_handler, --拆除
    [config.Build_State.REMOVING] = BuildDetailsWindow.set_cancel_removing_handler, --建筑取消拆除
    [config.Build_State.LV_UP] = BuildDetailsWindow.set_cancel_building_handler, --建筑取消升级
    [config.Build_State.DRILL] = BuildDetailsWindow.set_cancel_drill_handler, --取消训练
    [config.Build_State.DRILL_AND_LV_UP] = BuildDetailsWindow.set_cancel_drill_handler, --如果在训练并且升级中。先显示训练
    [config.Build_State.RESEARCH] = BuildDetailsWindow.set_cancel_research_handler, --取消研究
}

return BuildDetailsWindow
