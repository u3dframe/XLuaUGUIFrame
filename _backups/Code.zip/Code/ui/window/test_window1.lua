-- 登录界面
module("TestWindow1",package.seeall)
setmetatable( TestWindow1, {__index = BaseWindow} )

--1.准备UI（UI美术资源加载）
local ItemConfig = _G.Database.ItemConfig


function on_resource(self)

end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self)    
    self.btn_login_ = self.transform:Find("LoginBtn"):GetComponent(Button)
	self:add_event_handler(self.btn_login_.onClick, function()
        self:close()
    end)
    self.btn_pop_ = self.transform:Find("PopupWindows"):GetComponent(Button)
	self:add_event_handler(self.btn_pop_.onClick, function()
        UIManager.open_window("TestWindow2")
    end)
    self.btn_component_ = self.transform:Find("ComponentModeBtn"):GetComponent(Button)
    self:add_event_handler(self.btn_component_.onClick, function()
        UIManager.open_window("ComponentModeWindow")
    end)

    self.cur_select_btn_ = self.transform:Find("GMPanel/Drop"):GetComponent(Button)
    self:add_event_handler(self.cur_select_btn_.onClick, on_select_resource)
    self.cur_select_text_ = self.transform:Find("GMPanel/Drop/Text"):GetComponent(Text)
    self.drop_scroll_ = self.transform:Find("GMPanel/Drop/ScrollView").gameObject
    
    self.auto_scroll_rect_script_ = self.transform:Find("ScrollRect"):GetComponent(ToggleScrollRectParent)
    --self.auto_scroll_rect_script_.OnLocate = function(i) elog("Located: "..i) end
    --self.auto_scroll_rect_script_.OnLocationComplete = function(i) elog("OnLocationComplete: "..i) end
    self.auto_scroll_rect_script_:InitItems(10, function(i, obj)
        -- obj:GetComponent(RectTransform).localScale = Vector3(1, 1, 1)
        -- local pos = obj:GetComponent(RectTransform).position
        -- pos.z = 0
        -- obj:GetComponent(RectTransform).position = pos
        -- obj:GetComponent(RectTransform).sizeDelta = Vector2(100, 100)
    end)
    
    self.input_ = self.transform:Find("GMPanel/InputField"):GetComponent(InputField)
    self.add_btn_ = self.transform:Find("GMPanel/AddBtn"):GetComponent(Button)
    self:add_event_handler(self.add_btn_.onClick, send_res_to_server)
    
    --增加物品的控件
    local item_panel = self.transform:Find("GMItemPanel")
    self.item_id_input_ = item_panel:Find("IDInputField"):GetComponent(InputField)
    self.item_num_input_ = item_panel:Find("NumInputField"):GetComponent(InputField)
    self.item_num_input_.text = 100
    self.item_add_btn_ = item_panel:Find("AddBtn"):GetComponent(Button)
    self:add_event_handler(self.item_add_btn_.onClick, add_item)

    local gm_panel = self.transform:Find("RawGMPanel")
    self.raw_gm_input_ = gm_panel:Find("InputField"):GetComponent(InputField)
    self.raw_gm_btn_ = gm_panel:Find("Button"):GetComponent(Button)
    self:add_event_handler(self.raw_gm_btn_.onClick, on_click_gm)
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
    self.drop_scroll_:SetActive(false)
    self.item_str_ = {
        "木材", 
        "粮食", 
        "石材", 
        "铁锭", 
        "宝石", 
        "贵族经验", 
        "金币", 
        "兵",
        "体力",
        "伤兵"}
	for i = 1, 10 do
        local tran = self.drop_scroll_.transform:Find("Content/Button"..i)
        local txt = tran:Find("Text"):GetComponent(Text)
        local btn = tran:GetComponent(Button)
        txt.text = self.item_str_[i]
        self:add_event_handler(btn.onClick, on_click_select_resource, i)
    end
    self:on_click_select_resource(true, self.data[1] or 1)
    self.drop_scroll_:SetActive(false)
    self.input_.text = 10000000
    
    self.auto_scroll_rect_script_:Locate(1)

end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
     
end

function on_select_resource(self, event)
    self.drop_scroll_:SetActive(not self.drop_scroll_.activeSelf)
    
    
end

function on_click_select_resource(self, event, index)
    self.drop_scroll_:SetActive(not self.drop_scroll_.activeSelf)
    self.select_index_ = index
    self.cur_select_text_.text = self.item_str_[index]
end

function send_res_to_server(self)
    if self.input_.text == "" then
        return
    end
    local chat = {}
    chat.channel = 1
    if self.select_index_ < 8 then
        chat.content = string.format("lua@item(%d,0,%s)", self.select_index_, self.input_.text)
    elseif self.select_index_ == 8 then
        chat.content = string.format("lua@soldier(%d,%s)", 1, self.input_.text)
    elseif self.select_index_ == 10 then
        chat.content = string.format("lua@soldier_cure_add(%d,%s)", 1, self.input_.text)
    end
    Net.send("chat_chating", chat, function(res)
        if res.e == 0 then
            MsgCenter.send_message(Msg.SHOW_HINT, "已经添加成功！")
        end
    end)
end

function add_item(self)
    local itemid = tonumber(self.item_id_input_.text)
    local cfg = ItemConfig.ItemData[itemid]
    if not cfg then
        MsgCenter.send_message(Msg.SHOW_HINT, "物品不存在！")
        return
    end
    local count = tonumber(self.item_num_input_.text) or 1
    if count < 1 or count > 9999999 then
        MsgCenter.send_message(Msg.SHOW_HINT, "物品数量必须在1到9999999之间！")
        return
    end
    Net.send("chat_chating", {
        content = string.format("lua@item(10,%d,%d)", itemid, count)
    }, function(res)
        if res.e == 0 then
            MsgCenter.send_message(Msg.SHOW_HINT, "已经添加成功！")
        end
    end)
end



function on_click_unline(self)
    local chat = {}
    chat.channel = 1
    Net.register(self, "chat_chating", on_chat_chating)
    chat.content = string.format("lua@kick(1)")
    Net.send("chat_chating", chat, function(res)
        if res.e == 0 then
            MsgCenter.send_message(Msg.SHOW_HINT, "已经添加成功！")
        end
    end)
end

function on_click_gm(self)
    local cmd = string.lower(self.raw_gm_input_.text)
    if string.sub(cmd, 1, 4) ~= "lua@" then
        cmd = "lua@"..cmd
    end
    Net.send("chat_chating", {content = cmd}, function(res)
        if res.e == 0 then
            --请求服务器时间
            if string.match(cmd, "time") then
                Net.send("ping", {any = 0}, function(result)
                    Net:UpdateServerTime(result)
                end)
            end
            MsgCenter.send_message(Msg.SHOW_HINT, "执行成功！")
        end
    end)
end

