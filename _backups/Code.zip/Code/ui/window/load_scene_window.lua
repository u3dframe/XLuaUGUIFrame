module("LoadSceneWindow",package.seeall)
setmetatable( LoadSceneWindow, {__index = BaseWindow} )


function on_resource(self)

end

function on_init(self)
    self.canvas_group_ = self.transform:GetComponent(CanvasGroup)
    self.loading_image_ = self.transform:Find("Background"):GetComponent(RawImage)
    self.loading_txt_ = self.transform:Find("Text"):GetComponent(Text)
   
end

function on_open(self)
    local num = 0
    local str = {"", ".", "..", "...", "....", ".....", "......"}
    self.timer_ = LuaTimer.Add( 0, 200, function()
        num = num + 1
        local index = num%7 + 1
        self.loading_txt_.text = lang("加载中"..str[index])
    end)
end

function on_close(self)
    if self.timer_ then
        LuaTimer.Delete(self.timer_)
        self.timer_ = nil
    end 
end



function fade_out(self, start_cb, end_cb)
    if not self.canvas_group_ or Slua.IsNull(self.canvas_group_) then
        if start_cb then start_cb() end
        if end_cb then end_cb() end
        self:close()
        return
    end
    GameTween.DOFade(self.canvas_group_, 0, 0.5):SetEase(XEase.InCubic):OnStart(function()
        if start_cb then start_cb() end
    end):OnComplete(function()
        if self:is_alive() == false then return end
        if end_cb then end_cb() end
        self:close()
    end)
end
