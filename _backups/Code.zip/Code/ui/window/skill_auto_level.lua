module("SkillAutoLevel", package.seeall)
setmetatable(SkillAutoLevel, {__index = BaseWindow})


local ItemConfig = _G.Database.ItemConfig
local BasicConfig = _G.Database.BasicConfig
local HeroConfig = _G.Database.HeroConfig


function on_init(self)
    self.levelWin = self.data[1]
    self.hero = self.data[2]
    self.pos = self.data[3]
    self.serverSkill = self.hero:get_skill_by_pos(self.pos)
    self.maxLv = nil

    local closeBtn = self.transform:Find("Top/CloseBtn"):GetComponent(Button)
    self:add_event_handler(closeBtn.onClick, function() self:close() end)

    local cancelBtn = self.transform:Find("CancelBtn"):GetComponent(Button)
    self:add_event_handler(cancelBtn.onClick, function() self:close() end)

    local itemObj = self.transform:Find("Scroll View/skilldanBg").gameObject
    itemObj:SetActive(false)
    local itemContent = self.transform:Find("Scroll View/Viewport/Content")
    self.itemInfo = {}
    local expItems = ItemManager:get_hero_skill_exp_items()
    for i, v in ipairs(BasicConfig.BasicData.hero_skill_items) do
        local cfg = ItemConfig.ItemData[v[1]]
        if cfg and expItems[v[1]] then
            local info = {
                itemid = expItems[v[1]].id_,
                totalCnt = expItems[v[1]].count_,
                useCnt = 0,
                exp = v[2],
                index = i,
            }
            table.insert(self.itemInfo, info)
            local obj = GameObject.Instantiate(itemObj)
            obj:SetActive(true)
            obj.transform:SetParent(itemContent, false)
            local name = obj.transform:Find("DanName"):GetComponent(Text)
            name.text = cfg.name
            local cnt = obj.transform:Find("DanNum"):GetComponent(Text)
            info.cntComponent = cnt
            local bg = obj.transform:GetComponent(Image)
            UIUtil.set_sprite("UI/Common/Quality/item_"..cfg.quality, bg)
            local icon = obj.transform:Find("skilldanicon"):GetComponent(Image)
            UIUtil.set_sprite(cfg.icon, icon)
        end
    end
    table.sort(self.itemInfo, function(a, b) return a.exp > b.exp end)
    local totalExpOfItems = 0
    for _, info in ipairs(self.itemInfo) do
        totalExpOfItems = totalExpOfItems + info.totalCnt * info.exp
    end
    self.maxLvByAllItems = self.serverSkill.level
    local currExp = self.serverSkill.exp
    while totalExpOfItems > 0 do
        local total = SkillManager:get_skill_level_exp(self.serverSkill.skillid, self.maxLvByAllItems)
        if not total then break end
        local addExp = math.min(totalExpOfItems, total - currExp)
        totalExpOfItems = totalExpOfItems - addExp
        currExp = currExp + addExp
        if currExp >= total then
            self.maxLvByAllItems = self.maxLvByAllItems + 1
            currExp = currExp - total
        end
    end

    local confirmBtn = self.transform:Find("ConfirmBtn"):GetComponent(Button)
    self:add_event_handler(confirmBtn.onClick, function()
        local totalExp = 0
        local items = {}
        for _, info in ipairs(self.itemInfo) do
            if info.useCnt > 0 then
                totalExp = totalExp + info.exp * info.useCnt
                table.insert(items, {info.itemid, info.useCnt})
            end
        end
        SkillManager:levelup_skill(self.hero.id_, self.pos, self.serverSkill.skillid, items)
        if totalExp > 0 and self.levelWin and self.levelWin.expAnimator then
            self.levelWin.expAnimator:play(totalExp, false)
            local it = {}
            for _, info in ipairs(self.itemInfo) do
                if info.useCnt > 0 then
                    it[info.index] = info.useCnt
                end
            end
            self.levelWin:use_items(it)
        end
        self:close()
    end)

    self.slider = self.transform:Find("SelectMode/Slider"):GetComponent(Slider)
    self:add_event_handler(self.slider.onValueChanged, on_slider_value_change)
    local addBtn = self.transform:Find("SelectMode/Buttons/AddBtn"):GetComponent(Button)
    self:add_event_handler(addBtn.onClick, function()
        if self.slider.value >= self.slider.maxValue then return end
        self.slider.value = self.slider.value + 1
    end)
    local subBtn = self.transform:Find("SelectMode/Buttons/SubBtn"):GetComponent(Button)
    self:add_event_handler(subBtn.onClick, function()
        if self.slider.value <= self.slider.minValue then return end
        self.slider.value = self.slider.value - 1
    end)
    self.useCntTxt = self.transform:Find("SelectMode/Buttons/InputField/CountTxt"):GetComponent(Text)

    self.messager_:add_listener(Msg.UI_SKILL_CHANGE, update_skill)
end

function on_open(self)
    self:update_skill()
end

function update_skill(self)
    local oldValue = self.slider.value
    self.serverSkill = self.hero:get_skill_by_pos(self.pos)
    local maxStarLv = HeroManager:get_hero_skill_max_lv(self.hero.id_, self.hero.star_)
    local maxLv = #HeroConfig.Skill_upData + 1
    self.maxLv = math.min(maxLv, maxStarLv, self.maxLvByAllItems)
    if self.serverSkill.level >= self.maxLv then
        self:close()
    end
    self.slider.minValue = self.serverSkill.level + 1
    self.slider.maxValue = self.maxLv
    self.slider.value = self.maxLv
    if self.slider.value == oldValue then
        self:on_slider_value_change()
    end
end

function on_slider_value_change(self)
    self.useCntTxt.text = self.slider.value.."/"..self.maxLv
    local totalExp = SkillManager:get_skill_level_exp(self.serverSkill.skillid, self.serverSkill.level) - self.serverSkill.exp
    for lv = self.serverSkill.level + 1, self.slider.value - 1 do
        totalExp = totalExp + SkillManager:get_skill_level_exp(self.serverSkill.skillid, lv)
    end
    local e, u = self:_calc(totalExp)
    for i, info in ipairs(self.itemInfo) do
        info.useCnt = u[i] or 0
        info.cntComponent.text = info.useCnt
    end
end

function _calc(self, exp)
    local cnts = {}
    for i, info in ipairs(self.itemInfo) do
        cnts[i] = info.totalCnt
    end
    local minOverflow = math.huge
    local use
    local cache = {}
    for i, cnt in ipairs(cnts) do
        if cnt > 0 then
            local arg = {}
            for k, v in pairs(cnts) do
                arg[k] = v
            end
            arg[i] = arg[i] - 1
            local o, u = self:_calc_recursively(exp - self.itemInfo[i].exp, cache, arg)
            local over = self.itemInfo[i].exp + o - exp
            if over < minOverflow then
                minOverflow = over
                use = {}
                for k, v in pairs(u or {}) do
                    use[k] = v
                end
                use[i] = use[i] or 0
                use[i] = use[i] + 1
            end
        end
    end
    return minOverflow + exp, use
end

function _calc_recursively(self, exp, cache, cnts)
    if exp <= 0 then return 0 end
    if cache[exp] then return unpack(cache[exp]) end
    local minOverflow = math.huge
    local use
    for i, cnt in ipairs(cnts) do
        if cnt > 0 then
            local arg = {}
            for k, v in pairs(cnts) do
                arg[k] = v
            end
            arg[i] = arg[i] - 1
            local o, u = self:_calc_recursively(exp - self.itemInfo[i].exp, cache, arg)
            local over = self.itemInfo[i].exp + o - exp
            if over < minOverflow then
                minOverflow = over
                use = {}
                for k, v in pairs(u or {}) do
                    use[k] = v
                end
                use[i] = use[i] or 0
                use[i] = use[i] + 1
            end
        end
    end
    cache[exp] = {minOverflow + exp, use}
    return minOverflow + exp, use
end
