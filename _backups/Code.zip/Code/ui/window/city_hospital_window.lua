module("CityHospitalWindow", package.seeall)
setmetatable(CityHospitalWindow, {__index = BaseWindow})

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self) 
	local build_id = self.data[1]
	self.build_info_ = BuildManager:get_build_info_by_id(build_id)
	self.hurts_all_ = SoldierManager:get_hurts_all()
	self.title_cnt_ = self.transform:Find("WindowObj/Top/Board/Text"):GetComponent(Text)
	self.scroll_rect_ = self.transform:Find("WindowObj/ScrollRect"):GetComponent(ScrollPoolVertical)
	self.buttom_rect_ = self.transform:Find("WindowObj/Buttom")
	self.props_rect_ = self.transform:Find("WindowObj/RightPart/Props")
	self.timer_txt_ = self.buttom_rect_.transform:Find("RestoreBtn/Timer/Text"):GetComponent(Text)
	self.gold_txt_ = self.buttom_rect_.transform:Find("InstantHealBtn/Gold/Text"):GetComponent(Text)
	self.cancel_txt_ = self.buttom_rect_.transform:Find("CancelAllBtn/Text"):GetComponent(Text)
	self.cancel_txt_.text = lang("UI_CANCEL_ALL")
	self.hint_ = self.transform:Find("WindowObj/Hint")
	self.res_hint_ = self.transform:Find("WindowObj/ResHint")
	self.hint_txt_ = self.transform:Find("WindowObj/Hint/Text"):GetComponent(Text)
	self.hint_txt_.text = lang("UI_NONE_HURTS")
	self.res_hint_txt_ = self.transform:Find("WindowObj/ResHint/Text"):GetComponent(Text)
	self.res_hint_txt_.text = lang("UI_HOSIPITAL_RES_HINT")
	self.content_ = self.transform:Find("WindowObj/ScrollRect/Content")
	--top right
    self.target_desc_ = self.transform:Find("TargetPanel")
    self.target_txt_ = self.transform:Find("TargetPanel/Value"):GetComponent(Text)
	
	--Button
	self.cancel_all_btn_ = self.buttom_rect_.transform:Find("CancelAllBtn"):GetComponent(Button)
	self.instant_heal_btn_ = self.buttom_rect_.transform:Find("InstantHealBtn"):GetComponent(Button)
	self.restore_btn_ = self.buttom_rect_.transform:Find("RestoreBtn"):GetComponent(Button)
	self.info_btn_ = self.transform:Find("WindowObj/Top/Info"):GetComponent(Button)
	--prefab
	self.prefab_ = self.transform:Find("WindowObj/ScrollRect/Cache/Obj")
	self.prefab_.gameObject:SetActive(false)

	self:add_event_handler(self.cancel_all_btn_.onClick, on_cancel_btn_click)
	self:add_event_handler(self.instant_heal_btn_.onClick, on_instant_heal_btn_click)
	self:add_event_handler(self.restore_btn_.onClick, on_restore_btn_click)

	-- pop
	self.bg_ = self.transform:Find("Background")
	self.bg_.gameObject:SetActive(false)
	self.des_ = self.bg_.transform:Find("Center/Detatils"):GetComponent(Text)
	self.count_txt_ = self.bg_.transform:Find("Center/Image/Text"):GetComponent(Text)
	self.close_btn_ = self.bg_.transform:Find("Bg"):GetComponent(Button)
	self.add_btn_ = self.bg_.transform:Find("Center/Slider/AddBtn"):GetComponent(Button)
	self.sub_btn_ = self.bg_.transform:Find("Center/Slider/SubBtn"):GetComponent(Button)
	self.kick_btn_ = self.bg_.transform:Find("Center/Button"):GetComponent(Button)
	self.slider_ = self.bg_.transform:Find("Center/Slider"):GetComponent(Slider)

	self:add_event_handler(self.close_btn_.onClick, function() self.bg_.gameObject:SetActive(false) end)
	self:add_event_handler(self.add_btn_.onClick, on_add_click)
	self:add_event_handler(self.sub_btn_.onClick, on_sub_click)
	--self:add_event_handler(self.max_btn_.onClick, on_max_click)
	self:add_event_handler(self.kick_btn_.onClick, on_kick_click)
	self:add_event_handler(self.slider_.onValueChanged, on_kick_value_changed)
	self:add_event_handler(self.info_btn_.onClick, on_info_click)

	self.max_value_ = 0
	--启动界面 刷新道具
	self:set_props()
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
	self.slider_cnt_ = {}
	self.hurts_all_ = SoldierManager:get_hurts_all()
	if self.hurts_all_ and #self.hurts_all_ > 0 then
		self.hint_.gameObject:SetActive(false)
		self.res_hint_.gameObject:SetActive(false)
		self.props_rect_.gameObject:SetActive(true)
	else
		self.hint_.gameObject:SetActive(true)
		self.res_hint_.gameObject:SetActive(true)
		self.props_rect_.gameObject:SetActive(false)
	end
	self.target_txt_.text = lang("UI_BUILDSPEND_LVDES", self.build_info_.lv_)
	self.title_cnt_.text = "受伤部队:".."0".."/"..self.build_info_:get_hospital_max_cnt()
	self:init_pool()
	self.is_cancel_all_ = false
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
     
end

function main_title(self)
    return lang("UI_HOSPITAL_TITLE")
end

function on_after_top(self)
    self.target_desc_:SetSiblingIndex(self.transform.childCount)
end

function init_pool(self)
	--self.slider_tb_ = {}
	if not self.hurts_all_ or #self.hurts_all_ <= 0 then return end
	self.scroll_rect_:InitPool(#self.hurts_all_, function(index, obj)
		local soldier_img = obj.transform:Find("HeadFrame/SoldierImg"):GetComponent(Image)
		local soldier_name = obj.transform:Find("Name"):GetComponent(Text)
		local select_number = obj.transform:Find("Board/Number"):GetComponent(Text)
		local slider = obj.transform:Find("Slider"):GetComponent(Slider)
		local kick_btn = obj.transform:Find("KickBtn"):GetComponent(Button)
		local soldier = self.hurts_all_[index]

		--self.slider_tb_[index] = slider --保存slider
		soldier_name.text = lang("SOLDIER_LEVEL_"..soldier.lv_)..soldier.name_

		kick_btn.onClick:RemoveAllListeners()
		self:add_event_handler(kick_btn.onClick, on_kick_btn_click, slider, soldier.hurts_number_, index)

		self:set_slider(slider, select_number, index)
		if not self:is_alive() then return end
 		UIUtil.set_sprite(soldier.half_icon_path_, soldier_img)
	end)
end

function set_slider(self, obj, select_number, index)
	if not obj or not select_number then return end
	local slider = obj
	local add_btn = obj.transform:Find("AddBtn"):GetComponent(Button)
	local sub_btn = obj.transform:Find("SubBtn"):GetComponent(Button)
	local max_btn = obj.transform:Find("MaxBtn"):GetComponent(Button)
	local max_hurts = self.hurts_all_[index].hurts_number_

	slider.onValueChanged:RemoveAllListeners()
	slider.maxValue = max_hurts
	slider.minValue = 0

	add_btn.onClick:RemoveAllListeners()
	sub_btn.onClick:RemoveAllListeners()
	max_btn.onClick:RemoveAllListeners()

    self:add_event_handler(slider.onValueChanged, on_value_changed, obj, select_number, index)
    self:add_event_handler(add_btn.onClick, on_add_btn_click, slider, max_hurts)
    self:add_event_handler(sub_btn.onClick, on_sub_btn_click, slider)
    self:add_event_handler(max_btn.onClick, on_max_btn_click, slider, max_hurts)


    if self.slider_cnt_[index] then
    	max_hurts = self.slider_cnt_[index]
    else

    	if self.is_cancel_all_ then
    		max_hurts = 0
    	end
    end
    slider.value = max_hurts
    if slider.value == max_hurts then
    	self:on_value_changed(max_hurts, obj, select_number, index)
    end
end

function on_value_changed(self, event_data, obj, select_number, index)
	if not self.hurts_all_[index] then return end
	self.slider_cnt_[index] = event_data --保存slider数量
	select_number.text = event_data.."/"..self.hurts_all_[index].hurts_number_
	--设置材料消耗显示
	local sum_props = self:get_sum_props_all(index, event_data)
	self:set_props(sum_props)
	--设置总倒计时
	local timer = self:get_sum_time(index, event_data)
	self.timer_txt_.text = UIUtil.format_time(timer)
	--设置金币
	self.gold_txt_.text = SoldierManager:get_glod_hurts_recover(timer)
	--设置人数显示
	local sum = 0
	for k, v in pairs(self.slider_cnt_) do
		sum = sum + v
	end
	self.title_cnt_.text = "受伤部队:"..sum.."/"..self.build_info_:get_hospital_max_cnt()
end

function on_add_btn_click(self, event_data, slider, max_hurts)
	if slider.value >= max_hurts then return end
	slider.value = slider.value + 1 
end

function on_sub_btn_click(self, event_data, slider)
	if slider.value <= 0 then return end
	slider.value = slider.value - 1 
end

function on_max_btn_click(self, event_data, slider, max_hurts)
	if slider.value == max_hurts then return end
	slider.value = max_hurts
end

function on_kick_btn_click(self, event_data, slider, max_hurts, index)
	self.bg_.gameObject:SetActive(true)
	local soldier = self.hurts_all_[index]
	local str = lang("UI_SURE_KICK", soldier.lv_, soldier.name_)
	self.des_.text = str
	self:set_slider_value(slider, max_hurts, index)
end

--全部取消按钮
function on_cancel_btn_click(self, event_data)
	self.is_cancel_all_ = not self.is_cancel_all_
	if #self.slider_cnt_ <= 0 then return end
	if self.is_cancel_all_ then
		for k, v in pairs(self.hurts_all_) do
			local obj_name = string.format("obj[%d]/Slider", k)
			local slider = self.content_.transform:Find(obj_name)
			if slider then
				slider:GetComponent(Slider).value = 0
			end
			self.slider_cnt_[k] = 0 --slider 选中数量缓存
		end
		self.cancel_txt_.text = lang("UI_CANCEL_SELECT")
	else
		for k, v in pairs(self.hurts_all_) do
			local obj_name = string.format("obj[%d]/Slider", k)
			local slider = self.content_.transform:Find(obj_name)
			if slider and v then
				slider:GetComponent(Slider).value = v.hurts_number_
			end
			self.slider_cnt_[k] = v.hurts_number_
		end
		self.cancel_txt_.text = lang("UI_CANCEL_ALL")
	end
end

--立即治疗按钮
function on_instant_heal_btn_click(self, event_data)
	local id_tb, cnt_tb = self:get_select_hurts()
	if not id_tb or not cnt_tb then return end
	if #cnt_tb <= 0 then return end

	local content = lang("UI_SURE_CURE_HINT")
	local req_msg = {}
	req_msg.list = {
		["arr1"] = id_tb,
		["arr2"] = cnt_tb
	}
	self:show_hint_pop(content, function()
		Net.send("soldier_cure_finish", req_msg, function(result)
			if result.e == 7 then
				MsgCenter.send_message(Msg.SHOW_HINT, lang("ITEM_NOT_ENOUGH"))
			end
			if result.e == 0 then
				MsgCenter.send_message(Msg.CITY_SOLDIER_CURE_FINISHED)
				MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_SOLDIER_CURE_FINISHED"))
				self:close()
			end
		end)
	end)

	
end

function on_info_click(self, event_data)
	 MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_MAIN_UNOPEN"))
end

function show_hint_pop(self, content, func)
	local msg_ = {}
	msg_.title = ""
	msg_.content = content
	msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
	msg_.callback = function(index)
		if index == 2 then
			if func then func() end
		end
	end
	MsgCenter.send_message(Msg.SHOW_NOTIFY, msg_)
end

--治疗按钮
function on_restore_btn_click(self, event_data)
	local req_msg = {}
	local id_tb, cnt_tb = self:get_select_hurts()
	if not id_tb or not cnt_tb then return end
	if #cnt_tb <= 0 then return end
	req_msg.list = {
		["arr1"] = id_tb,
		["arr2"] = cnt_tb
	}
	local select_cnt = 0
	for k, v in pairs(cnt_tb) do
		select_cnt = select_cnt + v
	end
	log("msg: soldier_cure. req_msg = "..dumpTab(req_msg))
	Net.send("soldier_cure", req_msg, function(result)
		if result.e == 0 then
			MsgCenter.send_message(Msg.CITY_SOLDIER_CURE_UPDATE, self.build_info_.build_type_)
			self:close()
		end
	end)
end

function get_select_hurts(self)
	local soldier_id = {}
	local select_cnt = {}

	-- for k, v in pairs(self.slider_tb_) do
	-- 	if v.value and v.value > 0 then
	-- 		local id = self.hurts_all_[k].id_
	-- 		table.insert(soldier_id, id)
	-- 		table.insert(select_cnt, v.value)
	-- 	end
	-- end

	for k, v in pairs(self.slider_cnt_) do
		if v and v > 0 then
			local id = self.hurts_all_[k].id_
			table.insert(soldier_id, id)
			table.insert(select_cnt, v)
		end
	end
	return soldier_id, select_cnt
end

function get_sum_props_all(self, index, count)
	local key = self.hurts_all_[index].id_
	local props = self.hurts_all_[index].hurts_spend_
	self.props_value_ = self.props_value_ or {}
	self.props_value_[key] = {}
	for k, v in pairs(props) do
		local obj = {v[1], v[2], v[3] * count}
		table.insert(self.props_value_[key], obj)
	end
	--重新计算道具总量
	local sum_props = {}
	for k, v in pairs(self.props_value_) do
		for i = 1, config.Prop_Max do
			if v[i] then
				local item_type = v[i][1]
				if not sum_props[item_type] then
					sum_props[item_type] = {v[i][1], v[i][2], 0}
				end
				sum_props[item_type][3] = sum_props[item_type][3] + v[i][3]
			end
		end
	end
	return sum_props
end

function get_sum_time(self, index, count)
	local key = self.hurts_all_[index].id_
	local time = self.hurts_all_[index].hurts_uplong_

	self.timer_tb_ = self.timer_tb_ or {}
	self.timer_tb_[key] = SoldierManager:get_hurts_uplog(time, count)

	local sum_timer = 0
	for k, v in pairs(self.timer_tb_) do
		sum_timer = sum_timer + v
	end
	return math.ceil(sum_timer)
end

function set_props(self, spend_data)
	if not spend_data then
		spend_data = {
			[1] = {1, 0, 0},
			[2] = {2, 0, 0},
			[3] = {3, 0, 0},
			[4] = {4, 0, 0},
		}
	end

	local arg = 0
	for i = 1, config.Prop_Max do
		local obj = self.props_rect_.transform:Find("prop"..i)
		local icon = obj.transform:Find("icon"):GetComponent(Image)
		if spend_data[i] then
			local txt = obj.transform:Find("Text"):GetComponent(Text)
			local yes = obj.transform:Find("HintIcon/Yes")
			local no = obj.transform:Find("HintIcon/No")

			local str = spend_data[i][3] --需要的资源

			if str > 0 then
				arg = arg + 1
			end
			local had_money = ItemManager:get_resource(spend_data[i][1])
			if not had_money then had_money = 0 end
			local format_had_money = UIUtil.res_num_to_str(had_money)

			local res_is_full = had_money >= str

			obj.gameObject:SetActive(str > 0)

			yes.gameObject:SetActive(res_is_full)
			no.gameObject:SetActive(not res_is_full or str == 0)
			if str == 0 then
				yes.gameObject:SetActive(false)
				no.gameObject:SetActive(false)
			end
			--资源不够的时候
			if not res_is_full then
				str = UIUtil.res_num_to_str(str) --格式化数值
				str = lang("UI_SOLDIER_PROPS_COUNT", str)
				txt.text = lang("UI_BASIC_COLOR", config.FONT_COLOR.RED, format_had_money.."/"..str)
			else
				str = UIUtil.res_num_to_str(str)

				txt.text = lang("UI_BASIC_COLOR", config.FONT_COLOR.GREY, format_had_money.."/"..str)
			end
		else
			--obj.gameObject:SetActive(false)
		end

		if not self:is_alive() then return end
		UIUtil.set_sprite("UI/Common/ItemSmall/"..i, icon)
	end

	self.res_hint_.gameObject:SetActive(arg == 0)
	self.props_rect_.gameObject:SetActive(arg > 0)
end

--------------------------------------pop------------------------------------------------

function set_slider_value(self, slider, max_count, index)
	self.max_value_ = max_count
	self.slider_.maxValue = max_count	
	self.slider_.minValue = 0
	self.slider_.value = max_count
	self:on_kick_value_changed(max_count)
	self.soldier_ = self.hurts_all_[index]
end

function on_kick_value_changed(self, event_data)
	if event_data > self.max_value_ then return end
	local is_enable =  event_data > 0
	self.kick_btn_.interactable = is_enable
	GameUtil.SetImageGrey(self.kick_btn_:GetComponent(Image), not is_enable)
	self.count_txt_.text = event_data.."/"..self.max_value_
end

function on_add_click(self, event_data)
	if self.slider_.value >= self.max_value_ then return end
	self.slider_.value = self.slider_.value + 1
end

function on_sub_click(self, event_data)
	if self.slider_.value <= 0 then return end
	self.slider_.value = self.slider_.value - 1
end

function on_max_click(self, event_data)
	if self.slider_.value == self.max_value_ then return end
	self.slider_.value = self.max_value_
end

function on_kick_click(self, event_data)
	local msg_ = {}
	msg_.title = ""
	msg_.content = lang("UI_SURE_KICK_HINT")
	msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
	msg_.callback = function(index)
		if index == 2 then
			self:net_send(req_msg)
		end
    end
    MsgCenter.send_message(Msg.SHOW_NOTIFY, msg_)
end

function net_send(self, req_msg)

end