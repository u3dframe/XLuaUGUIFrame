-- 登录界面
module("TestWindow2",package.seeall)
setmetatable( TestWindow2, {__index = BaseWindow} )

--1.准备UI（UI美术资源加载）
function on_resource(self)

end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self) 
    self.btn_login_ = self.transform:Find("LoginBtn"):GetComponent(Button)
	self:add_event_handler(self.btn_login_.onClick, function()
        self:close()
    end)
    self.btn_pop_ = self.transform:Find("PopupWindows"):GetComponent(Button)
	self:add_event_handler(self.btn_pop_.onClick, function()
        UIManager.open_window("TestWindow3")
    end)
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
	
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
     
end
