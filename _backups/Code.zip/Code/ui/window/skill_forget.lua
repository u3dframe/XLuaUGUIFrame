module("SkillForget", package.seeall)
setmetatable(SkillForget, {__index = BaseWindow})



local ItemConfig = _G.Database.ItemConfig
local BasicConfig = _G.Database.BasicConfig
local HeroConfig = _G.Database.HeroConfig


function on_init(self)
    self.skillWin = self.data[1]
    self.hero = self.skillWin.hero
    self.pos = self.skillWin.pos
    self.serverSkill = self.hero:get_skill_by_pos(self.pos)
    self.skillCfg = HeroConfig.SkillData[self.serverSkill.skillid]

    local closeBtn = self.transform:Find("Top/CloseBtn"):GetComponent(Button)
    self:add_event_handler(closeBtn.onClick, function() self:close() end)

    local cancelBtn = self.transform:Find("CancelBtn"):GetComponent(Button)
    self:add_event_handler(cancelBtn.onClick, function() self:close() end)

    local confirmBtn = self.transform:Find("ConfirmBtn"):GetComponent(Button)
    self:add_event_handler(confirmBtn.onClick, function()
        SkillManager:forget_skill(self.hero.id_, self.pos, self.serverSkill.skillid)
        self:close()
        self.skillWin:close()
    end)

    local forgetTxt = self.transform:Find("skilltxt"):GetComponent(Text)
    forgetTxt.text = lang("SKILL_RECYCLE", self.serverSkill.level, self.skillCfg.name)

    local itemObj = self.transform:Find("itemcard").gameObject
    itemObj:SetActive(false)
    local content = self.transform:Find("Content")

    local totalExp = self.serverSkill.exp
    for lv = 1, self.serverSkill.level - 1 do
        totalExp = totalExp + SkillManager:get_skill_level_exp(self.serverSkill.skillid, lv)
    end
    local rest = totalExp * BasicConfig.BasicData.hero_skill_forget
    local expItemCfgs = {}
    for _, cfg in pairs(BasicConfig.BasicData.hero_skill_items) do
        table.insert(expItemCfgs, cfg)
    end
    table.sort(expItemCfgs, function(a, b) return a[2] > b[2] end)
    local items = {}
    for _, cfg in ipairs(expItemCfgs) do
        local exp = cfg[2]
        local cnt = math.floor(rest / exp)
        if cnt > 0 then
            rest = rest % exp
            table.insert(items, {cfg[1], cnt})
        end
    end
    for _, info in ipairs(items) do
        local cfg = ItemConfig.ItemData[info[1]]
        if cfg then
            local obj = GameObject.Instantiate(itemObj)
            obj:SetActive(true)
            obj.transform:SetParent(content, false)
            UIUtil.set_sprite("UI/Common/Quality/item_"..cfg.quality, obj:GetComponent(Image))
            local icon = obj.transform:Find("itemicon"):GetComponent(Image)
            UIUtil.set_sprite(cfg.icon, icon)
            obj.transform:Find("nametxt"):GetComponent(Text).text = cfg.name
            obj.transform:Find("numtxt"):GetComponent(Text).text = info[2]
        end
    end
    local noItem = self.transform:Find("skilltxt2")
    local hasItem = self.transform:Find("ItemTitle")
    noItem.gameObject:SetActive(#items == 0)
    hasItem.gameObject:SetActive(#items > 0)
end

function on_open(self)
    
end
