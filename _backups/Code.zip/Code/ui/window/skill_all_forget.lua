module("SkillAllForget", package.seeall)
setmetatable(SkillAllForget, {__index = BaseWindow})



function on_init(self)
    self.type = self.data[1]

    local rare = self.transform:Find("rare")
    local skills = SkillManager:get_skill_list_by_type(self.type)
    local hasRare = false
    for _, skill in ipairs(skills) do
        if skill:is_rare() then
            hasRare = true
            break
        end
    end
    rare.gameObject:SetActive(hasRare)
    local rareToggle = rare:Find("yuandian"):GetComponent(Toggle)

    local cancelBtn = self.transform:Find("CancelBtn"):GetComponent(Button)
    self:add_event_handler(cancelBtn.onClick, function() self:close() end)

    local confirmBtn = self.transform:Find("ConfirmBtn"):GetComponent(Button)
    self:add_event_handler(confirmBtn.onClick, function()
        SkillManager:onekey_resolve_skill(self.type, hasRare and rareToggle.isOn or false)
        self:close()
    end)
end

function on_open(self)
    
end
