module("SoldierKickWindow", package.seeall)
setmetatable(SoldierKickWindow, {__index = BaseWindow})

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self)
	local soldier_id = self.data[1]
	self.soldier_info_ = SoldierManager:get_soldier_info_by_id(soldier_id)

	self.close_btn_ = self.transform:Find("WindowObj/Top/CloseBtn"):GetComponent(Button)
	self.des_ = self.transform:Find("WindowObj/Center/Detatils"):GetComponent(Text)
	self.count_txt_ = self.transform:Find("WindowObj/Center/Image/Text"):GetComponent(Text)
	self.slider_ = self.transform:Find("WindowObj/Center/Slider"):GetComponent(Slider)
	self.add_btn_ = self.slider_.transform:Find("AddBtn"):GetComponent(Button)
	self.sub_btn_ = self.slider_.transform:Find("SubBtn"):GetComponent(Button)
	self.max_btn_ = self.slider_.transform:Find("MaxBtn"):GetComponent(Button)
	self.kick_btn_ = self.transform:Find("WindowObj/Center/Button"):GetComponent(Button)

	self:add_event_handler(self.close_btn_.onClick, on_close_click)
	self:add_event_handler(self.add_btn_.onClick, on_add_click)
	self:add_event_handler(self.sub_btn_.onClick, on_sub_click)
	self:add_event_handler(self.max_btn_.onClick, on_max_click)
	self:add_event_handler(self.kick_btn_.onClick, on_kick_click)
	self:add_event_handler(self.slider_.onValueChanged, on_value_changed)

	self:set_slider_value()
	self.des_.text = "主公，是否解雇这些士兵，解雇士兵会导致战斗力下降"
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
	
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
     
end

function set_slider_value(self)
	local max_value = self.soldier_info_:get_drill_max_count()
	self.max_value_ = self.soldier_info_.number_ < max_value and self.soldier_info_.number_ or max_value
	self.slider_.maxValue = self.max_value_
	--默认显示是0
	self:on_value_changed(0)
end

function on_value_changed(self, event_data)
	if event_data > self.max_value_ then return end
	local is_enable =  event_data > 0
	self.kick_btn_.interactable = is_enable
	GameUtil.SetImageGrey(self.kick_btn_:GetComponent(Image), not is_enable)
	self.count_txt_.text = event_data.."/"..self.max_value_
end

function on_add_click(self, event_data)
	if self.slider_.value >= self.max_value_ then return end
	self.slider_.value = self.slider_.value + 1
end

function on_sub_click(self, event_data)
	if self.slider_.value <= 0 then return end
	self.slider_.value = self.slider_.value - 1
end

function on_max_click(self, event_data)
	if self.slider_.value == self.max_value_ then return end
	self.slider_.value = self.max_value_
end

function on_kick_click(self, event_data)
	local msg_ = {}
	msg_.title = ""
	msg_.content = "主公，是否解雇这些士兵，解雇士兵会导致战斗力下降"
	msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
	msg_.callback = function(index)
		if index == 2 then
			self:net_send(req_msg)
		end
    end
    MsgCenter.send_message(Msg.SHOW_NOTIFY, msg_)
end

function net_send(self, req_msg)

end

function on_close_click(self, event_data)
	self:close()
end