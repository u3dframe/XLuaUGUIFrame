-- 行军收兵界面
module("WorldJourneyInfoWindow",package.seeall)
setmetatable( WorldJourneyInfoWindow, {__index = BaseWindow} )


--1.准备UI（UI美术资源加载）
function on_resource(self)
    local list = {
        "hero/HeroCard"
    }

    Yield(UIUtil.load_component(list, function(prefabs) 
        self.hero_card_prefab_ = prefabs[1]
    end))
end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self) 
    self.btn_close_ = self.transform:Find("WindowObj/Close"):GetComponent(Button)
	self:add_event_handler(self.btn_close_.onClick, function()
        self:close()
    end)

    self.item_panel_ = self.transform:Find("WindowObj/DataPanel/ScrollView/Content")
    self.item_prefab_ = self.transform:Find("WindowObj/DataPanel/ScrollView/Content/Item").gameObject
    self.item_prefab_:SetActive(false)
    self.item_go_ = {}
    
    self.match_name_ = self.transform:Find("WindowObj/InfoPanel/NameTxt"):GetComponent(Text)
    self.alive_num_ = self.transform:Find("WindowObj/InfoPanel/AliveTxt"):GetComponent(Text)
    
    -- hero panel
    self.hero_parent_ = {}
    self.hero_go_ = {}
    for i=1,2 do
        local str = string.format("WindowObj/HeroesPanel/HeroesGroup/HeroContent/Hero%d/HeroCard", i)
        self.hero_parent_[i] = self.transform:Find(str)
    end
    self.messager_:add_listener(Msg.WORLD_MARCH_DELETE, on_march_delete) 
end

--3.打开UI（打开/刷新UI处理）
function on_open(self) 
    self.march_ = WorldManager:get_march_by_idx(self.data[1])
    if not self.march_ then return end
    self.match_name_.text = self.march_.name_
    
    self:init_hero_panel()
    self:init_soldiers_panel()
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
    if self.item_go_ then
        for k,v in pairs(self.item_go_) do
            if v then
                Object.Destroy(v)
            end
        end  
    end
    self.item_go_ = nil
end


function on_march_delete(self, id)
    if self.march_.idx_ ~= id then return end
    self:close()
end

function init_hero_panel(self)
    local hero_list = self.march_.heroes_
    table.sort(hero_list, function(x, y)
		return x.pos_ < y.pos_
	end)
    for i=1,2 do
        local bg = self.hero_parent_[i]:Find("../Background"):GetComponent(Image)
        local bg_btn = self.hero_parent_[i]:Find("../Background"):GetComponent(Button)

        if hero_list[i] then
            local v = hero_list[i]
            bg.color = Color(1, 1, 1, 0)
            if not self.hero_go_[i] then
                local card = GameObject.Instantiate(self.hero_card_prefab_)
                card.transform:SetParent(self.hero_parent_[i], false)
                card:SetActive(true)
                self.hero_go_[i] = HeroCard:new(self)
                self.hero_go_[i]:AddLuaComponent(card)
                self.hero_go_[i]:init()
            end
            self.hero_go_[i].gameObject:SetActive(true)
            self.hero_go_[i]:set_data_troops(v, v.pos_)
            
        else
            if self.hero_go_[i] then
                self.hero_go_[i].gameObject:SetActive(false)
            end

            bg.color = Color(1, 1, 1, 1)
        end
    end
end

function init_soldiers_panel(self)
    local num = 0
    for i,v in ipairs(self.march_.soldiers_) do
        if not self.item_go_[i] then
            local go = GameObject.Instantiate(self.item_prefab_)
            go.transform:SetParent(self.item_panel_, false)
            self.item_go_[i] = go
        end
        self.item_go_[i].gameObject:SetActive(true)
        self.item_go_[i].gameObject.name = "item"..i
        local name = self.item_go_[i].transform:Find("SoldierType"):GetComponent(Text)
        local count = self.item_go_[i].transform:Find("AliveNun"):GetComponent(Text)
        local prop = SoldierManager:get_soldier_prop_by_id(v.id)
        name.text = lang("RESPOINT_3", prop.lv, prop.name)
        count.text = v.cnt
        num = num + v.cnt
    end
    self.alive_num_.text = lang("EXPEDITION_35", num)
end