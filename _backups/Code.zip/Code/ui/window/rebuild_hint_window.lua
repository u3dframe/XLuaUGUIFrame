local RebuildHintWindow = {}
setmetatable(RebuildHintWindow, {__index = _G.BaseWindow})

local UI = _G.UI

function RebuildHintWindow:on_init()
    self.content = self.transform:Find("WindowObj/Panel/Content"):GetComponent(UI.Text)
    self.btn = self.transform:Find("WindowObj/ButtonYellow"):GetComponent(UI.Button)

    self.content.text = "您的城墙已被其他君主摧毁或遭到强制迁城。系统自动随机帮你选择了移除地点重建城池。（这样做不会降低您的城池规模）"
    self:add_event_handler(self.btn.onClick, self.OnCityOver)

    --取消背景点击事件
    self.bgBtn = self.transform:Find("Background"):GetComponent(UI.Button)
    self.bgBtn.onClick:RemoveAllListeners()
end

function RebuildHintWindow:OnCityOver()
 
    elog("--------------------------------> wall_city_rebuild")
    Net.send("wall_city_rebuild", {}, function(result)
        if result.e == 0 then
            elog("wall_city_move is succeed!")
            --do something
            self:close()
            MsgCenter.send_message(Msg.CITY_REBUILD)
        end
    end)
end

return RebuildHintWindow