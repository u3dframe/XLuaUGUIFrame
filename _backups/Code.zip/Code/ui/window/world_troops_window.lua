-- 出征选兵界面
module("WorldTroopsWindow",package.seeall)
setmetatable( WorldTroopsWindow, {__index = BaseWindow} )


ORDER_STR = {lang("EXPEDITION_25"), lang("EXPEDITION_26"),
    lang("EXPEDITION_27"), lang("EXPEDITION_28")}

--1.准备UI（UI美术资源加载）
local BasicConfig = _G.Database.BasicConfig


function on_resource(self)
    local list = {
        "hero/HeroCard"
    }

    Yield(UIUtil.load_component(list, function(prefabs) 
        self.hero_card_prefab_ = prefabs[1]
    end))
end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self)
    
    
    -- ButtonPanel
    self.attack_btn_ = self.transform:Find("Panel/ButtonPanel/BattleBtn"):GetComponent(Button)
    self.attack_img_ = self.transform:Find("Panel/ButtonPanel/BattleBtn"):GetComponent(Image)
    self.attack_time_ = self.transform:Find("Panel/ButtonPanel/BattleBtn/Timer"):GetComponent(Text)
    self:add_event_handler(self.attack_btn_.onClick, on_click_attack_handler)
    self.cancel_btn_ = self.transform:Find("Panel/ButtonPanel/CancelBtn"):GetComponent(Button)
    self.cancel_txt_ = self.transform:Find("Panel/ButtonPanel/CancelBtn/Text"):GetComponent(Text)
    self:add_event_handler(self.cancel_btn_.onClick, on_click_cancel_select)
    self.cancel_count_ = 0
    self.cancel_txt_.text = lang("UI_TROOPS_ALL_CANCEL")
    self.order_btn_ = self.transform:Find("Panel/ButtonPanel/OrderBtn"):GetComponent(Button)
    self.order_txt_ = self.transform:Find("Panel/ButtonPanel/OrderBtn/Text"):GetComponent(Text)
    self:add_event_handler(self.order_btn_.onClick, on_click_order_handler)
    self.arrow_ = {}
    self.arrow_[1] = self.transform:Find("Panel/ButtonPanel/OrderBtn/Down").gameObject
    self.arrow_[2] = self.transform:Find("Panel/ButtonPanel/OrderBtn/Up").gameObject    
    -- HeroesPanel
    self.hero_parent_ = {}
    self.hero_go_ = {}
    for i=1,4 do
        local str = string.format("HeroesPanel/HeroesGroup/HeroContent/Hero%d/HeroCard", i)
        self.hero_parent_[i] = self.transform:Find(str)
    end
    
    -- Panel
    self.soldier_panel_ = self.transform:Find("Panel/ScrollRect/SoldlierPanel")
    self.soldier_prefab_ = self.transform:Find("Panel/ScrollRect/SoldlierPanel/Item").gameObject
    self.soldier_prefab_:SetActive(false)
    self.soldier_go_ = {}
    self.empty_go_ = self.transform:Find("Panel/ScrollRect/EmptyTxt").gameObject
    
    self.desc_txt_ = self.transform:Find("Panel/LeftContent/Text"):GetComponent(Text)
    self.power_txt_ = self.transform:Find("PowerPanel/Content/Value"):GetComponent(Text)
    self.result_guess_ = self.transform:Find("Panel/ResultPanel/Text"):GetComponent(Text)
    self.special_desc_ = self.transform:Find("Panel/RightContent/DescTxt"):GetComponent(Text)
    self.special_value_ = self.transform:Find("Panel/RightContent/Text"):GetComponent(Text)
    self.special_btn_ = self.transform:Find("Panel/RightContent/DownBtn"):GetComponent(Button)
    self:add_event_handler(self.special_btn_.onClick, on_click_special_handler)
    -- TargetPanel
    self.target_desc_ = self.transform:Find("TargetPanel")
    self.target_txt_ = self.transform:Find("TargetPanel/Value"):GetComponent(Text)
    
    -- MaskPanel
    self.mask_panel_ = self.transform:Find("MaskPanel")
    self.mask_btn_ = self.transform:Find("MaskPanel/Background"):GetComponent(Button)
    self:add_event_handler(self.mask_btn_.onClick, function()
        self:on_click_order_handler(true)
    end)
    self.order_go_ = {}
    for i=1,4 do
        self.order_go_[i] = self.transform:Find("MaskPanel/OrderPanel/ToggleGroup/Toggle"..i):GetComponent(Toggle)
        self:add_event_handler(self.order_go_[i].onValueChanged, on_toggle_changed, i)
    end
    
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
	self.obj_data_ = self.data[1]
    self.target_txt_.text = self.obj_data_:get_troop_type_name()
    self.show_mask_ = false
    local tmp_index = self.order_index_ or self.obj_data_:get_troops_order()
    if self.order_go_[tmp_index].isOn then
        self.order_go_[tmp_index].isOn = false
    end
    self.order_go_[tmp_index].isOn = true
    self:init_hero_panel()
    self:init_soldier_panel()
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
    if self.soldier_go_ then
        for k,v in pairs(self.soldier_go_) do
            if v then
                Object.Destroy(v)
            end
        end  
    end
    self.soldier_go_ = nil
end

function on_dispose(self)
end

function on_after_top(self)
    self.target_desc_:SetSiblingIndex(self.transform.childCount)
    self.mask_panel_:SetSiblingIndex(self.transform.childCount)
end


function get_logic_distance(self)
    local logic_form_x, logic_from_z = WorldManager:get_my_build_logic_axis()
    local logic_to_x = self.obj_data_.x_
    local logic_to_z = self.obj_data_.z_
    local delta_x = logic_to_x - logic_form_x
    local delta_z = logic_to_z - logic_from_z
    local distance = math.sqrt(delta_x*delta_x + delta_z*delta_z)
    return distance
end


function on_click_attack_handler(self)
    local num = 0
    for k,v in pairs(self.cur_num_) do
        num = num + v
    end
    if num == 0 then
        MsgCenter.send_message(Msg.SHOW_HINT, lang("EXPEDITION_30"))
        return
    end
    if not WorldManager:enable_battle() then
        MsgCenter.send_message(Msg.SHOW_HINT, lang("EXPEDITION_31"))
        return
    end
    local troops_list = {}
    troops_list.soldiers = {}
    troops_list.soldiers.arr1 = {}
    troops_list.soldiers.arr2 = {}
    troops_list.heroes = {0, 0}
    troops_list.target = self.obj_data_.idx_
    for k,v in pairs(self.heroes_) do
        troops_list.heroes[k] = v.id_
    end
    for k,v in pairs(self.cur_num_) do
        if v ~= 0 then
            table.insert(troops_list.soldiers.arr1, k)
            table.insert(troops_list.soldiers.arr2, v)
        end
    end
    local net_str = self.obj_data_:get_battle_msg()
    if not net_str then
        elog("the troops error occurred")
        return
    end
    if self.obj_data_.obj_type_ == config.WORLD_MONSTER then
        if self.obj_data_.lv_ > (WorldManager.monster_battle_lv_ + 1) then
            local str = lang("RESPOINT_25", (WorldManager.monster_battle_lv_ + 1))
            MsgCenter.send_message(Msg.SHOW_HINT, str)
            return
        end
    end
    Net.send(net_str, troops_list, function(result)
        if result.e == 0 then
            for k,v in pairs(self.heroes_) do
                v.state_ = Hero.ST_OUT
            end
            UIManager.back()
        end
    end)
end

function init_soldiers_panel(self)
    for k,v in pairs(self.soldier_go_) do
        if v then
            v:SetActive(false)
        end
    end    
    self.cur_num_max_ = {}      -- 当前兵种已有数量
    self.cur_limit_max_ = {}    -- 当前兵种限制最大数量（卡出征上限）
    self.cur_num_ = {}          -- 当前兵种数量
    local cur_num = config.BATTLE_NUM_MAX
    for i,v in ipairs(self.soldiers_) do     
        if v.number_ ~= 0 then
            self.cur_num_max_[v.id_] = v.number_
            self.cur_limit_max_[v.id_] = cur_num < v.number_ and cur_num or v.number_
            cur_num = cur_num - v.number_ < 0 and 0 or cur_num - v.number_
            if not self.soldier_go_[v.id_] then
                self.soldier_go_[v.id_] = GameObject.Instantiate(self.soldier_prefab_)
                self.soldier_go_[v.id_].transform:SetParent(self.soldier_panel_.transform, false)
                self.soldier_go_[v.id_].name = "soldier"..i
            end
            self.soldier_go_[v.id_]:SetActive(true)
            self.soldier_go_[v.id_].transform:SetSiblingIndex(i)
            local slider = self.soldier_go_[v.id_].transform:Find("Slider"):GetComponent(Slider)
            local value = self.soldier_go_[v.id_].transform:Find("ValuePanel/InputField"):GetComponent(InputField)
            self:add_event_handler(value.onEndEdit, on_input_field_value, v.id_) 
            local add_btn = self.soldier_go_[v.id_].transform:Find("MaxBtn"):GetComponent(Button)
            local sub_btn = self.soldier_go_[v.id_].transform:Find("MinBtn"):GetComponent(Button)
            local lv_txt = self.soldier_go_[v.id_].transform:Find("Head/LvGroup/Text"):GetComponent(Text)
            add_btn.onClick:RemoveAllListeners()
            self:add_event_handler(add_btn.onClick, on_soldier_value_btn, v.id_, 1)
            sub_btn.onClick:RemoveAllListeners()
            self:add_event_handler(sub_btn.onClick, on_soldier_value_btn, v.id_, -1)
            local icon = self.soldier_go_[v.id_].transform:Find("Head/Mask/Icon"):GetComponent(Image)
            slider.onValueChanged:RemoveAllListeners()
            self:add_event_handler(slider.onValueChanged, on_soldier_value_change, v.id_)    
            local tmp_value = 1
            local tmp_num = math.floor(self.cur_num_max_[v.id_] * tmp_value) 
            if tmp_num > self.cur_limit_max_[v.id_] then
                tmp_num = self.cur_limit_max_[v.id_]
                tmp_value = tmp_num/self.cur_num_max_[v.id_]
            end
            slider.value = tmp_value  
            value.text = tmp_num
            self.cur_num_[v.id_] = tmp_num
            lv_txt.text = lang("SOLDIER_LEVEL_"..v.lv_)..v.name_
            UIUtil.set_sprite("UI/Common/Soldier/soldier_icon_01", icon)
        end
    end

    if next(self.cur_num_max_) then
        self.empty_go_:SetActive(false)
    else
        self.empty_go_:SetActive(true) 
    end
end

function on_input_field_value(self, event, id)
    local result_num  = tonumber(event)
    local input_value = self.soldier_go_[id].transform:Find("ValuePanel/InputField"):GetComponent(InputField)
    local slider = self.soldier_go_[id].transform:Find("Slider"):GetComponent(Slider)
    if result_num < 0 then
        input_value.text = 0
        slider.value = 0
        return
    end    
    local cur_num = self:get_other_soldiers_num(id)    
    if result_num > self.cur_num_max_[id] then
        result_num = self.cur_num_max_[id]
    end    
    if cur_num + result_num > config.BATTLE_NUM_MAX then
        result_num = config.BATTLE_NUM_MAX - cur_num
    end    
    
    input_value.text = result_num    
    slider.value = result_num/self.cur_num_max_[id]    
    self.cur_num_[id] = result_num
    self:init_btn_state()
    self:speed_value()
    self:set_troops_desc()
end

function on_soldier_value_change(self, event, id)
    local input_value = self.soldier_go_[id].transform:Find("ValuePanel/InputField"):GetComponent(InputField)
    local slider = self.soldier_go_[id].transform:Find("Slider"):GetComponent(Slider)
    local result_num = math.ceil(self.cur_num_max_[id]*event)
    local cur_num = self:get_other_soldiers_num(id)
    
    -- 对比 其它之和和当前兵种是否超额
    if cur_num + result_num > config.BATTLE_NUM_MAX then
        result_num = config.BATTLE_NUM_MAX - cur_num
        slider.value = result_num/self.cur_num_max_[id]
    end
    input_value.text = result_num    
    self.cur_num_[id] = result_num
    self:init_btn_state()
    self:speed_value()
    self:set_troops_desc()
end

function on_soldier_value_btn(self, event, id, delta)
    local input_value = self.soldier_go_[id].transform:Find("ValuePanel/InputField"):GetComponent(InputField)
    local slider = self.soldier_go_[id].transform:Find("Slider"):GetComponent(Slider)
    local result_num = tonumber(input_value.text)
    if result_num == 0 and delta < 0 then
        MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_TROOPS_IS_MIN"))
        return
    end
    if result_num == self.cur_num_max_[id] and delta > 0 then
        MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_TROOPS_IS_MAX"))
        return
    end
    local cur_num = self:get_other_soldiers_num(id)
    if delta > 0 and cur_num + result_num + 1 > config.BATTLE_NUM_MAX then
        MsgCenter.send_message(Msg.SHOW_HINT, lang("EXPEDITION_29"))
        return
    end
    result_num = result_num + delta
    local tmp_value = result_num / (self.cur_num_max_[id] or 1)
    if tmp_value < 0.01 then
        tmp_value = 0.01
    end
    slider.value = tmp_value
    input_value.text = result_num    
    self.cur_num_[id] = result_num
    self:init_btn_state()
    self:speed_value()
    self:set_troops_desc()
end

function get_other_soldiers_num(self, id)
    local cur_num = 0
    for k,v in pairs(self.cur_num_) do
        if id ~= k then
            cur_num = cur_num + v
        end
    end
    return cur_num
end


function set_troops_desc(self)
    local num = 0
    local all_power = 0
    local all_weight = 0
    local density = self.obj_data_:get_prop().para or 0
    for i,v in ipairs(self.soldiers_ or {}) do
        local soldier_num = 0
        if self.soldier_go_[v.id_] then
            local value = self.soldier_go_[v.id_].transform:Find("ValuePanel/InputField"):GetComponent(InputField)
            soldier_num = tonumber(value.text)
            local tmp_weight = v:get_attribute_by_type(config.SOLDIER_ATTRIBUTES.WEIGHT)
            all_weight = all_weight + soldier_num * tmp_weight * density
        end
        if soldier_num ~= 0 then
            num = num + soldier_num
            all_power = all_power + soldier_num * v.fighting_power_
        end
    end
    
    all_power = math.floor(all_power)
    self.desc_txt_.text = string.format("%d/%d", num, config.BATTLE_NUM_MAX)
    self.power_txt_.text = all_power
    self.obj_data_:get_prop_power(function(prop_power)
        if all_power <= prop_power*BasicConfig.BasicData.force_combat[1] then
            self.result_guess_.text = lang("EXPEDITION_20")
        elseif all_power <= prop_power*BasicConfig.BasicData.force_combat[2] then
            self.result_guess_.text = lang("EXPEDITION_19")
        elseif all_power <= prop_power*BasicConfig.BasicData.force_combat[3] then
            self.result_guess_.text = lang("EXPEDITION_21")
        elseif all_power <= prop_power*BasicConfig.BasicData.force_combat[4] then
            self.result_guess_.text = lang("EXPEDITION_22")
        else
            self.result_guess_.text = lang("EXPEDITION_48")
        end 
    end)

    if self.obj_data_.obj_type_ == config.WORLD_RESPOINT then
        self.special_desc_.text = lang("UI_TROOPS_WEIGHT_BEARING")
        self.special_value_.text = math.floor(all_weight)
        self.result_guess_.text = ""
    else
        self.special_desc_.text = lang("EXPEDITION_24")
        self.special_value_.text = self.obj_data_:get_energy_cost()
    end
end

function on_click_cancel_select(self, event)
    local result = 1
    self.cancel_txt_.text = lang("UI_TROOPS_ALL_CANCEL")
    
    if self.cancel_count_ % 2 == 0 then
        self.cancel_txt_.text = lang("UI_TROOPS_ALL_SELECT")
        result = 0
    end
    self.cancel_count_ = self.cancel_count_ + 1
    for i,v in ipairs(self.soldiers_) do
        local go = self.soldier_go_[v.id_]
        if go and go.activeSelf then
            local slider = go.transform:Find("Slider"):GetComponent(Slider)
            if result == 1 then
                slider.value = math.ceil(self.cur_limit_max_[v.id_]/self.cur_num_max_[v.id_])
            else
                slider.value = 0
            end
        end
    end
end

function init_btn_state(self)
    local num = 0
    for k,v in pairs(self.cur_num_) do
        num = num + v
    end
    if num == 0 then
        GameUtil.SetImageGrey(self.attack_img_, true) 
    else
        GameUtil.SetImageGrey(self.attack_img_, false) 
    end
end

function init_order_state(self)
    self.arrow_[1]:SetActive(not self.show_mask_)
    self.arrow_[2]:SetActive(self.show_mask_)
    self.mask_panel_.gameObject:SetActive(self.show_mask_)
    self.order_txt_.text = ORDER_STR[self.order_index_]
end

function on_click_order_handler(self, event)
    if self.break_mask_ then
        self.break_mask_ = nil
        return
    end
    self.show_mask_ = not self.show_mask_
    self:init_order_state(self.show_mask_)
    if not self.show_mask_ then
        self:init_soldier_panel()
    end
end

function on_toggle_changed(self, event, index)
    if event then
        if not self.order_index_ then
            self.order_index_ = index
            self.order_txt_.text = ORDER_STR[self.order_index_]
            return
        end        
        self.order_index_ = index
        self:on_click_order_handler()
    end
end

function init_hero_panel(self)
    if not self.heroes_ then
        self.heroes_ = HeroManager:get_heroes_troop()
    end
    local hero_list = {self.heroes_[1], self.heroes_[2]}
    for i=1,4 do
        local bg = self.hero_parent_[i]:Find("../Background"):GetComponent(Image)
        
        local bg_btn = self.hero_parent_[i]:Find("../Background"):GetComponent(Button)
        bg_btn.onClick:RemoveAllListeners()
        if i < 3 then
            local break_btn = self.hero_parent_[i]:Find("../Break"):GetComponent(Button)
            if hero_list[i] then
                break_btn.gameObject:SetActive(true)
            else
                break_btn.gameObject:SetActive(false)
            end
            break_btn.onClick:RemoveAllListeners()
            self:add_event_handler(break_btn.onClick, on_click_break_handler, i)
            self:add_event_handler(bg_btn.onClick, on_click_background_handler, i, hero_list[i])
            local v = hero_list[i]
            bg.color = Color(1, 1, 1, 1)
            if not self.hero_go_[i] then
                local card = GameObject.Instantiate(self.hero_card_prefab_)
                card.transform:SetParent(self.hero_parent_[i], false)
                card:SetActive(true)
                self.hero_go_[i] = HeroCard:new(self)
                self.hero_go_[i]:AddLuaComponent(card)
                self.hero_go_[i]:init()
            end
            self.hero_go_[i].gameObject:SetActive(true)
            self.hero_go_[i]:set_data_troops_ex(v, i)
        else
            
        end

    end
    self:set_troops_desc()
end

function init_soldier_panel(self)
    self:sort_soldiers_list()
    self:init_soldiers_panel()
    self:speed_value()
    self:set_troops_desc()
    self:init_btn_state()
end

function sort_soldiers_list(self)
    -- 1=等级 2=负重 3=速度 4=搭配
    if self.order_index_ == 1 then
        self.soldiers_ = SoldierManager:get_soldier_by_level_priority()
    elseif self.order_index_ == 2 then
        self.soldiers_ = SoldierManager:get_soldier_by_weight_priority()
    elseif self.order_index_ == 3 then
        self.soldiers_ = SoldierManager:get_soldier_by_speed_priority()
    elseif self.order_index_ == 4 then
        self.soldiers_ = SoldierManager:get_soldier_by_collocation_priority()
    else
        self.soldiers_ = SoldierManager:get_soldier()
    end
end

function speed_value(self)
    local soldier_speed
    for i,v in ipairs(self.soldiers_) do
        if self.cur_num_[v.id_] and self.cur_num_[v.id_] ~= 0 then
            if not soldier_speed then
                soldier_speed = v:get_speed()
            end
            if soldier_speed > v:get_speed() then
                soldier_speed = v:get_speed()
            end
        end
    end
    if not soldier_speed then
        soldier_speed = 0
    end
    local distance = self:get_logic_distance()    
    local attr_speed = self:get_speed_attr_value()
    local time = UIUtil.get_march_time_by_distance(distance, soldier_speed, attr_speed)
    
    local time_str = UIUtil.format_time(time)
    if time_str then
        self.attack_time_.gameObject:SetActive(true)
        self.attack_time_.text = time_str
    else
        self.attack_time_.gameObject:SetActive(false)
    end
end

-- 根据对象来获取对应的属性加成
function get_speed_attr_value(self)
    local speed_add = AttrsManager:get_attrs_value_by_name("speed_add")
    local attr_speed = speed_add
    if self.obj_data_.obj_type_ == config.WORLD_MONSTER then
        local speed_madd = AttrsManager:get_attrs_value_by_name("speed_madd")
        attr_speed = speed_add + speed_madd
    end
    return attr_speed
end

function on_click_break_handler(self, event, index)
    self.heroes_[index] = nil
    self:init_hero_panel()
end

function on_click_background_handler(self, event, index, hero)
    self.break_mask_ = true
    UIManager.open_window("HeroTroopsWindow", nil, index, hero)
end

function refresh_hero_panel(self, index, hero)
    if not hero then return end
    for i=1,2 do
        if index == i then
            self.heroes_[index] = hero
        elseif self.heroes_[i] and hero and self.heroes_[i].id_ == hero.id_ then
            self.heroes_[i] = nil
        end
    end
    self:init_hero_panel()
end

function on_click_special_handler(self, event)
    if self.obj_data_.obj_type_ == config.WORLD_RESPOINT then

    else
        self.break_mask_ = true
        MasterManager:buy_energy()
    end
end
