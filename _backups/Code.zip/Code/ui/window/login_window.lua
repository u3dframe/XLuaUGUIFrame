-- 登录界面
local dkjson                = require "Tools/dkjson"
module("LoginWindow",package.seeall)
setmetatable( LoginWindow, {__index = BaseWindow} )

local UI = _G.UnityEngine.UI

local server_list = {
    {"花见花开", "106.53.91.60", 10240},
    --{"内网1服", "192.168.0.21", 1024},
    --{"内网2服", "192.168.0.21", 1029},
    --{"内网3服", "192.168.0.24", 1030},
    --{"内网4服", "192.168.0.20", 1029},
    --{"内网5服", "192.168.0.20", 1030},
    --{"内网6服", "192.168.0.20", 1031},
    --{"内网7服", "192.168.0.23", 1027},
    --{"内网8服", "192.168.0.23", 1028},
    --{"内网9服", "192.168.0.23", 1029},
    --{"策划1001服", "192.168.0.25", 1001},
    --{"策划1002服", "192.168.0.25", 1002},
    --{"策划1003服", "192.168.0.25", 1003},
    --{"策划1004服", "192.168.0.25", 1004},
    --{"策划1005服", "192.168.0.25", 1005},
    --{"策划1006服", "192.168.0.25", 1006},
    --{"策划1007服", "192.168.0.25", 1007},
    --{"策划1008服", "192.168.0.25", 1008},
    --{"策划1009服", "192.168.0.25", 1009},
    --{"外网1服", "116.63.137.206", 10001},
    --{"外网2服", "116.63.137.206", 10002},
}

--1.准备UI（UI美术资源加载）
function on_resource(self)

end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self)
    dump(self.transform:Find("LoginBtn"), "loginBtn")
    dump(Button, "Button")
    self.btn_login_ = self.transform:Find("LoginBtn"):GetComponent(Button)
    self:add_event_handler(self.btn_login_.onClick, on_click_enter_world)    
    self.off_line_login_ = self.transform:Find("OfflineBtn"):GetComponent(Button)
    self:add_event_handler(self.off_line_login_.onClick, function()
        AudioManager.Play("SOUND_BUTTON_COMMON")
        local msg_ = {}
        msg_.title = lang("UI_BASIC_HINT")
        msg_.content = lang("测试测试测试")
        msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
        msg_.callback = function(index) 
            if index == 1 then
                elog("show elog stack traceback")
            else
                local num = 1
                num = num + abc
            end
        end
        MsgCenter.send_message(Msg.SHOW_NOTIFY,msg_)
    end)
    local url = "http://192.168.0.29:8080/cfgs/frontend/qcc/serverlist.json"
    --[[
    dump(ExtHttp, "ExtHttp")
    local extHttp = ExtHttp()
    local req = extHttp:CreateHttpRequest(url, "GET", function(response)
        dump(response.GetResponseText, "aido.callback")
    end ,
    function(data)
        dump(data, "aido.data")
    end )
    --]]
    local function callback(data)
        dump(data, "aido.data")
    end
    -- req:Start()
    
    StartCoroutine( function()
        local url = "http://192.168.0.29:8080/cfgs/frontend/qcc/serverlist.json"
    
        local httpController = HttpController()
        local t = {}
        httpController:Request(url, t)

        dump(t, "t")
        CoController.Wait(function()

            return t.success == nil
        end)
        dump(t, "aido.data.t")
        dump(dkjson.decode(t.result), "severlist")
    end)

    print("hhhhhh-----")


    self.account_in_ = self.transform:Find("DataPanel/AInputField"):GetComponent(InputField)
    self.create_in_ = self.transform:Find("DataPanel/CInputField"):GetComponent(InputField)

    
    self.cur_server_btn_ = self.transform:Find("Drop"):GetComponent(Button)
    self.cur_server_txt_ = self.transform:Find("Drop/Text"):GetComponent(Text)
    self.drop_scroll_ = self.transform:Find("Drop/ScrollView").gameObject
    self.scrollRect = self.drop_scroll_:GetComponent(_G.ScrollPoolVertical)
    self:add_event_handler(self.cur_server_btn_.onClick, function() self.drop_scroll_:SetActive(not self.drop_scroll_.activeSelf) end)
    Net.register(self, "role_list", self.on_role_list)
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)

local account = GameData.GetString("LoginAccount")
local name = GameData.GetString("LoginName")
local server = GameData.GetString("LoginServer")
self.select_index_ = tonumber(server) or 1
self:init_server_list()
    self.account_in_.text = account
    self.create_in_.text = name
    BgmManager.Play("Audio/Bgm/login")
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
     
end

function init_server_list(self)
    self.scrollRect:InitPool(#server_list, function(index, obj)
        local v = server_list[index]
        local txt = obj.transform:Find("Text"):GetComponent(UI.Text)
        local btn = obj:GetComponent(UI.Button)

        txt.text = string.format("%s %s:%s", v[1], v[2], v[3])
        self:add_event_handler(btn.onClick, on_click_select_server, index)
    end)
    if #server_list < self.select_index_ then
        self.select_index_ = #server_list
    end
    self:on_click_select_server(true, self.select_index_)
end

function on_click_select_server(self, event, index)
    self.select_index_ = index
    self.cur_server_txt_.text = server_list[index][1]
    self.drop_scroll_:SetActive(false)
end

function on_click_enter_world(self)
    if self.account_in_.text == "" then
        MsgCenter.send_message(Msg.SHOW_HINT, "输入账号")
        return
    end
        if self.create_in_.text == "" then
        MsgCenter.send_message(Msg.SHOW_HINT, "输入创建的名字")
        return
    end
    AudioManager.Play("SOUND_BUTTON_COMMON")
    GameData.SetString("LoginAccount", self.account_in_.text)
    GameData.SetString("LoginName", self.create_in_.text)
    GameData.SetString("LoginServer", self.select_index_ or 1)
    UIManager.open_window("LoadSceneWindow", function(load_win)
        local server_data = server_list[self.select_index_]
        Net:connect_server(server_data[2], server_data[3], 1)
    end)
end

function LoginWindow:on_role_list( data)
    local _,role = next(data.roles)
    dump(data, "on_roleList")
    if role then
        self:enter_role_game(role.rid)
    else
        local create_data = {}
        create_data.rname = GameData.GetString("LoginName")
        Net.send("role_create", create_data, function(result)
            if result.e == 0 then
                self:enter_role_game(result.rid)
            else
                local win = UIManager.get_window("LoadSceneWindow")
                if win then
                    win:fade_out()
                end
                Net.disconnect_server()
            end
        end)
    end
end

function LoginWindow:enter_role_game( myRid)
    local login_data = {}
    login_data.rid = myRid
    _G.Net.send("role_login", login_data, function(result)
        if result.e == 0 then
            -- 关闭loading界面
            GameManager:on_enter_main(data, function()
                self:close(function()
                    local win = UIManager.get_window("LoadSceneWindow")
                    if win then
                        win:fade_out()
                    end
                end)
            end)
        else
            MsgCenter.send_message(Msg.SHOW_HINT, "登陆失败！")
        end
    end)
end