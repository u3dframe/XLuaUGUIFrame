local CityFeteWindow = {}
setmetatable(CityFeteWindow, {__index = _G.BaseWindow})

local UI = _G.UnityEngine.UI
local Net = _G.Net
local BuildManager = _G.BuildManager
local MsgCenter = _G.MsgCenter
local Msg = _G.Msg
local lang = _G.lang
local Time = _G.Time
local ItemManager = _G.ItemManager
local GameUtil = _G.GameUtil
local UIUtil = _G.UIUtil
local PluginPointer
local TopBanner

local FIFTH_ITEM_POS = 5 --第五个道具的位置


--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function CityFeteWindow:on_init()
    PluginPointer = _G.PluginPointer
    TopBanner = _G.TopBanner
    self.fete = BuildManager:GetFete()

    self.itemGroup = self.transform:Find("WindowObj/RightBg")

    self.freeTxt = self.transform:Find("WindowObj/RightBg/info/info1/Text"):GetComponent(UI.Text)
    self.residueTxt = self.transform:Find("WindowObj/RightBg/info/info2/Text"):GetComponent(UI.Text)
    self.itemName = self.transform:Find("WindowObj/RightBg/Button/Text"):GetComponent(UI.Text)

    self.itemBg = self.transform:Find("WindowObj/RightBg/Button"):GetComponent(UI.Button)
    self.itemImg = self.transform:Find("WindowObj/RightBg/Button/Image"):GetComponent(UI.Image)

    --self.infoBtn = self.transform:Find("InfoBtn"):GetComponent(UI.Button)
    self.feteItemBtn = self.transform:Find("WindowObj/RightBg/Button"):GetComponent(UI.Button)
    --self:add_event_handler(self.infoBtn.onClick, self.OnInfoBtnClick)
    self:add_event_handler(self.feteItemBtn.onClick, self.OnFeteBtnClick)

    self.speed = 1
    self.accSpend = 80  --加速度
    self.maxSpeed = 50  --最大速度
    self.currTime = 0
    self.interval = 1

    self.pointerEvent = {}

    self.messager_:add_listener(Msg.CITY_FETE_UPDATE, self.OnRefreshFete)
end
function CityFeteWindow:on_after_top()
    --self.infoBtn.transform:SetSiblingIndex(self.transform.childCount)
end

--3.打开UI（打开/刷新UI处理）
function CityFeteWindow:on_open()
    if not self.fete then
        return
    end
    self:RefreshHintTxt() --刷新祭祀次数
    self:RefreshItemAll() --刷新道具
    local basic = self.fete:GetSacBasic()
    local prop = ItemManager:get_item_prop_by_id(basic.free_item)
    local item = ItemManager:get_item_by_id(basic.free_item)

    local cnt = not item and "" or " "..item.count_
    self.itemName.text = prop.name..cnt

    self.itemBg.interactable = item ~= nil
    GameUtil.SetImageGrey(self.itemBg:GetComponent(UI.Image), not item)
    GameUtil.SetImageGrey(self.itemImg, not item)

end

--5.关闭UI（UIManager销毁UI前处理）
function CityFeteWindow:on_close()
    self.messager_:remove_listener(Msg.CITY_FETE_UPDATE)
    if self.pointerEvent then
        for _, v in pairs(self.pointerEvent) do
            v:dispose()
        end
    end
    --防止长按逻辑错误 导致不能播放资源改变动画
    TopBanner:RecoverAnimation()
end

function CityFeteWindow:OnRefreshFete()
    self:on_open()
end

function CityFeteWindow:RefreshItemAll()
    for i = 1, 4 do
        self:RefreshEveryClick(i)
    end

    local itemCardObj = self.itemGroup:Find("Materil"..FIFTH_ITEM_POS)
    --第五个道具功能开放
    if self.pointerEvent[FIFTH_ITEM_POS] then
        self.pointerEvent[FIFTH_ITEM_POS]:dispose()
        self.pointerEvent[FIFTH_ITEM_POS] = nil
    end
    local pointer = PluginPointer:new(self, itemCardObj.gameObject, self.OnShowHint, FIFTH_ITEM_POS)
    self.pointerEvent[FIFTH_ITEM_POS] = pointer
end

--刷新祭祀次数
function CityFeteWindow:RefreshHintTxt()
    self.residueTxt.text = lang("UI_CITYFETE_TODY_TIME")..self.fete:GetResidueTimes()
    self.freeTxt.text = lang("UI_CITYFETE_FREE_TIME")..self.fete:GetFreeTimes()
end

function CityFeteWindow:RefreshEveryClick(index)
    self:RefreshHintTxt()
    local itemData = self.fete:GetItem(index)
    local itemCardObj = self.itemGroup:Find("Materil"..index)
    self:SetItem(itemData, itemCardObj)

    if itemData.unlock then
        --如果是解锁并且不存在event的时候注册
        if not self.pointerEvent[index] then
            local pointer = PluginPointer:new(self, itemCardObj.gameObject, self.OnFeteHandler, index)
            self.pointerEvent[index] = pointer
        end
    else
        if self.pointerEvent[index] then
            self.pointerEvent[index]:dispose()
            self.pointerEvent[index] = nil
        end
        local pointer = PluginPointer:new(self, itemCardObj.gameObject, self.OnShowHint, index)
        self.pointerEvent[index] = pointer
    end
end

function CityFeteWindow:SetItem(itemData, itemCardObj)
    local iconArea = itemCardObj:Find("Bg")
    local icon = itemCardObj:Find("Image")
    local count = itemCardObj:Find("Text")
    local btn = itemCardObj:Find("Button")
    local buyIcon = btn:Find("cost")
    local buyTxt = buyIcon:Find("Text")
    local buyImg = buyIcon:Find("Image")
    local buyHintTxt = btn:Find("Text")
    --set Item
    local cfg = ItemManager:get_ui_info({itemData.prop[1], itemData.prop[2]})
    if not cfg then
        return elog(string.format("Can't find config of item: %s,%s", itemData.prop[1], itemData.prop[2]))
    end
    UIUtil.set_sprite("UI/Common/Quality/item_"..cfg.quality, iconArea:GetComponent(UI.Image))
    UIUtil.set_sprite(cfg.icon, icon:GetComponent(UI.Image))
    count:GetComponent(UI.Text).text = itemData.prop[3]

    GameUtil.SetImageGrey(iconArea:GetComponent(UI.Image), not itemData.unlock)
    GameUtil.SetImageGrey(btn:GetComponent(UI.Image), not itemData.unlock)
    --set btn
    -- if not itemData.price then
    --     btn.gameObject:SetActive(false)
    -- end
    btn.gameObject:SetActive(true)
    local prop = itemData.price
    local temp = prop[1] ~= nil
    buyIcon.gameObject:SetActive(temp)
    buyHintTxt.gameObject:SetActive(not temp)
    if self:is_alive() and prop[1] then
        buyTxt:GetComponent(UI.Text).text = prop[3]
        UIUtil.set_sprite("UI/Common/ItemSmall/"..prop[1], buyImg:GetComponent(UI.Image))
    else
        buyHintTxt:GetComponent(UI.Text).text = prop
    end
end

--持续点击
function CityFeteWindow:LongPress()
    --如果消耗不足
    local price = self.fete:GetItemPrice(self.itemPos)
    if self.fete:GetFreeTimes() <= 0 and not ItemManager:check_coin(price) then
        self:SendMessage()
        self:NotityNotEnough()
        return
    end
    --如果是第一次使用金币
    if self.fete:IsFirstTimeGoldFete() then
        local item = self.fete:GetItem(self.itemPos)
        self:SendMessage()
        self:ShowNotityWindow(item.price[3], self.itemPos)
        return
    end

    --匀加速。达到最高速度不再加速
    self.speed = self.speed + self.accSpend
    if self.speed > self.maxSpeed then
        self.speed = self.maxSpeed
    end
    self.currTime = self.currTime + Time.deltaTime * self.speed
    if self.currTime >= self.interval then
        self.currTime = 0
        self.itemCnt = self.itemCnt + 1
        self:PlayAnime()
        self.fete:SetFeteCnt(self.itemPos)
        self:RefreshEveryClick(self.itemPos)
    end
end

--播放动画
function CityFeteWindow:PlayAnime()
    local data = self.fete:GetItem(self.itemPos)
    local resCnt = ItemManager:get_count_by_prop(data.prop)
    --数据格式
    local resData = {
        list = {
            [1] = {
            id = self.itemPos,
            change = {data.prop[3], 0},
            last = {resCnt + data.prop[3], 0}
        }
        }
    }
    ItemManager:on_resource_change(resData)
    --资源动画
    if self.fete:GetFreeTimes() == 0 then
        --金币动画
        local goldCnt = ItemManager:get_count_by_prop(data.price)
        local goldData = {
            list = {
                [1] = {
                    id = data.price[1],
                    change = - data.price[3],
                    last = goldCnt - data.price[3]
                },
                --args = "MASTER"
            }
        }
        ItemManager:on_coin_change(goldData)
    end
    --显示获得物品动画
end

function CityFeteWindow:OnShowHint(event, index)
    if event == PluginPointer.POINTER_CLICK then
        if index == FIFTH_ITEM_POS then
            MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_MAIN_UNOPEN"))
            return
        end
        if self.fete:GetResidueTimes() <= 0 then
            MsgCenter.send_message(Msg.SHOW_HINT, lang("CITY_FETE_COUNT_USEUP"))
            return
        end
        local hintTxt = self.fete:GetItemHint(index)
        MsgCenter.send_message(Msg.SHOW_HINT, hintTxt)
    end
end

function CityFeteWindow:OnFeteHandler(event, index)
    self.itemPos = index
    if event == PluginPointer.POINTER_ALWAY_DOWN then
        self.pointerHandler = 1
        if self.fete:GetResidueTimes() <= 0 then
            MsgCenter.send_message(Msg.SHOW_HINT, lang("CITY_FETE_COUNT_USEUP"))
            return
        end
        --长按
        self.itemCnt = self.itemCnt or 0
        self:LongPress()
    elseif event == PluginPointer.POINTER_CLICK then
        self.pointerHandler = 2
        if self.fete:GetResidueTimes() <= 0 then
            MsgCenter.send_message(Msg.SHOW_HINT, lang("CITY_FETE_COUNT_USEUP"))
            return
        end
        --点击
        self.itemCnt = 1
        self.itemPos = index
        self:OnItemclick()
    elseif event == PluginPointer.POINTER_UP then
        if not self.pointerHandler or self.pointerHandler == 2 then
            return
        end
        --清除时间状态
        self.currTime = 0
        self.speed = 0.1
        --发消息
        TopBanner:NoAnimation()
        self:SendMessage()
	end
end


function CityFeteWindow:OnItemclick()
    --首次金币祭祀
    if self.fete:IsFirstTimeGoldFete() then
        local item = self.fete:GetItem(self.itemPos)
        self:ShowNotityWindow(item.price[3], self.itemPos)
        return
    end
    self:SendMessage()
end

function CityFeteWindow:SendMessage()
    if self.itemCnt == 0 then
        TopBanner:RecoverAnimation()
        return
    end
    local req = {
        sacrifice_point = self.itemPos,
        sacrifice_count = self.itemCnt
    }
    Net.send("sacrifice", req, function(result)
        if result.e == 0 then
            if self.pointerHandler == 2 then
                self.fete:SetFeteCnt(self.itemPos)
                if self.fete:GetFreeTimes() < 0 then
                    self:RefreshEveryClick(self.itemPos)
                else
                    self:RefreshItemAll()
                end
            end
            --刷新建筑 title
            local isShow = self.fete:GetFreeTimes() > 0
            MsgCenter.send_message(Msg.CITY_FETE_UPDATE, isShow)
        end
        --恢复动画
        TopBanner:RecoverAnimation()
        self.pointerHandler = nil
        self.itemPos = nil
        self.itemCnt = 0
    end)
end

function CityFeteWindow:ShowNotityWindow(goldCnt, pos)
    local msg_ = {}
    msg_.title = ''
    msg_.content = lang("UI_CITYFETE_HINT", goldCnt)
    msg_.buttons = {lang('UI_BASIC_CANCEL'), lang('UI_BASIC_SURE')}
    msg_.callback = function(index)
        if index == 2 then
            self.itemCnt = 1
            self.itemPos = pos
            --弹出窗口相当是单点祭祀
            self.pointerHandler = 2
            self:SendMessage()
        end
    end
    MsgCenter.send_message(Msg.SHOW_NOTIFY, msg_)
end

function CityFeteWindow:NotityNotEnough()
    local msg_ = {}
    msg_.title = ''
    msg_.content = lang("ITEM_NOT_ENOUGH")
    msg_.buttons = {lang('UI_BASIC_SURE')}
    MsgCenter.send_message(Msg.SHOW_NOTIFY, msg_)
end

function CityFeteWindow:OnInfoBtnClick()

end

function CityFeteWindow:OnFeteBtnClick()
    _G.UIManager.open_window("FeteUseItemWindow")
end

return CityFeteWindow


