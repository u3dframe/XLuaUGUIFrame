-- 登录界面
module("HeroTroopsWindow",package.seeall)
setmetatable( HeroTroopsWindow, {__index = BaseWindow} )

--1.准备UI（UI美术资源加载）
local BasicConfig = _G.Database.BasicConfig


function on_resource(self)
    local list = {
        "hero/HeroCard"
    }

    Yield(UIUtil.load_component(list, function(prefabs) 
        self.hero_card_prefab_ = prefabs[1]
    end))
end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self) 
    
    self.btn_close_ = self.transform:Find("WindowObj/Close"):GetComponent(Button)
	self:add_event_handler(self.btn_close_.onClick, function()
        self:close()
    end)
    self.sure_btn_ = self.transform:Find("WindowObj/BottomBtns/SureBtn"):GetComponent(Button)
    self:add_event_handler(self.sure_btn_.onClick, on_click_sure_hero)
    self.info_btn_ = self.transform:Find("WindowObj/BottomBtns/InfoBtn"):GetComponent(Button)
    self:add_event_handler(self.info_btn_.onClick, on_click_info_hero)
    self.hero_card_parent_ = self.transform:Find("WindowObj/InfoPanel/HeroGroup/HeroCard")
    self.hero_list_parent_ = self.transform:Find("WindowObj/HerosPanel/ScrollView/Content")
    self.active_go_ = {}
    
    -- attrs
    self.power_txt_ = self.transform:Find("WindowObj/InfoPanel/InfoPanel/PowerTxt"):GetComponent(Text)
    self.name_txt_ = self.transform:Find("WindowObj/InfoPanel/InfoPanel/Name"):GetComponent(Text)
    self.power_arrow_ = {}
    self.power_arrow_[1] = self.transform:Find("WindowObj/InfoPanel/InfoPanel/ArrowUp"):GetComponent(Image)
    self.power_arrow_[2] = self.transform:Find("WindowObj/InfoPanel/InfoPanel/ArrowDown"):GetComponent(Image)
    self.hero_value_ = {}
    self.attr_items_ = {}
    self.attr_arrow_ = {}
    self.hero_bar_ = {}
    self.attr_max_ = {}
    for i=1,3 do
        self.attr_items_[i] = self.transform:Find("WindowObj/InfoPanel/AttrsPanel/AttrsItem"..i)
        self.hero_value_[i] = self.attr_items_[i]:Find("AttrsValue"):GetComponent(Text)
        self.hero_bar_[i] = {}
        self.hero_bar_[i][1] = self.attr_items_[i]:Find("ValueBar/BarGreen"):GetComponent(Image)
        self.hero_bar_[i][2] = self.attr_items_[i]:Find("ValueBar/BarRed"):GetComponent(Image)
        self.attr_arrow_[i] = {}
        self.attr_arrow_[i][1] = self.attr_items_[i]:Find("ArrowUp"):GetComponent(Image)
        self.attr_arrow_[i][2] = self.attr_items_[i]:Find("ArrowDown"):GetComponent(Image)
        self.attr_max_[i] = BasicConfig.BasicData.hero_attrs[i]
    end
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
    self.troops_index_ = self.data[1]
    self.hero_data_ = self.data[2]
	self:init_cur_head(self.data[2])
    self:set_hero_diff_attrs(self.data[2])
    self:init_list_panel()
    self.cur_hero_card_:set_data_troops_hero(self.hero_data_, self.troops_index_)
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)

end

function init_cur_head(self)
    if self.cur_hero_card_ then
        return
    end
    local card = GameObject.Instantiate(self.hero_card_prefab_)
    card.transform:SetParent(self.hero_card_parent_, false)
    card:SetActive(true)
    self.cur_hero_card_ = HeroCard:new(self)
    self.cur_hero_card_:AddLuaComponent(card)
    self.cur_hero_card_:init()
    
--    self.cur_hero_card_.transform.localScale = Vector3(0.8, 0.8, 0.8)
end

function init_list_panel(self)
    self.hero_list_ = HeroManager:get_heroes()
    local hero_num = #self.hero_list_
    for i=1,#self.active_go_ do
        if hero_num < i and self.active_go_[i].gameObject.activeSelf then
            self.active_go_[i].gameObject:SetActive(false)
        end
    end
    for i=1,hero_num do
        local v = self.hero_list_[i]
        if not self.active_go_[i] then
            local card = GameObject.Instantiate(self.hero_card_prefab_)
            card.transform:SetParent(self.hero_list_parent_, false)
            card:SetActive(true)
            self.active_go_[i] = HeroCard:new(self)
            self.active_go_[i]:AddLuaComponent(card)
            self.active_go_[i]:init()
        end
        self.active_go_[i].gameObject:SetActive(true)
        self.active_go_[i]:set_data_troops_list(v)
        self.active_go_[i].transform.localScale = Vector3(0.8, 0.8, 0.8)
        self.active_go_[i].transform.pivot = Vector2(0.5, 0.5)
        local button = self.active_go_[i].transform:GetComponent(ButtonClick)
        if not button then
            button = self.active_go_[i].gameObject:AddComponent(ButtonClick)
        end
        self.active_go_[i].btn_.onClick:RemoveAllListeners()
        self:add_event_handler(self.active_go_[i].btn_.onClick, on_select_head_handler, v)
    end
end

function on_select_head_handler(self, event, hero)
    local hero_data = hero
    self.cur_hero_card_:set_data_troops_hero(hero_data, self.troops_index_)
    self:set_hero_diff_attrs(hero_data)
    self.hero_data_ = hero_data
end

function on_click_sure_hero(self, event)
    local win = UIManager.get_window("WorldTroopsWindow")
    if win then
        win:refresh_hero_panel(self.troops_index_, self.hero_data_)
    end
    self:close()
end

function on_click_info_hero(self, event)
    MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_MAIN_UNOPEN"))
end

function set_hero_diff_attrs(self, heroData)
    local cur_hero = self.data[2]
    local attr_list = {0,0,0}
    if heroData then
        attr_list = heroData:get_attr()
    end
    
    local cur_attr_list = {0,0,0} 
    local cur_power = 0
    if cur_hero then
        cur_attr_list = cur_hero:get_attr()
        cur_power = cur_hero:get_power()
    end
    local hero_power = 0
    local hero_name = ""
    if heroData then
        hero_power = heroData:get_power()
        hero_name = heroData:get_color_name()
    end
    self.power_txt_.text = hero_power
    self.name_txt_.text = hero_name
    if heroData then
        if cur_power < hero_power then
            self.power_arrow_[1].color = Color(1, 1, 1, 1)
            self.power_arrow_[2].color = Color(1, 1, 1, 0)
        elseif cur_power == hero_power then
            self.power_arrow_[1].color = Color(1, 1, 1, 0)
            self.power_arrow_[2].color = Color(1, 1, 1, 0)
        else
            self.power_arrow_[1].color = Color(1, 1, 1, 0)
            self.power_arrow_[2].color = Color(1, 1, 1, 1)
        end
    else
        self.power_arrow_[1].color = Color(1, 1, 1, 0)
        self.power_arrow_[2].color = Color(1, 1, 1, 0) 
    end
    for i=1,3 do
        self.hero_value_[i].text = attr_list[i]
        if cur_attr_list[i] < attr_list[i] then
            self.attr_arrow_[i][1].color = Color(1, 1, 1, 1)
            self.attr_arrow_[i][2].color = Color(1, 1, 1, 0)
            
            self.hero_bar_[i][1].color = Color(1, 1, 1, 1)
            self.hero_bar_[i][2].color = Color(1, 1, 1, 0)
        elseif cur_attr_list[i] == attr_list[i] then
            self.attr_arrow_[i][1].color = Color(1, 1, 1, 0)
            self.attr_arrow_[i][2].color = Color(1, 1, 1, 0)
            
            self.hero_bar_[i][1].color = Color(1, 1, 1, 1)
            self.hero_bar_[i][2].color = Color(1, 1, 1, 0)
        else
            self.attr_arrow_[i][1].color = Color(1, 1, 1, 0)
            self.attr_arrow_[i][2].color = Color(1, 1, 1, 1)
            
            self.hero_bar_[i][1].color = Color(1, 1, 1, 0)
            self.hero_bar_[i][2].color = Color(1, 1, 1, 1)
        end
        self.hero_bar_[i][1].fillAmount = attr_list[i] / self.attr_max_[i]
        self.hero_bar_[i][2].fillAmount = attr_list[i] / self.attr_max_[i]
    end
end