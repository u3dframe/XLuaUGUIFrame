local BuildCreateWindow = {}
setmetatable(BuildCreateWindow, {__index = _G.BaseWindow})

local BuildManager = _G.BuildManager
local lang = _G.lang
local UI = _G.UnityEngine.UI
local Msg = _G.Msg
local config = _G.config

--1.准备UI（UI美术资源加载）
function BuildCreateWindow.on_resource()
end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function BuildCreateWindow:on_init()
    --data
    self.space_class_ = self.data[1]
    self.curr_space_id_ = self.space_class_.id_
    self.data_ = BuildManager:get_space_info_by_id(self.curr_space_id_)
    --ui组件
    self.details_txt_ = self.transform:Find('WindowObj/Details'):GetComponent(UI.Text)
    self.item_parent_pos_ = self.transform:Find('WindowObj/RightBg/Items')
    self.togglge_group_ = self.item_parent_pos_.gameObject:GetComponent(UI.ToggleGroup)
    self.build_btn_ = self.transform:Find('WindowObj/RightBg/Button'):GetComponent(UI.Button)
    self.back_empty_btn_ = self.transform:Find('Background'):GetComponent(UI.Button)
    self.timer_txt_ = self.transform:Find('WindowObj/RightBg/Button/Timer'):GetComponent(UI.Text)
    self.build_name_ = self.transform:Find('WindowObj/BuildInfo/Name'):GetComponent(UI.Text)
    self.build_lv_ = self.transform:Find('WindowObj/BuildInfo/Lv'):GetComponent(UI.Text)
    --add_listener
    self:add_event_handler(self.back_empty_btn_.onClick, self.btn_callback)
    self:add_event_handler(self.build_btn_.onClick, self.click_build_btn)
    self:init_items()
    self.messager_:add_listener(
        _G.Msg.CITY_BUILDING_SUCCEED,
        function()
            self.is_show_ = true
        end
    )
    self.messager_:add_listener(_G.Msg.CITY_UP_LV_FINISHED, BuildCreateWindow.on_up_lv_finished)
end

--3.打开UI（打开/刷新UI处理）
function BuildCreateWindow:on_open()
    self.allow_build_data_ = self.data_.allow_build_
    if not self.allow_build_data_ then
        return
    end

    for k, v in ipairs(self.build_create_items_) do
        if not self.allow_build_data_[k] then
            v.gameObject:SetActive(false)
        else
            self:set_item_data(k, v)
        end
    end
    if self.build_create_items_ and self.build_create_items_[1] then
        local first_toggle = self.build_create_items_[1]:GetComponent(UI.Toggle)
        first_toggle.isOn = true
    end
    _G.MsgCenter.send_message(Msg.CITY_HIDE_UI_ALL, true)
end

--5.关闭UI(UIManager销毁UI前处理)
function BuildCreateWindow:on_close()
    if not self.is_show_ then
        self.space_class_:hide_build_img()
    end
    if _G.SceneManager.City_Scene then
        _G.SceneManager.City_Scene:back_play_animate()
    else
        _G.SceneController.currentScene:GetCameraController():FocusBack();
    end
    self.messager_:remove_listener(Msg.CITY_BUILDING_SUCCEED)
    self.messager_:remove_listener(Msg.CITY_UP_LV_FINISHED)
    _G.MsgCenter.send_message(Msg.CITY_HIDE_UI_ALL, false)
end

function BuildCreateWindow:set_item_data(index, obj)
    --data
    local build_type = self.allow_build_data_[index]
    local build_data = BuildManager:get_build_data(build_type)
    local up_info = build_data:get_update_info_by_level(1)
    --ui组件
    local toggle = obj:GetComponent(UI.Toggle)
    toggle.onValueChanged:RemoveAllListeners()
    self:add_event_handler(toggle.onValueChanged, callback_toggle, obj, build_data, up_info)
    local name = obj.transform:Find('BuildInfo/Name'):GetComponent(UI.Text)
    local tip_img = obj.transform:Find('Tip'):GetComponent(UI.Image)
    local tip = obj.transform:Find('Tip/Text'):GetComponent(UI.Text)
    local icon = obj.transform:Find('Icon'):GetComponent(UI.Image)
    local gray = obj.transform:Find('Gray')
    local limit_number = obj.transform:Find('BuildInfo/Count'):GetComponent(UI.Text)
    --是否满足升级或者建造解锁条件
    local is_full, depend_name, min_level = BuildManager:unlock_proviso_meet(build_data, 1)
    local _, curr_count, total_count = BuildManager:check_build_limit(build_data)
    name.text = lang('UI_BASIC_COLOR', config.FONT_COLOR.ORANGE, build_data.name_)
    -- is_full 已经解锁
    if is_full then
        tip_img.gameObject:SetActive(false)
        gray.gameObject:SetActive(false)
        --资源田需要显示 可建造数量
        if build_data:is_outside_build() then
            limit_number.text = curr_count .. '/' .. total_count
        end
        limit_number.gameObject:SetActive(build_data:is_outside_build())
    else
        tip.text = lang('UI_BUILDCREATE_UNLOCK', depend_name, min_level)
        tip_img.gameObject:SetActive(true)
        gray.gameObject:SetActive(true)
        limit_number.gameObject:SetActive(false)
    end

    _G.UIUtil.set_sprite(up_info.path, icon)
    obj.gameObject:SetActive(true)
end

function BuildCreateWindow:init_items()
    self.build_create_items_ = {}
    for i = 1, 6 do
        local obj = self.transform:Find('WindowObj/RightBg/Items/BuildCreate' .. i)
        table.insert(self.build_create_items_, obj)
    end
end

function callback_toggle(self, evnet_data, obj, build_data, up_info)
    if not build_data or not up_info then
        _G.elog('build_data or up_info is nil')
        return
    end
    local select_img = obj.transform:Find('Selected')
    local name = obj.transform:Find('BuildInfo/Name'):GetComponent(UI.Text)
    local is_full = _G.BuildManager:unlock_proviso_meet(build_data, 1)

    self.select_build_id_ = build_data.build_type_
    self.space_class_:show_img_by_path(up_info.path)

    select_img.gameObject:SetActive(evnet_data)
    --修改选中后的字体
    if evnet_data then
        name.text = lang('UI_BASIC_COLOR', '#3f2b09', build_data.name_)
    else
        name.text = lang('UI_BASIC_COLOR', config.FONT_COLOR.ORANGE, build_data.name_)
    end
    --是否可以建造
    self.build_btn_.interactable = is_full
    _G.GameUtil.SetImageGrey(self.build_btn_:GetComponent(UI.Image), not is_full)
    if is_full then
        local is_allow_build = BuildManager:check_build_limit(build_data)
        self.build_btn_.interactable = is_allow_build
        _G.GameUtil.SetImageGrey(self.build_btn_:GetComponent(UI.Image), not is_allow_build)
    end
    --设置建筑说明
    self.details_txt_.text = build_data.introduce_
    self.timer_txt_.text = _G.UIUtil.format_time(up_info.uplong / 1000)
    --设置建筑名称等级
    local build_name = lang('UI_BASIC_COLOR', config.FONT_COLOR.YELLOW, build_data.name_)
    local lv = lang('UI_BASIC_COLOR', config.FONT_COLOR.GREY, lang('UI_BASIC_LV') .. build_data.lv_)
    self.build_name_.text = build_name
    self.build_lv_.text = lv
end

function BuildCreateWindow:click_build_btn()
    _G.UIManager.open_window('BuildSpendWindow', nil, self.space_class_, self, _G.config.Build_State.BUILDING)
end

function BuildCreateWindow:on_up_lv_finished()
    self:on_open()
end

function BuildCreateWindow:btn_callback()
    self:close()
end

return BuildCreateWindow
