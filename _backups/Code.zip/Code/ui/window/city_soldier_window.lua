module("CitySoldierWindow", package.seeall)
setmetatable(CitySoldierWindow, {__index = BaseWindow})

Silder_MinCount = 1 --silder 最小值

--1.准备UI（UI美术资源加载）
local SoldierskillConfig = _G.Database.SoldierskillConfig


function on_resource(self)

end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self)
	self.space_class_ = self.data[1]
	--现在没有配置上兵营和兵的联系 建筑id为2，兵id为1  
	local id = self.space_class_.build_info_ and self.space_class_.build_info_.id_
	self.build_info_ = BuildManager:get_build_info_by_id(id)
	--UI
	--self.soldier_power_ = self.transform:Find("WindowObj/FightingPower/Text"):GetComponent(Text)
	self.soldier_power_ = self.transform:Find("WindowObj/RightPanel/PowerAndNum/PowerText"):GetComponent(Text)
	self.people_img_ = self.transform:Find("WindowObj/SoldierImg")
	local left_panel = self.transform:Find("WindowObj/LeftPanel/Panel")
	self.icon_content_ = left_panel:Find("Scroll View/Viewport/Content")
	local hero_icon_obj = self.icon_content_:Find("HeroIcon").gameObject
	hero_icon_obj:SetActive(false)
	self.selected_ = hero_icon_obj.transform:Find("Selected")
	self.selected_:SetParent(nil, false)
	self.selected_.gameObject:SetActive(false)
	self.soldier_info_all_ = SoldierManager:get_soldier_info_by_build_type(self.build_info_.build_type_)
	self.icon_preson_tb_ = {}
	for i = 1, #self.soldier_info_all_ do
		local obj = GameObject.Instantiate(hero_icon_obj)
		obj.transform:SetParent(self.icon_content_, false)
		obj:SetActive(true)
		self.icon_preson_tb_[i] = obj
		self:set_content_item(i, obj)
		local btn = obj:GetComponent(Button)
		self:add_event_handler(btn.onClick, function() self:callback_select(i) end)
	end
	local prev_btn = left_panel:Find("Prev"):GetComponent(Button)
	self:add_event_handler(prev_btn.onClick, function() self:select_prev() end)
	local next_btn = left_panel:Find("Next"):GetComponent(Button)
	self:add_event_handler(next_btn.onClick, function() self:select_next() end)
	local right_panel = self.transform:Find("WindowObj/RightPanel")
	--info
	self.properties_ = self.transform:Find("WindowObj/RightPanel/Properties")
	self.soldier_name_lv_ = self.transform:Find("WindowObj/NamePanel/Name")
	self.soldier_count_ = self.transform:Find("WindowObj/RightPanel/PowerAndNum/NumText"):GetComponent(Text)
	self.soldier_describe_ = self.transform:Find("WindowObj/NamePanel/Desc/Text"):GetComponent(Text)
	self.soldier_skill_ = self.transform:Find("WindowObj/RightPanel/Skills")
	--bottom
	--self.bottom_ = self.transform:Find("WindowObj/Bottom")
	self.plane1_ = right_panel:Find("Plane1")
	self.plane2_ = right_panel:Find("Plane2")
	self.plane3_ = right_panel:Find("Plane3")
	self.slider_ = self.plane1_:Find("SliderBar/Slider/NumberSlider"):GetComponent(Slider)
	self.res_panel_ = right_panel:Find("CostPanel/Res")
	self.spend_obj_tb_ = {} --消耗道具表
	for i = 1, 4 do
		local icon = self.res_panel_:Find("ResItem"..i)
		self.spend_obj_tb_[i] = icon
	end

	self.hint_time_ = self.plane2_.transform:Find("Text"):GetComponent(Text)
	self.timer_txt_ = self.plane1_:Find("Button/Timer"):GetComponent(Text)
	--self.input_field_ = self.plane1_:Find("Slider/InputField"):GetComponent(InputField)
	self.number_txt_ = self.plane1_:Find("SliderBar/Num/Text"):GetComponent(Text)
	self.cancel_timer_ = self.plane2_:Find("Timer"):GetComponent(Text)
	--self.timer_img_ = self.plane2_:Find("Slider/Mask"):GetComponent(Image)
	self.timer_slider_ = self.plane2_:Find("Slider"):GetComponent(Slider)
	self.not_unlock_txt_ = self.plane3_:Find("Text"):GetComponent(Text)
	self.gold_count_1_ = self.plane1_:Find("GoldDrill/Text1"):GetComponent(Text) --立即训练按钮金币显示
	self.gold_count_2_ = self.plane2_:Find("GoldSpeedUPBtn/Text1"):GetComponent(Text)   --训练加速 金币显示
	self.cancel_txt_ = self.plane2_:Find("CancelBtn/Text"):GetComponent(Text)
	--btn
	self.add_btn_ = self.plane1_:Find("SliderBar/Slider/AddBtn"):GetComponent(Button)
	self.sub_btn_ = self.plane1_:Find("SliderBar/Slider/SubBtn"):GetComponent(Button)
	self.drill_btn_ = self.plane1_:Find("Button"):GetComponent(Button)
	self.cancel_queue_btn_ = self.plane2_:Find("CancelBtn"):GetComponent(Button)
	self.info_btn_ = right_panel:Find("InfoBtn"):GetComponent(Button)
	self.promote_btn = self.transform:Find("WindowObj/RightPanel/PromoteBtn"):GetComponent(Button)
	self.gold_speedup_btn_ = self.plane2_:Find("GoldSpeedUPBtn"):GetComponent(Button)
	self.prop_speedup_btn_ = self.plane2_:Find("PropSpeedUpBtn"):GetComponent(Button)
	self.immediately_btn_ = self.plane1_:Find("GoldDrill"):GetComponent(Button)
	--tips
	self.tips_ = self.transform:Find("WindowObj/Tips")
	self.tips_.gameObject:SetActive(false)
	self.tips_title_ = self.tips_.transform:Find("Board/Title"):GetComponent(Text)
	self.tips_content_ = self.tips_.transform:Find("Board/Des"):GetComponent(Text)

	self:add_event_handler(self.add_btn_.onClick, callback_add_btn)
	self:add_event_handler(self.sub_btn_.onClick, callback_sub_btn)
	self:add_event_handler(self.drill_btn_.onClick, callback_drill_btn)
	self:add_event_handler(self.cancel_queue_btn_.onClick, callback_cancel_btn)
	self:add_event_handler(self.slider_.onValueChanged, callback_soldier_change)
	--self:add_event_handler(self.input_field_.onEndEdit, callback_end_editor)
	self:add_event_handler(self.info_btn_.onClick, callback_soldier_info)
	self:add_event_handler(self.promote_btn.onClick, callback_promote)
	self:add_event_handler(self.info_btn_.onClick, callback_info_btn)

	self:add_event_handler(self.gold_speedup_btn_.onClick, callback_gold_btn)
	self:add_event_handler(self.prop_speedup_btn_.onClick, callback_prop_btn)
	self:add_event_handler(self.immediately_btn_.onClick, callback_immediately_btn)

	--训练完成
	self.messager_:add_listener(Msg.CITY_SOIDIER_FINISHED, on_soldier_drill_finished)
	
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
	self:get_unlock_soldier() --获取已经解锁的士兵
	self:set_icon_show_priority()
	self:callback_select(self.curr_select_icon_)
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
	self:close_lua_timer()
    self.messager_:remove_listener(Msg.CITY_SOIDIER_FINISHED)
end

function main_title(self)
   	if self.build_info_ then
   		return self.build_info_.name_
	end
end

-- function init_item(self)
-- 	self.spend_obj_tb_ = {} --消耗道具表
-- 	self.icons_ = self.bottom_:Find("Icons/bg")
-- 	for i = 1, 4 do
-- 		local icon = self.icons_:Find("ResItem"..i)
-- 		self.spend_obj_tb_[i] = icon
-- 	end
-- end

function select_prev(self)
	self:callback_select(self.curr_select_icon_ - 1)
end

function select_next(self)
	self:callback_select(self.curr_select_icon_ + 1)
end

--设置icon 优先级
function set_icon_show_priority(self)
	--如果点了晋升按钮，就定位到点击晋升按钮时候的士兵
	--如果点了金币训练按钮，就定位到点击金币训练按钮的士兵
	if self.is_click_lvup_btn_ or self.is_click_gole_lvup_btn_ then
		return
	end
	--优先级 1.训练 2.等级最大 3.解锁
	--这里是根据等级来排顺序的
	local timer_exis, finish_train, id, class = SoldierManager:check_soldier_state(self.build_info_.build_type_)
	if timer_exis then
		local soldier = SoldierManager:get_soldier_info_by_id(id, class)
		if not soldier then
			self.curr_select_icon_ = 1
			return
		end
		self.curr_select_icon_ = soldier.lv_
		return
	end
	--已经解锁的兵种
	local s_tb = {}
	for k, v in pairs(self.soldier_unlock_) do
		table.insert(s_tb, v)
	end
	--等级最大
	if #s_tb > 0 then
		table.sort(s_tb, function(x, y)
			return x.lv_ > y.lv_
		end)
		self.curr_select_icon_ = s_tb[1].lv_
	else
		self.curr_select_icon_ = 1
	end
end

--获取已经解锁的士兵们
function get_unlock_soldier(self)
	self.soldier_unlock_ = {}
	for k, v in pairs(self.soldier_info_all_) do
		local is_meet, build_info = self:is_unlock(v)
		if is_meet then
			table.insert(self.soldier_unlock_, v)
		end
	end
	table.sort(self.soldier_unlock_, function(x, y)
		return x.lv_ > y.lv_
	end)
end

function on_soldier_change(self, id)
	--这里可以把等级作为顺序id
	self.soldier_info_ = self:find_item_by_level(id)
	self.soldier_power_.text = self.soldier_info_.fighting_power_
	self.max_count_ = self.soldier_info_:get_drill_max_count()
	--解锁面板显示
	self:show_btn_drill_or_cancel()
	self:init_info()
	self:init_bottom()
end

function find_item_by_level(self, lv)
	if not self.soldier_info_all_ then return end
	local obj
	for _, v in pairs(self.soldier_info_all_) do
		if v.lv_ == lv then
			obj = v
			break
		end
	end
	if not obj then elog("not found value in table. lv = %s", lv) end
	return obj
end

function show_btn_drill_or_cancel(self)
	local is_meet, build_info = self:is_unlock(self.soldier_info_)
	
	if not is_meet then
		local depend_lv = self.soldier_info_.unlock_
		self.not_unlock_txt_.text = lang("UI_SOLDIER_UNLOCK", build_info.name_, depend_lv)
	end
	if not is_meet then is_meet = false end
	self.unlock_ = is_meet --是否解锁
end

function show_plane(self)
	local timer_exis, finish_train, soldier_id, class = SoldierManager:check_soldier_state(self.build_info_.build_type_)
	local soldier = SoldierManager:get_soldier_info_by_id(soldier_id, class)
	if not timer_exis then timer_exis = false end
	local is_meet, build_info = self:is_unlock(self.soldier_info_)
	if is_meet then
		self.plane3_.gameObject:SetActive(false)
		self.res_panel_.gameObject:SetActive(true)
		self.plane2_.gameObject:SetActive(timer_exis)
		self.plane1_.gameObject:SetActive(not timer_exis)
	else
		self.plane1_.gameObject:SetActive(false)
		self.plane2_.gameObject:SetActive(false)
		self.res_panel_.gameObject:SetActive(false)
		self.plane3_.gameObject:SetActive(true)
	end
	if timer_exis then
		local remaining_time = soldier and soldier.end_time_ - Net.server_time() or nil
		--local remaining_time = soldier.end_time_ - Net.server_time()
		self.gold_count_2_.text = self:set_gold_number(remaining_time)

		--在训练中
		if soldier:is_training() then
			self.hint_time_.text = lang("UI_SOLDIER_REMAINING_TIME")
			self.cancel_txt_.text = lang("UI_SOLDIER_CANCEL_DRILL")
		elseif soldier:is_soldier_updating() then --在晋升中
			self.hint_time_.text = lang("UI_SOLDIER_PROMOTION_TIME")
			self.cancel_txt_.text = lang("UI_SOLDIER_CANCEL_PROMOTE")
		end
		self:play_timer(soldier)
	end
	self.timer_exis_ = timer_exis --保存时间状态
end

--设置金币数量
function set_gold_number(self, remaining_time)
	return SoldierManager:get_gold_drill_number(remaining_time)
end

function init_info(self)
	local name = self.soldier_name_lv_:Find("NameImage"):GetComponent(Image)
	UIUtil.set_sprite("UI/Window/Solider/soldier_name_"..self.soldier_info_.soldier_type_, name)
	local lv = self.soldier_name_lv_:Find("Lv"):GetComponent(Text)
	lv.text = lang("UI_SOLDIER_NAME_LV", self.soldier_info_.lv_)
	self.soldier_count_.text =  self.soldier_info_.number_ or 0
	self.soldier_describe_.text = UIUtil.string_insert(self.soldier_info_.describe_, "\n")
	local attr = self.soldier_info_.attribute_
	for k, v in ipairs(config.SOLDIER_ATTR) do
		if attr[v] then
			self:set_info_item(k, attr[v])
		end
		if k >= 3 then break end
	end
	--技能
	local skill_data = self.soldier_info_.skill_info_
	for i = 1, config.SOLDIER_SKILL_MAX do
		local skill_item = self.soldier_skill_:Find("Skill"..i)
		if skill_data[i] then
			self:set_info_skill(skill_item, i)
		else
			local mask = skill_item:Find("Mask")
			--local name = skill_item:Find("BoardName")
			local icon = skill_item:Find("Icon")
			mask.gameObject:SetActive(true)
			--name.gameObject:SetActive(false)
			icon.gameObject:SetActive(false)
		end
	end
	
	--如果到达最大等级 则隐藏晋升按钮
	local lenth = #self.soldier_info_all_
	local not_max_lv = self.soldier_info_all_[lenth - 1].lv_ > self.soldier_info_.lv_
	self.promote_btn.gameObject:SetActive(not_max_lv)
	if not_max_lv then
		--1.已经解锁2.没有在训练3.数量不能为零 4.晋升的目标士兵不能是未解锁的(也就是已经解锁的士兵中，最后俩个肯定是置灰状态)
		local count = self.soldier_info_.number_
		local is_last_two
		if #self.soldier_unlock_ <= 2 then
			is_last_two = true
		else
			is_last_two = self.soldier_info_.lv_ >= self.soldier_unlock_[2].lv_
		end
		if self.unlock_ and not self.timer_exis_ and count > 0 and not is_last_two then
			GameUtil.SetImageGrey(self.promote_btn:GetComponent(Image), false)
		else
			--未解锁按钮置灰
			GameUtil.SetImageGrey(self.promote_btn:GetComponent(Image), true)
		end 
    end
end

function init_bottom(self)
	--默认最大值150
	self.slider_.maxValue = self.max_count_
	self.slider_.value = self.max_count_
end

--设置item
function set_content_item(self, index, obj)
	local soldier_info = self:find_item_by_level(index)
	--local icon_unlock_path = soldier_info.small_icon_path_
	-- local content_item = obj
	-- local unlock = content_item.transform:Find("Unlock")
	-- local notlock = content_item.transform:Find("NotLock")

	-- local unlock_icon = content_item.transform:Find("Unlock/Icon"):GetComponent(Image)
	-- local notlock_icon = content_item.transform:Find("NotLock/Icon"):GetComponent(Image)
	-- local name_lv = content_item.transform:Find("Text"):GetComponent(Text)
	-- local canvas_com = name_lv.gameObject:GetComponent(Canvas)
	--判读是否满足解锁条件
	local is_meet = self:is_unlock(soldier_info)
	obj.transform:Find("LockMask").gameObject:SetActive(not is_meet)

	local icon = obj.transform:Find("Icon"):GetComponent(Image)
	UIUtil.set_sprite(soldier_info.small_icon_path_, icon)

	--设置字体层级
	-- canvas_com.sortingLayerName = "screen"
	-- canvas_com.sortingOrder = 1

	-- local str = lang("UI_SOLDIER_ICON_NAME_LV", soldier_info.lv_, soldier_info.name_)

	-- if is_meet then
	-- 	name_lv.text = lang("UI_BASIC_COLOR", config.FONT_COLOR.WHITE, str)
	-- else
	-- 	name_lv.text = lang("UI_BASIC_COLOR", config.FONT_COLOR.GREY, str)
	-- end

	-- self:load_img(icon_unlock_path, unlock_icon, unlock)
	-- self:load_img(icon_unlock_path, notlock_icon, notlock)
end

--是否解锁
function is_unlock(self, soldier_info)
	local build_type = soldier_info.build_type_
	local build_info = BuildManager:get_build_info_by_build_type(build_type)
	if not build_info then
		build_info = BuildManager:get_build_data(build_type)
		return false, build_info
	end
	local depend_lv = soldier_info.unlock_
	return depend_lv <= build_info.lv_, build_info
end

-- function load_img(self, path, img, parent)
-- 	if not parent.gameObject.activeSelf then return end
-- 	UIUtil.set_sprite(path, img)
-- end

function set_info_item(self, index, data)
	local path = "Property"..index
	local value_txt = self.properties_:Find(path.."/Value"):GetComponent(Text)
	local mask = self.properties_:Find(path.."/BarBg/Mask")
	value_txt.text = data
	local scale = mask.localScale
	scale.x = data / self.soldier_info_.max_value_[index]
	mask.localScale = scale
end

function set_info_skill(self, obj, index)
	local skill_info = self.soldier_info_.skill_info_[index]
	local icon = obj.transform:Find("Icon"):GetComponent(Image)
	--local btn = obj.transform:Find("Icon"):GetComponent(Button)
	--local board_name = obj.transform:Find("BoardName")
	--local name = obj.transform:Find("BoardName/Text"):GetComponent(Text)
	local mask = obj.transform:Find("Mask")

	--board_name.gameObject:SetActive(true)
	mask.gameObject:SetActive(false)
	--name.gameObject:SetActive(true)
	icon.gameObject:SetActive(true)

	--name.text = skill_info.name_
	if not self:is_alive() then return end
    UIUtil.set_sprite(skill_info.path_, icon)

    local obj_tb = {}
    obj_tb.skill_id = skill_info.id_
    obj_tb.obj = obj
    PluginPointer:new(self, icon.gameObject, tips_show_handler, obj_tb)
end

function show_tips(self, obj, skill_id)
	if not obj or not skill_id then return end
	local skill = SoldierskillConfig.SoldierskillData[skill_id]
	if not skill then return end
	local title = skill.name
	local content = skill.skilldescribe
	self.tips_title_.text = title or ""
	self.tips_content_.text = content or ""

	-- 定位置

	local pos1 = obj.transform.position
	local new_pos1 = Vector3(pos1.x - 12, pos1.y - 17, pos1.z)
	--local new_pos1 = pos1
	self.tips_.transform.position = new_pos1
	self.tips_.gameObject:SetActive(true)

end

function tips_show_handler(self, event, obj_tb)
	if event == PluginPointer.POINTER_ALWAY_DOWN then
		local skill_id = obj_tb.skill_id
		local obj = obj_tb.obj
		self:show_tips(obj, skill_id)
	elseif event == PluginPointer.POINTER_UP then
        self.tips_.gameObject:SetActive(false)
    end
end


function play_timer(self, soldier)
	if not soldier then return end
	if not soldier.start_time_ or not soldier.end_time_ then return end
	local start_time = soldier.start_time_
	local end_time = soldier.end_time_
	local total_time = math.floor(soldier.total_time_)

	local curr_second = total_time - (math.floor(end_time - Net.server_time()))
	if curr_second < 0 then curr_second = 0 end

 	local last_time = Net.server_time()
 	self.lua_timer_ = LuaTimer.Add(0, 1000, function()
 		--时间不精确处理
        if Net.server_time() - last_time > 1 then
            curr_second = curr_second + 1
        end
        last_time = Net.server_time()

        if curr_second > total_time then
            return false
        end
        self.cancel_timer_.text = UIUtil.format_time(total_time - curr_second)
		self.timer_slider_.value = curr_second / total_time
        curr_second = curr_second + 1
 	end)
end

function close_lua_timer(self)
	if self.lua_timer_ then
    	LuaTimer.Delete(self.lua_timer_)
    	self.lua_timer_ = nil
    end
end

function on_soldier_drill_finished(self, build_id, soldier_id)
	if self.build_info_ and self.build_info_.id_ == build_id then
		self:close()
	end
end

function callback_end_editor(self, event_data)
	local input = tonumber(event_data)
	if not input then return end
	if input <= 0 then
		input = 1
	elseif input >= self.max_count_ then
		input = self.max_count_
	end
	if input == self.slider_.value then
		self:callback_soldier_change(input)
	end
	self.slider_.value = tonumber(input)
end

function callback_soldier_change(self, event_data)
	self.soldier_cnt_ = event_data
	local spend_data = self.soldier_info_.spend_
	--self.input_field_.text = event_data
	self.number_txt_.text = event_data.."/"..self.max_count_

	self.is_enough_ = true

	for i = 1, config.Prop_Max do
		if spend_data[i] then
			local path = "ResItem"..spend_data[i][1]
			local txt = self.res_panel_:Find(path.."/Num"):GetComponent(Text)
			local icon = self.res_panel_.transform:Find(path.."/Icon"):GetComponent(Image)

			self.spend_obj_tb_[i].gameObject:SetActive(true)
			--GameObject
			--get data
			local str = spend_data[i][3] * event_data
			local had_money = ItemManager:get_resource(spend_data[i][1])
			if not had_money then had_money = 0 end
			if had_money < str then
				str = UIUtil.res_num_to_str(str)
				str = lang("UI_SOLDIER_PROPS_COUNT", str)
				self.is_enough_ = false
			else
				str = UIUtil.res_num_to_str(str)
				self.is_enough_ = true
			end
			--set data
			txt.text = str
			if not self:is_alive() then return end
    		UIUtil.set_sprite("UI/Common/Item/"..spend_data[i][1], icon)
		else
			local path = "ResItem"..i
			local txt = self.res_panel_.transform:Find(path.."/Num"):GetComponent(Text)
			local icon = self.res_panel_.transform:Find(path.."/Icon"):GetComponent(Image)
			if not self:is_alive() then return end
			UIUtil.set_sprite("UI/Common/Item/"..i, icon)
			txt.text = "0"
		end
	end

	local remaining_time = self.soldier_info_:get_drill_time(event_data)
	self.timer_txt_.text = UIUtil.format_time(remaining_time)
	--设置金币数量
	local cnt = self:set_gold_number(remaining_time)
	self.gold_count_1_.text = UIUtil.res_num_to_str(cnt)
end

function callback_promote(self, event_data)
	--正在训练无法晋升
	if self.timer_exis_ then
		--local hint_str = self.build_info_.name_.."正在训练，暂时无法晋升"
		local hint_str = lang("UI_SOLDIERDES_HINT3", self.build_info_.name_)
		MsgCenter.send_message(Msg.SHOW_HINT, hint_str)
		return
	end
	if self.soldier_info_ and self.soldier_info_.id_ then
		--当前兵未解锁
		if not self.unlock_ then
			self:show_hint_not_lock() -- 提示
			return
		end
		if self.soldier_info_.number_ <= 0 then

			MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_SOLDIERDES_HINT2"))
			return
		end
		-- -1 是因为要多算一个
		if self.soldier_unlock_[1].lv_ - 1 <= self.soldier_info_.lv_ then
			self:show_hint_not_lock()
			return
		end
		local next_soldier
		for k, v in ipairs(self.soldier_unlock_) do
			if v.soldier_type_ == self.soldier_info_.soldier_type_ then
				next_soldier = v
				break
			end
		end
		--参数：士兵id ，晋升目标士兵的id，可晋升的最大数量，建筑id
		UIManager.open_window("SoldierPromoteWindow", function()
			self.is_click_lvup_btn_ = true
			self.curr_select_icon_ = self.soldier_info_.lv_ 
		end, self.soldier_info_.id_, next_soldier.id_, self.max_count_, self.build_info_.id_)		  
	end
end

--点击详情icon
function callback_info_btn(self, event_data)
	if self.soldier_info_ and self.build_info_ then
		UIManager.open_window("SoldierDetailsWindow", nil, self.soldier_info_.lv_, self.build_info_.id_)
	end
end

--显示当前士兵或者晋升士兵未解锁 情况下的提示
function show_hint_not_lock(self)
	local soldier = SoldierManager:get_soldier_info_by_id(self.soldier_info_.id_ + 2)
	if soldier then
		local build_type = soldier.build_type_
		local lv = soldier.unlock_
		local build = BuildManager:get_build_info_by_build_type(build_type)
		--local str = build.name_.."达到"..lv.."级时可晋升"..soldier.lv_.."级"..soldier.name_
		local str = lang("UI_SOLDIER_PROMOTE_HINT", build.name_, lv, soldier.lv_, soldier.name_)
		MsgCenter.send_message(Msg.SHOW_HINT, str)
	end
end

function callback_add_btn(self, event_data)
	if self.slider_.value >= self.max_count_ then
		return
	end
	self.slider_.value = self.slider_.value + 1
end

function callback_sub_btn(self, event_data)
	if self.slider_.value <= Silder_MinCount then
		return
	end
	self.slider_.value = self.slider_.value - 1
end

--道具加速
function callback_prop_btn(self, event_data)
	local build_id = self.build_info_.id_
	if not build_id then return end
	UIManager.open_window("SpeedUpWindow", nil, config.SPEEDUP_DRILL, build_id)
end

--金币加速
function callback_gold_btn(self, event_data)
	local build_id = self.build_info_.id_
	if not build_id then return end
	local req_msg = {}
	req_msg.id = self.build_info_.id_
	self:show_tips_view(req_msg)
end

--立即加速
function callback_immediately_btn(self, event_data)
	self.is_click_gole_lvup_btn_ = true
	self.curr_select_icon_ = self.soldier_info_.lv_
	local res_msg = {}
	res_msg.id = self.build_info_.id_
	res_msg.soldier = self.soldier_info_.id_
	res_msg.soldiercnt = self.soldier_cnt_
	local msg_ = {}
	msg_.title = ""
	msg_.content = lang("UI_SOLDIER_FINISH")
	msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
	msg_.callback = function(index)
		if index == 2 then
			Net.send("build_soldier_finish", res_msg, function(result)
				if result.e == 0 then
					self:on_open()
					local str = lang("UI_HINT_DRILL_COMPLETE", self.soldier_info_.lv_, self.soldier_info_.name_)
					MsgCenter.send_message(Msg.SHOW_HINT, str)
				elseif result.e == 7 then
					MsgCenter.send_message(Msg.SHOW_HINT, lang("ITEM_NOT_ENOUGH"))
				end
			end)
		end
	end
	MsgCenter.send_message(Msg.SHOW_NOTIFY, msg_)
end

function show_tips_view(self, req_msg)
	local msg_ = {}
	msg_.title = ""
	msg_.content = lang("UI_SOLDIER_FINISH")
	msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
	msg_.callback = function(index)
		if index == 2 then
			Net.send("build_soldier_dectime", req_msg, function(result)
				if result.e == 5 then
					MsgCenter.send_message(Msg.SHOW_HINT, lang("ITEM_NOT_ENOUGH"))
				elseif result.e == 3 then
					self:close()
				elseif result.e == 0 then
					self:on_open()
				end
			end)
		end
    end
    MsgCenter.send_message(Msg.SHOW_NOTIFY, msg_)
end

--造兵
function callback_drill_btn(self, event_data)
	--是否资我的资源满足条件
	if not self.is_enough_ then
		MsgCenter.send_message(Msg.SHOW_HINT, lang("UI_SOLDIER_PROPS_NOT_ENOUGH"))
		return
	end

	local req_msg = {}
	req_msg.id = self.build_info_.id_
	req_msg.soldier = self.soldier_info_.id_
	req_msg.soldiercnt = self.soldier_cnt_
	Net.send("build_soldier", req_msg, function(result)
		if result.e == 3 then
			elog("There are already soldiers in training")
		end
		if result.e == 0 then
			MsgCenter.send_message(Msg.CITY_SOIDIER_UPDATE, self.build_info_.id_, self.soldier_info_.id_)
			self:close()
		end
	end)
end

--取消队列
function callback_cancel_btn(self, event_data)
	self:close_lua_timer()
	local msg_ = {}
    msg_.title = ""
    msg_.content = lang("UI_SOLDIER_REBATE", self.soldier_info_.rebate_)
    msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
    msg_.callback = function(index)
    	if index == 2 then
    		Net.send("build_soldier_cancel", {id = self.build_info_.id_}, function(result)
    			if result.e ~= 0 then
    				elog("cancel be fail! message = build_soldier_cancel, id = %s, result.e = %s", self.build_info_.id_, result.e)
    			end
				if result.e == 0 then
					self.space_class_:stop_timer_2()
					self:close()
				end
			end)
		end
    end
    MsgCenter.send_message(Msg.SHOW_NOTIFY, msg_)
end

function callback_select(self, index)
	if type(index) ~= "number" then return end
	if index < 1 or index > #self.soldier_info_all_ then return end
	self.curr_select_icon_ = index
	self:close_lua_timer()   --clear计时器
	local icon = self.icon_preson_tb_[index]
	self.selected_:SetParent(icon.transform, false)
	self.selected_.gameObject:SetActive(true)
	self:on_soldier_change(index) --刷新页面
	self:show_plane() --显示底部面板
	self:callback_end_editor(self.max_count_) --刷新buttom

	self:update_preson_img() --更新士兵角色
end

function update_preson_img(self)
	-- local people_path = self.soldier_info_.path_
	-- UIUtil.set_sprite(people_path, self.people_img_:GetComponent(Image)) --设置人物img
	

	local soldier_type = self.soldier_info_.soldier_type_
	local lv = self.soldier_info_.lv_
	--临时判断
	local fn = Application.dataPath..string.format("/BundleRes/Model/Soldier/soldier_type_%d/lv_%d/siji_SkeletonData.asset", soldier_type, lv)
	local file, _ = io.open(fn)
	if not file then
		soldier_type = 2
		lv = 3
	end

	local draw_go = self.people_img_.gameObject
	local draw_go_skeleton = self.people_img_:GetComponent(Spine.Unity.SkeletonGraphic)
	if draw_go_skeleton then
		GameObject.Destroy(draw_go_skeleton)
	end

	GameUtil.BuildSkeletonDataAsset_Soldier(soldier_type, lv, draw_go, function()
			draw_go.transform.localScale = Vector3(0.1, 0.1, 0.1)
			--local draw_go_skeleton = draw_go.transform:GetComponent(Spine.Unity.SkeletonGraphic)
			--draw_go_skeleton.color = Color(1, 1, 1, 0.5)
	end)
end

function callback_back_btn(self, event_data)
	self:close()
end

