local RecruitGainRewardWindow = {}
setmetatable(RecruitGainRewardWindow, {__index = _G.BaseWindow})


local UIUtil = _G.UIUtil
local RecruitManager = _G.RecruitManager
local ItemManager = _G.ItemManager
local HeroManager = _G.HeroManager


function RecruitGainRewardWindow:on_init()
    local ty = self.data[1]
    local times = self.data[2]
    local items = self.data[3]

    local btnGroup = self.transform:Find("Panel/ButtonGroup")
    local ensureBtn = btnGroup:Find("Button2"):GetComponent(Button)
    self:add_event_handler(ensureBtn.onClick, function() self:close() end)
    local againBtn = btnGroup:Find("Button1")
    self:add_event_handler(againBtn:GetComponent(Button).onClick, function()
        local send
        if times == 1 then
            send = RecruitManager:recruit_free(ty)
            if not send then
                send = RecruitManager:recruit_one(ty)
            end
        elseif times == 10 then
            send = RecruitManager:recruit_ten(ty)
        end
        if send then self:close() end
    end)
    local prop
    if times == 1 then
        prop = RecruitManager.costProp[ty].onePrice
    elseif times == 10 then
        prop = RecruitManager.costProp[ty].tenPrice
    end
    local cfg = ItemManager:get_ui_info(prop)
    UIUtil.set_sprite(cfg.icon, againBtn:Find("Item"):GetComponent(Image))
    local leftTxt = againBtn:Find("AmountTxt/Left"):GetComponent(Text)
    local rightTxt = againBtn:Find("AmountTxt/Right"):GetComponent(Text)
    local originColor = leftTxt.color
    local on_item_change = function()
        local has = ItemManager:get_count_by_prop(prop)
        leftTxt.text = has
        if has < prop[3] then
            leftTxt.color = UIUtil.get_color(config.FONT_COLOR.RED)
        else
            leftTxt.color = originColor
        end
        rightTxt.text = prop[3]
    end
    on_item_change()
    self.messager_:add_listener(Msg.ITEM_CHANGE, on_item_change)

    local itemContent = self.transform:Find("Panel/Content")
    local card = self.transform:Find("Cache/Card").gameObject
    card:SetActive(false)
    for _, item in ipairs(items) do
        local obj = GameObject.Instantiate(card)
        obj:SetActive(true)
        obj.transform:SetParent(itemContent, false)
        local iconArea = obj.transform:Find("IconArea")
        iconArea:Find("Count/Text"):GetComponent(Text).text = item[3]
        local icon
        local data
        if ItemManager.is_item_type(item[1]) then
            local cfg = ItemManager:get_config(item[2])
            data = {
                name = cfg.name,
                icon = cfg.icon,
                quality = "UI/Common/Quality/item_"..cfg.quality,
            }
            icon = iconArea:Find("Icon"):GetComponent(Image)
        elseif item[1] == config.ITEM_HERO then
            local cfg = HeroManager:get_config(item[2])
            data = {
                name = cfg.name,
                icon = cfg.icon,
                quality = "UI/Common/Quality/hero_"..cfg.quality,
            }
            icon = iconArea:Find("Icon/Head"):GetComponent(Image)
        end
        obj.transform:Find("NameTxt"):GetComponent(Text).text = data.name
        UIUtil.set_sprite(data.quality, iconArea:GetComponent(Image))
        UIUtil.set_sprite(data.icon, icon)
    end
end


return RecruitGainRewardWindow
