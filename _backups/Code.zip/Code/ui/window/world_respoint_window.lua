-- 资源采集详情
module("WorldRespointWindow",package.seeall)
setmetatable( WorldRespointWindow, {__index = BaseWindow} )

--1.准备UI（UI美术资源加载）
function on_resource(self)
    local list = {
        "hero/HeroCard"
    }

    Yield(UIUtil.load_component(list, function(prefabs) 
        self.hero_card_prefab_ = prefabs[1]
    end))
end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self) 
    self.btn_close_ = self.transform:Find("WindowObj/Close"):GetComponent(Button)
	self:add_event_handler(self.btn_close_.onClick, function()
        self:close()
    end)
    self.item_panel_ = self.transform:Find("WindowObj/InfoPanel/Contents/ItemList")
    self.item_txt_ = {}
    for i=1,5 do
        self.item_txt_[i] = self.item_panel_:Find("Item"..i.."/ItemName"):GetComponent(Text)
    end
    self.item_use_ = self.transform:Find("WindowObj/InfoPanel/AddBtn"):GetComponent(Button)
    self:add_event_handler(self.item_use_.onClick, on_use_item_handler)
    self.obj_icon_ = self.transform:Find("WindowObj/InfoPanel/Icon"):GetComponent(Image)
    
    self.soldier_panel_ = self.transform:Find("WindowObj/TroopPanel/Contents/SoldierList")
    self.soldier_prefab_ = self.transform:Find("WindowObj/Cache/Soldier").gameObject
    self.soldier_prefab_:SetActive(false)
    self.soldier_go_ = {}
    
    self.respoint_dect_ = self.transform:Find("WindowObj/InfoPanel/DescGroup/DescTxt"):GetComponent(Text)
    self.player_name_ = self.transform:Find("WindowObj/TroopPanel/DescGroup/Name"):GetComponent(Text)
    
    -- hero panel
    self.hero_parent_ = {}
    self.hero_go_ = {}
    self.hero_card_ = {}
    for i=1,2 do
        local str = string.format("WindowObj/TroopPanel/HeroContent/Hero%d/HeroCard", i)
        self.hero_card_[i] = self.transform:Find("WindowObj/TroopPanel/HeroContent/Hero"..i)
        self.hero_parent_[i] = self.transform:Find(str)
    end
    self.messager_:add_listener(Msg.WORLD_RESPOINT_DELETE, on_respoint_delete) 
    self.messager_:add_listener(Msg.WORLD_RESPOINT_REFRESH, on_respoint_delete) 
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
    self.obj_ = self.data[1]
    self:init_item_panel()
    _G.WorldManager:GetTroops(self.obj_, function(troops)
        self.soldier_list_ = troops.soldiers
        self.heroesList = troops.soldiers
        self:init_soldier_panel()
        self:init_hero_panel()
    end)
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
    if self.time_count_ then
        LuaTimer.Delete(self.time_count_)
        self.time_count_ = nil
    end
    if self.soldier_go_ then
        for k,v in pairs(self.soldier_go_) do
            if v then
                Object.Destroy(v)
            end
        end  
    end
    self.soldier_go_ = nil
end

function init_item_panel(self)
    local prop = self.obj_:get_prop()
    local path = string.gsub(prop.model, "Sprites/", "")
    UIUtil.set_sprite(path, self.obj_icon_)
    self.respoint_dect_.text = string.format("等级%d %s", prop.level, self.obj_:get_name())
--    lang("RESPOINT_1",
--        prop.level, self.obj_:get_name(), self.obj_.x_, self.obj_.z_)
    self.item_use_.gameObject:SetActive(true)
    if WorldManager.respoint_buff_ then
        local time = WorldManager.respoint_buff_.ti - Net.server_time()
        if time < 0 then time = 0 end
        self.item_txt_[5].text = UIUtil.format_time(time)
        local prop = self.obj_:get_prop()
        if prop.type == config.ITEM_GOLD then
            self.item_use_.gameObject:SetActive(false)
            self.item_txt_[5].text = lang("RESPOINT_24")
        else
            self.item_txt_[5].text = UIUtil.format_time(time)
        end
    else
        self.item_txt_[5].text = "00:00:00"
    end
    local server_speed = self.obj_.speed_ * 3600
    local base_speed = self.obj_:get_prop().speed * 3600
    local delta = server_speed - base_speed
    local str1 = lang("RESPOINT_2", base_speed)
    local str2 = lang("RESPOINT_2", delta)
    self.item_txt_[2].text = str1
    self.item_txt_[3].text = string.format("<color=#3CC14F>+%s</color>", str2)
    
    -- 时时刷新
    if self.time_count_ then
        LuaTimer.Delete(self.time_count_)
        self.time_count_ = nil
    end 
    self.time_count_ = LuaTimer.Add( 0, 100, function()
        local num = self.obj_:get_res_num()
        self.item_txt_[1].text = num
        self.item_txt_[4].text = math.floor(self.obj_.all_cnt_ - num)
        if WorldManager.respoint_buff_ then
            local time = WorldManager.respoint_buff_.ti - Net.server_time()
            if time < 0 then time = 0 end
            self.item_txt_[5].text = UIUtil.format_time(time)
        end
    end)
end

function init_soldier_panel(self)
    if not self:is_alive() then return end
    --UIUtil.destroy_all_children(self.soldier_panel_)
    local count = 0
    for i,v in ipairs(self.soldier_list_) do
        if not self.soldier_go_[i] then
            self.soldier_go_[i] = GameObject.Instantiate(self.soldier_prefab_)
            self.soldier_go_[i].transform:SetParent(self.soldier_panel_, false)
        end
        self.soldier_go_[i]:SetActive(true)
        local prop = SoldierManager:get_soldier_prop_by_id(v[1])
        local num = self.soldier_go_[i].transform:Find("Value"):GetComponent(Text)
        local name = self.soldier_go_[i].transform:Find("Name"):GetComponent(Text)
        num.text = v[2]
        count = count + v[2]
        name.text = lang("RESPOINT_3", prop.lv, prop.name)
    end
    self.player_name_.text = string.format("<color=#EBB555>%s</color>（%d）", self.obj_.name_, count)
end

function on_respoint_delete(self, id)
    if self.obj_.idx_ ~= id then return end
    self:close()
end

function on_use_item_handler(self, event)
    UIManager.open_window("ItemRespointWindow", nil, self.obj_)
end

function init_hero_panel(self)
    local hero_list = self.heroesList
    table.sort(hero_list, function(x, y)
		return x.pos_ < y.pos_
	end)
    for i=1,2 do
        local bg = self.hero_parent_[i]:Find("../Background"):GetComponent(Image)

        local bg_btn = self.hero_parent_[i]:Find("../Background"):GetComponent(Button)

        if hero_list[i] then
            local v = hero_list[i]
            bg.color = Color(1, 1, 1, 0)
            if not self.hero_go_[i] then
                local card = GameObject.Instantiate(self.hero_card_prefab_)
                card.transform:SetParent(self.hero_parent_[i], false)
                card:SetActive(true)
                self.hero_go_[i] = HeroCard:new(self)
                self.hero_go_[i]:AddLuaComponent(card)
                self.hero_go_[i]:init()
            end
            self.hero_go_[i].gameObject:SetActive(true)
            self.hero_go_[i]:set_data_troops(v, i)

        else
            self.hero_card_[i].gameObject:SetActive(false)
            bg.color = Color(1, 1, 1, 1)
        end
    end
end