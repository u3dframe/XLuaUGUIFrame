-- 行军收兵界面
module("ItemJourneyReturnWindow",package.seeall)
setmetatable( ItemJourneyReturnWindow, {__index = BaseWindow} )


--1.准备UI（UI美术资源加载）
local BasicConfig = _G.Database.BasicConfig


function on_resource(self)

end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self) 
    self.btn_close_ = self.transform:Find("WindowObj/Close"):GetComponent(Button)
	self:add_event_handler(self.btn_close_.onClick, function()
        self:close()
    end)
    self.item_panel_ = self.transform:Find("WindowObj/ItemPanel/Contents")
    self.item_prefab_ = self.transform:Find("WindowObj/ItemPanel/Contents/ItemCard").gameObject
    self.item_prefab_:SetActive(false)
    self.item_go_ = {}    
    self.messager_:add_listener(Msg.WORLD_MARCH_DELETE, on_march_delete) 
    self.messager_:add_listener(Msg.ITEM_CHANGE, on_item_change) 
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
    self.march_ = WorldManager:get_march_by_idx(self.data[1])
    self.items_ = {}
    local item = ItemManager:get_item_by_id(BasicConfig.BasicData.armycancel)
    if item then
        table.insert(self.items_, item)
    end
    UIUtil.hide_all_children(self.item_panel_)
    for i,v in ipairs(self.items_) do
        if not self.item_go_[i] then
            local go = GameObject.Instantiate(self.item_prefab_)
            go.transform:SetParent(self.item_panel_, false)
            self.item_go_[i] = go
        end
        self.item_go_[i].gameObject:SetActive(true)
        self.item_go_[i].gameObject.name = "item"..i
        local name = self.item_go_[i].transform:Find("NameTxt"):GetComponent(Text)
        local desc = self.item_go_[i].transform:Find("DescTxt"):GetComponent(Text)
        local icon = self.item_go_[i].transform:Find("Item/IconArea/Icon"):GetComponent(Image)
        local background = self.item_go_[i].transform:Find("Item/Background"):GetComponent(Image)
        local count = self.item_go_[i].transform:Find("Item/IconArea/UseCount"):GetComponent(Text)
        local btn = self.item_go_[i].transform:Find("UseBtn"):GetComponent(Button)
        self:add_event_handler(btn.onClick, on_use_item_handler, v.id_)
        local prop = v:get_prop()
        name.text = prop.name
        count.text = v.count_
        desc.text = prop.desc
        UIUtil.set_sprite(prop.icon, icon)
        UIUtil.set_sprite("UI/Common/Quality/item_"..prop.quality, background)
    end
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)

end

function on_march_delete(self, id)
    if self.march_.idx_ ~= id then return end
    self:close()
end

function on_item_change(self, data)
    self:on_open()
end

function on_use_item_handler(self, event, itemid)
    if not ItemManager:check_item_count(itemid) then
        local prop = ItemManager:get_item_prop_by_id(itemid)
        local str = lang("RESOURCE_BUILDING_3", prop.name)
        MsgCenter.send_message(Msg.SHOW_HINT, str)
        return
    end
    
    local msg_ = {}
    msg_.title = lang("UI_BASIC_HINT")
    msg_.content = lang("EXPEDITION_8")
    msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
    msg_.callback = function(index) 
        if index == 2 then
            local data = {}
            data.id = self.march_.idx_
            --WorldAniTmp.march_ratio_protect_[self.march_.idx_] = 1
            Net.send("army_cancel", data, function(result)
                --WorldAniTmp.march_ratio_protect_[self.march_.idx_] = nil
                if result.e == 0 then
                    self:close()
                end
            end)
        end
    end
    MsgCenter.send_message(Msg.SHOW_NOTIFY,msg_)
end