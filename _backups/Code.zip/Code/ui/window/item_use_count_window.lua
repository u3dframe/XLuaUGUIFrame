module("ItemUseCountWindow", package.seeall)
setmetatable(ItemUseCountWindow, {__index = BaseWindow})


SLIDER_MIN_VALUE = 1


--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self)
	--data
	self.item_ = self.data[1]
	self.on_success_ = self.data[2]
	self.max_use_count_ = self.item_.count_
	self.use_count_ = self.max_use_count_

	local close_btn = self.transform:Find("Panel/Top/CloseBtn"):GetComponent(Button)
	self:add_event_handler(close_btn.onClick, on_close_click)
	local use_btn = self.transform:Find("Panel/UseBtn"):GetComponent(Button)
	self:add_event_handler(use_btn.onClick, on_use_click)
	
	local item_card = self.transform:Find("Panel/Inside/ItemCard")
	UIUtil.set_sprite("UI/Common/Quality/item_"..self.item_.prop_.quality, item_card:GetComponent(Image))
	local icon = item_card:Find("Icon")
    UIUtil.set_sprite(self.item_.prop_.icon, icon:GetComponent(Image))
	
	local txts = self.transform:Find("Panel/Inside/Scroll View/Viewport/Content")
	local confirm_txt = txts:Find("ConfirmText"):GetComponent(Text)
	confirm_txt.text = lang("ITEM_CONFIRM_TO_USE", self.item_.prop_.name)
	self.use_effect_txt_ = txts:Find("UseEffectText"):GetComponent(Text)
	self.inherent_rewards_ = {}
	self.random_rewards_ = {}
	if self.item_.prop_.usepara then
		if self.item_.prop_.usetype == config.ITEM_USE_TYPES.GAIN_ALL then
			self.inherent_rewards_ = self.item_.prop_.usepara
		elseif self.item_.prop_.usetype == config.ITEM_USE_TYPES.GAIN_RANDOM then
			self.random_rewards_ = self.item_.prop_.usepara
		elseif self.item_.prop_.usetype == config.ITEM_USE_TYPES.DROP then
			local dropid = self.item_.prop_.usepara[1]
			self.random_rewards_ = ItemManager:get_drop_data(dropid)
			for i = 2, #self.item_.prop_.usepara do
				table.insert(self.inherent_rewards_, self.item_.prop_.usepara[i])
			end
		end
	end
	self:refresh_use_effect_txt()

	local slider_bar = self.transform:Find("Panel/Inside/SliderBar")
	self.num_txt_ = slider_bar:Find("Num/Text"):GetComponent(Text)
	local add_btn = slider_bar:Find("Slider/AddBtn"):GetComponent(Button)
	self:add_event_handler(add_btn.onClick, on_add_click)
	local sub_btn = slider_bar:Find("Slider/SubBtn"):GetComponent(Button)
	self:add_event_handler(sub_btn.onClick, on_sub_click)
	self.slider_ = slider_bar:Find("Slider/NumberSlider"):GetComponent(Slider)
	self:add_event_handler(self.slider_.onValueChanged, on_value_changed)
	self.slider_.maxValue = self.max_use_count_
	self.slider_.minValue = 0
	self.slider_.value = self.max_use_count_
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
	
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)

end

function refresh_use_effect_txt(self)
	local ir = {}
	for _, reward in pairs(self.inherent_rewards_) do
		local cfg = ItemManager:get_ui_info(reward)
		table.insert(ir, string.format("%s*%s", cfg.name, UIUtil.res_num_to_str(reward[3] * self.use_count_)))
		table.insert(ir, ",")
	end
	table.remove(ir)
	local rr = {}
	for _, reward in pairs(self.random_rewards_) do
		local cfg = ItemManager:get_ui_info(reward)
		table.insert(rr, string.format("%s*%s", cfg.name, UIUtil.res_num_to_str(reward[3] * self.use_count_)))
		table.insert(rr, ",")
	end
	table.remove(rr)
	local str = ""
	if #ir > 0 then
		str = str..string.format("%s %s", lang("ITEM_USE_TO_GAIN"), table.concat(ir))
		if #rr > 0 then
			str = str.."\n"
		end
	end
	if #rr > 0 then
		str = str..string.format("%s %s", lang("ITEM_USE_TO_GAIN_RANDOM"), table.concat(rr))
	end
	self.use_effect_txt_.text = str
end

function on_value_changed(self, event_data)
	if self.slider_.value < SLIDER_MIN_VALUE then
		self.slider_.value = SLIDER_MIN_VALUE
	end
	self.use_count_ = self.slider_.value
	self.num_txt_.text = string.format("%s/%s", self.use_count_, self.max_use_count_)
	self:refresh_use_effect_txt()
end

function on_add_click(self, event_data)
	if self.slider_.value >= self.slider_.maxValue then
		return
	end
	self.slider_.value = self.slider_.value + 1
end

function on_sub_click(self, event_data)
	if self.slider_.value <= SLIDER_MIN_VALUE then
		return
	end
	self.slider_.value = self.slider_.value - 1
end

function on_close_click(self, event_data)
	self:close() 
end

function on_use_click(self, event_data)
	self.item_:confirm_to_use(self.use_count_, self.on_success_)
	self:close()
end

