module("SoldierPromoteWindow", package.seeall)
setmetatable(SoldierPromoteWindow, {__index = BaseWindow})

Silder_Min = 1 --滑动条最小值

Attribute = config.SOLDIER_ATTR --需要显示的属性id

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self)
	self.soldier_id_ = self.data[1]
	self.next_soldier_id_ = self.data[2]
	self.max_count_ = self.data[3]
	self.build_id_ = self.data[4]
	self.soldier_info_ = SoldierManager:get_soldier_info_by_id(self.soldier_id_)
	self.next_soldier_info_ = SoldierManager:get_soldier_info_by_id(self.next_soldier_id_)

	self.panel_ = self.transform:Find("Panel")
	-- top
	self.title_ = self.panel_.transform:Find("Top/Title/Text"):GetComponent(Text)
	self.close_btn_ = self.panel_.transform:Find("Top/CloseBtn"):GetComponent(Button)
	-- center
	self.left_ = self.panel_.transform:Find("Center/Left")
	self.right_ = self.panel_.transform:Find("Center/Right")
	--Buttom
	-------->props
	self.props_rect_ = self.panel_.transform:Find("Buttom/Props")
	-------->slider
	local slider_rect = self.panel_.transform:Find("Buttom/SliderBar")
	self.slider_ = slider_rect:Find("Slider/NumberSlider"):GetComponent(Slider)
    self.number_ = slider_rect:Find("Num/Text"):GetComponent(Text)
    self.add_btn_ = slider_rect:Find("Slider/AddBtn"):GetComponent(Button)
    self.sub_btn_ = slider_rect:Find("Slider/SubBtn"):GetComponent(Button)
	-------->button
	self.gold_lvup_btn_ = self.panel_.transform:Find("Buttom/Buttons/GoldPromoteBtn"):GetComponent(Button)
	self.normal_lvup_btn_ = self.panel_.transform:Find("Buttom/Buttons/PromoteBtn"):GetComponent(Button)
	self.timer_txt_ = self.panel_.transform:Find("Buttom/Buttons/PromoteBtn/Timer/Text"):GetComponent(Text)
	self.gold_txt_ = self.gold_lvup_btn_ .transform:Find("Num"):GetComponent(Text)
	--event
	self:add_event_handler(self.gold_lvup_btn_.onClick, on_gold_lvup_click)
	self:add_event_handler(self.normal_lvup_btn_.onClick, on_normal_lvup_click)
	self:add_event_handler(self.close_btn_.onClick, on_close_btn_click)
	self:add_event_handler(self.slider_.onValueChanged, on_value_changed)
	self:add_event_handler(self.add_btn_.onClick, on_add_btn_click)
	self:add_event_handler(self.sub_btn_.onClick, on_sub_btn_click)
	--self:add_event_handler(self.input_field_.onEndEdit, on_end_editor)
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
	if self.soldier_info_ and self.next_soldier_info_ then
		--设置左边的属性
		self:set_attribute_info(self.soldier_info_, self.left_)
		--设置右边的属性
		self:set_attribute_info(self.next_soldier_info_, self.right_)
		--Up info
		self.up_info_ = SoldierManager:get_lvup_info_by_lv(self.soldier_info_.id_, self.next_soldier_info_.id_)
		--晋升花费
		self.procost_ = self.up_info_.procost
		--设置晋升最大数量
		self:set_slider_value()
	end
	
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
     
end

--设置info
function set_attribute_info(self, soldier_info, parent)
	local img = parent.transform:Find("Person/ImageMask/Image")
	local name_img = parent.transform:Find("Person/NameAndLv/Name"):GetComponent(Image)
	local lv_txt = parent.transform:Find("Person/NameAndLv/Lv"):GetComponent(Text)
	local power = parent.transform:Find("PowerAndCount/Power"):GetComponent(Text)
	local number = parent.transform:Find("PowerAndCount/Number"):GetComponent(Text)

	-- if not self:is_alive() then return end
	-- UIUtil.set_sprite(soldier_info.path_, img)

 	local draw_go = img.gameObject
	local draw_go_skeleton = img:GetComponent(Spine.Unity.SkeletonGraphic)
	local soldier_type = 2
	local lv = 3

	if not draw_go_skeleton then
		GameUtil.BuildSkeletonDataAsset_Soldier(soldier_type, lv, draw_go, function()
	            draw_go.transform.localScale = Vector3(0.05, 0.05, 0.05)
	            --local draw_go_skeleton = draw_go.transform:GetComponent(Spine.Unity.SkeletonGraphic)
	            --draw_go_skeleton.color = Color(1, 1, 1, 0.5)
	    end)
	end

	UIUtil.set_sprite("UI/Window/Solider/soldier_name_"..self.soldier_info_.soldier_type_, name_img)
	lv_txt.text = lang("UI_SOLDIER_NAME_LV", soldier_info.lv_)
	power.text = soldier_info.fighting_power_
	number.text = soldier_info.number_
	--属性
	local attr = soldier_info.attribute_
	local max_value = soldier_info.max_value_
	for k, v in ipairs(Attribute) do
		if k <= 3 then
			self:set_attr_part1(k, attr[v], max_value[k], parent)
		else
			self:set_attr_part2(k, attr[v], parent)
		end
	end
end

function set_attr_part1(self, index, value, max_value, parent)
	local path = "Attributes/Attribute"..index
	local value_txt = parent.transform:Find(path.."/Text"):GetComponent(Text)
	local mask = parent.transform:Find(path.."/Slider/Mask")
	value_txt.text = value
	mask.localScale = Vector3(value / max_value, 1, 1)
end

function set_attr_part2(self, index, value, parent)
	local path = "Attributes/Attribute"..index.."/Value"
	local txt = parent.transform:Find(path):GetComponent(Text)
	txt.text = value
end

function set_props(self, event_data)
	local spend_data = self.procost_
	for i = 1, config.Prop_Max do
		local obj = self.props_rect_.transform:Find("prop"..i)
		local icon = obj.transform:Find("icon"):GetComponent(Image)
		local txt = obj.transform:Find("Text"):GetComponent(Text)

		if spend_data[i] then
			obj.gameObject:SetActive(true)
			local str = spend_data[i][3] * event_data
			local had_money = ItemManager:get_resource(spend_data[i][1])
			if not had_money then had_money = 0 end
			if had_money < str then
				str = UIUtil.res_num_to_str(str)
				str = lang("UI_SOLDIER_PROPS_COUNT", str)
				self.is_enough_ = false
			else
				str = UIUtil.res_num_to_str(str)
				self.is_enough_ = true
			end
			txt.text = str
			if not self:is_alive() then return end
			UIUtil.set_sprite("UI/Common/Item/"..spend_data[i][1], icon)
		else
			--obj.gameObject:SetActive(false)
			if not self:is_alive() then return end
			UIUtil.set_sprite("UI/Common/Item/"..i, icon)
			txt.text = "0"
		end
	end
end

--设置金币数量
function set_gold_number(self, remaining_time)
	return SoldierManager:get_gold_drill_number(remaining_time)
end

function set_slider_value(self)
	local max_value = self.max_count_ > self.soldier_info_.number_ and self.soldier_info_.number_ or self.max_count_
	self.slider_.maxValue = max_value
	self.slider_.minValue = Silder_Min
	--默认slider为最大值
	self.slider_.value = max_value
end

function on_value_changed(self, event_data)
	local time = self.up_info_.prolong * event_data / 1000
	--self.input_field_.text = event_data
	self.number_.text = event_data.."/"..self.slider_.maxValue
	self.timer_txt_.text = UIUtil.format_time(time)
	self:set_props(event_data)
	self.gold_txt_.text = self:set_gold_number(time)
	self.select_cnt_ = event_data --当前选择的数量
end

function on_end_editor(self, event_data)
	local input = tonumber(event_data)
	if not input then return end
	if input <= 0 then
		input = 1
	elseif input >= self.max_count_ then
		input = self.max_count_
	end
	if input == self.slider_.value then
		self:callback_soldier_change(input)
	end
	self.slider_.value = tonumber(input)
end

function on_add_btn_click(self, event_data)
	if self.slider_.value >= self.max_count_ then
		return
	end
	self.slider_.value = self.slider_.value + 1
end

function on_sub_btn_click(self, event_data)
	if self.slider_.value <= Silder_Min then
		return
	end
	self.slider_.value = self.slider_.value - 1
end
			
--立即晋升
function on_gold_lvup_click(self, event_data)
	local res_msg = {}
	res_msg.id = self.build_id_
	res_msg.soldier = self.soldier_id_
	res_msg.soldiercnt = self.select_cnt_
	res_msg.target = self.next_soldier_id_
	local msg_ = {}
	msg_.title = ""
	msg_.content = lang("UI_SOLDIERDES_HINT4")
	msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
	msg_.callback = function(index)
		if index == 2 then
			Net.send("promotion_soldier_finish", res_msg, function(result)
				if result.e == 0 then
					local str = lang("UI_SOLDIERDES_HINT5", self.soldier_info_.lv_, self.soldier_info_.name_)
					MsgCenter.send_message(Msg.SHOW_HINT, str)
					if self.soldier_info_.number_ <= 0 then
						self:close()
						return
					end
					self:on_open()
				end
			end)
		end
	end
	MsgCenter.send_message(Msg.SHOW_NOTIFY, msg_)
end

--普通晋升
function on_normal_lvup_click(self, event_data)
	local res_msg = {}
	res_msg.id = self.build_id_
	res_msg.soldier = self.soldier_id_
	res_msg.soldiercnt = self.select_cnt_
	res_msg.target = self.next_soldier_id_
	Net.send("promotion_soldier", res_msg, function(result)
		if result.e == 0 then
			MsgCenter.send_message(Msg.CITY_SOIDIER_UPDATE, self.build_id_, self.soldier_id_)
			self:close_all()
		end
	end)
end

function on_close_btn_click(self, event_data)
	self:close()
end