-- 背包界面
module("ItemListWindow",package.seeall)
setmetatable( ItemListWindow, {__index = BaseWindow} )


NUM_PAGES = 5

local page2type = {
    [1] = nil,  --全部
    [2] = 1,    --资源
    [3] = 2,    --加速
    [4] = 3,    --增益
    [5] = 4,    --其它
}

local type2page = {}

for p, t in pairs(page2type) do
    if t then type2page[t] = p end
end

local ItemConfig = _G.Database.ItemConfig


function get_type_by_page(page)
    return page2type[page]
end

function get_page_by_type(itemType)
    return type2page[itemType] or 1
end


--1.准备UI（UI美术资源加载）
function on_resource(self)
    Yield(UIUtil.load_component("Common/ItemCard", function(prefab)
        self.item_prefab_ = prefab
    end))
end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self)
    self.item_selected_ = self.transform:Find("Cache/Selected")
    self.item_selected_.gameObject:SetActive(false)
    local scroll_rect = self.transform:Find("Container/ListPanel")
    self.scroll_rect_ = scroll_rect:GetComponent(ScrollRect)
    self.item_content_ = scroll_rect:Find("Viewport/Content")
    self.info_ = self.transform:Find("Container/InfoPanel/Info")
    self.info_name_ = self.info_:Find("ItemName"):GetComponent(Text)
    self.info_desc_ = self.info_:Find("Desc"):GetComponent(Text)
    self.detail_btn_ = self.info_:Find("DetailBtn")
    self.use_btn_ = self.info_:Find("UseBtn")

    local detail_item = GameObject.Instantiate(self.item_prefab_)
    detail_item.transform:SetParent(self.info_:Find("ItemCard"), false)
    self.info_item_ = ItemCard:new()
    self.info_item_:AddLuaComponent(detail_item)
    self.info_item_:init()
    self.info_item_.name_.gameObject:SetActive(false)
    self.curr_info_id_ = nil

    self.item_objs_ = {}
    self.sorted_items_ = {}
    self.refresh_flag_ = true
    self.new_items_info_ = {}

    local toggle_group = self.transform:Find("Container/ToggleGroup")
    self.toggles_ = toggle_group:GetComponentsInChildren(Toggle).Table
    for i, t in ipairs(self.toggles_) do
        self:add_event_handler(t.onValueChanged, on_page_toggle_change, i)
    end

    self.messager_:add_listener(Msg.ITEM_CHANGE, on_item_change)

    self.current_page_ = nil
    self:turn_to_page_immediately(1)
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
    self:refresh_current_page()
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)

end

function select_item_obj(self, index)
    local item_obj = self.item_objs_[index]
    self.item_selected_:SetParent(item_obj.icon_area_, false)
    self.item_selected_.gameObject:SetActive(true)
    local new_tag = item_obj.new_tag_
    if new_tag and new_tag.gameObject.activeSelf then
        new_tag:SetAsLastSibling()
    end
    local item = self.sorted_items_[index]
    self.info_.gameObject:SetActive(true)
    if self.curr_info_id_ == item.id_ then
        self.info_item_:set_item(config.ITEM_ITEM, item.id_, item.count_)
        return
    end
    self.curr_info_id_ = item.id_
    if item:can_show_rewards() then
        self.detail_btn_.gameObject:SetActive(true)
        local btn = self.detail_btn_:GetComponent(Button)
        btn.onClick:RemoveAllListeners()
        self:add_event_handler(btn.onClick, function()
            item:show_rewards()
        end)
    else
        self.detail_btn_.gameObject:SetActive(false)
    end
    if item:can_use() then
        self.use_btn_.gameObject:SetActive(true)
        local btn = self.use_btn_:GetComponent(Button)
        btn.onClick:RemoveAllListeners()
        self:add_event_handler(btn.onClick, function()
            item:use()
        end)
    else
        self.use_btn_.gameObject:SetActive(false)
    end
    self.info_item_:set_item(config.ITEM_ITEM, item.id_, item.count_)
    self.info_name_.text = item.prop_.name
    self.info_desc_.text = item.prop_.desc
end

function deselect_item_obj(self)
    self.info_.gameObject:SetActive(false)
    self.item_selected_.gameObject:SetActive(false)
end

function refresh_item_list(self, page)
    if not self.gameObject.activeSelf then return end
    if not self.refresh_flag_ then return end
    self.refresh_flag_ = false
    local items = ItemManager:get_sorted_item_list_of_showpoint(get_type_by_page(page), config.ITEM_SHOW_POINT.ITEM_BAG)
    self.sorted_items_ = items
    for i = #self.item_objs_ + 1, #items do
        local itemobj = GameObject.Instantiate(self.item_prefab_)
        local btn = itemobj:AddComponent(Button)
        btn.transition = Selectable.Transition.None
        itemobj.transform:SetParent(self.item_content_, false)
        self.item_objs_[i] = ItemCard:new()
        self.item_objs_[i]:AddLuaComponent(itemobj)
        self.item_objs_[i]:init()
    end
    for i = #items + 1, #self.item_objs_ do
        self.item_objs_[i].gameObject:SetActive(false)
    end
    local has_selected = false
    for i = 1, #items do
        local item_obj = self.item_objs_[i]
        if not item_obj.gameObject.activeSelf then
            item_obj.gameObject:SetActive(true)
        end
        local btn = item_obj.gameObject:GetComponent(Button)
        btn.onClick:RemoveAllListeners()
        self:add_event_handler(btn.onClick, function()
            self:on_click_item_handler(i)
        end)
        local item = items[i]
        local itemid = item.id_
        item_obj:set_item(config.ITEM_ITEM, itemid, item.count_)
        --新物品标记
        local new_info = self.new_items_info_[itemid]
        if not new_info and ItemManager:is_item_new(itemid) then
            new_info = {
                [get_page_by_type()] = true,
                [get_page_by_type(item.prop_.type)] = true,
            }
            self.new_items_info_[itemid] = new_info
        end
        if new_info and new_info[page] then
            item_obj:set_new_tag(true)
            new_info[page] = nil
            if next(new_info) == nil then
                self.new_items_info_[itemid] = nil
                ItemManager:clear_new_tag(itemid)
            end
        else
            item_obj:set_new_tag(false)
        end
        if itemid == self.selected_item_id_ then
            self:select_item_obj(i)
            has_selected = true
        end
    end
    if self.selected_item_id_ then
        if not ItemManager:get_item_by_id(self.selected_item_id_) then
            self.selected_item_id_ = nil
        end
    end
    if not has_selected then
        self:deselect_item_obj()
    end
end

--立即跳转到某页
function turn_to_page_immediately(self, page)
    if page < 1 or page > NUM_PAGES then return end
    if self.current_page_ == page then return end
    self.scroll_rect_:StopMovement()
    self.scroll_rect_.verticalNormalizedPosition = 1
    self.current_page_ = page
    self.refresh_flag_ = true
    self:refresh_current_page()
end

function refresh_current_page(self)
    self:refresh_item_list(self.current_page_)
end

function refresh_page(self, page)
    self:refresh_item_list(page)
end

function on_click_item_handler(self, index)
    local item = self.sorted_items_[index]
    if not item then return end
    if item.id_ == self.selected_item_id_ then
        self:deselect_item_obj()
        self.selected_item_id_ = nil
    else
        self:select_item_obj(index)
        self.selected_item_id_ = item.id_
    end
end

function on_page_toggle_change(self, isOn, index)
    if isOn then
        self:turn_to_page_immediately(index)
    end
end

function on_item_change(self, data)
    if not data or #data == 0 then return end
    if self.current_page_ == get_page_by_type() then
        self.refresh_flag_ = true
    else
        for _, v in pairs(data) do
            local cfg = ItemConfig.ItemData[v.id]
            if cfg and self.current_page_ == get_page_by_type(cfg.type) then
                self.refresh_flag_ = true
                break
            end
        end
    end
    self:refresh_current_page()
end
