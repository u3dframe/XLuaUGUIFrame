local RandomShopRewardWindow = {}
setmetatable(RandomShopRewardWindow, {__index = _G.BaseWindow})

local MerchantConfig = _G.Database.MerchantConfig
local UI = _G.UnityEngine.UI
local lang = _G.lang

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function RandomShopRewardWindow:on_init()
    self.title = self.transform:Find("Panel/Top/Text"):GetComponent(UI.Text)
    self.title.text = lang("UI_RANDOMSHOP_REWARD_TITLE")
    self.hintTxt = self.transform:Find("Panel/Hint"):GetComponent(UI.Text)
    self.scrollPoolGrid = self.transform:Find("Panel/Bg/ScrollRect"):GetComponent(_G.ScrollPoolGrid)
    self.closeBtn = self.transform:Find("Panel/Top/CloseBtn"):GetComponent(UI.Button)
    self:add_event_handler(self.closeBtn.onClick, function()
        self:close()
    end)
end

--3.打开UI（打开/刷新UI处理）
function RandomShopRewardWindow:on_open()
    self:SetData()
end

function RandomShopRewardWindow:SetData()
    local basic = _G.MerchantConfig.MerbasicData
    self.hintTxt.text = lang("UI_RANDOMSHOP_REWARD_HINT", basic.intimacy_limit)

    local list = basic.show_reward
    _G.dump(list, "RandomShopReward list", 3, "#CF2D2D")
    if not list then
        return
    end
    self.scrollPoolGrid:InitPool(#list, function(index, obj)
        local v = list[index]
        local item = _G.ItemCard:new()
        if item and v then
            item:AddLuaComponent(obj)
            item:init()
            item:set_item_prop(v)
        end
    end)
end
return RandomShopRewardWindow