module("NotifyGoldWindow",package.seeall)
setmetatable( NotifyGoldWindow, {__index = BaseWindow})

NORMAL = 1  -- 普通按钮
GOLD   = 2  -- 金币按钮

function on_init(self) 
	self.data_tb_ = self.data[1]
	self.content_ = self.transform:Find("WindowObj/Panel/Content"):GetComponent(Text)
	self.btn_group_ = self.transform:Find("WindowObj/BtnGroup")
	-- button prefab
	self.normal_btn_ = self.transform:Find("WindowObj/Cache/NorBtn")
	self.glod_btn_ = self.transform:Find("WindowObj/Cache/GoldBtn")

	self.normal_btn_.gameObject:SetActive(false)
	self.glod_btn_.gameObject:SetActive(false)

	-- 宏定义与obj 映射表
	self.button_tb_ = {
		[NORMAL] = self.normal_btn_,
		[GOLD] = self.glod_btn_,
	}
	self:set_data()
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
	
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
     
end

------------------------------------------------------------------------------------------------

function on_show_normal_btn(self, data, obj)
	local btn_name = obj.transform:Find("Text"):GetComponent(Text)
	btn_name.text = data
end

function on_show_gold_btn(self, data, obj)
	local btn_name = obj.transform:Find("Text"):GetComponent(Text)
	local gold_cnt = obj.transform:Find("Image/Text"):GetComponent(Text)
	btn_name.text = data[1]
	gold_cnt.text = data[2]
end

Check_Type = {
	[NORMAL] = on_show_normal_btn,
	[GOLD] = on_show_gold_btn,
}

------------------------------------------------------------------------------------------------

function set_data(self)
	local content = self.data_tb_.content
	local buttons = self.data_tb_.buttons

	UIUtil.destroy_all_children(self.btn_group_.transform, true)

	self.content_.text = content
	if buttons and #buttons > 0 then
		for k, v in pairs(buttons) do
			local btn_type
			if type(v) == "string" then
				btn_type = NORMAL
			elseif type(v) == "table" then
				btn_type = GOLD
			end

			if self.Check_Type[btn_type] then
				-- clone 按钮
				local go = self:create_gameobject(self.button_tb_[btn_type])
				go.onClick:RemoveAllListeners()
				self:add_event_handler(go.onClick,function()
					if self.data_tb_.callback then
						self.data_tb_.callback(k)
					end
					self:close()
			    end)
				self.Check_Type[btn_type](self, v, go)
			end
		end
	end
end

-- 检查格式
function check_format(self, data)
	
end

function create_gameobject(self, prefab)
	local go = GameObject.Instantiate(prefab)
	go.transform:SetParent(self.btn_group_.transform, false)
	go.gameObject:SetActive(true)
	return go:GetComponent(Button)
end