--组件模块界面
local ComponentModeWindow = {}
setmetatable(ComponentModeWindow, {__index = _G.BaseWindow})


--1.准备UI（UI美术资源加载）
function ComponentModeWindow:on_resource()

end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function ComponentModeWindow:on_init()
	self.closeBtn = self.transform:Find("CloseBtn"):GetComponent(Button)
	self:add_event_handler(self.closeBtn.onClick, function()
		self:close()
	end)
end

function ComponentModeWindow:on_open()
	self:InitScrollRect()
end

--5.关闭UI（UIManager销毁UI前处理）
function ComponentModeWindow:on_close()
     
end

--ScrollRect组件
function ComponentModeWindow:InitScrollRect()
	self.scrollRect = self.transform:Find("ComponentGroup/ScrollRect"):GetComponent(ScrollPoolVertical)
	-- InitPool  参数： 1. 列表count。  2. callback(index, obj)  3. 定位
	local count = 30
	self.scrollRect:InitPool(count, function(index, obj)
		local txt = obj.transform:Find("Text"):GetComponent(Text)
		txt.text = index
	end)
end

return ComponentModeWindow