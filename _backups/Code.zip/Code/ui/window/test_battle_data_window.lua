module("TestBattleDataWindow", package.seeall)
setmetatable(TestBattleDataWindow, {__index = BaseWindow})


--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self)
	local text = self.data[1] or ""
	self.text_ = self.transform:Find("Scroll View/Viewport/Content/Text"):GetComponent(Text)
	self.text_.text = text
	local close = self.transform:Find("CloseBtn"):GetComponent(Button)
	self:add_event_handler(close.onClick, function() self:close() end)
	local copy = self.transform:Find("CopyBtn"):GetComponent(Button)
	self:add_event_handler(copy.onClick, function()
		GameUtil.CopyText(self.text_.text)
	end)
end
