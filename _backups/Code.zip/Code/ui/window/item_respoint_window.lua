-- 采集速度加成
module("ItemRespointWindow",package.seeall)
setmetatable( ItemRespointWindow, {__index = BaseWindow} )


--1.准备UI（UI美术资源加载）
local BasicConfig = _G.Database.BasicConfig


function on_resource(self)

end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self) 
    self.btn_close_ = self.transform:Find("WindowObj/Close"):GetComponent(Button)
	self:add_event_handler(self.btn_close_.onClick, function()
        self:close()
    end)
    self.item_panel_ = self.transform:Find("WindowObj/ItemPanel/Contents")
    self.item_prefab_ = self.transform:Find("WindowObj/ItemPanel/Contents/ItemCard").gameObject
    self.item_prefab_:SetActive(false)
    self.respoint_bar_ = self.transform:Find("WindowObj/BarPanel/BarGroup/BarMask"):GetComponent(Image)
    self.respoint_txt_ = self.transform:Find("WindowObj/BarPanel/BarGroup/Time"):GetComponent(Text)
    self.item_go_ = {}    
    self.messager_:add_listener(Msg.WORLD_RESPOINT_DELETE, on_respoint_delete) 
    self.messager_:add_listener(Msg.WORLD_RESPOINT_REFRESH, on_respoint_delete) 
    self.messager_:add_listener(Msg.ITEM_CHANGE, on_item_change)
    self.messager_:add_listener(Msg.RESPOINT_REFRESH, on_respoint_refresh)
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
    self.obj_ = self.data[1]
    self:refresh_bar_time()
    for i,v in ipairs(BasicConfig.BasicData.respoint) do
        local item = ItemManager:get_item_by_id(v)
        local prop = ItemManager:get_item_prop_by_id(v)
        local num = 0
        if item then
            prop = item:get_prop()
            num = item.count_
        end
        if not self.item_go_[i] then
            local go = GameObject.Instantiate(self.item_prefab_)
            go.transform:SetParent(self.item_panel_, false)
            self.item_go_[i] = go
        end
        if not prop.usepara[1][3] and num == 0 then
            self.item_go_[i].gameObject:SetActive(false)
        else
            self.item_go_[i].gameObject:SetActive(true)
        end
        if self.item_go_[i].gameObject.activeSelf then
            self.item_go_[i].gameObject.name = "item"..i
            local name = self.item_go_[i].transform:Find("NameTxt"):GetComponent(Text)
            local desc = self.item_go_[i].transform:Find("DescTxt"):GetComponent(Text)
            local icon = self.item_go_[i].transform:Find("Item/IconArea/Icon"):GetComponent(Image)
            local background = self.item_go_[i].transform:Find("Item/Background"):GetComponent(Image)
            local count = self.item_go_[i].transform:Find("Item/IconArea/UseCount"):GetComponent(Text)
            local use_btn = self.item_go_[i].transform:Find("UseBtn"):GetComponent(Button)
            local gold_btn = self.item_go_[i].transform:Find("GoldBtn"):GetComponent(Button)
            use_btn.onClick:RemoveAllListeners()
            gold_btn.onClick:RemoveAllListeners()
            if num == 0 then
                use_btn.gameObject:SetActive(false)
                gold_btn.gameObject:SetActive(true)
                self:add_event_handler(gold_btn.onClick, on_use_gold_handler, v)
            else
                use_btn.gameObject:SetActive(true)
                gold_btn.gameObject:SetActive(false)
                self:add_event_handler(use_btn.onClick, on_use_item_handler, v)
            end
            name.text = prop.name
            count.text = num
            desc.text = prop.desc
            UIUtil.set_sprite(prop.icon, icon)
            UIUtil.set_sprite("UI/Common/Quality/item_"..prop.quality, background)
        end
    end
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
    if self.time_count_ then
        LuaTimer.Delete(self.time_count_)
        self.time_count_ = nil
    end 
end

function use_before_callback(self, use_func)

end

function on_use_item_handler(self, event, itemid)
    local item = ItemManager:get_item_by_id(itemid)
    if not item then return end

    item.use_respoint_gold_ = false
    item:use()
      
end

function on_use_gold_handler(self, event, itemid)
    local msg_ = {}
    msg_.title = lang("UI_BASIC_HINT")
    if WorldManager.respoint_buff_ then
        msg_.content = lang("RESPOINT_30")
    else
        msg_.content = lang("RESPOINT_31")
    end
    msg_.buttons = {lang("UI_BASIC_CANCEL"), lang("UI_BASIC_SURE")}
    msg_.callback = function(index) 
        if index == 2 then
            local item = Item(itemid, 1)
            item.use_respoint_gold_ = true
            item:use()
        end
    end
    MsgCenter.send_message(Msg.SHOW_NOTIFY,msg_)   
end

function on_item_change(self, data)
    self:on_open()
end

function on_respoint_refresh(self)
    self:on_open()
end

function refresh_bar_time(self)
    local buff = WorldManager.respoint_buff_
    if not buff then
        self.respoint_bar_.fillAmount = 0
        self.respoint_txt_.text = "道具加速 00:00:00"
        return
    end    
    if self.time_count_ then
        LuaTimer.Delete(self.time_count_)
        self.time_count_ = nil
    end
    self.time_count_ = LuaTimer.Add( 0, 1000, function()
        local time_up = buff.ti - Net.server_time()
        if not buff.ti then
            elog("world respoint buff findn't ti, pls call wanghong check data")
            LuaTimer.Delete(self.time_count_)
            return
        end
        local time_down = buff.ti - (buff.ti or Net.server_time())
        if time_up < 0 then time_up = 0 end
        self.respoint_txt_.text = "道具加速 "..UIUtil.format_time(time_up)
        self.respoint_bar_.fillAmount = time_up / time_down
    end)
end

function on_respoint_delete(self, id)
    if self.obj_.idx_ ~= id then return end
    self:close()
end