module("NotifyWindow",package.seeall)
setmetatable( NotifyWindow, {__index = BaseWindow} )


CacheNotify = {}

function on_resource(self)

end

function on_init(self)
    self.title_ = self.transform:Find("WindowObj/Title"):GetComponent(Text)
    self.content_ = self.transform:Find("WindowObj/Panel/Content"):GetComponent(Text)
    self.button_group_ = self.transform:Find("WindowObj/BtnGroup")
    self.button_blue_prefab_ = self.transform:Find("WindowObj/ButtonBlue")
    self.button_blue_prefab_.gameObject:SetActive(false)
    self.button_yellow_prefab_ = self.transform:Find("WindowObj/ButtonYellow")
    self.button_yellow_prefab_.gameObject:SetActive(false)
    if self.data[1].cover_close then
        local btn = self.transform:Find("Background"):GetComponent(Button)
        btn.onClick:RemoveAllListeners()
        self:add_event_handler(btn.onClick,function()
            self.data[1].cover_close()
        end)
    end
    self.btn_close_ = self.transform:Find("WindowObj/Close"):GetComponent(Button)
    self:add_event_handler(self.btn_close_.onClick, function()
        AudioManager.Play("SOUND_BUTTON_CLOSE")
        if not self:check_cache() then
            self:close()
        end
        if self.data_.close_callback then
            self.data_.close_callback()
        end
    end)
    self:set_data(self.data[1])
end

function set_data(self, data)
    self.data_ = data
    self.title_.text = data.title or lang("UI_BASIC_HINT")
    self.content_.text = data.content
    
    local btn = nil
    UIUtil.destroy_all_children(self.button_group_.transform,true)
    if data ~= nil and data.buttons ~= nil then
        for i=1,#data.buttons do
            local btn_prefab
            if #data.buttons == 1 or i % 2 == 0 then
                btn_prefab = self.button_yellow_prefab_
            else
                btn_prefab = self.button_blue_prefab_
            end
            btn = GameObject.Instantiate(btn_prefab)
            btn.transform:SetParent(self.button_group_.transform, false)
            btn.transform:Find("Text"):GetComponent(Text).text = data.buttons[i]
            btn.name = i
            btn.gameObject:SetActive(true)
            self:add_event_handler(btn:GetComponent(Button).onClick, on_click_buttons, btn)
        end
    else
        btn = GameObject.Instantiate(self.button_yellow_prefab_)
        btn.transform:SetParent(self.button_group_.transform, false)
        btn.transform:Find("Text"):GetComponent(Text).text = lang("UI_BASIC_SURE")
        btn.name = tostring(1)
        btn.gameObject:SetActive(true)
        self:add_event_handler(btn:GetComponent(Button).onClick, on_click_buttons, btn)
    end

end

function get_data(self)
    return self.data_
end

function push_data(data)
    table.insert(NotifyWindow.CacheNotify, data)
end

function on_click_buttons(self, event, btn)
    if not self:check_cache() then
        AudioManager.Play("SOUND_BUTTON_COMMON")
        self:close(function()
            if self.data_.callback ~= nil then
                self.data_.callback(tonumber(btn.name))
            end
        end)
    end
end

function check_cache(self)
    if next(CacheNotify) then
        local data = CacheNotify[1]
        self:set_data(data)
        table.remove(CacheNotify, 1)
        return true
    end
    return false
end