-- 行军加速界面
module("ItemJourneySpeedWindow",package.seeall)
setmetatable( ItemJourneySpeedWindow, {__index = BaseWindow} )


--1.准备UI（UI美术资源加载）
local BasicConfig = _G.Database.BasicConfig


function on_resource(self)

end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self) 
    self.btn_close_ = self.transform:Find("WindowObj/Close"):GetComponent(Button)
	self:add_event_handler(self.btn_close_.onClick, function()
        self:close()
    end)
    self.item_panel_ = self.transform:Find("WindowObj/ItemPanel/Contents")
    self.item_prefab_ = self.transform:Find("WindowObj/ItemPanel/Contents/ItemCard").gameObject
    self.item_prefab_:SetActive(false)
    self.martch_bar_ = self.transform:Find("WindowObj/BarPanel/BarGroup/BarMask"):GetComponent(Image)
    self.martch_txt_ = self.transform:Find("WindowObj/BarPanel/BarGroup/Time"):GetComponent(Text)
    self.item_go_ = {}    
    self.messager_:add_listener(Msg.WORLD_MARCH_DELETE, on_march_delete) 
    self.messager_:add_listener(Msg.ITEM_CHANGE, on_item_change) 
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
    self.march_ = WorldManager:get_march_by_idx(self.data[1])
    self:refresh_bar_time()
    self.items_ = {}
    for i,v in ipairs(BasicConfig.BasicData.armydectime) do
        local item = ItemManager:get_item_by_id(v[1])
        if item then
            table.insert(self.items_, item)
        end        
    end
 
    UIUtil.hide_all_children(self.item_panel_)
    for i,v in ipairs(self.items_) do
        if not self.item_go_[i] then
            local go = GameObject.Instantiate(self.item_prefab_)
            go.transform:SetParent(self.item_panel_, false)
            self.item_go_[i] = go
        end
        self.item_go_[i].gameObject:SetActive(true)
        self.item_go_[i].gameObject.name = "item"..i
        local name = self.item_go_[i].transform:Find("NameTxt"):GetComponent(Text)
        local desc = self.item_go_[i].transform:Find("DescTxt"):GetComponent(Text)
        local icon = self.item_go_[i].transform:Find("Item/IconArea/Icon"):GetComponent(Image)
        local background = self.item_go_[i].transform:Find("Item/Background"):GetComponent(Image)
        local count = self.item_go_[i].transform:Find("Item/IconArea/UseCount"):GetComponent(Text)
        local btn = self.item_go_[i].transform:Find("UseBtn"):GetComponent(Button)
        btn.onClick:RemoveAllListeners()
        self:add_event_handler(btn.onClick, on_use_item_handler, v.id_)
        local prop = v:get_prop()
        name.text = prop.name
        count.text = v.count_
        desc.text = prop.desc
        UIUtil.set_sprite(prop.icon, icon)
        UIUtil.set_sprite("UI/Common/Quality/item_"..prop.quality, background)
    end
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
    if self.time_count_ then
        LuaTimer.Delete(self.time_count_)
        self.time_count_ = nil
    end 
end

function on_use_item_handler(self, event, itemid)
    local data = {}
    data.id = self.march_.idx_
    data.itemid = itemid
    Net.send("army_dectime", data, function(result)
        if result.e == 0 then
            self:on_open()
            MsgCenter.send_message(Msg.SHOW_HINT, lang("EXPEDITION_7"))
        end
    end)
        
end

function on_march_delete(self, id)
    if self.march_.idx_ ~= id then return end
    self:close()
end

function on_item_change(self, data)
    
end

function refresh_bar_time(self)
    if self.time_count_ then
        LuaTimer.Delete(self.time_count_)
        self.time_count_ = nil
    end
    self.time_count_ = LuaTimer.Add( 0, 1000, function()
        if not self:is_alive() then
            if self.time_count_ then
                LuaTimer.Delete(self.time_count_)
                self.time_count_ = nil
            end
            return
        end
        local time_up = self.march_.runinfo_.ti_end - Net.server_time()
        local time_down = (self.march_.runinfo_.ti_end + self.march_.runinfo_.ti_dec) - self.march_.runinfo_.ti_start
        if self.martch_txt_ then
            self.martch_txt_.text = UIUtil.format_time(time_up)
        end
        if self.martch_bar_ then
            self.martch_bar_.fillAmount = 1 - time_up / time_down
        end
    end)
end