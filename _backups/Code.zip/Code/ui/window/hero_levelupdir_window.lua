local HerolevelupdirWindow = {}
setmetatable( HerolevelupdirWindow, {__index = _G.BaseWindow})

local UI = _G.UnityEngine.UI
local UnityEngine = _G.UnityEngine
local HeroManager = _G.HeroManager
local lang = _G.lang
local UIUtil = _G.UIUtil

--1.准备UI（UI美术资源加载）
function HerolevelupdirWindow.on_init()

end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function HerolevelupdirWindow:on_init()
	local hero_id = self.data[1]
	self.hero_data_ = HeroManager:get_active_hero_by_id(hero_id)
	self.title_ = self.transform:Find("Panel/Top/TitleTxt"):GetComponent(UI.Text)
	self.title_.text = lang("UI_HERO_LVUP_TITLE")
	self.close_btn_ = self.transform:Find("Panel/Top/CloseBtn"):GetComponent(UI.Button)

	self.hint_txt_ = self.transform:Find("Panel/BgInside/Bg/TipsTxt"):GetComponent(UI.Text)

	self.items_group_ = self.transform:Find("Panel/BgInside/center/ScrollRect/Viewport/Content")
	self.item_prefab_ = self.transform:Find("Panel/BgInside/center/ScrollRect/Viewport/Cache/item")
	self.item_prefab_.gameObject:SetActive(false)

	self.buttons_ = self.transform:Find("Panel/BgInside/chooseoption")
	self.sub_btn_ = self.buttons_.transform:Find("SubBtn"):GetComponent(UI.Button)
	self.add_btn_ = self.buttons_.transform:Find("AddBtn"):GetComponent(UI.Button)
	self.input_field_ = self.buttons_.transform:Find("InputField"):GetComponent(UI.InputField)
	self.slider = self.buttons_.transform:Find("Slider"):GetComponent(UI.Slider)
	--self.max_btn_ = self.buttons_.transform:Find("MaxBtn"):GetComponent(UI.Button)

	self.cancel_btn_ = self.transform:Find("Panel/bottom/cancelBtn"):GetComponent(UI.Button)
	self.sure_btn_ = self.transform:Find("Panel/bottom/sureBtn"):GetComponent(UI.Button)

	self:add_event_handler(self.close_btn_.onClick, self.close_btn_handler)
	self:add_event_handler(self.sub_btn_.onClick, self.sub_btn_handler)
	self:add_event_handler(self.add_btn_.onClick, self.add_btn_handler)
	--self:add_event_handler(self.max_btn_.onClick, self.max_btn_handler)
	self:add_event_handler(self.input_field_.onEndEdit, self.on_end_edit)
	self:add_event_handler(self.slider.onValueChanged, self.OnValueChanged)
	self:add_event_handler(self.cancel_btn_.onClick, self.cancel_btn_handler)
	self:add_event_handler(self.sure_btn_.onClick, self.sure_btn_handler)

	self.items_ = {}
end

--3.打开UI（打开/刷新UI处理）
function HerolevelupdirWindow:on_open()
	if not self.hero_data_ then return end
	self:set_data()
end

--5.关闭UI（UIManager销毁UI前处理）
function HerolevelupdirWindow.on_close()

end

function HerolevelupdirWindow:set_data()
	self.prop_data_ = _G.ItemManager:get_hero_exp_item() -- 升级道具
	if not self.prop_data_ or #self.prop_data_ <= 0 then return end
	--计算出总经验
	local exp = 0
	for _, v in ipairs(self.prop_data_) do
		exp = exp + v.count_ * v.exp
	end
	--从大到小排序
    table.sort(self.prop_data_, function(x, y) return x.id_ > y.id_ end)

	local max_uplv = HeroManager:get_lv_by_exp(self.hero_data_.id_, exp)
	if not max_uplv then
		_G.dump(0, "max_uplv is nil, pls check it", 1, "#CF2D2D")
		return
	end

	--隐藏prefab
	for i = 1, #self.items_ do
        if self.items_[i] then
            self.items_[i].gameObject:SetActive(false)
        end
    end


	self.max_count_ = max_uplv - self.hero_data_.lv_ == 0 and 1 or max_uplv - self.hero_data_.lv_
	--设置slider
	self.slider.minValue = 1
	self.slider.maxValue = self.max_count_
	if self.slider.value == self.max_count_ then
		self:OnValueChanged(self.max_count_)
		return
	end
	self.slider.value = self.max_count_
end

--设置到具
function HerolevelupdirWindow:set_item_data(obj, v)
	if not obj or not v then return end
	obj.gameObject:SetActive(true)
	local bg = obj:GetComponent(UI.Image)
	local icon = obj.transform:Find("Icon"):GetComponent(UI.Image)
	--local name = obj.transform:Find("Name"):GetComponent(UI.Text)
	local number = obj.transform:Find("Board/Text"):GetComponent(UI.Text)
	local prop = v.prop_
	--name.text = prop.name
	number.text = v.choose_cnt
	if not self:is_alive() then
		return
	end
	UIUtil.set_sprite("UI/Common/Quality/Item_"..prop.quality, bg)
	UIUtil.set_sprite(prop.icon, icon)
end

function HerolevelupdirWindow.create_obj(obj, parent)
	local go = UnityEngine.GameObject.Instantiate(obj)
    go.transform:SetParent(parent, false)
    go.gameObject:SetActive(true)
    go.transform.localPosition = UnityEngine.Vector3(0, 0, 0)
    return go
end

--选择道具
function HerolevelupdirWindow:choose_prop()
	if self.input_cnt_ <= 0 then return end
	local start_lv = self.hero_data_.lv_
	--获取到目标等级 需要的经验
	local sum_exp = 0
	for i = start_lv, start_lv + self.input_cnt_ - 1 do
		local need_exp = self.hero_data_:get_exp(i)
		sum_exp = sum_exp + need_exp
	end
	sum_exp = sum_exp - self.hero_data_.cur_exp_
	--获取需要使用的道具
	local prop = {}

	for _, v in ipairs(self.prop_data_) do
		if sum_exp > 0 then
			--如果总经验小于0 break
			if sum_exp <= 0 then break end
			local need_cnt = math.ceil(sum_exp / v.exp)
			if need_cnt <= 0 then break end
			table.insert(prop, v)
			if need_cnt >= v.count_ then
				sum_exp = sum_exp - v.count_ * v.exp
				prop[#prop].choose_cnt = v.count_
			else
				--如果道具足够 不再检测下一个道具
				--sum_exp = sum_exp - need_cnt * need_cnt
				prop[#prop].choose_cnt = need_cnt
				break
			end
		else
			break
		end
	end
	return prop
end

function HerolevelupdirWindow:refresh_prop(prop)
	if not prop then return end
	if self.items_ and #self.items_ > 0 then
		for _, v in ipairs(self.items_) do
			if v then v.gameObject:SetActive(false) end
		end
	end
	--设置到具UI
	for i, v in ipairs(prop) do
		if not self.items_[i] then
			local go = self.create_obj(self.item_prefab_, self.items_group_)
			self.items_[i] = go
		end
		self:set_item_data(self.items_[i], v)
	end
end

function HerolevelupdirWindow:on_end_edit(event_data)
	local input = tonumber(event_data)
	if not input then return end
	if input <= 0 then
		input = 1
	elseif input >= self.max_count_ then
		input = self.max_count_
	end
	self.input_cnt_ = input
	self.input_field_.text = input.."/"..self.max_count_

	self.hint_txt_.text = lang("UI_HERO_HINT_LVUP", self.hero_data_.name_, self.hero_data_.lv_ + input)

	--刷新道具数量
	self.choose_prop_ = self:choose_prop()
	self:refresh_prop(self.choose_prop_)
end

function HerolevelupdirWindow:OnValueChanged(eventData)
	self:on_end_edit(eventData)
end

function HerolevelupdirWindow:sub_btn_handler()
	if not self.input_cnt_ then return end
	if self.input_cnt_ <= 1 then
		return
	end
	local result = self.input_cnt_ - 1
	self:on_end_edit(result)
end

function HerolevelupdirWindow:add_btn_handler()
	if not self.input_cnt_ then return end
	if self.input_cnt_ >= self.max_count_ then
		return
	end
	local result = self.input_cnt_ + 1
	self:on_end_edit(result)
end

function max_btn_handler()
	-- if not self.input_cnt_ then return end
	-- if self.input_cnt_ < self.max_count_ then
	-- 	self:on_end_edit(self.max_count_)
	-- end
end

function HerolevelupdirWindow:cancel_btn_handler()
	self:close()
end

function HerolevelupdirWindow:sure_btn_handler()
	if not self.prop_data_ or #self.prop_data_ <= 0 then
		return
	end

	if not self.choose_prop_ or #self.choose_prop_ <= 0 then
		return
	end

    local cost_data = {}
	for _, v in ipairs(self.choose_prop_) do
		local prop = {
			array = {_G.config.ITEM_ITEM, v.id_, v.choose_cnt}
	    }
	    table.insert(cost_data, prop)
	end

	if #cost_data <= 0 then return end

	local obj = {
		id = self.hero_data_.id_,
		cost = cost_data
    }
	_G.dump(obj, "this req msg！")
    _G.Net.send("hero_levelup", obj, function(result)
		if result.e == 0 then
			_G.printf("---------------------- > lv = %s, result.exp = %s",result.level, result.exp)
			self.hero_data_:set_level(result.level)
			self.hero_data_.cur_exp_ = result.exp
			self.hero_data_.max_exp_ = self.hero_data_:get_exp()
			self.hero_data_ = HeroManager:get_active_hero_by_id(self.hero_data_.id_)
			self:set_data()
			_G.MsgCenter.send_message(_G.Msg.CITY_HERO_LVUP)
			self:close()
		end
    end)
end

function HerolevelupdirWindow:close_btn_handler()
	self:close()
end

return HerolevelupdirWindow