-- 怪物信息界面
module("WorldMonsterInfoWindow",package.seeall)
setmetatable( WorldMonsterInfoWindow, {__index = BaseWindow} )


--1.准备UI（UI美术资源加载）
function on_resource(self)
    Yield(UIUtil.load_component("Common/ItemCard", function(prefab)
        self.item_prefab_ = prefab
    end))
end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self) 
    self.head_img_ = self.transform:Find("WindowObj/InfoPanel/Mask/HeadImg"):GetComponent(Image)
    
    self.attack_btn_ = self.transform:Find("WindowObj/AttackBtn"):GetComponent(Button)
    self:add_event_handler(self.attack_btn_.onClick, on_click_attack_handler)
    self.close_btn_ = self.transform:Find("WindowObj/CloseBtn"):GetComponent(Button)
    self:add_event_handler(self.close_btn_.onClick, function()
        self:close()
    end)
    self.name_ = self.transform:Find("WindowObj/InfoPanel/NameGroup/Name"):GetComponent(Text)
    self.lv_ = self.transform:Find("WindowObj/InfoPanel/NameGroup/Lv"):GetComponent(Text)
    self.power_ = self.transform:Find("WindowObj/InfoPanel/Power/Text"):GetComponent(Text)
    self.distane_ = self.transform:Find("WindowObj/InfoPanel/NameGroup/Distance/Text"):GetComponent(Text)
    self.axis_ = self.transform:Find("WindowObj/InfoPanel/NameGroup/Axis/Text"):GetComponent(Text)
    
    self.vip_tips_ = self.transform:Find("WindowObj/InfoPanel/DescTxt"):GetComponent(Text)
    self.vip_tips1_ = self.transform:Find("WindowObj/DescTxt"):GetComponent(Text)
    self.item_panel_ = self.transform:Find("WindowObj/ItemGroup/ItemPanel")
    
    self.win_rect_ = self.transform:Find("WindowObj"):GetComponent(RectTransform)
    self.item_rect_ = self.transform:Find("WindowObj/ItemGroup"):GetComponent(RectTransform)
    
    self.item_panel1_ = self.transform:Find("WindowObj/ItemGroup/ItemPanel")
    self.item_panel2_ = self.transform:Find("WindowObj/FirstItemGroup/ItemPanel")
    self.item_first_panel_ = self.transform:Find("WindowObj/FirstItemGroup").gameObject
end

--3.打开UI（打开/刷新UI处理）
function on_open(self)
	self.obj_data_ = self.data[1]
    local prop = self.obj_data_.prop_
    UIUtil.set_sprite(prop.drawpath, self.head_img_)
    
    self.name_.text = prop.name
    self.lv_.text = lang("UI_MONSTERINFO_LV")..prop.lv
    self.power_.text = "战力："..prop.power
    self.distane_.text = lang("UI_MONSTERINFO_DISTANE", self:get_distance())
    self.axis_.text = string.format("%d, %d", self.obj_data_.x_, self.obj_data_.z_)
    self:init_item_panel()
    self:init_first_item_panel()    
    self:init_window_size()
end

--5.关闭UI（UIManager销毁UI前处理）
function on_close(self)
    if self.item_go1_ then
        for k,v in pairs(self.item_go1_) do
            if v then
                Object.Destroy(v.gameObject)
            end
        end  
    end
    self.item_go1_ = nil
    if self.item_go2_ then
        for k,v in pairs(self.item_go2_) do
            if v then
                Object.Destroy(v.gameObject)
            end
        end  
    end
    self.item_go2_ = nil
end

function on_click_attack_handler(self)
    local x = self.obj_data_.x_
    local z = self.obj_data_.z_
    if _G.FairyGUI then
        self:close()
        _G.UIController:ShowUI("UIStrike", {obj = self.obj_data_})
		return
	end
    self:close(function()
        UIManager.open_window("WorldTroopsWindow", nil, self.obj_data_)
    end)
end

function get_distance(self)
    local pos_x = self.obj_data_.x_
    local pos_z = self.obj_data_.z_
    local main_x, main_z = WorldManager:get_my_build_logic_axis()
    local delta_x = pos_x - main_x
    local delta_z = pos_z - main_z
    local distance = math.sqrt(delta_x*delta_x + delta_z*delta_z)
    return math.floor(distance)
end

function init_first_item_panel(self)
    if not self:show_first_item() then
        self.item_first_panel_:SetActive(false)
        return 
    end
    if not self.item_first_panel_.activeSelf then
        self.item_first_panel_:SetActive(true)
    end
    UIUtil.destroy_all_children(self.item_panel2_)
    self.item_go2_ = {}
    for i,v in ipairs(self.obj_data_.prop_.firstreward) do
        local itemobj = GameObject.Instantiate(self.item_prefab_)
        itemobj.name = tostring(i)
        itemobj:SetActive(true)
        itemobj.transform:SetParent(self.item_panel2_, false)
        itemobj.transform.localScale = Vector3(0.9,0.9,0.9)
        self.item_go2_[i] = ItemCard:new()
        self.item_go2_[i]:AddLuaComponent(itemobj)
        self.item_go2_[i]:init()
        self.item_go2_[i]:set_item_prop(v)
    end
end

function init_item_panel(self)
    UIUtil.destroy_all_children(self.item_panel1_)
    self.item_go1_ = {}
    for i,v in ipairs(self.obj_data_.prop_.reward) do
        local itemobj = GameObject.Instantiate(self.item_prefab_)
        itemobj.name = tostring(i)
        itemobj:SetActive(true)
        itemobj.transform:SetParent(self.item_panel1_, false)
        itemobj.transform.localScale = Vector3(0.9,0.9,0.9)
        self.item_go1_[i] = ItemCard:new()
        self.item_go1_[i]:AddLuaComponent(itemobj)
        self.item_go1_[i]:init()
        self.item_go1_[i]:set_item_prop(v)
    end
end

function show_first_item(self)
    if WorldManager.monster_battle_lv_ >= self.obj_data_.lv_ then
        return false
    end
    return true
end

function init_window_size(self)
    local heiht = 555
    local posy = -230
    self.vip_tips_.text = lang("EXPEDITION_3", 2)
    self.vip_tips1_.text = ""
    if not self:show_first_item() then
        heiht = 450
        posy = -30
        self.vip_tips1_.text = lang("EXPEDITION_3", 2)
        self.vip_tips_.text = ""
    end
    self.win_rect_.sizeDelta = Vector2(self.win_rect_.sizeDelta.x, heiht)
    
    self.item_rect_.anchoredPosition = Vector2(self.item_rect_.anchoredPosition.x, posy)
end
