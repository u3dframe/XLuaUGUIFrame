module("SkillBag", package.seeall)
setmetatable(SkillBag, {__index = BaseWindow})


local Type2Page = {
    [config.SKILL_TYPES.COMMAND] = 1,
    [config.SKILL_TYPES.AFFAIRS] = 2,
    [config.SKILL_TYPES.IDEAS] = 3,
}

local Page2Type = {}
for k, v in pairs(Type2Page) do
    Page2Type[v] = k
end

local SelectedTypes = {
    Skill = 1,
    Frag = 2,
}

OperationTypes = {
    Learn = 1,      --学习
    Show = 2,       --展示
}


local ItemConfig = _G.Database.ItemConfig
local HeroConfig = _G.Database.HeroConfig


function on_init(self)
    self.opt = self.data[1]
    self.hero = self.data[2]
    self.pos = self.data[3]

    local title = self.transform:Find("Top/Text"):GetComponent(Text)
    if self.opt == OperationTypes.Learn then
        title.text = lang("SKILL_TITLE")
    end

    local closeBtn = self.transform:Find("Top/CloseBtn"):GetComponent(Button)
    self:add_event_handler(closeBtn.onClick, function() self:close() end)

    self.skillItem = self.transform:Find("Cache/Skill").gameObject
    self.skillItem:SetActive(false)
    self.selected = self.transform:Find("Cache/Selected")
    local content = self.transform:Find("ScrollView/Viewport/Content")
    self.skillContent = content:Find("Gained")
    self.fragContent = content:Find("Ungained")

    self.skillObjs = {}
    self.fragObjs = {}
    self.fragIDs = {}
    self:refresh_frags()

    local toggleGroup = self.transform:Find("Panel/ToggleGroup")
    self.toggles = toggleGroup:GetComponentsInChildren(Toggle).Table
    for i, toggle in ipairs(self.toggles) do
        self:add_event_handler(toggle.onValueChanged, on_page_toggle_change, i)
    end

    self.selectedIcon = self.transform:Find("Image/skill_icon"):GetComponent(Image)
    self.selectedDetail = self.transform:Find("Image/skill_title1")
    self.decomposeBtn = self.transform:Find("Image/Button"):GetComponent(Button)

    self.selectedType = {}
    self.selectedID = {}
    for _, ty in pairs(config.SKILL_TYPES) do
        self.selectedType[Type2Page[ty]] = SelectedTypes.Skill
    end
    self.currentPage = self.hero and Type2Page[self.hero.type_] or 1

    local bottomBtns = self.transform:Find("BottomBtnGroup")
    local researchBtn = bottomBtns:Find("ResearchBtn"):GetComponent(Button)
    local oneKeyDecomposeBtn = bottomBtns:Find("DecomposeBtn"):GetComponent(Button)
    self.learnBtn = bottomBtns:Find("LearnBtn"):GetComponent(Button)
    self:add_event_handler(researchBtn.onClick, function()
        --TODO
    end)
    if self.opt == OperationTypes.Learn then
        oneKeyDecomposeBtn.gameObject:SetActive(false)
        self:add_event_handler(self.learnBtn.onClick, function()
            if self.selectedType[self.currentPage] == SelectedTypes.Skill then
                local toLearnID = self.selectedID[self.currentPage]
                if self.hero:has_skill(toLearnID) then
                    MsgCenter.send_message(Msg.SHOW_HINT, lang("SKILL_LEARN"))
                    return
                end
                SkillManager:learn_skill(self.hero.id_, self.pos, toLearnID)
            end
            self:close()
        end)
    elseif self.opt == OperationTypes.Show then
        self.learnBtn.gameObject:SetActive(false)
        self:add_event_handler(oneKeyDecomposeBtn.onClick, function()
            UIManager.open_window("SkillAllForget", nil, Page2Type[self.currentPage])
        end)
    else
        elog("Invalid operation type: "..tostring(self.opt))
    end

    self.messager_:add_listener(Msg.SKILL_CHANGE, on_skill_change)
    self.messager_:add_listener(Msg.ITEM_CHANGE, on_frag_change)
end

function on_open(self)
    if self.toggles[self.currentPage].isOn then
        self:refresh_current_page()
    end
    self.toggles[self.currentPage].isOn = true
end

function on_skill_change(self)
    if not self.gameObject.activeSelf then return end
    self:refresh_current_page()
end

function on_frag_change(self, data)
    if not data or #data == 0 then return end
    if not self.gameObject.activeSelf then return end
    for _, d in pairs(data) do
        if ItemManager:is_skill_fragment(d.id) then
            self:refresh_frags()
            self:refresh_frag_list()
            return
        end
    end
end

function refresh_frags(self)
    for _, ty in pairs(config.SKILL_TYPES) do
        self.fragIDs[Type2Page[ty]] = {}
    end
    for id, _ in pairs(ItemManager:get_all_item_cfg_of_showpoint(config.ITEM_SHOW_POINT.SKILL_BAG)) do
        local sk = SkillManager:get_skill_cfg_by_frag_id(id)
        if sk then
            table.insert(self.fragIDs[Type2Page[sk.type]], id)
        end
    end
    for _, arr in pairs(self.fragIDs) do
        table.sort(arr, function(a, b)
            local sk1, id1, _ = SkillManager:get_skill_cfg_by_frag_id(a)
            local sk2, id2, _ = SkillManager:get_skill_cfg_by_frag_id(b)
            return SkillManager.skill_cfg_comparator(sk1, id1, sk2, id2)
        end)
    end
end

function on_page_toggle_change(self, isOn, i)
    if isOn then
        self.currentPage = i
        self:refresh_current_page()
    end
end

function refresh_current_page(self)
    self:refresh_skill_list()
    self:refresh_frag_list()
end

function refresh_skill_list(self)
    local skills = SkillManager:get_sorted_skill_list_by_type(Page2Type[self.currentPage])
    for i = #self.skillObjs + 1, #skills do
        local item = GameObject.Instantiate(self.skillItem)
        item.transform:SetParent(self.skillContent, false)
        table.insert(self.skillObjs, item)
    end
    for i = 1, #skills do
        self.skillObjs[i]:SetActive(true)
    end
    for i = #skills + 1, #self.skillObjs do
        self.skillObjs[i]:SetActive(false)
    end
    for i, skill in ipairs(skills) do
        self:set_skill_item(self.skillObjs[i], skill)
    end
    if self.selectedType[self.currentPage] == SelectedTypes.Skill then
        local selectedID = self.selectedID[self.currentPage]
        local selectedIndex
        for i, skill in ipairs(skills) do
            if skill.id_ == selectedID then
                selectedIndex = i
                break
            end
        end
        if not selectedIndex then
            if #skills > 0 then
                selectedIndex = 1
                self.selectedID[self.currentPage] = skills[selectedIndex].id_
            else
                self.selectedType[self.currentPage] = SelectedTypes.Frag
                self.selectedID[self.currentPage] = self.fragIDs[self.currentPage][1]
            end
        end
        if selectedIndex then
            local icon = self.skillObjs[selectedIndex].transform:Find("skill_icon")
            self.selected:SetParent(icon, false)
            if self.opt == OperationTypes.Learn then
                self.learnBtn.gameObject:SetActive(true)
            end
        end
        self:show_selected_info()
    end
end

function set_skill_item(self, item, skill)
    local cfg = skill.cfg_
    local icon = item.transform:Find("skill_icon")
    UIUtil.set_sprite(cfg.icon, icon:GetComponent(Image))
    local btn = icon:GetComponent(Button)
    btn.onClick:RemoveAllListeners()
    self:add_event_handler(btn.onClick, function()
        if self.selectedType[self.currentPage] == SelectedTypes.Skill
            and self.selectedID[self.currentPage] == skill.id_ then return end
        if self.opt == OperationTypes.Learn then
            self.learnBtn.gameObject:SetActive(true)
        end
        self.selectedType[self.currentPage] = SelectedTypes.Skill
        self.selectedID[self.currentPage] = skill.id_
        self.selected:SetParent(icon, false)
        self:show_selected_info()
    end)
    local rare = item.transform:Find("rare")
    rare.gameObject:SetActive(skill:is_rare())
    local name = item.transform:Find("skillnametxt"):GetComponent(Text)
    name.text = cfg.name
    local num = item.transform:Find("skillnumtxt"):GetComponent(Text)
    num.text = skill.count_
end

function refresh_frag_list(self)
    local fragIDs = self.fragIDs[self.currentPage]
    for i = #self.fragObjs + 1, #fragIDs do
        local item = GameObject.Instantiate(self.skillItem)
        item.transform:SetParent(self.fragContent, false)
        table.insert(self.fragObjs, item)
    end
    for i = 1, #fragIDs do
        self.fragObjs[i]:SetActive(true)
    end
    for i = #fragIDs + 1, #self.fragObjs do
        self.fragObjs[i]:SetActive(false)
    end
    for i, id in ipairs(fragIDs) do
        self:set_frag_item(self.fragObjs[i], id)
    end
    if self.selectedType[self.currentPage] == SelectedTypes.Frag then
        local selectedID = self.selectedID[self.currentPage]
        local selectedIndex
        for i, id in ipairs(fragIDs) do
            if id == selectedID then
                selectedIndex = i
                break
            end
        end
        if not selectedIndex and #fragIDs > 0 then
            selectedIndex = 1
            self.selectedID[self.currentPage] = fragIDs[selectedIndex]
        end
        if selectedIndex then
            local icon = self.fragObjs[selectedIndex].transform:Find("skill_icon")
            self.selected:SetParent(icon, false)
            if self.opt == OperationTypes.Learn then
                self.learnBtn.gameObject:SetActive(false)
            end
        end
        self:show_selected_info()
    end
end

function set_frag_item(self, item, frag_id)
    local skill, _, need = SkillManager:get_skill_cfg_by_frag_id(frag_id)
    local fragCfg = ItemConfig.ItemData[frag_id]
    local icon = item.transform:Find("skill_icon")
    UIUtil.set_sprite(fragCfg.icon, icon:GetComponent(Image))
    local btn = icon:GetComponent(Button)
    btn.onClick:RemoveAllListeners()
    self:add_event_handler(btn.onClick, function()
        if self.selectedType[self.currentPage] == SelectedTypes.Frag
            and self.selectedID[self.currentPage] == frag_id then return end
        if self.opt == OperationTypes.Learn then
            self.learnBtn.gameObject:SetActive(false)
        end
        self.selectedType[self.currentPage] = SelectedTypes.Frag
        self.selectedID[self.currentPage] = frag_id
        self.selected:SetParent(icon, false)
        self:show_selected_info()
    end)
    local rare = item.transform:Find("rare")
    rare.gameObject:SetActive(skill.rare > 0)
    local name = item.transform:Find("skillnametxt"):GetComponent(Text)
    name.text = fragCfg.name
    local num = item.transform:Find("skillnumtxt"):GetComponent(Text)
    local frag = ItemManager:get_item_by_id(frag_id)
    local cnt = frag and frag.count_ or 0
    local img = icon:GetComponent(Image)
    if cnt == 0 then
        img.color = Color(0.6, 0.6, 0.6, 1)
    else
        img.color = Color.white
    end
    num.text = string.format("%d/%d", cnt, need)
end

function show_selected_info(self)
    local id = self.selectedID[self.currentPage]
    local cfg
    local isSkill = self.selectedType[self.currentPage] == SelectedTypes.Skill
    local rare
    if isSkill then
        cfg = HeroConfig.SkillData[id]
        rare = cfg.rare > 0
    else
        cfg = ItemConfig.ItemData[id]
        rare = SkillManager:get_skill_cfg_by_frag_id(id).rare > 0
    end
    UIUtil.set_sprite(cfg.icon, self.selectedIcon)
    local name = self.selectedDetail:Find("Name")
    name:Find("Image").gameObject:SetActive(rare)
    name:GetComponentInChildren(Text).text = cfg.name
    local descCom = self.selectedDetail:Find("skillintroducetxt"):GetComponent(Text)
    local desc = cfg.desc
    if isSkill and self.opt == OperationTypes.Learn then
        local sk = self.hero:get_skill_by_pos(self.pos)
        desc = SkillManager:get_skill_buff_desc(id, sk and sk.level or 1, self.hero.id_)
    end
    descCom.text = desc
    self.decomposeBtn.gameObject:SetActive(isSkill)
    if isSkill then
        self.decomposeBtn.onClick:RemoveAllListeners()
        self:add_event_handler(self.decomposeBtn.onClick, function()
            UIManager.open_window("SkillRecycleWindow", nil, id)
        end)
    end
end
