--使用祭祀道具，增加祭祀次数
local FeteUseItemWindow = {}
setmetatable(FeteUseItemWindow, {__index = _G.BaseWindow})

local ItemManager = _G.ItemManager
local UI = _G.UnityEngine.UI
local lang = _G.lang
local Msg = _G.Msg
local resmng = _G.resmng

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function FeteUseItemWindow:on_init()
    self.fete = BuildManager:GetFete()
    self.closeBtn = self.transform:Find("Panel/Top/CloseBtn"):GetComponent(UI.Button)
    self.itemObj = self.transform:Find("Panel/ItemCard").gameObject
    self.feteCnt = self.transform:Find("Panel/Text"):GetComponent(UI.Text)
    self.useBtn = self.transform:Find("Panel/Button"):GetComponent(UI.Button)
    self:add_event_handler(self.closeBtn.onClick, function()
        self:close()
    end)

    self.messager_:add_listener(Msg.ITEM_CHANGE, self.OnItemChange)
    self.messager_:add_listener(Msg.CITY_FETE_UPDATE, self.OnRefreshFete)
end

--3.打开UI（打开/刷新UI处理）
function FeteUseItemWindow:on_open()
    self:SetData()
end

--5.关闭UI（UIManager销毁UI前处理）
function FeteUseItemWindow:on_close()
    self.messager_:remove_listener(Msg.ITEM_CHANGE)
    self.messager_:remove_listener(Msg.CITY_FETE_UPDATE)
end

function FeteUseItemWindow:SetData()
    --刷新今日次数
    self.feteCnt.text = lang("UI_CITYFETE_FREE_TIME")..self.fete:GetFreeTimes()

    local basic = self.fete:GetSacBasic()
    local item = ItemManager:get_item_by_id(basic.free_item)

    local prop = {
        _G.config.ITEM_ITEM,
        basic.free_item,
        item and item.count_ or 0
    }
    local itemCard = _G.ItemCard:new()
    itemCard:AddLuaComponent(self.itemObj)
    itemCard:init()
    itemCard:set_item(prop[1], prop[2], prop[3])

    self.useBtn.onClick:RemoveAllListeners()
    self:add_event_handler(self.useBtn.onClick, function()
        if item then
            item:use()
        end
    end)
end

function FeteUseItemWindow:OnItemChange(list)
    if not next(list or {}) then
        return
    end
    local basic = self.fete:GetSacBasic()
    for _, v in ipairs(list) do
        if v.id == basic.free_item then
            self:on_open()
        end
    end
end

function FeteUseItemWindow:OnRefreshFete()
    self.feteCnt.text = lang("UI_CITYFETE_FREE_TIME")..self.fete:GetFreeTimes()
end

return FeteUseItemWindow