local BuildSpendWindow = {}
setmetatable(BuildSpendWindow, {__index = _G.BaseWindow})

local BasicConfig = _G.Database.BasicConfig
local CityConfig = _G.Database.CityConfig
local UI = _G.UnityEngine.UI
local BuildManager = _G.BuildManager
local Net = _G.Net
local config = _G.config
local UIUtil = _G.UIUtil
local Msg = _G.Msg
local MsgCenter = _G.MsgCenter
local lang = _G.lang

--1.准备UI（UI美术资源加载）
function BuildSpendWindow.on_resource()
end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function BuildSpendWindow:on_init()
    self.space_class_ = self.data[1]
    self.create_class_ = self.data[2]
    self.type_ = self.data[3]
    --text
    self.build_name_ = self.transform:Find('WindowObj/BuildInfo/Name'):GetComponent(UI.Text)
    --self.txt_next_level_info_ = self.transform:Find("WindowObj/Level"):GetComponent(UI.Text)
    self.build_lv_ = self.transform:Find('WindowObj/BuildInfo/Lv'):GetComponent(UI.Text)
    self.btn_update_txt_ = self.transform:Find('WindowObj/RightBg/UpadateButton/Timer'):GetComponent(UI.Text)
    self.btn_name_ = self.transform:Find('WindowObj/RightBg/UpadateButton/Text'):GetComponent(UI.Text)
    self.introduce_ = self.transform:Find('WindowObj/IntroduceTxt'):GetComponent(UI.Text)
    self.rect_requirement_ = self.transform:Find('WindowObj/RightBg/Requirement')
    self.hint_txt_ = self.transform:Find('WindowObj/RightBg/LineSplit1/Text'):GetComponent(UI.Text)
    self.max_hint_ = self.transform:Find('WindowObj/RightBg/MaxHint')
    self.txt_lv_name_ = self.transform:Find('WindowObj/RightBg/Introduce/Txt/Name_lv'):GetComponent(UI.Text)
    self.txt_details_info_ = self.transform:Find('WindowObj/RightBg/Introduce/Txt/Details'):GetComponent(UI.Text)
    self.gold_txt_ = self.transform:Find('WindowObj/RightBg/GoldUpBtn/Icon/Text'):GetComponent(UI.Text)
    self.gold_des_txt_ = self.transform:Find('WindowObj/RightBg/GoldUpBtn/Text'):GetComponent(UI.Text)
    --top right
    self.target_desc_ = self.transform:Find('TargetPanel')
    self.target_txt_ = self.transform:Find('TargetPanel/Value'):GetComponent(UI.Text)
    --button
    self.btn_background_ = self.transform:Find('Background'):GetComponent(UI.Button)
    self.btn_update_ = self.transform:Find('WindowObj/RightBg/UpadateButton'):GetComponent(UI.Button)
    self.btn_gold_ = self.transform:Find('WindowObj/RightBg/GoldUpBtn'):GetComponent(UI.Button)
    --add_listener
    self:add_event_handler(self.btn_background_.onClick, BuildSpendWindow.btn_callback)
    self:add_event_handler(self.btn_update_.onClick, BuildSpendWindow.building_callback)
    self:add_event_handler(self.btn_gold_.onClick, BuildSpendWindow.gold_building_callback)

    self.messager_:add_listener(Msg.CITY_UP_LV_FINISHED, BuildSpendWindow.on_up_lv_finished)
    --init
    self:init_item()
end

function BuildSpendWindow:on_open()
    self:stop_timer_all()
    self:hide_item()
    if self.type_ == config.Build_State.BUILDING then
        self.build_type_ = self.create_class_.select_build_id_
        self.build_info_ = BuildManager:get_build_data(self.build_type_)
        self.update_data_ = self.build_info_:get_update_info_by_level(1)
        self.hint_txt_.text = lang('UI_BASIC_LV') .. ' ' .. 1
    elseif self.type_ == config.Build_State.LV_UP then
        self.build_info_ = self.space_class_.build_info_
        self.build_id_ = self.build_info_.id_
        local lv = self.build_info_.lv_
        self.update_data_ = self.build_info_:get_update_info_by_level(lv + 1)
        self.hint_txt_.text = lang('UI_BUILDSPEND_LV2')
    end
    --超出最大等级
    if self.build_info_:lv_out_range() then
        --self.txt_next_level_info_.text = lang("UI_BUILDSPEND_LV1", self.build_info_.lv_)
        self.btn_update_.gameObject:SetActive(false)
        self.btn_gold_.gameObject:SetActive(false)
        self.rect_requirement_.gameObject:SetActive(false)
        self.txt_details_info_.gameObject:SetActive(false)
        self:hide_item()
        self.max_hint_.gameObject:SetActive(true)
    else
        self.rect_requirement_.gameObject:SetActive(true)
        self.btn_update_.gameObject:SetActive(true)
        self.btn_gold_.gameObject:SetActive(true)
        self.max_hint_.gameObject:SetActive(false)
    end
    self:set_date()
    MsgCenter.send_message(Msg.CITY_HIDE_UI_ALL, true)
end

function BuildSpendWindow:on_after_top()
    --self.target_desc_:SetSiblingIndex(self.transform.childCount)
end

--5.关闭UI（UIManager销毁UI前处理）
function BuildSpendWindow:on_close()
    self:stop_timer_all()
    if self.type_ == config.Build_State.LV_UP then
        if _G.SceneManager.City_Scene then
            _G.SceneManager.City_Scene:back_play_animate()
        else
            _G.SceneController.currentScene:GetCameraController():FocusBack();
        end
    end
    self.messager_:remove_listener(Msg.CITY_UP_LV_FINISHED)
    MsgCenter.send_message(Msg.CITY_HIDE_UI_ALL, false)
end

--------------------------------------- 逻辑--------------------------------------

function BuildSpendWindow:init_item()
    self.spend_items_tb_ = {}
    for i = 1, 7 do
        local obj = self.transform:Find('WindowObj/RightBg/Requirement/Content/BuildSpend' .. i)
        table.insert(self.spend_items_tb_, obj)
    end
end

function BuildSpendWindow:hide_item()
    for _, v in pairs(self.spend_items_tb_) do
        v.gameObject:SetActive(false)
    end
end

function BuildSpendWindow:main_title()
    if self.type_ == config.Build_State.BUILDING then
        return lang('UI_BUILDCREATE_TITLE')
    elseif self.type_ == config.Build_State.LV_UP then
        return lang('UI_BUILDSPEND_TITLE')
    end
end

function BuildSpendWindow:set_date()
    self:queue_mananer() --建筑队列控制(button控制)
    self:set_Introduce() --WindowObj - Introduce
    self:set_item() --item
end

function BuildSpendWindow:set_Introduce()
    local name = lang('UI_BASIC_COLOR', config.FONT_COLOR.YELLOW, self.build_info_.name_)
    local lv = lang('UI_BASIC_COLOR', config.FONT_COLOR.GREY, lang('UI_BASIC_LV') .. self.build_info_.lv_)
    self.introduce_.text = self.build_info_.introduce_
    self.build_name_.text = name
    if self.build_info_.lv_ <= 0 then
        self.build_lv_.gameObject:SetActive(false)
    else
        self.build_lv_.text = lv
        self.build_lv_.gameObject:SetActive(true)
    end
    self:set_des_info()
    local free_build_time = _G.AttrsManager:get_attrs_value_by_name('free_build_time')
    if free_build_time >= self.update_data_.uplong / 1000 then
        self.gold_txt_.text = lang('UI_BASIC_FREE')
    else
        self.gold_txt_.text = self:set_gold_number()
    end

    if self.update_data_.updatepath and #self.update_data_.updatepath > 0 then
        self.txt_details_info_.alignment = _G.TextAnchor.UpperLeft
    else
        self.txt_details_info_.alignment = _G.TextAnchor.UpperCenter
    end

    if self.update_data_.byinintroduce and self.update_data_.byinintroduce ~= '' then
        self.txt_lv_name_.text = lang(self.update_data_.byinintroduce)
    else
        self.txt_lv_name_.gameObject:SetActive(false)
    end
    --设置icon 详情
    for i = 1, 2 do
        local icon_obj = self.transform:Find('WindowObj/RightBg/Introduce/Icon' .. i)
        if self.update_data_.updatepath[i] then
            local icon_img = icon_obj.transform:Find('Image'):GetComponent(UI.Image)
            local hint_txt = icon_obj.transform:Find('Unlock/Text'):GetComponent(UI.Text)
            if not self:is_alive() then
                return
            end
            hint_txt.text = lang(self.update_data_.iconinintroduce)
            UIUtil.set_sprite(self.update_data_.updatepath[i], icon_img)
            icon_obj.gameObject:SetActive(true)
        else
            icon_obj.gameObject:SetActive(false)
        end
    end
end

function BuildSpendWindow:set_item()
    self.spend_data_ = {} --花费(条件)表
    if self.update_data_ and self.update_data_.precondition then
        self.term_count_ = #self.update_data_.precondition
        for _, v in pairs(self.update_data_.precondition) do
            if v then
                table.insert(self.spend_data_, v)
            end
        end
    end
    for _, v in ipairs(self.update_data_.upcost) do
        table.insert(self.spend_data_, v)
    end
    local i = 1
    for _, v in ipairs(self.spend_items_tb_) do
        if not v.gameObject.activeSelf then
            if self.spend_data_[i] == nil then
                v.gameObject:SetActive(false)
            else
                v.gameObject:SetActive(true)
                self:set_items_data(i, v)
            end
            i = i + 1
        end
    end
end

function BuildSpendWindow:set_des_info()
    if self.build_info_.lv_ <= 0 then
        self.txt_details_info_.text = self.build_info_.introduce_
        return
    end
    --不需要显示数值的
    local more_des_tb, offset_tb = self.build_info_:get_moredes_value_offset()
    if not more_des_tb or not offset_tb then
        local str
        if lang(self.update_data_.introduce[1]) == 'undefine' then
            str = nil
        else
            str = lang(self.update_data_.introduce[1])
        end
        self.txt_details_info_.text = str
    else
        local value_tb = {}
        for k, v in pairs(more_des_tb) do
            local color_txt = string.format('<color=#06A809>%s</color>', '+' .. offset_tb[k])
            table.insert(value_tb, v .. color_txt)
        end
        local introduce = ''
        for _, v in ipairs(self.update_data_.introduce) do
            local des = lang(v)
            introduce = introduce .. des
        end
        self.txt_details_info_.text = string.format(introduce, unpack(value_tb))
    end
end

--队列管理
function BuildSpendWindow:queue_mananer()
    local time = UIUtil.format_time(self.update_data_.uplong / 1000)
    local str, glod_btn_str
    if self.type_ == config.Build_State.BUILDING then
        str = lang('UI_BUILDCREATE_TITLE')
        glod_btn_str = lang('UI_BUILDSPEND_GLOD_BUILD')
    elseif self.type_ == config.Build_State.LV_UP then
        str = lang('UI_BUILDSPEND_UP')
        glod_btn_str = lang('UI_BUILDSPEND_GOLD_LVUP')
    end
    self.btn_name_.text = str
    self.gold_des_txt_.text = glod_btn_str
    self.btn_update_txt_.text = time

    local queue = BuildManager:get_queue()
    _G.dump(queue, 'queue info')
    if queue and #queue > 0 then
        for _, v in pairs(queue) do
            local build = BuildManager:get_build_info_by_id(v.value)
            if build then
                self:SetBuildQueue(build)
            end
        end
    end
end

--设置子物体
function BuildSpendWindow:set_items_data(index, obj)
    local describe = obj.transform:Find('Describe'):GetComponent(UI.Text)
    local yes = obj.transform:Find('IsFull/Yes')
    local no = obj.transform:Find('IsFull/No')
    local icon = obj.transform:Find('Icon/Image'):GetComponent(UI.Image)
    if index <= self.term_count_ then --判断是否建筑等级符合要求
        --是否满足升级/解锁条件
        local is_full, target_name, target_lv, target_build = BuildManager:unlock_proviso_meet(self.build_info_, index)
        if not is_full then
            self.btn_update_.interactable = false
            _G.GameUtil.SetImageGrey(self.btn_update_:GetComponent(UI.Image), true)

            describe.text = lang('UI_BUILDSPEND_LV4', target_name, target_lv)
        else
            describe.text = lang('UI_BUILDSPEND_LV3', target_name, target_lv)
        end
        if target_build then
            local lv
            if target_build.lv_ > 0 then --建筑存在
                lv = nil
            else --建筑等级为0的时候 1.建筑没建造出来 2.建筑正在建造
                lv = 1
            end
            if not self:is_alive() then
                return
            end
            UIUtil.set_sprite(target_build:get_update_info_by_level(lv).path, icon)
        end
        yes.gameObject:SetActive(is_full)
        no.gameObject:SetActive(not is_full)
    else
        --判断消耗否是符合
        local is_full = _G.ItemManager:check_resource(self.spend_data_[index])
        local spend_v = self.spend_data_[index][3]
        local had_money = _G.ItemManager:get_resource(self.spend_data_[index][1])

        if not had_money then
            had_money = 0
        end
        self:load_icon(self.spend_data_[index][1], icon)
        --不满足条件 按钮置灰
        if not is_full then
            self.btn_update_.interactable = false
            _G.GameUtil.SetImageGrey(self.btn_update_:GetComponent(UI.Image), true)
            describe.text = lang('UI_BUILDSPEND_DES1', UIUtil.res_num_to_str(had_money), UIUtil.res_num_to_str(spend_v))
        else
            describe.text = lang('UI_BUILDSPEND_DES2', UIUtil.res_num_to_str(had_money), UIUtil.res_num_to_str(spend_v))
        end
        yes.gameObject:SetActive(is_full)
        no.gameObject:SetActive(not is_full)
    end
end

function BuildSpendWindow:SetBuildQueue(build)
    local obj
    for _, v in ipairs(self.spend_items_tb_) do
        if not v.gameObject.activeSelf then
            obj = v
            break
        end
    end
    local describe = obj.transform:Find('Describe'):GetComponent(UI.Text)
    local yes = obj.transform:Find('IsFull/Yes')
    local no = obj.transform:Find('IsFull/No')
    local icon = obj.transform:Find('Icon/Image'):GetComponent(UI.Image)

    if not self:is_alive() then
        return
    end
    UIUtil.set_sprite('UI/Common/Basic/icon_speedup', icon)
    self:timer(build, describe, obj)
    yes.gameObject:SetActive(false)
    no.gameObject:SetActive(true)
    obj.gameObject:SetActive(true)
end

function BuildSpendWindow:load_icon(icon_id, img)
    if not self:is_alive() or not icon_id then
        return
    end
    UIUtil.set_sprite('UI/Common/Item/' .. icon_id, img)
end

function BuildSpendWindow:timer(build, txt_com, obj)
    if (not build.start_time_) or (not build.end_time_) or (not build.total_time_) then
        return
    end
    --local start_time = build.start_time_
    local end_time = build.end_time_
    local total_time = build.total_time_
    --FF0000

    --设置队列显示时间
    local str = build:get_queue_txt()

    local curr_second = total_time - (math.floor(end_time - Net.server_time()))
    if curr_second < 0 then
        curr_second = 0
    end
    local last_time = Net.server_time()
    local lua_timer =
        _G.LuaTimer.Add(
        0,
        1000,
        function()
            --时间不精确处理
            if Net.server_time() - last_time > 1 then
                curr_second = curr_second + 1
            end
            last_time = Net.server_time()
            if curr_second > total_time then
                obj.gameObject:SetActive(false)
                --self:on_open()
                return false
            end
            txt_com.text = lang('UI_BUILDSPEND_TXT1', str, UIUtil.format_time(total_time - curr_second))
            curr_second = curr_second + 1
        end
    )
    self.timer_tb_ = self.timer_tb_ or {}
    self.timer_tb_[build.id_] = lua_timer
end

--通过建筑id 停止建筑计时器
function BuildSpendWindow:stop_timer_by_id(build_id)
    if not build_id then
        return
    end
    if not self.timer_tb_ then
        return
    end
    if not self.timer_tb_[build_id] then
        return
    end

    _G.LuaTimer.Delete(self.timer_tb_[build_id])
    self.timer_tb_[build_id] = nil
end

function BuildSpendWindow:stop_timer_all()
    if not self.timer_tb_ then
        return
    end
    for _, v in pairs(self.timer_tb_) do
        if v then
            _G.LuaTimer.Delete(v)
        end
    end
    self.timer_tb_ = nil
end

--设置金币数量
function BuildSpendWindow:set_gold_number()
    local free_build_time = _G.AttrsManager:get_attrs_value_by_name('free_build_time')
    free_build_time = free_build_time or nil
    local remaining_time = self.update_data_.uplong / 1000 - free_build_time
    -- 金币=系数1*（训练时间）^系数2-系数3
    -- 结果四舍五入，最小值为1
    local basic = BasicConfig.BasicData
    local number = basic.build_gold1 * remaining_time ^ basic.build_gold2 - basic.build_gold3
    if not number then
        _G.printf('number is nil')
        number = 1
    end
    local integer_num = math.floor(number + 0.5)
    if integer_num <= 0 then
        integer_num = 1
    end
    return integer_num
end

function BuildSpendWindow:show_tips_view(req_msg)
    local msg_ = {}
    msg_.title = ''
    --msg_.content = "主公，只需要花费少量金币即可完成当前队列, 确定是否要使用"
    msg_.content = lang('UI_BUILDSPEND_SPEEDUP_HINE')
    msg_.buttons = {lang('UI_BASIC_CANCEL'), lang('UI_BASIC_SURE')}
    msg_.callback = function(index)
        if index == 2 then
            Net.send(
                'build_levelup_dectime',
                req_msg,
                function(result)
                    if result.e == 5 then
                        MsgCenter.send_message(Msg.SHOW_HINT, '道具不足')
                    elseif result.e == 3 then
                        self:close()
                    elseif result.e == 0 then
                        self:on_open()
                    end
                end
            )
        end
    end
    MsgCenter.send_message(Msg.SHOW_NOTIFY, msg_)
end

----------------------------------------回调---------------------------------------

function BuildSpendWindow:on_up_lv_finished(id)
    --建造/升级 结束关闭计时器
    self:stop_timer_by_id(id)
    --self:stop_timer_all()
    --self.type_ = config.LV_UP
    self:on_open()
end

-- 检查第二队列状态
function BuildSpendWindow:check_queue()
    -- 如果有队列卷道具 使用队列卷道具
    local queue_item = _G.ItemManager:get_queue_item()
    if queue_item then
        local content = lang('UI_MAIN_UNLOCK_QUEUE_BY_ITEM', queue_item.prop_.name)
        self:request_unlock(content)
    else
        -- 队列没有解锁，并且没有道具 提示用户使用金币购买
        local remaining = UIUtil.format_time(BuildManager:get_queue2_time())
        local name = self.build_info_.name_
        local up_time = UIUtil.format_time(self.update_data_.uplong / 1000)

        local time = self.update_data_.uplong / 1000 - BuildManager:get_queue2_time()
        local gold_cnt = BuildManager:get_glod_count_by_time(time)
        local days = BuildManager:get_days_by_gold(gold_cnt)
        local content = lang('UI_BUILDSPEND_UNLOCK_QUEUE_BY_GOLD', days, remaining, name, up_time)
        self:request_unlock(content, gold_cnt)
    end
end

function BuildSpendWindow:request_unlock(content, gold_cnt, func)
    local button_info
    if gold_cnt then
        button_info = {lang('UI_BASIC_SURE'), gold_cnt}
    else
        button_info = lang('UI_BASIC_SURE')
    end
    local msg_ = {}
    msg_.content = content
    msg_.buttons = {
        lang('UI_BASIC_CANCEL'),
        button_info
    }
    msg_.callback = function(index)
        if index == 2 then
            local req_msg = {}
            req_msg.long = self.update_data_.uplong
            Net.send(
                'mainqueue_passive_add',
                req_msg,
                function(result)
                    if result.e == 0 then
                        if func then
                            func()
                        end
                        self:close()
                    elseif result.e == 2 then
                        MsgCenter.send_message(Msg.SHOW_HINT, lang('ITEM_NOT_ENOUGH'))
                    end
                end
            )
        end
    end
    MsgCenter.send_message(Msg.SHOW_GOLD_NOTIFY, msg_)
end

-- 金币建造按钮
function BuildSpendWindow:gold_building_callback()
    if self.build_info_ and self.build_info_.id_ then
    end
    local req_msg = {}
    if self.type_ == config.Build_State.BUILDING then
        req_msg.buildtype = self.build_type_
        req_msg.pos = self.space_class_.id_ - CityConfig.BuildData[self.build_type_].startpos + 1
        Net.send(
            'build_add_finish',
            req_msg,
            function(result)
                if result.e == 0 then
                    self.space_class_:refresh_build_info() --刷新
                    self.space_class_:show_img_by_path(self.update_data_.path)
                    self.build_info_ = BuildManager:get_build_info_by_space_id(self.space_class_.id_)
                    if self.build_info_ and self.build_info_.id_ then
                        MsgCenter.send_message(Msg.CITY_GOLD_UP_LV, self.build_info_.id_)
                    end
                    if _G.EventKey then
                        _G.event.fire(_G.EventKey.CITY_BUILDING_SUCCEED)
                    else
                        MsgCenter.send_message(Msg.CITY_BUILDING_SUCCEED)
                    end

                    -- -- 刷新数据
                    self.type_ = config.Build_State.LV_UP
                    self:on_open()
                    self:close_all()
                elseif result.e == 7 then
                    MsgCenter.send_message(Msg.SHOW_HINT, lang('ITEM_NOT_ENOUGH'))
                end
            end
        )
    elseif self.type_ == config.Build_State.LV_UP then
        req_msg.id = self.build_id_
        Net.send(
            'build_levelup_finish',
            req_msg,
            function(result)
                if result.e == 0 then
                    --self:close_all()
                    MsgCenter.send_message(Msg.CITY_GOLD_UP_LV, self.build_id_)
                elseif result.e == 7 then
                    MsgCenter.send_message(Msg.SHOW_HINT, lang('ITEM_NOT_ENOUGH'))
                end
            end
        )
    end
end

--建造
function BuildSpendWindow:building_callback()
    -- 是否雇佣第二个队列
    if BuildManager:is_hire_sencond_queue(self.update_data_.uplong) then
        self:check_queue()
        return
    end
    --队列不足提示
    if BuildManager:is_full_queue() then
        local str = lang('UI_BUILDSPEND_FULL')
        MsgCenter.send_message(Msg.SHOW_HINT, str)
        return
    end
    if self.type_ == config.Build_State.BUILDING then
        Net.send(
            'build_add',
            {
                buildtype = self.build_type_,
                pos = self.space_class_.id_ - CityConfig.BuildData[self.build_type_].startpos + 1
            },
            function(result)
                if result.e == 0 then
                    self.space_class_:refresh_build_info()
                    self.space_class_:show_img_by_path(self.update_data_.path)
                    self.build_info_ = BuildManager:get_build_info_by_space_id(self.space_class_.id_)
                    if self.build_info_ and self.build_info_.id_ then
                        MsgCenter.send_message(Msg.CITY_UP_LV_UPDATE, self.build_info_.id_)
                    end
                    if _G.EventKey then
                        _G.event.fire(_G.EventKey.CITY_BUILDING_SUCCEED)
                    else
                        MsgCenter.send_message(Msg.CITY_BUILDING_SUCCEED)
                    end
                    self:close_all()
                end
            end
        )
    elseif self.type_ == config.Build_State.LV_UP then
        Net.send(
            'build_levelup',
            {id = self.build_id_},
            function(result)
                if result.e == 0 then
                    MsgCenter.send_message(Msg.CITY_UP_LV_UPDATE, self.build_id_)
                    self:close_all()
                end
            end
        )
    end
end

function BuildSpendWindow:btn_callback()
    self:close()
end

return BuildSpendWindow
