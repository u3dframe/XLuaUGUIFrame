local HeroAnimeWindow = {}
setmetatable( HeroAnimeWindow, {__index = _G.BaseWindow})

local UnityEngine = _G.UnityEngine
local UI = _G.UnityEngine.UI
local UIUtil = _G.UIUtil
local lang = _G.lang
local GameTween = _G.GameTween
local Vector3 = _G.Vector3

--1.准备UI（UI美术资源加载）
function HeroAnimeWindow:on_resource()
	local list = {
        "hero/HeroCard"
    }

    _G.Yield(UIUtil.load_component(list, function(prefabs) 
        self.hero_card_prefab_ = prefabs[1]
    end))
end

--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function HeroAnimeWindow:on_init()
	local hero_id = self.data[1]
	self.hero_data_ = _G.HeroManager:get_active_hero_by_id(hero_id)

	self.center_ = self.transform:Find("Panel/Center")
	self.buttom_ = self.transform:Find("Panel/Buttom")
	self.title_ = self.transform:Find("Panel/Top/Text")
	self.arrow_ = self.transform:Find("Panel/Center/ChipIcon/Arrow")
	--self.hero_card_group_ = self.transform:Find("Panel/Center/HeroCardGroup")
	self.arrt_panel_ = self.transform:Find("Panel/Center/SelectMode/AttrGroup")
	self.stage_group_old_ = self.transform:Find("Panel/Center/ClassGroup1")
	self.stage_group_ = self.transform:Find("Panel/Center/ClassGroup2")
	-- self.star_txt_old_ = self.transform:Find("Panel/Center/oldstar"):GetComponent(UI.Text)
	-- self.star_txt_ = self.transform:Find("Panel/Center/star"):GetComponent(UI.Text)
	self.oldCard = self.transform:Find("Panel/Center/ChipIcon/Chip")
	self.newCard = self.transform:Find("Panel/Center/ChipIcon/TargetChip")
	--self.sure_btn_ = self.transform:Find("Panel/Buttom/SureButton"):GetComponent(UI.Button)
	self.att_prefab_ = self.transform:Find("Panel/Cache/AttrItem")
	self.att_prefab_.gameObject:SetActive(false)

	--self:add_event_handler(self.sure_btn_.onClick, self.on_sure_btn_handler)
	self.closeBtn = self.transform:Find("Panel/Top/CloseBtn"):GetComponent(UI.Button)
	self:add_event_handler(self.closeBtn.onClick, function()
		self:close()
	end)

	--self.active_go_ = {}
end

--3.打开UI（打开/刷新UI处理）
function HeroAnimeWindow:on_open()
	if not self.hero_data_ then return end
	self:set_data()
	--self:play_animation()
end

--5.关闭UI（UIManager销毁UI前处理）
function HeroAnimeWindow:on_close()

end

function HeroAnimeWindow:set_data()

	local attrs_snapshot = self.hero_data_:get_attrs_snapshot()
	local old_attrs_value = attrs_snapshot.attrs_value_
	local old_power  = attrs_snapshot.power_
	local old_lv_limit = attrs_snapshot.max_lv_
	local old_hero = _G.Hero(self.hero_data_.id_)
	old_hero:clone(self.hero_data_)
	old_hero.star_ = attrs_snapshot.star_
	local hero_list = {old_hero, self.hero_data_}


    local old_star = hero_list[1]:get_star_lv()
    local star = hero_list[2]:get_star_lv()

	self:SetCard(self.oldCard, hero_list[1])
	self:SetCard(self.newCard, hero_list[2])
	-- 设置属性
	local attr_name = {
		lang("UI_HERO_TYPE1"),
		lang("UI_HERO_TYPE2"),
		lang("UI_HERO_TYPE3"),
    }
	--战斗力单独处理
	local powerData = {lang("UI_HERO_POWER"), old_power, self.hero_data_:get_power()}
	local powerObj = self.arrt_panel_.transform:Find("AttrItem")
	local oldTxt = powerObj.transform:Find("Text"):GetComponent(UI.Text)
	local newObj = powerObj.transform:Find("FinalTxt"):GetComponent(UI.Text)
	local labelTxt = lang("UI_BASIC_COLOR", "#A8A8B8" , powerData[1])
	oldTxt.text = powerData[2]
	newObj.text = labelTxt.."\t"..powerData[3]

	local attr_data = {}
	--三维属性
	for i = 1, 3 do
		attr_data[i] = {attr_name[i], old_attrs_value[i], self.hero_data_:get_attr(i)}
	end

	--设置等级上限

	if old_star < star then
		attr_data[4] = {lang("UI_HERO_LV_LIMIT"), old_lv_limit, self.hero_data_:get_max_lv()}
	end

	if not attr_data or #attr_data <= 0 then return end

	for i, v in ipairs(attr_data) do
		local attr_obj = self.arrt_panel_.transform:Find("AttrItem"..i)
		if not attr_obj then
			attr_obj = self:create_obj(self.att_prefab_, self.arrt_panel_)
			attr_obj.name = "AttrItem"..i
			attr_obj.gameObject:SetActive(true)
		end
		if attr_obj and v then
			attr_obj.gameObject:SetActive(true)
			local old_txt = attr_obj.transform:Find("Text"):GetComponent(UI.Text)
			local new_txt = attr_obj.transform:Find("FinalTxt"):GetComponent(UI.Text)
			local icon = attr_obj.transform:Find("Image"):GetComponent(UI.Image)
			local label = lang("UI_BASIC_COLOR", "#A8A8B8" , v[1])
			old_txt.text = label.."\t"..v[2]
			new_txt.text = label.."\t"..v[3]
			if not self:is_alive() then
				return
			end
			UIUtil.set_sprite("UI/Common/Basic/attr_0"..i, icon)
		end
	end
end

function HeroAnimeWindow:SetCard(cardRect, hero)
	local star = hero:get_star_lv()
	local stage = hero:get_stage_lv()
	local starTxt = cardRect.transform:Find("StarTxt"):GetComponent(UI.Text)
	local bar = cardRect.transform:Find("Bar")
	local card = UnityEngine.GameObject.Instantiate(self.hero_card_prefab_)

	card.transform:SetParent(cardRect, false)
	card:SetActive(true)
	local heroCard = HeroCard:new(self)
	heroCard:AddLuaComponent(card)
	heroCard:init()
	heroCard.gameObject:SetActive(true)
	heroCard:SetHeroStar(hero)


	starTxt.text = lang("UI_HERO_STAR", star)..lang("UI_HERO_STAGE", stage)
	self:set_stage(bar, stage)
end

function HeroAnimeWindow:create_obj(obj, parent)
	local go = _G.GameObject.Instantiate(obj)
    go.transform:SetParent(parent, false)
    go.gameObject:SetActive(true)
    go.transform.localPosition = _G.Vector3(0, 0, 0)
    return go
end

function HeroAnimeWindow:set_stage(stage_group, stage)
	--设置阶级
	for i = 1, 5 do
		local obj = stage_group.transform:Find("Bar"..i)
		if obj then
			local img = obj.transform:Find("Color")
			if i <= stage then
				img.gameObject:SetActive(true)
			else
				img.gameObject:SetActive(false)
			end
		end
	end
end

--
function HeroAnimeWindow:play_animation()
	--self.hero_card_group_:GetComponent(HorizontalLayoutGroup).enabled = false
	--先隐藏
	self.center_.gameObject:SetActive(false)
	self.buttom_.gameObject:SetActive(false)

	self.tween_ = _G.XSequence()
	self.tween_:SetAutoKill(false)
	--title
	self.title_.transform.localScale = Vector3(3, 3, 3)
	self.tween_:Append(GameTween.DOScale(self.title_.transform, 1, 0.3):SetEase(3):OnComplete(
		function()
			self.center_.gameObject:SetActive(true)

			self.arrow_.gameObject:SetActive(false)
			self.active_go_[2].gameObject:SetActive(false)
			self.arrt_panel_.gameObject:SetActive(false)
		end
	))

	--card1
	self.active_go_[1].transform.localScale = Vector3(2, 2, 2)
	self.tween_:Append(GameTween.DOScale(self.active_go_[1].transform, 1, 0.2):SetEase(3):OnComplete(
		function()
			self.center_.gameObject:SetActive(true)
			self.arrow_.gameObject:SetActive(true)
			self.active_go_[2].gameObject:SetActive(true)
		end
	))

	--card2
	-- local pos = self.active_go_[2].transform.position
	-- self.active_go_[2].transform.position = self.active_go_[1].transform.position
	self.active_go_[2].transform.localScale = Vector3(2, 2, 2)
	self.tween_:Append(GameTween.DOScale(self.active_go_[2].transform, 1, 0.2):SetEase(3):OnComplete(
		function()
			self.center_.gameObject:SetActive(true)
			self.arrow_.gameObject:SetActive(true)

			self.arrt_panel_.gameObject:SetActive(true)
			self.buttom_.gameObject:SetActive(true)
		end
	))

	-- for i = 1, 3 do
	-- 	local attr_obj = self.arrt_panel_.transform:Find("AttrItem"..i)
	-- 	if attr_obj then
	-- 		attr_obj.gameObject:SetActive(false)
	-- 		self.tween_:Append(GameTween.DOScale(self.title_.transform, 1, 0.3):SetEase(3):OnComplete(

	-- 		))
	-- 	end
	-- end
end 


function HeroAnimeWindow:on_sure_btn_handler()
	self:close()
end

return HeroAnimeWindow

