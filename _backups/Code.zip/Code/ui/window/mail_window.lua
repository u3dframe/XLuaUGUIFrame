-- 邮件界面
module("MailWindow",package.seeall)
setmetatable( MailWindow, {__index = BaseWindow} )


local type_order = {
    {config.MAIL_MODULE_TYPES.COMMON, config.MAIL_TYPES[config.MAIL_MODULE_TYPES.COMMON].ALLIANCE},
    {config.MAIL_MODULE_TYPES.COMMON, config.MAIL_TYPES[config.MAIL_MODULE_TYPES.COMMON].ACTIVITY},
    {config.MAIL_MODULE_TYPES.COMMON, config.MAIL_TYPES[config.MAIL_MODULE_TYPES.COMMON].SYSTEM},
    {config.MAIL_MODULE_TYPES.REPORT, config.MAIL_TYPES[config.MAIL_MODULE_TYPES.REPORT].BATTLE},
    {config.MAIL_MODULE_TYPES.REPORT, config.MAIL_TYPES[config.MAIL_MODULE_TYPES.REPORT].RESOURCE},
    {config.MAIL_MODULE_TYPES.REPORT, config.MAIL_TYPES[config.MAIL_MODULE_TYPES.REPORT].WILD_BATTLE},
}


--2.初始化UI（第一次打开UI处理，用于界面初始化:组件关联、变量赋值，事件绑定）
function on_init(self)
    local item_obj = self.transform:Find("Cache/Item").gameObject
    item_obj:SetActive(false)
    local content = self.transform:Find("Panel/Scroll View/Viewport/Content")
    self.mail_objs_ = {}
    for _, tys in pairs(type_order) do
        local obj = GameObject.Instantiate(item_obj)
        obj:SetActive(true)
        obj.transform:SetParent(content, false)
        table.insert(self.mail_objs_, obj)
        local icon = obj.transform:Find("Icon"):GetComponent(Image)
        UIUtil.set_sprite(string.format("UI/Window/mail/icon_%s_%s", unpack(tys)), icon)
        local title = obj.transform:Find("Text"):GetComponent(Text)
        title.text = lang(string.upper(string.format("MAIL_TYPE_%s_%s", unpack(tys))))
        local btn = obj.transform:GetComponent(Button)
        btn.onClick:RemoveAllListeners()
        self:add_event_handler(btn.onClick, function()
            UIManager.open_window("MailListWindow", nil, unpack(tys))
        end)
    end

    self.messager_:add_listener(Msg.MAIL_ADD, refresh)
    self.messager_:add_listener(Msg.MAIL_DEL, refresh)
    self.messager_:add_listener(Msg.MAIL_READ, refresh)
end

function on_open(self)
    self:refresh()
end

function refresh(self)
    if not self.gameObject.activeSelf then return end
    for i, tys in ipairs(type_order) do
        local obj = self.mail_objs_[i]
        local has_detail = obj.transform:Find("HasDetail")
        local no_detail = obj.transform:Find("NoDetail")
        local mail_cnt = MailManager:get_mails_count(unpack(tys))
        local has_mails = mail_cnt > 0
        local btn = obj.transform:GetComponent(Button)
        has_detail.gameObject:SetActive(has_mails)
        no_detail.gameObject:SetActive(not has_mails)
        btn.interactable = has_mails
        local unread_tag = obj.transform:Find("Icon/UnreadCount")
        local unread_cnt = MailManager:get_unread_mails_count(unpack(tys))
        if unread_cnt > 0 then
            unread_tag.gameObject:SetActive(true)
            local txt = unread_tag:Find("Text"):GetComponent(Text)
            txt.text = unread_cnt
        else
            unread_tag.gameObject:SetActive(false)
        end
    end
end
