module("SkillRecycleWindow", package.seeall)
setmetatable(SkillRecycleWindow, {__index = BaseWindow})



local HeroConfig = _G.Database.HeroConfig


function on_init(self)
    self.skillid = self.data[1]

    local closeBtn = self.transform:Find("Panel/Top/CloseBtn"):GetComponent(Button)
    self:add_event_handler(closeBtn.onClick, function() self:close() end)

    local cancelBtn = self.transform:Find("Panel/CancelBtn"):GetComponent(Button)
    self:add_event_handler(cancelBtn.onClick, function() self:close() end)

    local skillObj = self.transform:Find("Panel/Center/ChipIcon/oldSkillBorder")
    local skillCfg = HeroConfig.SkillData[self.skillid]
    skillObj:Find("oldskilltxt"):GetComponent(Text).text = skillCfg.name
    local skillIcon = skillObj:Find("skillicon"):GetComponent(Image)
    UIUtil.set_sprite(skillCfg.icon, skillIcon)
    self.skillCnt = skillObj:Find("num"):GetComponent(Text)

    local itemObj = self.transform:Find("Panel/Center/ChipIcon/newSkillBorder")
    local prop = skillCfg.resolve[1]
    self.itemCntPerSkill = prop[3]
    local itemCfg = ItemManager:get_ui_info(prop)
    itemObj:Find("newskilltxt"):GetComponent(Text).text = itemCfg.name
    local itemIcon = itemObj:Find("newskillicon"):GetComponent(Image)
    UIUtil.set_sprite(itemCfg.icon, itemIcon)
    self.itemCnt = itemObj:Find("num"):GetComponent(Text)

    local slider = self.transform:Find("Panel/Center/SelectMode")
    self.valueTxt = slider:Find("Buttons/InputField/CountTxt"):GetComponent(Text)
    self.slider = slider:Find("Slider"):GetComponent(Slider)
    self.slider.minValue = 1
    self.slider.value = 1
    self:add_event_handler(self.slider.onValueChanged, on_slider_value_change)

    local addBtn = slider:Find("Buttons/AddBtn"):GetComponent(Button)
    self:add_event_handler(addBtn.onClick, function()
        if self.slider.value < self.slider.maxValue then
            self.slider.value = self.slider.value + 1
        end
    end)
    local subBtn = slider:Find("Buttons/SubBtn"):GetComponent(Button)
    self:add_event_handler(subBtn.onClick, function()
        if self.slider.value > self.slider.minValue then
            self.slider.value = self.slider.value - 1
        end
    end)

    local confirmBtn = self.transform:Find("Panel/OkBtn"):GetComponent(Button)
    self:add_event_handler(confirmBtn.onClick, function()
        SkillManager:resolve_skill(self.skillid, self.slider.value)
        self:close()
    end)
end

function on_open(self)
    local skill = SkillManager:get_skill_by_id(self.skillid)
    if not skill or skill.count_ <= 0 then
        self:close()
    end
    local oldValue = self.slider.value
    self.slider.maxValue = skill.count_
    if oldValue == self.slider.value then
        self:on_slider_value_change()
    end
end

function on_slider_value_change(self)
    self.valueTxt.text = self.slider.value.."/"..self.slider.maxValue
    self.skillCnt.text = self.slider.value
    self.itemCnt.text = self.slider.value * self.itemCntPerSkill
end
