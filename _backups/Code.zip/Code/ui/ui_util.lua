module("UIUtil", package.seeall)

--sprite读取
local BasicConfig = _G.Database.BasicConfig
local ItemManager = _G.ItemManager


function set_sprite(sprite_name, ref_image, callback)
    if not sprite_name then return end
    if string.find(sprite_name, "http") then
        GameLog.LogWarning("can not set head with 'set_sprite'!")
        return
    end
    if not sprite_name or sprite_name == "" then
        GameLog.LogWarning("sprite name can not be nil or empty!")
        return
    end
	local url = string.format("Sprites/%s", sprite_name)
	return ResourcesManager.LoadSpriteAsync(url,
		function(sprite)
			if not Slua.IsNull(sprite) and not Slua.IsNull(ref_image) then
				ref_image.sprite = sprite
			end
            if callback then callback() end
		end
	)
end

function SetItem(item, _type, id, count)
    local cfg = ItemManager:get_ui_info({_type, id})
    if not cfg then
        return elog(string.format("Can't find config of item: %s,%s", _type, id))
    end
	item:GetChild("iconloader").url = "art/"..cfg.icon
	item:GetChild("ItemNameTxt").text = cfg.name
	item:GetChild("CountTxt").text = count
	item:GetChild("TimeTxt").text = cfg.label or 0
    item:GetController("state").selectedPage = cfg.label and "label" or "normal"
end

function SetSoldierHead(item, data)
    local prop = SoldierManager:get_soldier_prop_by_id(data[1])
    local icon = item:GetChild("iconloader")
    local num = item:GetChild("AmountTxt")
    local name = item:GetChild("SoldierNameTxt")
    num.text = data[2]
    name.text = lang("RESPOINT_3", prop.lv, prop.name)
    icon.url = "art/"..prop.route
end

function SetHeroHead(item, hero, pos,remove)
    if not hero then
        if remove then
            item.visible=false
            return
        end

        item:GetController("Herotype").selectedPage = "none"
        item:GetController("color").selectedIndex = 0
        item:GetChild("ComStar"):GetController("visible").selectedPage = "none";
        item:GetChild("HeroNameTxt").text = ""
        item:GetChild("levelTxt").text=""
        if pos then
            item:GetController("HeroPos").selectedIndex = pos
        end
       return
    end
    --dump(hero, "hero")
    item.visible=true
    item:GetController("Herotype").selectedIndex = hero.type_ - 1
    item:GetController("color").selectedIndex = hero.quality_ - 1
    item:GetChild("levelTxt").text = _G.lang("UI_HERO_LV2", hero.lv_)
    item:GetChild("HeroNameTxt").text = hero.name_
    item:GetChild("IconLoader").url = "Icon/HeroHead/"..hero:get_prop().squarehead
    item:GetController("Namecolor").selectedIndex = hero.quality_ - 1
    --dump(hero.star_, "hero.star_")
    local star = hero:get_star_lv()
    item:GetChild("ComStar"):GetController("visible").selectedIndex = star - 1
    if pos then
        item:GetController("HeroPos").selectedIndex = pos
    end
end

function LoadBuildingModel(path, parent, callback)
    if not path or path == '' then
        _G.GameLog.LogWarning('path name can not be nil or empty!')
        return
    end
    local url = string.format('Model/%s', path)
    return _G.ResourcesManager.InstantiateGameObjectAsync(
        url,
        function(buildingObj)
            if not _G.Slua.IsNull(buildingObj) and not _G.Slua.IsNull(parent) then
                local buildTrans = buildingObj.transform
                buildTrans:SetParent(parent)
                buildTrans.localScale = _G.Vector3.one;
                buildTrans.localPosition = _G.Vector2.zero;
            end
            if callback then
                callback(buildingObj)
            end
        end
    )
end


--根据字符串颜色码获取Color对象
function get_color(color)
	local b,c = ColorUtility.TryParseHtmlString(color)
	if b then
		return c
	else
		return Color.white
	end
end

function hide_all_children(parent_transform)
    if not parent_transform then return end
    local num = parent_transform.transform.childCount
    for i = 1, num do
        local v = parent_transform.transform:GetChild(i-1)
        if v and v.gameObject.activeSelf then
            v.gameObject:SetActive(false)
        end
    end
end

--删除所有指定子元素
function destroy_all_children(parent_transform, include_hide, ...)
    local except_transforms = {...}
    if parent_transform then
        if not include_hide then
            include_hide = false
        end
        local children = parent_transform:GetComponentsInChildren(Transform, include_hide)
        for i=#children,1,-1 do
            if parent_transform ~= children[i] then
                local is_except = false
                if #except_transforms > 0 then
                    for j=1,#except_transforms do
                        if children[i] == except_transforms[j] then
                            is_except = true
                            break
                        end
                    end
                end
                if not is_except then 
                    Object.Destroy(children[i].gameObject)
                end
            end
        end
    end
end

function destroy_active_children(parent_transform, ...)
    local except_transforms = {...}
    if parent_transform then
        local children = parent_transform:GetComponentsInChildren(Transform, false)
        for i=#children,1,-1 do
            if parent_transform ~= children[i] then
                local is_except = false
                if #except_transforms > 0 then
                    for j=1,#except_transforms do
                        if children[i] == except_transforms[j] then
                            is_except = true
                            break
                        end
                    end
                end
                if not is_except then 
                    Object.Destroy(children[i].gameObject)
                end
            end
        end
    end
end

-- 获得指定UI组件Preab(异步)
function load_component(name, callback)
    if not name then
        ELOG("[UIUtils.load_component] component prefab name can not be nil!!")
        return
    end

    local param_type = type(name)

    if param_type == "string" then
        local url = string.format("UI/Component/%s", name)
        return ResourcesManager.LoadObjectAsync(url,
            function(obj) 
                if not Slua.IsNull(obj) and callback then
                    callback(obj)
                end
            end)
    elseif param_type == "table" then
        local urls = {}
        for _, v in ipairs(name) do
            table.insert(urls, string.format("UI/Component/%s", v)) 
        end

        return ResourcesManager.LoadObjectMultiAsync(urls, function(loaded)
            _G.dump(loaded.Table, "resources loaded : ", 99)
            callback(loaded.Table)
        end)
    end
end

-- 逻辑坐标转世界坐标(localPosition)
function logic_axis_to_map_axis(logicX, logicZ)
    local obj = WorldManager:get_world_obj(logicX, logicZ)
    local center_tmp = config.WORLD_START + 0.5
    if obj and obj.obj_type_ == config.WORLD_MAIN then
        center_tmp = config.WORLD_START
    end
    local x = logicX * 2 + (center_tmp - 1) *2
    local z = -(logicZ * 2 + (center_tmp - 1) *2)
    return x, z
end

-- 世界坐标转逻辑坐标
function map_axis_to_logic_axis(x, z)
    local point_pos = Vector3(x, 0, z)
    local re_point_pos = Quaternion.AngleAxis(45, Vector3.down) * point_pos
    local logic_x = math.floor((math.abs(re_point_pos.x) - config.WORLD_START * 2) / 2) + 1
    local logic_z = math.floor((math.abs(re_point_pos.z) - config.WORLD_START * 2) / 2) + 1
    return logic_x, logic_z
end

function get_grid_xz_by_name(name)
    if not name then return end
    local num1 = string.find(name, '{')
    local num2 = string.find(name, '}{')
    local num3 = string.find(name, '}}')
    if not num1 then return end
    local x = tonumber(string.sub(name, num1+1, num2-1))
    local z = tonumber(string.sub(name, num2+2, num3-1))
    return x,z
end

function get_world_axis(mapName, bigName)
    if not mapName then return 0, 0 end
    if not bigName then return 0, 0 end
    local x,z = UIUtil.get_grid_xz_by_name(mapName)
    local big_x, big_z = 1, 1
    if bigName then
        big_x, big_z = UIUtil.get_grid_xz_by_name(bigName)
    end
    if not x then
        elog("get_world_axis paramer is error, pls check data"..mapName)
    end
    return x + (big_x - 1) * 25 - config.WORLD_START, z + (big_z - 1) * 25 - config.WORLD_START
end

function get_logic_parent(x, z, logicBox)
    if not logicBox then
        logicBox = GameObject.Find("WorldMap/LogicBox").transform
    end
    local logic_x = x
    local logic_z = z
    local logic_box_x = math.floor((logic_x + config.WORLD_START-1)/25) + 1
    local logic_box_z = math.floor((logic_z + config.WORLD_START-1)/25) + 1
    local select_x = (logic_x + config.WORLD_START)%25 == 0 and 25 or (logic_x + config.WORLD_START)%25
    local select_z = (logic_z + config.WORLD_START)%25 == 0 and 25 or (logic_z + config.WORLD_START)%25    
    local str1 = string.format("LogicCell{%d}{%d}}", logic_box_x, logic_box_z)
    local logic_panel = logicBox:Find(str1)
    if not logic_panel then return end
    local str2 = string.format("select{%d}{%d}}", select_x, select_z)
    local select_panel = logic_panel:Find(str2)
    if not select_panel then return end
    return select_panel
end

--时间(秒)转换成 00:00:00
function format_time(lt)
    if lt == nil or lt == "" then return end
    if not tonumber(lt) then return end
    local hour = math.floor(lt / 3600)
    local min = math.floor((lt - hour * 3600) / 60)
    local sec = lt - hour * 3600 - min * 60
    return string.format("%.2d:%.2d:%.2d", hour, min, sec)
end

function get_march_time_by_distance(distance, speed, attsSpeed)
    if not speed then return 0 end
    if speed == 0 then return 0 end
    if not distance then return 0 end
    speed = speed or 1
    attsSpeed = attsSpeed or 0
    local a = BasicConfig.BasicData.march_a
    local b = BasicConfig.BasicData.march_b
    local c = BasicConfig.BasicData.march_c    
    -- 出征时间 =(-a*距离^2+b*距离+c) /(速度*(1+加成))
    local time = (-a * math.pow(distance, 2) + b * distance + c) / (speed *(1 + attsSpeed))
    return time
end

function get_detect_time_by_distance(distance, attsSpeed)
    local speed = BasicConfig.BasicData.detect_speed or 0
    if speed == 0 then return 0 end
    if not distance then return 0 end
    attsSpeed = attsSpeed or 0
    local a = BasicConfig.BasicData.detect_a
    local b = BasicConfig.BasicData.detect_b
    local c = BasicConfig.BasicData.detect_c    
    -- 侦察行军时间 =(-a*距离^2+b*距离+c) /(速度*(1+加成))
    local time = (-a * math.pow(distance, 2) + b * distance + c) / (speed *(1 + attsSpeed))
    return time
end

--计算平面上2条线段的交点
function get_cross_point(start1, end1, start2, end2)
    local base = end2 - start2
    local bm = base.magnitude
    local hypo = start2 - start1
    local d1 = math.abs(base.x * hypo.y - base.y * hypo.x) / bm
    hypo = end1 - start2
    local d2 = math.abs(base.x * hypo.y - base.y * hypo.x) / bm
    local t = d1 / (d1 + d2)
    local temp = (end1 - start1) * t
    return start1 + temp
end

--资源数值转字符串
function res_num_to_str(num)
    if not num then num = 0 end
    if type(num) ~= "number" or num < 0 then
        elog("The number is invalid: "..tostring(num))
        return "0"
    end
    if num < 10000 then return tostring(num) end
    if num < 100000000 then return lang("RESOURCE_NUM_WAN", math.floor(num / 1000) / 10) end
    return lang("RESOURCE_NUM_YI", math.floor(num / 10000000) / 10)
end

-- 小时 分钟
function get_format_time(time)
    if not time then return "" end
    if time < 0 then return "" end
    local hour = math.floor(time / 3600)
    local min = math.floor((time - hour * 3600) / 60)
    local str = string.format("%s小时%s分钟", hour, min)
    if hour == 0 then
        str = string.format("%s分钟", min)
    end
    return str
end

-- 分 秒
function get_format_time_sec(time)
    if not time then return "" end
    if time < 0 then return "" end
    local min = math.floor(time / 60)
    local sec = math.floor((time - min * 60) % 60)
    local str = string.format("%s分%s秒", min, sec)
    if min == 0 then
        str = string.format("%s秒", sec)
    end
    return str
end

-- x小时x分x秒，为0的部分不显示
function get_format_time_tidy(time)
    if type(time) ~= "number" or time <= 0 then
        return string.format(lang("UI_BASE_SECONDS"), 0)
    end
    local hours = math.floor(time / 3600)
    local rest = time % 3600
    local minutes = math.floor(rest / 60)
    local seconds = math.floor(rest % 60)
    local str = ""
    if hours > 0 then
        str = str..string.format(lang("UI_BASE_HOURS"), hours)
    end
    if minutes > 0 then
        str = str..string.format(lang("UI_BASE_MINUTES"), minutes)
    end
    if seconds > 0 then
        str = str..string.format(lang("UI_BASE_SECONDS"), seconds)
    end
    return str
end

--返回当前时间与传入时间的差值的文本表示
function time_str_from(timestamp)
    local diff = 0
    if type(timestamp) == "number" then
        diff = Net.server_time() - timestamp
    end
    if diff < 60 then diff = 60 end
    if diff < 3600 then
        return lang("UI_BASE_MINUTES_AGO", math.floor(diff / 60))
    elseif diff < 86400 then
        return lang("UI_BASE_HOURS_AGO", math.floor(diff / 3600))
    elseif diff < 172800 then
        return lang("UI_BASE_DAYS_AGO", math.floor(diff / 86400))
    end
    return os.date("%m-%d", timestamp)
end

-- 保留nNum后面n位小数
function get_precise_decimal(nNum, n)
    if type(nNum) ~= "number" then
        return nNum
    end
    n = n or 0
    n = math.floor(n)
    if n < 0 then
        n = 0
    end
    local nDecimal = 10 ^ n
    local nTemp = math.floor(nNum * nDecimal)
    local nRet = nTemp / nDecimal
    return nRet
end

-- 获取字符串第一个字
function get_first_char(str)
    if not str then return "" end
    if type(str) ~= "string" then return "" end
    for i=1,4 do
        local c = string.sub(str,i,i)
        local b = string.byte(c)
        if b > 128 then
            return string.sub(str,1,3)
        else
            return string.sub(str,1,1) 
        end
    end
    return ""
end

--在字符串中所有字符之间插入指定字符
function string_insert(str, insertStr) 
    local len = #str; 
    local left = len; 
    local cnt = 0; 
    local arr={0,0xc0,0xe0,0xf0,0xf8,0xfc}; 
    local indx = -left; 
    local newstr = ""; 
    while left ~= 0 do 
        local tmp=string.byte(str,-left); 
        local i=#arr; 
        while arr do 
            if tmp>=arr[i] then  
                left=left-i; 
                break; 
            end 
            i=i-1;             
        end 
        local substr = string.sub(str,indx,-left - 1); 
        if left ~= 0 then 
            newstr = newstr .. substr .. insertStr; 
        else 
            newstr = newstr .. substr; 
        end 

        indx = -left; 
        cnt=cnt+1; 
    end 
    return newstr; 
end

function IsNaN(value)
    return value ~= value
end

--将时间戳格式化为指定格式，默认为 xxxx年x月x日 xx:xx:xx 
function FormatTimestamp(ts, fmt)
    ts = ts or os.time()
    local t = os.date("*t", ts)
    if fmt then return string.format(fmt, t.year, t.month, t.day, t.hour, t.min, t.sec) end
    return lang("UI_BASE_TIME_FORMAT", t.year, t.month, t.day, t.hour, t.min, t.sec)
end

--将时间段格式化为指定格式，默认为xx:xx:xx
function FormatDuration(d, fmt)
    local hour = math.floor(d / 3600)
    local rest = d % 3600
    local min = math.floor(rest / 60)
    local sec = rest % 60
    if fmt then return string.format(fmt, hour, min, sec) end
    return string.format("%.2d:%.2d:%.2d", hour, min, sec)
end

local function __CalcExpItemRecursively(exp, itemList)
    local use = {}
    local overflow = 0
    local restExp = exp
    for i, info in ipairs(itemList) do
        local e, c, _ = unpack(info)
        if c > 0 then
            local total = e * c
            if total <= restExp then
                use[i] = c
                restExp = restExp - total
            else
                use[i] = math.floor(restExp / e)
                restExp = restExp - use[i] * e
                local o1 = e - restExp
                local list = {}
                for k, v in ipairs(itemList) do
                    --只取经验更少的道具进行递归
                    list[k] = {v[1], k > i and v[2] or 0, v[3]}
                end
                local o2, u = __CalcExpItemRecursively(restExp, list)
                if o1 <= o2 then
                    use[i] = use[i] + 1
                    overflow = o1
                else
                    for m, n in pairs(u) do
                        use[m] = (use[m] or 0) + n
                    end
                    overflow = o2
                end
                restExp = 0 --这种情况不关心restExp剩余值，直接置为0终止循环
            end
        end
        if restExp <= 0 then break end
    end
    if restExp > 0 then --递归终止
        overflow = math.huge
    end
    return overflow, use
end

--给定一个经验值和物品列表，计算经验溢出最少的物品组合，物品的总经验必须足够
--exp: 目标经验值
--itemInfo: 物品信息表{key = {物品提供经验, 物品总数量}, ...}
--return: 最少的溢出经验, 物品使用表{key : 使用数量, ...}
function CalcExpItem(exp, itemInfo)
    local itemList = {}
    for k, v in pairs(itemInfo) do
        table.insert(itemList, {v[1], v[2], k})
    end
    table.sort(itemList, function(a, b) return a[1] > b[1] end)
    local o, u = __CalcExpItemRecursively(exp, itemList)
    local use = {}
    for i, v in pairs(u) do
        use[itemList[i][3]] = v
    end
    return o, use
end
