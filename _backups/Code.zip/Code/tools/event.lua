local List = _G.List
local assert = assert
local rilist = rilist--This is a Func

local e = {}
local o = {}

local event = {}
 _G.event = event

event.once = function(id, func)
  local it = o[id]
  if it == nil then
    it = List:New()
    o[id] = it
  end
  it:PushBack(assert(func))
end

event.add_listener = function(id, key, func)
  local it = e[id]
  if it == nil then
    it = List:New()
    e[id] = it
  end
  it:PushBack({key = key, func = assert(func)})
end

event.remove_listener = function(id, key)
  local it = e[id]
  if it ~= nil then
    for v in rilist(it) do
      if v.key == key then
        it:EraseValue(v)
        break
      end
    end
  end
end

event.fire = function(id, arg)
  local it = e[id]
  if it ~= nil then
    for v in rilist(it) do
      v.func(arg, id)
    end
  end
  it = o[id]
  if it ~= nil then
    for v in rilist(it) do
      v(arg)
    end
    it:Clear()
  end
end

return event