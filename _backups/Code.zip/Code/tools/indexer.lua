_G.Indexer = {}

local Indexer = _G.Indexer

function Indexer.New()
    local count = 0
    local t = {}
    local mt = {}
    mt.__call = function(_,idx)
        count = idx or count
        count = count + 1
        return count
    end
    setmetatable(t, mt)
    return t
end
