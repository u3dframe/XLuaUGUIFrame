local persistentDataPath = _G.Application.persistentDataPath
local CustomFileSystem   = _G.Game.IO.CustomFileSystem
local cjson              = require("tools/dkjson")
local GameFileSystem     = {}
local gfsList            = {}

function GameFileSystem:New(path, o)
    o = o or {}
    if not gfsList[path] then
        local fullPath = string.format("%s/%s", persistentDataPath, path)
        gfsList[path] = CustomFileSystem(fullPath)
    end

    local mt = {__index = self}
    setmetatable(o, mt)
    o.lfs = gfsList[path]
    o.path = path
    return o
end

function GameFileSystem:GetDirectoryFiles(path)
    return self.lfs:GetDirectoryFiles(path)
end

function GameFileSystem:WriteFile(path, content)
    self.lfs:Write(path, content)
end

function GameFileSystem:ReadFile(path)
    local content = self.lfs:Read(path)

    return content
end

function GameFileSystem:ExistsFile(path)
    return self.lfs:Exists(path)
end

function GameFileSystem:MakeRootDirectoryExsit()
    self.lfs:MakeRootDirectoryExsit()
end

--删除一个文件
function GameFileSystem:DeleteFile(path)
    self.lfs:Delete(path)
end

--将一个table写成json
function GameFileSystem:WriteJsonTable( path , data )
    self.lfs:Write(path, cjson.encode(data))
end

--读取json文件返回一个table
function GameFileSystem:ReadJsonTable( path )
    return cjson.decode(self.lfs:Read(path))
end

function GameFileSystem:WriteEncryptTable(path, data, key)
    local jsonContent = _G.GameUtil.RijndaelEncrypt(cjson.encode(data), key)
    self.lfs:Write(path, jsonContent)
end

function GameFileSystem:ReadEncryptTable(path, key)
    if self.lfs:Exists(path) then
        local jsonEncryptContent = self.lfs:Read(path)
        local jsonContent = _G.GameUtil.RijndaelDecrypt(jsonEncryptContent, key)
        return cjson.decode(jsonContent)
    end
end

return GameFileSystem
