local Time         = _G.Time
local create       = coroutine.create
local yield        = coroutine.yield
_G.CoController    = {}
local CoController = _G.CoController

function CoController.Start(func, ...)
    local params = {...}
    local cofunc = function()
        func(unpack(params))
    end
    return create(cofunc)
end

function CoController.IsFinished(handle)
    if handle then
        return handle.finished
    end
    return false
end

function CoController.Wait(waiting, handle)
    handle = handle or { finished = false }
    while waiting() and not handle.finished do

        Yield()
    end
end

function CoController.WaitFrame(count, handle)
    handle = handle or { finished = false }
    local count_target = Time.frameCount + count
    while Time.frameCount < count_target and not handle.finished do
        Yield()
    end
end

function CoController.WaitSeconds(seconds, handle)
    handle = handle or { finished = false }
    local count_target = Time.time + seconds
    while Time.time < count_target and not handle.finished do
        Yield()
    end
end

local function once(func)
    local fired = false
    return function()
        if fired then return end
        fired = true
        func()
    end
end

function CoController.WaitNetPackage(protoID, waitTime)
    local Check = _G.NetController.CheckMessage
    print("waiting for net receive " .. tostring(protoID))
    local count_target = Time.time + waitTime or 1
    local expireTime = Time.time + 8
    local showed = false
    local waiting = once(function()
        _G.LogicMain.ShowNetWaiting(true)
        showed = true
    end)
    while not Check(protoID) do
        yield()
        if Time.time >= expireTime then
            if _G.UIController.GetUI("UINetWaiting"):IsShow() then
                _G.LogicMain.ShowNetWaiting(false)
            end
            return false
        end
        if Time.time >= count_target then
            waiting()
        end
    end
    if showed then
        _G.LogicMain.ShowNetWaiting(false)
    end
    return true
end

function CoController.WaitBTComplete(bt)
    while not bt.IsComplete do
        yield()
    end
end

function CoController.WaitTimelineComplete(pd)
    print("check start")
    local done = false
    local check = function()
        done = true
    end
    pd:WaitDone(check)
    while not done do
        yield()
    end
    print("is done")
end