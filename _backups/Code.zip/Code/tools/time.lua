local Time     = {}

local serverTime = 0
local serverTimeDiff = 0
local TimerController = _G.EngineCore.GameController.TimerController

function Time.UTCTime()
    return TimerController.LocalUTCTime + serverTimeDiff
end

function Time.SetServerTime(st)
    serverTime = st
    serverTimeDiff = serverTime - TimerController.LocalUTCTime
end

function Time.ServerTime()
    return TimerController.Milliseconds / 1000 + serverTimeDiff
end

function Time.IsExpire(t)
    return Time.Now >= t
end

function Time.Expire(t)
    return Time.Now - t
end

function Time.Left(t)
    return math.max(t - Time.Now, 0)
end

function Time.FormatSpecial(t)
    local seconds = t % 60
    t = math.floor(t / 60)
    local minutes = t % 60
    t = math.floor(t / 60)
    local hours = t % 24
    t = math.floor(t / 24)

    local days = math.floor(t)

    if days > 0 then
        return string.format("%02d:%02d:%02d:%02d", days, hours, minutes, seconds)
    end

    return string.format("%02d:%02d:%02d", hours, minutes, seconds)
end


Time = setmetatable(Time, {
    __index = function(_, k)
        if k == "Now" then
            return TimerController.LocalUTCTime + serverTimeDiff
        end

        if k == "ServerTime" then
            return TimerController.Milliseconds / 1000 + serverTimeDiff
        end

        assert("方法未定义")
    end
})

return Time
