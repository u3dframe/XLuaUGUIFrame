---
--- Lua Fun - a high-performance functional programming library for LuaJIT
---
--- Copyright (c) 2013-2017 Roman Tsisyk <roman@tsisyk.com>
---
--- Distributed under the MIT/X11 License. See COPYING.md for more details.
---

local exports = {}
-- local methods = {}

-- compatibility with Lua 5.1/5.2
-- local unpack = rawget(table, "unpack") or unpack

--------------------------------------------------------------------------------
-- Tools
--------------------------------------------------------------------------------

local function partial(fun, ...)
    local argCount = select('#', ...)
    assert(type(fun) == "function", "partial need a function")
    assert(argCount <= 7, "partial parameter only support 7 args")
    if argCount == 0 then
        return fun
    elseif argCount == 1 then
        local a = select('1', ...)
        return function(...)
            return fun(a, ...)
        end
    elseif argCount == 2 then
        local a = select('1', ...)
        local b = select('2', ...)
        return function(...)
            return fun(a, b, ...)
        end
    elseif argCount == 3 then
        local a = select('1', ...)
        local b = select('2', ...)
        local c = select('3', ...)
        return function(...)
            return fun(a, b, c, ...)
        end
    elseif argCount == 4 then
        local a = select('1', ...)
        local b = select('2', ...)
        local c = select('3', ...)
        local d = select('4', ...)
        return function(...)
            return fun(a, b, c, d, ...)
        end
    elseif argCount == 5 then
        local a = select('1', ...)
        local b = select('2', ...)
        local c = select('3', ...)
        local d = select('4', ...)
        local e = select('5', ...)
        return function(...)
            return fun(a, b, c, d, e, ...)
        end
    elseif argCount == 6 then
        local a = select('1', ...)
        local b = select('2', ...)
        local c = select('3', ...)
        local d = select('4', ...)
        local e = select('5', ...)
        local f = select('6', ...)
        return function(...)
            return fun(a, b, c, d, e, f, ...)
        end
    elseif argCount == 7 then
        local a = select('1', ...)
        local b = select('2', ...)
        local c = select('3', ...)
        local d = select('4', ...)
        local e = select('5', ...)
        local f = select('6', ...)
        local g = select('7', ...)
        return function(...)
            return fun(a, b, c, d, e, f, g, ...)
        end
    end
end
exports.partial = partial

--------------------------------------------------------------------------------
-- module definitions
--------------------------------------------------------------------------------

-- a special syntax sugar to export all functions to the global table
setmetatable(exports, {
    __call = function(t, override)
        for k, v in pairs(t) do
            if rawget(_G, k) ~= nil then
                local msg = 'function ' .. k .. ' already exists in global scope.'
                if override then
                    rawset(_G, k, v)
                    print('WARNING: ' .. msg .. ' Overwritten.')
                else
                    print('NOTICE: ' .. msg .. ' Skipped.')
                end
            else
                rawset(_G, k, v)
            end
        end
    end,
})

return exports
