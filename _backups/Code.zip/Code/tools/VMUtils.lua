local Rx
local inspect
local logError
if _G.package.cpath ~= "" and false then
    print(package.cpath)
    Rx = require("Rx")
    _G.unpack = unpack or table.unpack
    inspect = require("inspect")
    logError = print
    dump = function(t, type)
        print(type, inspect(t))
    end
else
    _G.unpack = unpack or table.unpack
    inspect = require("Tools/inspect")
    Rx = require("Tools/Rx")
    logError = _G.GameLog.LogError
end

local hashSetMt = {_name = "hashSetMt"}

local function makeHashSet(t)
    return setmetatable({ (t or {}) }, hashSetMt)
end

local arrayMt = {_name = "arrayMt"}

local function makeArray(t)
    return setmetatable({ t }, arrayMt)
end

local VM = {
    number  = type(0),
    hashset = makeHashSet,
    map     = "map",
    array   = makeArray,
    string  = type(""),
    boolean = type(true),
}

local function isarray(t)
    if type(t) ~= "table" then
        return false
    end

    local n = #t
    for i in pairs(t) do
        if type(i) ~= "number" then
            return false
        end

        if i > n then
            return false
        end
    end

    return true
end

local function unwrap(v, targetType)
    if v == VM.array then
        return {}, VM.array
    end

    if v == VM.hashset then
        return {}, VM.hashset
    end

    if type(v) == "table" then
        if getmetatable(v) == hashSetMt then
            return (unpack(v)), VM.hashset
        end

        if targetType == VM.hashset then
            return v, VM.hashset
        end

        if getmetatable(v) == arrayMt then
            return (unpack(v)), VM.array
        end

        if isarray(v) then
            return v, VM.array
        end

        return v, VM.map
    end

    return v, type(v)
end

local reactVar
local reactMap
local reactTable
local reactArray
local reactToMap

local function cleanUp(subject, vars)
    if subject.observers then
        subject.observers = {}
    end

    if not vars then
        return
    end

    for _, v in pairs(vars) do
        v:cleanUp()
    end
end

local function SplitLine(inputstr)
    local sep = "\n"

    local t = {}

    for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
        table.insert(t, str)
    end

    return t
end

local function collectParentKeys(var)
    local parents = { var }
    while parents[#parents].parent do
        parents[#parents + 1] = parents[#parents].parent
    end

    local chain = { "vm" }
    for i = #parents, 1, -1 do
        local parent = parents[i]
        local next_ = parents[i - 1]
        if parent then
            if next_ then
                table.insert(chain, parent.key(next_))
            end
        end
    end

    return chain
end

local function printStack(var, result, title)
    local msgs = {}
    for _, str in ipairs(SplitLine(debug.traceback("", 1))) do
        table.insert(msgs, str)
    end

    if result then
        table.insert(msgs, 3, ("\t%s"):format(result))
    end

    table.insert(msgs, 1, (table.concat(collectParentKeys(var), "->")))
    table.insert(msgs, 2, (title))

    logError(table.concat(msgs, "\n"))
end

local function checkType(var, v)
    local type_ = var.type
    if type_ == VM.map then
        if type(v) ~= "table" then
            printStack(var, nil, "变量类型必须是 hashmap!")
            return
        end
    elseif type_ == VM.hashset then
        if type(v) ~= "table" then
            printStack(var, nil, "变量类型必须是 hashset!")
            return
        end
    elseif type_ == VM.array then
        if not isarray(v) then
            printStack(var, nil, "变量类型必须是 array!")
            return
        end
    elseif type_ == "number" then
        if type(v) ~= "number" then
            printStack(var, nil, "变量类型必须是 number!")
            return
        end
    elseif type_ == "string" then
        if type(v) ~= "string" then
            printStack(var, nil, "变量类型必须是 string!")
            return
        end
    elseif type_ == "boolean" then
        if type(v) ~= "boolean" then
            printStack(var, nil, "变量类型必须是 boolean!")
            return
        end
    end

    return true
end

reactToMap = function(t, react, notifyObjects)
    if not next(t) then
        return
    end

    local changed = false

    for k, v in pairs(t) do
        local var = react[k]
        local value, vType = unwrap(v, var.type)

        if checkType(var, value) then
            if vType ~= VM.map then
                local ok, result = pcall(function()
                    var.rx(value)
                end)
                if not ok then
                    printStack(var, result)
                    return
                end
            else
                reactToMap(value, var, notifyObjects)
            end

            changed = true
        end
    end

    if changed then
        notifyObjects[react] = true
    end
end

local function makeAccessField(subject, accessMap, parent, vars)
    return function(self, k)
        local accessField = accessMap[k]
        if accessField then
            return accessField
        end

        if k == "parent" then
            return parent
        end

        if k == "value" then
            return subject:getValue()
        end

        if vars and vars[k] then
            return vars[k]
        end

        error(("没有定义变量 : %s -> %s"):format(table.concat(collectParentKeys(self), "->"), k))
    end
end

reactMap = function(map, parent)
    local react = {}

    local subject = Rx.BehaviorSubject.create(react)

    local vars = {}

    local new = function(k, v)
        assert(k ~= "rx", "rx 是关键字！")
        assert(k ~= "value", "value 是关键字！")
        assert(k ~= "type", "type 是关键字！")
        assert(not vars[k], "key值已经存在！")

        local value, type = unwrap(v)

        if type == VM.hashset then
            vars[k] = reactTable(value, react)
            return
        end

        if type == VM.array then
            vars[k] = reactArray(value, react)
            return
        end

        if type == VM.map then
            vars[k] = reactMap(value, react)
            return
        end

        vars[k] = reactVar(value, react)
    end

    for k, v in pairs(map) do
        new(k, v)
    end

    local function key(var)
        for k,v in pairs(vars) do
            if v == var then
                return k
            end
        end
    end

    return setmetatable(react, {
        __index = makeAccessField(subject, {
            type    = VM.map,
            rx      = subject,
            new     = new,
            key     = key,
            cleanUp = function() cleanUp(subject, vars) end,
        }, parent, vars),

        __tostring = function()
            local t = {}
            for k, v in pairs(vars) do
                table.insert(t, string.format("%s -> %s", k, tostring(v)))
            end
            return string.format("(Map){ %s }", table.concat(t, " | "))
        end,

        __newindex = function(self, k, v)
            local var = vars[k]

            if not var then
                error(("不能在运行时增减变量 : %s -> %s"):format(table.concat(collectParentKeys(self), "->"), k))
            end

            local value, type = unwrap(v, var.type)

            if not checkType(var, value) then
                return
            end

            if type == VM.map and not next(value) then
                return
            end


            local notifyObjects = {}

            if type ~= VM.map then
                var.rx(value)
                notifyObjects[self] = true
            elseif reactToMap(value, var, notifyObjects) then
                notifyObjects[self] = true
            end

            for notifyObject in pairs(notifyObjects) do
                local p = notifyObject
                while p do
                    if not notifyObjects[p] then
                        notifyObjects[p] = true
                    end
                    p = p.parent
                end
            end

            for notifyObject in pairs(notifyObjects) do
                notifyObject.rx(notifyObject)
            end
        end
    })
end

reactArray = function(var, parent)
    local react = {}

    local subject = Rx.BehaviorSubject.create(var)

    return setmetatable(react, {
        __index = makeAccessField(subject, {
            type    = VM.array,
            parent  = parent,
            rx      = subject,
            cleanUp = function() cleanUp(subject) end
        }),

        __tostring = function(self)
            local t = {}
            for _, v in ipairs(self.rx:getValue()) do
                table.insert(t, string.format("%s", tostring(v)))
            end
            return string.format("(Array)[ %s ]", table.concat(t, " | "))
        end,

        __newindex = function(self, k)
            error(("不能在运行时增减变量 : %s -> %s"):format(table.concat(collectParentKeys(self), "->"), k))
        end,
    })
end

reactTable = function(var, parent)
    local react = {}

    local subject = Rx.BehaviorSubject.create(var)

    return setmetatable(react, {
        __index = makeAccessField(subject, {
            type    = VM.hashset,
            parent  = parent,
            rx      = subject,
            cleanUp = function() cleanUp(subject) end,
        }),

        __tostring = function(self)
            local t = {}
            for k, v in pairs(self.rx:getValue()) do
                table.insert(t, string.format("%s : %s", k, tostring(v)))
            end
            return string.format("(HashSet)%s", inspect(self.rx:getValue()))
        end,

        __newindex = function(self, k)
            error(("不能在运行时增减变量 : %s -> %s"):format(table.concat(collectParentKeys(self), "->"), k))
        end,
    })
end

reactVar = function(var, parent)
    local react = {}

    local subject = Rx.BehaviorSubject.create(var)

    assert(type(var) ~= "nil", "不能传入空值!")

    return setmetatable(react, {
        __index = makeAccessField(subject, {
            type    = type(var),
            parent  = parent,
            rx      = subject,
            cleanUp = function() cleanUp(subject) end
        }),
        __tostring = function(self)
            return string.format("(Var)%s:%s", tostring(subject:getValue()), self.type)
        end
    })
end

rawset(_G, "VM", VM)

return reactMap