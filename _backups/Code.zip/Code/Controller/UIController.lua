local UIBase = require "Base/UIBase"
local GameController = _G.EngineCore.GameController
_G.UIController = {}
local UIController    = _G.UIController
local UIList       = {}

--打开的ui
local activeUIList       = {}
local activeStaticUIList = {}
local activeNomalUIList  = {}
local activeWindowUIList = {}

local stablePackages =
{
    "CommonButton",
    "ImageCommon",
    "ImageCommonButton",
    "ImageCommonIcon",
    "ImageCommonBg",
    "ImageCommonBigBg",
    "ImageCommonSlider",
    "CommonSlider",
    "CommonComponent",
    "ImageCommonHero"
    -- "CommonImage",
}

local useFont =
{
    "fztys",
    "msyh",
}

function UIController:Init()
    GameController.uiController:InitStablePackageList(stablePackages)
    -- GameController.uiController:PreLoadFont(useFont)
end

function UIController:Get(uiName)
    if not UIList[uiName] then
        UIList[uiName] =  UIBase:New(uiName)
        local uiScript = string.format("FUI/%s" , uiName)
        require (uiScript)
    end
    return UIList[uiName]
end

function UIController:ShowUI(uiName, args, calBack)
    local ui = self:Get(uiName)
    if ui then
        return ui:Show(args, calBack)
    end
end

function UIController:CloseUI(uiName)
    local ui = self:Get(uiName)
    if ui then
        ui:Hide()
    end
end

--关掉所有UI，回到主界面
function UIController:CloseAllUI(isForce)
    --StaticUI不会被删除
    for _, ui in ipairs(activeUIList) do
        if isForce then
            ui:Hide()
        elseif ui.uiType ~= _G.GlobalEmum.UIType.Static then
            ui:Hide()
        end
    end
end

function UIController:PushToActiveUI(ui)
    table.insert(activeUIList , ui)
    if self.uiType == _G.GlobalEmum.UIType.Static then
        activeStaticUIList[ui.uiName] = true
    elseif self.uiType == _G.GlobalEmum.UIType.NormalUI then
        activeNomalUIList[ui.uiName] = true
    elseif self.uiType == _G.GlobalEmum.UIType.Window then
        activeWindowUIList[ui.uiName] = true
    end
end

function UIController:RemoveFromActiveUI(ui)
    for i,v in ipairs(activeUIList) do
        if v == ui then
            table.remove(activeUIList, i)
        end
    end
    if self.uiType == _G.GlobalEmum.UIType.Static then
        activeStaticUIList[ui.uiName] = nil
    elseif self.uiType == _G.GlobalEmum.UIType.NormalUI then
        activeNomalUIList[ui.uiName] = nil
    elseif self.uiType == _G.GlobalEmum.UIType.Window then
        activeWindowUIList[ui.uiName] = nil
    end
end

function UIController:LoadGameObjectToUI(loader, obj)
    return GameController.uiController:LoadGameObjectToUI(loader, obj)
end


UIController:Init()