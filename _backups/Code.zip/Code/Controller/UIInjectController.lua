local UIInjectController = _G.DefineGVar("UIInjectController", {
    plugins = {}
})

function UIInjectController:Use(plugin)
    table.insert(self.plugins, plugin)

    if type(plugin.OnInit) == "function" then
        plugin:OnInit()
    end
end

function UIInjectController:InjectAfterInitVM(ui, vm)
    for _, v in ipairs(self.plugins) do
        if type(v.OnAfterInitVM) == "function" then
            v:OnAfterInitVM(ui, vm)
        end
    end
end

function UIInjectController:InjectAfterInitBinds(ui)
    for _, v in ipairs(self.plugins) do
        if type(v.OnAfterInitBinds) == "function" then
            v:OnAfterInitBinds(ui)
        end
    end
end

function UIInjectController:InjectBeforeHide(ui)
    for _, v in ipairs(self.plugins) do
        if type(v.OnBeforeHide) == "function" then
            v:OnBeforeHide(ui)
        end
    end
end