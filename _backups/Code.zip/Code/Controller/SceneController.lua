local SceneBase = require "Base/SceneBase"

_G.SceneController                   = {}
local SceneController                = _G.SceneController
local sceneList                      = {}

function SceneController:Get(sceneName)
    if not sceneList[sceneName] then
        sceneList[sceneName] = SceneBase:New(sceneName)
        local luaPath = string.format("Scene/%s" , sceneName)
        require (luaPath)
    end
    return sceneList[sceneName]
end


function SceneController:LoadScene(sceneName , args)
    print("SceneController:LoadScene bb")
    if _G.string.IsNullOrEmpty(sceneName) then
        print("the sceneName is null or empty")
    end

    print("SceneController:LoadScene cc")
    if self.currentScene then
        print("SceneController:Unload old")
        self.currentScene:Unload()
    end

    self.currentScene = self:Get(sceneName)
    print("SceneController:LoadScene dd")
    if not self.currentScene then
        print(string.format("error scene: %s"  , sceneName ))
        return
    end

    self.currentScene:LoadScene(args)
end

function SceneController:GetMainCamObj()
    if not self.currentScene then
        return
    end
    return self.currentScene:GetMainCameraObj()
end

function SceneController:OnUpdate(dt)
    if self.currentScene then
        self.currentScene:OnUpdate(dt)
    end
end

function SceneController:EnterCity()
    _G.UIController:ShowUI("UILoading")
    _G.AudioManager.Play("SOUND_BUTTON_CHANGE")
    _G.Net.send("map_unwatch")
    self:LoadScene("SceneMain")
end

function SceneController:UnloadAll()
    print("SceneController:LoadScene cc")
    if self.currentScene then
        print("SceneController:Unload old")
        self.currentScene:Unload()
    end
end

function SceneController:EnterWorld()
    
    _G.AudioManager.Play("SOUND_BUTTON_CHANGE")
    _G.SceneManager.enter_world(function()
        _G.WorldManager:build_world_obj()
        _G.WorldManager:init_watch_pos()
    end)
    

    -- _G.UIController:ShowUI("UILoading")
    -- _G.AudioManager.Play("SOUND_BUTTON_CHANGE")
    -- _G.Net.send("map_watch", {})
    -- self:LoadScene("SceneWorld")
end