local root = assert(arg[1])
package.path =
    root ..
    "/lualib/?.lua;" ..
        root .. "/lualib/?/init.lua;" .. root .. "/skynet/lualib/?.lua;" .. root .. "/skynet/lualib/?/init.lua;"
package.cpath = root .. "/luaclib/?.so;" .. root .. "/skynet/luaclib/?.so"

local lfs = require "lfs"
local lpeg = require "lpeg"
local parser = require "sprotoparser"
local sprotocore = require "sproto.core"
local traceback = require "trace.c"
local getupvalue = require "debug.getupvalue"
local uitl = require "util"

local parserfunc = getupvalue(parser.parse, "parser")

local check_protocol = getupvalue(parserfunc, "check_protocol")
local exception = getupvalue(parserfunc, "exception")
local proto = getupvalue(parserfunc, "proto")
local adjust = getupvalue(parserfunc, "adjust")

local function parser_check(text, filename)
    local state = {file = filename, pos = 0, line = 1}
    local r = lpeg.match(proto * -1 + exception, text, 1, state)
    return check_protocol(adjust(r))
end

local function calc_min_max(st)
    local min, max
    for name, v in pairs(st.protocol) do
        local tag = v.tag
        if not min then
            min, max = tag, tag
        end
        if min > tag then
            min = tag
        end
        if max < tag then
            max = tag
        end
    end
    return min, max
end

local function trim(s)
    return (string.gsub(s, "\n[\n\r]*", "\n"))
end

traceback = debug.traceback
local function loadall(mat, outf)
    local files = {}
    for file in lfs.dir(root .. "/proto/") do
        if file ~= "." and file ~= ".." then
            if file:match(mat) then
                local f = io.open(root .. "/proto/" .. file)
                local source = f:read("*a")
                f:close()
                local ok, st = pcall(parser_check, source)
                if not ok then
                    error(string.format("\n%s\nin ./%s", st, file))
                end
                local min, max = calc_min_max(st)
                if min then
                    table.insert(files, {file, min, max, source})
                end
            end
        end
    end
    table.sort(
        files,
        function(a, b)
            return a[2] < b[2]
        end
    )
    local file_content = {}
    for _, info in ipairs(files) do
        table.insert(file_content, "#" .. info[1])
        table.insert(file_content, info[4])
    end
    local source = trim(table.concat(file_content, "\n"))
    print(string.format("merge %s/sproto/%s to %s ", root, mat, root .. "/proto/" .. outf))
    local outfile = io.open(root .. "/proto/" .. outf, "w")
    outfile:write(source)
    outfile:close()
    sprotocore.newproto(parser.parse(source))
end

loadall(".c2s$", "proto.c2s.sproto")
loadall(".s2c$", "proto.s2c.sproto")
