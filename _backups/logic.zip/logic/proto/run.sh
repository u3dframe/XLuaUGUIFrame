#!/bin/bash

ROOT=$(
	cd $(dirname $0)/..
	pwd
)
${ROOT}/skynet/3rd/lua/lua ${ROOT}/proto/merge.lua ${ROOT}