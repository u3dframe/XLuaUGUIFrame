local skynet = require "skynet"
local timer = require "timer"
local utime = require "util.time"
local ceil = math.ceil

local _M = {}

--- @param ti number
--- @param cb fun():void
--- @return number timerid
function _M.add(ti, cb)
    return timer.add(ti * 100, cb)
end

--- @param expire number
--- @param cb fun():void
--- @return number timerid
function _M.addexpire(expire, cb)
    local now = utime.time()
    local diff = expire - now
    return timer.add(ceil(diff * 100), cb)
end

--- @param id number timerid
--- @return fun():any
function _M.del(id)
    return timer.del(id)
end

--- @param ti number
function _M.wait(ti)
    local co = coroutine.running()
    _M.add(
        ti,
        function()
            skynet.wakeup(co)
        end
    )
    skynet.wait(co)
end

--- @param expire number timestamp
function _M.wait_to(expire)
    local co = coroutine.running()
    _M.addexpire(
        expire,
        function()
            skynet.wakeup(co)
        end
    )
    skynet.wait(co)
end

return _M
