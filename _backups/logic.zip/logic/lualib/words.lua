local skynet = require "skynet"

local address
skynet.init(function()
    address = skynet.uniqueservice("base/words")
end)

local _M = {}

--- @param str string
--- @return boolean
function _M.dirtycheck(str)
    return skynet.call(address, "lua", "dirtycheck", str)
end

--- @param str string
--- @return string
function _M.dirtyfilter(str)
    return skynet.call(address, "lua", "dirtyfilter", str)
end

--- @param set string
--- @param str string
--- @return string
function _M.charcheck(str, set)
    return skynet.call(address, "lua", "charcheck", str, set)
end

return _M
