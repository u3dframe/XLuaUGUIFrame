local skynet = require "skynet"
local util = require "util.string"
local utime = require "util.time"

local escape_map = {
    ["\0"] = "\\0",
    ["\b"] = "\\b",
    ["\n"] = "\\n",
    ["\r"] = "\\r",
    ["\t"] = "\\t",
    ["\26"] = "\\Z",
    ["\\"] = "\\\\",
    ["'"] = "\\'",
    ['"'] = '\\"'
}
local function quote_sql_str(str)
    return (string.gsub(str, '[\0\b\n\r\t\26\\\'"]', escape_map))
end

local _M = {}

function _M.select_rolelist(proxy, self)
    local _uid, _sid = self.uid, self.sid
    local sql = util.strfmt("select rid,sid,rname from t_player where uid={1} and sid={2}", _uid, _sid)
    local d = skynet.call(proxy, "lua", "query", sql)
    local r = {}
    for _, row in ipairs(d) do
        local rid, sid, rname = row[1], row[2], row[3]
        r[rid] = {
            sid = sid,
            rid = rid,
            rname = rname
        }
    end
    return r
end

function _M.select_role(proxy, rid)
    local sql = util.strfmt("select rid,sid,rname from t_player where rid={1}", rid)
    local d = skynet.call(proxy, "lua", "query", sql)
    local row = d[1]
    if row then
        local rid, sid, rname = row[1], row[2], row[3]
        return {
            sid = sid,
            rid = rid,
            rname = rname
        }
    end
end

function _M.role_create(proxy, args)
    local _uid, _sid = args.uid, args.sid
    local rid = _uid
    local rname = args.rname
    local quote_rname = quote_sql_str(rname)
    local sql =
        util.strfmt(
        "insert ignore t_player(rid,rname,sid,uid,created) values({1},'{2}',{3},'{4}',{5})",
        rid,
        quote_rname,
        _sid,
        _uid,
        utime.time_int()
    )

    local d = skynet.call(proxy, "lua", "query", sql)
    if d.affected_rows == 0 then
        return 3
    end
    return 0, rid, rname
end

return _M
