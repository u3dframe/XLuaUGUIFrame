local skynet = require "skynet"
local logerr = require "log.err"
local LOCK = require "skynet.queue"

local SAVE
local DIRTY
local QUEUE
local SAVE_LOCK
local INSAVE

local buildsql =
    [[CREATE TABLE IF NOT EXISTS `t_mod_%s`(
	`id` BIGINT NOT NULL,
	`val` MEDIUMBLOB NULL,
	`ver` INT(11) NULL DEFAULT '0',
	PRIMARY KEY (`id`)
)
ENGINE=Innodb;
]]

local chache_pack = skynet.packstring
local chache_unpack = skynet.unpack
local format = string.format
local traceback = debug.traceback
local xpcall = xpcall

local function load_record(self, k)
    local ssql = format("select val,ver from t_mod_%s where id=%s", k, self.rid)
    local d = skynet.call(self.proxy, "lua", "safe_query", ssql)
    if d.errno then
        if d.errno == 1146 then
            skynet.send(self.proxy, "lua", "query", format(buildsql, k))
            return load_record(self, k)
        else
            error(d.err)
        end
    elseif #d == 1 then
        d = d[1]
        d[1] = chache_unpack(d[1])
    elseif #d == 0 then
        local isql = format("insert ignore t_mod_%s(id,val) values(?,?)", k)
        skynet.call(self.proxy, "lua", "stmt", isql, self.rid, chache_pack {})
        return load_record(self, k)
    else
        assert(false)
    end
    return d
end

local function save_record(self, k, val, ver)
    local usql = format("update t_mod_%s set val=?,ver=? where id=?", k)
    skynet.call(self.proxy, "lua", "stmt", usql, chache_pack(val), ver, self.rid)
end

local function load(self, k)
    local m = SAVE[k]
    if m then
        return m
    end
    SAVE[k] = load_record(self, k)
end

local function save(self)
    if not DIRTY then
        return
    end
    local errn = 0
    for k, d in pairs(SAVE) do
        if d.dirty then
            local val, ver = d[1], d[2]
            local ok, err = xpcall(save_record, traceback, self, k, val, ver)
            if not ok then
                logerr(err)
                errn = errn + 1
            else
                if d[2] == ver then
                    d.dirty = nil
                end
            end
        end
    end
    assert(errn == 0, "raised error when save")
end

local function getsub(S, K, ...)
    if K == nil then
        return S
    end
    local s = S[K]
    if not s then
        s = {}
        S[K] = s
    end
    return getsub(s, ...)
end

local _M = {}

function _M.init()
    SAVE = {}
    SAVE_LOCK = LOCK()
    QUEUE =
        setmetatable(
        {},
        {
            __index = function(t, k)
                local q = LOCK()
                t[k] = q
                return q
            end
        }
    )
end

local function load_inner(self, k, ...)
    local m = SAVE[k]
    if m then
        return getsub(m[1], ...)
    end
    QUEUE[k](load, self, k)
    local S = SAVE[k][1]
    return getsub(S, ...)
end

local function dirty_inner(self, k)
    assert(self)
    DIRTY = true
    local d = SAVE[k]
    d.dirty, d[2] = true, d[2] + 1
    if not INSAVE then
        INSAVE = true
        skynet.fork(
            function()
                skynet.sleep(6000)
                INSAVE = nil
                _M.save(self)
            end
        )
    end
end

function _M.save(self)
    SAVE_LOCK(save, self)
end

function _M.unload(self)
    while DIRTY do
        _M.save(self)
        local dirty
        for _, v in pairs(SAVE) do
            if v.dirty then
                dirty = true
                break
            end
        end
        if not dirty then
            DIRTY = nil
        end
    end
    SAVE = nil
end

local function proxy(k, ...)
    local args = {...}
    local c
    local function get(self)
        if c then
            return c
        end
        c = load_inner(self, k, table.unpack(args))
        return c
    end
    return {
        get = get,
        getsub = function(self, ...)
            return getsub(get(self), ...)
        end,
        dirty = function(self)
            dirty_inner(self, k)
        end
    }
end

--- @class modcache
--- @field get fun(self:role):table
--- @field getsub fun(self:role,...:string):table
--- @field dirty fun(self:role):void

--- @type fun(...:string):modcache
local call =
    setmetatable(
    _M,
    {
        __call = function(_, ...)
            return proxy(...)
        end
    }
)

return call
