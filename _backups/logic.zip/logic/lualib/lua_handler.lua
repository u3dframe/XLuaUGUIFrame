--- @type table<string,fun(...):any>
local _M = {}

return _M
