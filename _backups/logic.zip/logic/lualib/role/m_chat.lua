local skynet = require "skynet"
local log = require "log"

-- local chatd
-- skynet.init(
--     function()
--         chatd = skynet.uniqueservice("game/chatd")
--     end
-- )

-- require("role.mods") {
--     name = "chat",
--     enter = function(self)
--         skynet.send(chatd, "lua", "reg", self.rid, self.fd)
--     end,
--     afk = function(self)
--         skynet.send(chatd, "lua", "unreg", self.rid)
--     end
-- }

local _H = require "client.handler"

-- local function create_chat_msg(self, channel, content)
--     return {
--         rid = self.rid,
--         rname = self.rname,
--         channel = channel,
--         content = content
--     }
-- end

-- function _H.chat_chating(self, msg)
--     local ok, ret = skynet.call(skynet.uniqueservice("game/cmd"), "lua", "agent_comand", self.rid, msg.content)
--     if ok then
--         log("cmd:" .. msg.content)
--         return {e = 0}
--     end
--     if not skynet.call(chatd, "lua", "world_chat", create_chat_msg(self, msg.channel, msg.content)) then
--         return {e = 1}
--     --full
--     end
--     return {e = 0}
-- end

local utime = require "util.time"
function _H.ping(self, msg)
    msg.ti = utime.time()
    return msg
end
