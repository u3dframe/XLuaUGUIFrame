local logerr = require "log.err"
local ipairs = ipairs
local xpcall = xpcall
local traceback = debug.traceback
local events = {}
local skynet = require "skynet"

local _M = {}
local list = {
    ["EV_UPDATE"] = true, --跨天更新
    ["EV_SOLDIER_PICK"] = true, --士兵收取
    ["EV_MONSTER_KILL"] = true, --击杀野怪
    ["EV_ACTIVITY_VAL"] = true, --活跃值变化
    ["EV_BUILD_DECTIME"] = true, --建筑加速
    ["EV_BUILDING_LVUP"] = true, --建筑升级
    ["EV_ATTRS_CHANGE"] = true --属性变化
}

function _M.reg(k, name, cb)
    assert(list[k] and name and cb)
    local grp = events[k]
    if not grp then
        grp = {}
        events[k] = grp
    end
    for _, node in ipairs(grp) do
        if node[2] == name then
            node[1], name = cb, nil
            logerr("duplicated call in cb %s.%s", tostring(k), tostring(node[2]))
            break
        end
    end
    if name then
        table.insert(grp, {cb, name})
    end
end

local function occur(k, ...)
    local grp = events[k]
    if grp then
        for _, node in ipairs(grp) do
            local ok, err = xpcall(node[1], traceback, ...)
            if not ok then
                logerr(err)
            end
        end
    end
end

function _M.occur(k, ...)
    skynet.fork(occur, k, ...)
end

_M.raw_occur = occur

return _M
