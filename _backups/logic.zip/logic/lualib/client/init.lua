local skynet = require "skynet"
local socketdriver = require "skynet.socketdriver"
local log = require "log"

local string = string

local client = {}
local sender

local thread = {}
local retmsg = {}
local reterr = {}

--- @param session number
--- @param result table
function client.response(session, result)
    local co = thread[session]
    if not co then
        log("Invalid session " .. session)
    else
        retmsg[session] = result
        thread[session] = nil
        reterr[session] = nil
        skynet.wakeup(co)
    end
end

--- @param self role
--- @param why string
function client.close(self, why)
    skynet.call(self.gate, "lua", "kick", self.fd, why or "close")
end

--- @param self role
--- @param t string
--- @param data table
function client.push(self, t, data)
    local msg = string.pack(">s2", sender(t, data))
    if self.fd then
        socketdriver.send(self.fd, msg)
    end
end

--- @param fd number
--- @param t string
--- @param data table
function client.pushfd(fd, t, data)
    if not fd then
        return
    end
    local m = sender(t, data)
    local msg = string.pack(">s2", m)
    socketdriver.send(fd, msg)
end

--- @param fds table<number,any>
--- @param t string
--- @param data table
function client.pushfds(fds, t, data)
    local msg = string.pack(">s2", sender(t, data))
    for fd in pairs(fds) do
        socketdriver.send(fd, msg)
    end
end

--- @param objs table<any,role>
--- @param t string
--- @param data table
function client.pushobjs(objs, t, data)
    local msg = string.pack(">s2", sender(t, data))
    for _, obj in pairs(objs) do
        if obj.fd then
            socketdriver.send(obj.fd, msg)
        end
    end
end

--- @param self role
--- @param ti number
--- @param t string
--- @param data table
--- @return table | nil
function client.request(self, ti, t, data)
    local session = skynet.genid()
    local msg = string.pack(">s2", sender(t, data, session))
    assert(socketdriver.send(self.fd, msg))
    local co = coroutine.running()
    thread[session] = co
    skynet.timeout(
        ti,
        function()
            local o = thread[session]
            if not o then
                return
            end
            retmsg[session] = string.format("timeout %s %s", tostring(self.fd), tostring(t))
            reterr[session] = true
            thread[session] = nil
            skynet.wakeup(o)
        end
    )
    skynet.wait()
    local err = reterr[session]
    local ret = retmsg[session]
    reterr[session], retmsg[session] = nil, nil
    if err then
        return false, ret
    end
    return ret
end

local rpc_req_load
--- @param rpc_req string
--- @param host table|nil
function client.initpush(rpc_req, host)
    if rpc_req_load then
        assert(rpc_req == rpc_req_load)
    else
        rpc_req_load = rpc_req
        local sprotoloader = require "sprotoloader"
        local protoloader = skynet.uniqueservice "protoloader"
        local slot = skynet.call(protoloader, "lua", "index", rpc_req)
        local sp = sprotoloader.load(slot)
        host = host or sp:host "package"
        sender = host:attach(sp)
    end
end

return client
