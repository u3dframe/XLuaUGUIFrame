local client = require "client"
local skynet = require "skynet"
local socketdriver = require "skynet.socketdriver"
local log = require "log"

local host
local control = require "client.control"
local handler = require "client.handler"

local xpcall = xpcall
local string = string
local traceback = debug.traceback
local controlcheck = control.check

local function retclient(fd, response, result, name)
    if response and fd then
        local msg = string.pack(">s2", response(result))
        if not socketdriver.send(fd, msg) then
            log("response %s failure", name)
        end
    end
end

local function execute(f, self, args, response, name)
    local result = f(self, args)
    retclient(self.fd, response, result, name)
end

local function handle_msg(name, response, f, self, args)
    local ok, result = controlcheck(self, name)
    if not ok then
        ok, result = xpcall(execute, traceback, f, self, args, response, name)
    else
        ok, result = xpcall(retclient, traceback, self.fd, response, result, name)
    end
    if not ok then
        log("raise error = %s", result)
    end
end

function client.dispatch(self, msg, sz)
    local type, name, args, response = host:dispatch(msg, sz)
    if type == "REQUEST" then
        local f = handler[name]
        if f then
            handle_msg(name, response, f, self, args)
        else
            error("Invalid command " .. name)
        end
    else
        local session, result, _ = name, args, response
        client.response(session, result)
    end
end

function client.dispatch_special(self, f, msg, sz)
    local type, name, args, response = host:dispatch(msg, sz)
    assert(type == "REQUEST", "dispatch_special " .. name)
    handle_msg(name, response, f, self, args)
end

function client.initrpc(rpc_run)
    local sprotoloader = require "sprotoloader"
    local protoloader = skynet.uniqueservice "protoloader"
    local slot = skynet.call(protoloader, "lua", "index", rpc_run)
    host = sprotoloader.load(slot):host "package"
    return host
end

function client.init(rpc_run, rpc_req)
    client.initpush(rpc_req, client.initrpc(rpc_run))
end

return client
