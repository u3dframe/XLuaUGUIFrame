--- @type table<string,fun(self:role,msg:table):table>
local _M = {}
return _M