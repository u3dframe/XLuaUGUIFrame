local skynet = require "skynet"

skynet.register_protocol {
    name = "master",
    id = 110,
    pack = skynet.pack,
    unpack = skynet.unpack,
}

--- @type table<string,fun(...):table>
local _M = {}
return _M