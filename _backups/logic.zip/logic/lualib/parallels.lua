local skynet = require "skynet"

---@class parallels
local _M = {}

local _MT = {__index = _M}

---@return parallels
local function new()
    return setmetatable(
        {
            list = {},
            boot_co = nil,
            boot_error = nil
        },
        _MT
    )
end

local function wakeup_waitco(self, err)
    if not self.boot_error then
        self.boot_error = err
    end
    local boot_co = self.boot_co
    if boot_co then
        self.boot_co = nil
        skynet.wakeup(boot_co)
    end
end

local function wait_end(self)
    assert(not self.boot_co, "allready in wait %s", tostring(self.boot_co))
    self.boot_co = coroutine.running()
    if not next(self.list) then
        skynet.yield()
    else
        skynet.wait(self.boot_co)
    end
    if self.boot_error then
        error(self.boot_error)
    end
end

---@param self parallels
---@param func fun(...):...
---@param ... any
---@return void
function _M.add(self, func, ...)
    local token = {}
    local list = self.list
    list[token] = true
    skynet.fork(
        function(...)
            token.co = coroutine.running()
            local ok, err = xpcall(func, debug.traceback, ...)
            if not ok then
                wakeup_waitco(self, err)
            else
                list[token] = nil
                if not next(list) then
                    wakeup_waitco(self)
                end
            end
        end,
        ...
    )
end

---@param self parallels
---@return void
function _M.wait(self)
    return wait_end(self)
end

return new
