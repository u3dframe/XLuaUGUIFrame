local inner = require "inner"
local skynet = require "skynet"
local uniq = require "uniq.c"
local _M = {}
local CBLIST = {}

local calendard
skynet.init(
    function()
        calendard = skynet.uniqueservice("sys/calendard")
    end
)

local MT = {
    __gc = function(t)
        local uniq_id = t[1]
        if uniq_id then
            t[1] = nil
            CBLIST[uniq_id] = nil
            skynet.send(calendard, "inner", "cron_unsubscribe", uniq_id)
        end
    end
}

function _M.subscribe(cb, cron, lastti)
    local uniq_id = uniq.id(1)
    skynet.call(calendard, "inner", "cron_subscribe", skynet.self(), uniq_id, cron, lastti)
    local ret = setmetatable({uniq_id, cb}, MT)
    CBLIST[uniq_id] = ret
    return ret
end

function _M.unsubscribe(ret)
    MT.__gc(ret)
end

function inner.calendard_timeout(uniq_id, ti)
    local cb = CBLIST[uniq_id]
    if not cb then
        return
    end
    cb[2](ti)
end

function inner.calendard_finish(uniq_id)
    local cb = CBLIST[uniq_id]
    if not cb then
        return
    end
    cb[1] = nil
    CBLIST[uniq_id] = nil
    cb[2](0)
end

function _M.next_time(cron, lastti)
    return skynet.call(calendard, "inner", "next_time", cron, lastti)
end

function _M.near_time(cron, lastti)
    return skynet.call(calendard, "inner", "near_time", cron, lastti)
end

return _M
