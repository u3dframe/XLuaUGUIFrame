local skynet = require "skynet"
local client = require "client"
local onlogin = require "robot.onlogin"
local cfgdata = require "cfg.data"
local building = require "robot.buildingup"
local timer = require "timer.second"
local utime = require "util.time"
local chat = require "robot.chat"

local _H = require "client.handler"

local CAMPS
function _H.buildsoldier_all(self, msg)
    CAMPS = {}
    for _, info in ipairs(msg.list) do
        CAMPS[info.id] = info
    end
end
local LOCK = require("skynet.queue")()
local function startup(self)
    for soldier, cfg in pairs(cfgdata.soldier) do
        local buildtype = cfg.buildtype
        local bs = building.builds(self, buildtype)
        for id, b in pairs(bs) do
            local runinfo = CAMPS[id] and CAMPS[id].runinfo
            if runinfo then
                skynet.error("camp", buildtype, "run need", runinfo.ti_long, "wait", runinfo.ti_end - utime.time())
            else
                local soldiercnt = CAMPS[id] and CAMPS[id].soldiercnt
                if soldiercnt then
                    local r = assert(client.request(self, 100, "build_soldier_pick", {id = id}))
                    print("build_soldier_pick", id, 1, r.e, r.soldier, r.soldiercnt)
                    return
                else
                    local r =
                        assert(
                        client.request(
                            self,
                            100,
                            "build_soldier",
                            {
                                id = id,
                                soldier = 2,
                                soldiercnt = 1
                            }
                        )
                    )
                    print("build_soldier", id, 1, r.e)
                    return
                end
            end
        end
    end
end

function _H.buildsoldier(self, msg)
    CAMPS[msg.id] = msg
    LOCK(startup, self)
end

function _H.soldier_info(self, msg)
    --require("util").pdump(msg)
end

local dectime = {}
function _H.map_army(self, msg)
    local id = msg.id
    if not dectime[id] then
        chat(self, "lua@item(10,10031,2)")
        dectime[id] = true
        local ret =
            client.request(
            self,
            100,
            "army_dectime",
            {
                id = id,
                itemid = 10031
            }
        )
        assert(ret.e == 0, require("util").dump(ret))
    end
end

local MONSTS = {}
local r
function _H.map_monster(self, msg)
    MONSTS[msg.id] = msg
    if not r then
        r = true
    else
        return r
    end
    skynet.sleep(100)
    local ret =
        client.request(
        self,
        100,
        "battle_monster",
        {
            target = msg.id,
            soldier = {1, 2},
            soldiercnt = {10, 30}
        }
    )
    assert(ret.e == 0, require("util").dump(ret))
end

function _H.army_info(self, msg)
end

function _H.army_result(self, msg)
    require("util").pdump(msg, "army_result")
end

require("robot.event").reg(
    function(self)
        LOCK(startup, self)
    end,
    "buildingchange"
)

require("robot.onlogin").reg(
    function(self)
        timer.wait(1)
        LOCK(startup, self)
    end
)

require("robot.onlogin").reg(
    function(self)
        client.request(self, 100, "map_watch", {})
    end
)
