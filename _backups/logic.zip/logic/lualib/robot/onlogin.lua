local parallels = require "parallels"

local _M = {}

local cbs = {}
function _M.reg(cb)
    table.insert(cbs, cb)
end

function _M.occur(self)
    local pa = parallels()
    for _, cb in ipairs(cbs) do
        pa:add(cb, self)
    end
    pa:wait()
end

return _M