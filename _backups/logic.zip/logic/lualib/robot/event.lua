local skynet = require "skynet"
local _M = {}

local CBS = setmetatable({}, {
    __index = function(t, k)
        local v = {}
        t[k] = v
        return v
    end
})

function _M.reg(cb, type)
    table.insert(CBS[type], cb)
end

function _M.occur(type, ...)
    for _, cb in pairs(CBS[type]) do
        skynet.fork(cb, ...)
    end
end

return _M