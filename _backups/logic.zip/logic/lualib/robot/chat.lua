local _H = require "client.handler"
local log = require "log"
local client = require "client"
local skynet = require "skynet"
local util = require "util"
local onlogin = require "robot.onlogin"

function _H.chat_chating(self, msg)
    log(msg.content)
end

local function chat(self, str)
    client.push(
        self,
        "chat_chating",
        {
            channel = 1,
            content = str
        }
    )
end

onlogin.reg(
    function(self)
        chat(self, "lua@item(1,0,10000000)")
        chat(self, "lua@item(2,0,10000000)")
        chat(self, "lua@item(3,0,10000000)")
        chat(self, "lua@item(4,0,10000000)")
    end
)

return chat
