local client = require "client"
local skynet = require "skynet"
local utime = require "util.time"
local timer = require "timer.second"
local onlogin = require "robot.onlogin"
local event = require "robot.event"
local cfgdata = require "cfg.data"

local _H = require "client.handler"

local queuemax = 2

local BUILDS
function _H.city_build_all(self, msg)
    BUILDS = {}
    skynet.error("servertime", msg.ti, utime.time())
    for _, d in pairs(msg.list) do
        BUILDS[d.id] = d
    end
end

local function startbuild(self, id)
    local e =
        assert(
        client.request(
            self,
            1000,
            "build_levelup",
            {
                id = id
            }
        )
    ).e
    assert(e == 0, e)
end

local function calc_maxlevel(self, buildtype)
    local level, cnt = 0, 0
    for _, d in pairs(BUILDS) do
        if d.buildtype == buildtype then
            if level < d.level then
                level = d.level
            end
            cnt = cnt + 1
        end
    end
    return level, cnt
end

local function checklevelup(self, d)
    local buildupdate = cfgdata.city_buildupdate[d.buildtype]
    local level = d.level
    local cfg = buildupdate[level + 1]
    if not cfg then
        return
    end
    for _, cond in ipairs(cfg.precondition) do
        local buildtype, needlevel = cond[1], cond[2]
        if calc_maxlevel(self, buildtype) < needlevel then
            return
        end
    end
    return true
end

local function checkadd(self)
    for buildtype, cfg in pairs(cfgdata.city_build) do
        local level, cnt = calc_maxlevel(self, buildtype)
        if cnt < cfg.maxcnt then
            local e =
                assert(
                client.request(
                    self,
                    1000,
                    "build_add",
                    {
                        buildtype = buildtype
                    }
                )
            ).e
            assert(e == 0, e)
        end
    end
end

local function startup(self)
    local ids, cnt = {}, 0
    local now = utime.time()
    for id, d in pairs(BUILDS) do
        if d.levelup then
            cnt = cnt + 1
            skynet.error(id, "city_build inlevelup", "need", d.levelup.ti_long, "wait", d.levelup.ti_end - now)
        elseif checklevelup(self, d) then
            table.insert(ids, id)
        end
    end
    if cnt < queuemax then
        if #ids > 0 then
            local id = ids[math.random(1, #ids)]
            skynet.error("city_build inlevelup", cnt .. "/" .. #ids, "start", id)
            return startbuild(self, id)
        end
    end
    checkadd(self)
end

function _H.city_build(self, msg)
    local id = msg.id
    local old = BUILDS[id]
    BUILDS[id] = msg
    if not old then
        skynet.error("city_build new", id)
    elseif old.levelup and not msg.levelup then
        skynet.error("city_build inlevelup finish", id)
    end
    startup(self)
    event.occur("buildingchange", self, msg)
end

onlogin.reg(
    function(self)
        timer.wait(1)
        assert(BUILDS)
        startup(self)
    end
)

local _M = {}

function _M.builds(self, buildtype)
    local ret = {}
    for _, b in pairs(BUILDS) do
        if b.buildtype == buildtype then
            ret[b.id] = b
        end
    end
    return ret
end

return _M
