local skynet = require "skynet"
require "inner"

local _M = {}

local _MT = {
    __gc = function(t)
        local addr = t.addr
        if addr then
            t.addr = nil
            skynet.send(addr, "inner", "unreference")
        end
    end
}

function _M.ref(addr, wait)
    local ok, ret = pcall(skynet.call, addr, "inner", "reference", wait)
    if ok and ret then
        return setmetatable({addr = addr}, _MT)
    else
        if not ok then
            if string.sub(ret, -11) == "call failed" then -- skynet.lua yield_call error "call failed"
                return nil, "quitting"
            else
                return nil, "quited"
            end
        else
            return nil, "quitting"
        end
    end
end

function _M.unref(ref)
    local addr = ref.addr
    if addr then
        ref.addr = nil
        skynet.send(addr, "inner", "unreference")
    end
end

function _M.addr(ref)
    return ref.addr
end

return _M
