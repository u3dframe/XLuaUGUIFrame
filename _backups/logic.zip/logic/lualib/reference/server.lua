local skynet = require "skynet"

local ref = 0
local cb
local delay
local ver = 0

local _M = {}
local _H = require "inner"

function _H.reference(wait)
    if ref ~= -1 then
        ref = ref + 1
        return true
    else
        if wait then
            skynet.wait()
        end
    end
end

local function check()
    if ref == 0 then
        ver = ver + 1
        local s = ver
        if delay then
            skynet.sleep(delay)
        end
        if s ~= ver then
            return
        end
        if ref == 0 then
            ref = -1
            cb()
        end
    end
    return ref ~= 0 and ref ~= -1
end

function _H.unreference()
    if ref ~= -1 then
        ref = ref - 1
        if ref == 0 then
            skynet.fork(check)
        end
    end
end

function _M.check()
    return check()
end

function _M.init(_cb, _delay)
    cb = _cb
    delay = _delay
    if _delay then
        skynet.fork(check)
    end
end

_M.ref = function()
    assert(_H.reference())
end
_M.unref = _H.unreference

return _M
