local sharetable = require "skynet.sharetable"
local skynet = require "skynet"
local queue = require "skynet.queue"
local mcast = require "mcast"
local parallels = require "parallels"

local _M = {}

local auto_Q =
    setmetatable(
    {},
    {
        __index = function(t, k)
            local Q = queue()
            t[k] = Q
            return Q
        end
    }
)

local function just_query(t, k)
    local v = assert(sharetable.query(k), "not found " .. k)
    t[k] = v
    return v
end

local function query(t, k)
    local v = rawget(t, k)
    if v then
        return v
    end
    return just_query(t, k)
end

local CACHES =
    setmetatable(
    {},
    {
        __index = function(t, k)
            local _t = auto_Q[k](query, t, k)
            auto_Q[k] = nil
            return _t
        end
    }
)

_M.CACHES = CACHES

local cbs = {}
skynet.init(
    function()
        mcast(
            "cfgupdate",
            function(changes)
                local t = CACHES
                local pa = parallels()
                require("util").pdump(changes)
                for k in pairs(changes) do
                    if rawget(t, k) then
                        pa:add(
                            function()
                                skynet.error("requery cfg", k)
                                auto_Q[k](just_query, t, k)
                                auto_Q[k] = nil
                            end
                        )
                    end
                end
                pa:wait()
                for _, cb in pairs(cbs) do
                    skynet.fork(cb, changes)
                end
            end
        ):subscribe()
    end
)

function _M.onchange(cb, nm)
    cbs[nm] = cb
end

return _M
