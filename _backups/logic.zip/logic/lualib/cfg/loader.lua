local lfs = require "lfs"

local function load_luacfg(f)
    local file = assert(io.open(f))
    local source = file:read("*a")
    file:close()
    local ret = {}
    local ok, err = pcall(assert(load(source, "@" .. f, "t", ret)))
    if ok then
        return err or ret
    else
        error(string.format("occur error when load [%s] %s", tostring(f), tostring(err)))
    end
end

local function load_convert(f)
    local file = assert(io.open(f))
    local source = file:read("*a")
    file:close()
    local ok, err = pcall(assert(load(source, "@" .. f, "t", _ENV)))
    if ok then
        return err
    else
        error(string.format("occur error when load [%s] %s", tostring(f), tostring(err)))
    end
end

local function alise_field(tbls)
    local ret = {}
    for file, tbl in pairs(tbls) do
        for f, t in pairs(tbl) do
            if type(t) == "table" then
                local nm = string.format("%s_%s", file, f)
                if f == file then
                    nm = file
                end
                assert(not ret[nm], nm)
                ret[nm] = t
            end
        end
    end
    return ret
end

local function load_dir(root)
    local ret = {}
    for file in lfs.dir(root .. "/") do
        if file ~= "." and file ~= ".." then
            local pos = string.find(file, ".lua$")
            if pos then
                local name = string.sub(file, 1, pos - 1)
                ret[name] = load_luacfg(string.format("%s/%s", root, file))
            end
        end
    end
    -- local convert = load_convert(root .. "/convert/init.lua")
    -- for nm, call in pairs(convert) do
    --     call(ret[nm])
    -- end
    return alise_field(ret)
end

return load_dir
