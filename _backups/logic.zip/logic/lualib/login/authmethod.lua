local md5 = require "md5"

local _M = {}
function _M.token(tk, token, ti)
    return true
end
return _M
