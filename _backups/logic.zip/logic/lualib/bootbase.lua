local skynet = require "skynet"
local settingloader = require "setting.loader"
local _M = {}

function _M.start(boot, bootlast)
    settingloader.init_from_dir()
    if not skynet.getenv("daemon") then
        skynet.uniqueservice("console")
    end
    skynet.newservice("sys/console")

    local svr_id = assert(tonumber(skynet.getenv("svr_id")))

    --skynet.uniqueservice("uniq_initd",svr_id)
    --skynet.uniqueservice("debuggerd")
    if boot then
        boot()
    end
    --settingloader.opencluster()
    if bootlast then
        bootlast()
    end
    --skynet.uniqueservice("exporter")
end

function _M.main(boot)
    local procuuid = skynet.getenv("procuuid")
    local ok, err = xpcall(boot, debug.traceback)
    if not ok then
        skynet.error(string.format("boot %s end failure used %d %s", procuuid, skynet.now(), err))
        skynet.newservice("quit")
    else
        skynet.error(string.format("boot %s end success used %d", procuuid, skynet.now()))
    end
    skynet.exit()
end

return _M
