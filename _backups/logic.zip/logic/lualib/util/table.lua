local ustring = require "util.string"
local table = table
local ipairs = ipairs
local pairs = pairs
local type = type
local tremove = table.remove

local _M = {}

---@param t table
---@return table
local function tcopy(t)
    local r = {}
    for k, v in pairs(t) do
        if type(v) == "table" then
            r[k] = tcopy(v)
        else
            r[k] = v
        end
    end
    return r
end

_M.copy = tcopy

---@param t number[][]
---@return table<number,number>, number
function _M.array_reduce(t, num)
    local dec = {}
    while num > 0 and #t > 0 do
        local first_info = t[1]
        local id, cnt = first_info[1], first_info[2]
        if cnt > num then
            first_info[2] = cnt - num
            dec[id] = (dec[id] or 0) + num
            num = 0
        else
            tremove(t, 1)
            num = num - cnt
            dec[id] = (dec[id] or 0) + cnt
        end
    end
    return dec, num
end

---@param array table[]
---@param k any
---@return ...
function _M.array_find(array, k)
    for _, c in ipairs(array) do
        if c[1] == k then
            return table.unpack(c, 2)
        end
    end
end

function _M.remove(array, k)
    for i, v in ipairs(array) do
        if v == k then
            return table.remove(array, i)
        end
    end
end

function _M.array2str(array)
    local str = ""
    if array then
        for _, v in ipairs(array) do
            if str ~= "" then
                str = str .. ";"
            end
            str = str .. table.concat(v, ":")
        end
    end
    return str
end

function _M.str2array(str)
    local array = {}
    local lines = ustring.split(str, ";")
    for _, s in ipairs(lines) do
        local t = {}
        for i, v in ipairs(ustring.split(s, ":")) do
            t[i] = tonumber(v)
        end
        table.insert(array, t)
    end
    return array
end
---@param array number[][]
---@return table<number,number>
function _M.array2dict(array)
    local ret = {}
    for _, info in ipairs(array) do
        ret[info[1]] = info[2]
    end
    return ret
end

---@param dict table<number,number>
---@return number[][]
function _M.dict2array(dict)
    local ret = {}
    for k, v in pairs(dict) do
        table.insert(ret, {k, v})
    end
    return ret
end

function _M.dict_to_sproto(list)
    local ret = {}
    for k, v in pairs(list) do
        table.insert(ret, {array = {k, v}})
    end
    return ret
end

---@param list  table[]
---@return table<number,number>
function _M.sproto_to_dict(list)
    local ret = {}
    for _, info in ipairs(list) do
        local array = info.array
        local k, v = array[1], array[2]
        ret[k] = v
    end
    return ret
end

function _M.arrays2dict(list)
    local ret = {}
    local arr1 = list.arr1
    local arr2 = list.arr2
    for k, v in ipairs(arr1) do
        ret[v] = arr2[k]
    end
    return ret
end

function _M.dict2arrays(list)
    local ret = {arr1 = {}, arr2 = {}}
    for k, v in pairs(list) do
        table.insert(ret.arr1, k)
        table.insert(ret.arr2, v)
    end
    return ret
end
---@param list number[][]
---@return ret table[]
function _M.array_to_sproto(list)
    local ret = {}
    for _, a in ipairs(list) do
        table.insert(ret, {array = a})
    end
    return ret
end

---@param list table[]
---@return ret number[][]
function _M.sproto_to_array(list)
    local ret = {}
    for _, info in ipairs(list) do
        table.insert(ret, info.array)
    end
    return ret
end

function _M.merge(cb)
    cb = cb or function(o_val, n_val)
            return n_val
        end
    return function(...)
        local ret = {}
        for _, t in ipairs({...}) do
            for k, v in pairs(t) do
                if ret[k] then
                    v = cb(ret[k], v)
                end
                ret[k] = v
            end
        end
        return ret
    end
end

return _M
