local time_core = require "time.core"

---@class utime
---@field midnight fun(t:number):number
---@field next_midnight fun(t:number):number
---@field get_wday fun(t:number):number
---@field to_daysec fun(t:number):number
---@field now fun():number
---@field time fun():number
---@field time_int fun():number
---@field time_elapse fun(t:number):number
---@field debug_init fun(t:number):void
---@field DEBUG_DEFINE boolean
local _M = setmetatable({}, {__index = time_core})

local default_day_sep = 0 * 60 * 60
---@param t1 number
---@param t2 number
---@param sep number|nil
---@return boolean
function _M.same_day(t1, t2, sep)
    sep = sep or default_day_sep
    assert(sep >= 0 and sep < 86400)
    return time_core.same_day(t1, t2, sep)
end

---@param t1 number
---@param t2 number
---@param sep number|nil
---@param hours number|nil
---@return boolean
function _M.same_hours(t1, t2, sep, hours)
    hours = hours or 1
    sep = sep or default_day_sep
    assert(sep >= 0 and sep < 3600)
    return time_core.same_hours(t1, t2, sep, hours)
end

---@param now number
---@return number next week monday midnight
function _M.next_week_midnight(now)
    local midnight = time_core.midnight(now)
    local wday = time_core.get_wday(midnight)
    if wday == 0 then
        wday = 7
    end
    return midnight + (8 - wday) * 86400
end

---@param now number
---@return number this week monday midnight
function _M.this_week_midnight(now)
    return _M.next_week_midnight(now) - 604800
end

---- check same next week monday midnight
local default_week = 0
---@param t1 number
---@param t2 number
---@param sep number
---@return boolean
function _M.same_week(t1, t2, sep)
    sep = sep or default_week
    assert(sep >= 0 and sep < 604800)
    return _M.next_week_midnight(t1 - sep) == _M.next_week_midnight(t2 - sep)
end

return _M
