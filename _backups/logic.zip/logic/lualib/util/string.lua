local _M = {}

-- local ext = require "ext.c"
-- _M.split = ext.split_string
-- _M.split_row = ext.splitrow_string

local gsub = string.gsub
local tonumber = tonumber

--- @param fmt string
--- @return string
function _M.strfmt(fmt, ...)
    local params = {...}
    return (gsub(
        fmt,
        "{(%d+)}",
        function(k)
            return params[tonumber(k)]
        end
    ))
end

return _M
