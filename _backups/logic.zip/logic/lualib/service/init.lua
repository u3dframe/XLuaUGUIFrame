local skynet = require "skynet"
local service = require "service.release"

service.NORET = {}

local function add_stop_cmd(funcs, release)
    assert(not funcs.stop, "use release replace stop")
    if release then
        service.release("add_stop_cmd", release)
    end
    local WAIT_QUIT
    funcs.stop = function()
        if WAIT_QUIT then
            local co = coroutine.running()
            table.insert(WAIT_QUIT, co)
            skynet.wait(co)
        else
            WAIT_QUIT = {}
            service.releaseall()
            for _, co in pairs(WAIT_QUIT) do
                skynet.wakeup(co)
            end
            skynet.fork(skynet.exit) --//wakeup queue run before fork queue
        end
    end
end

local function ret(r, ...)
    if r ~= service.NORET then
        return skynet.retpack(r, ...)
    end
end

service.ret = ret

function service.dispatch(proto, funcs)
    local dispatch = function(session, _, cmd, ...)
        local f = funcs[cmd]
        if f then
            if session > 0 then
                ret(f(...))
            else
                f(...)
            end
        else
            skynet.error("Unknown command : ", proto, cmd)
            skynet.response()(false)
        end
    end
    skynet.dispatch(proto, dispatch)
    return dispatch
end

function service.start(mod)
    local info = mod.info or mod
    if type(info) ~= "function" then
        service.info = function()
            return info
        end
    else
        service.info = info
    end
    skynet.info_func(service.info)

    local funcs = require "lua_handler"
    add_stop_cmd(funcs, mod.release)

    local dispatch = mod.dispatch or {}
    if not dispatch.lua then
        service.dispatch("lua", funcs)
    end
    for name, call in pairs(dispatch) do
        skynet.dispatch(name, call)
    end
    skynet.start(
        function()
            if mod.init then
                mod.init()
            end
            if mod.regquit then
                service.regquit()
            end
            if mod.master then
                skynet.send(skynet.uniqueservice("sys/masterd"), "lua", "reg", mod.master)
            end
        end
    )
end

return service
