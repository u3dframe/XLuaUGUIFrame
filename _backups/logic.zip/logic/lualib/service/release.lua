local skynet = require "skynet"

local service_name = SERVICE_NAME
local releases = {}
local service = {}
function service.release(nm, call)
    assert(nm and call)
    for _, node in ipairs(releases) do
        if node[1] == nm then
            node[2] = call
            call = nil
            break
        end
    end
    if call then
        table.insert(releases, 1, {nm, call})
    end
end

function service.releaseall()
    for _, node in ipairs(releases) do
        local ok, err = pcall(node[2])
        if not ok then
            skynet.error(err)
        end
    end
end

local regquit
function service.regquit(force)
    if not regquit or force then
        regquit = true
        skynet.fork(function()
            local mgr = skynet.uniqueservice("quitmgr")
            skynet.send(mgr, "lua", "reg", skynet.self(), service_name)
        end)
    end
end

return service
