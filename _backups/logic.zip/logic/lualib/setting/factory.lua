local datacenter = require "skynet.datacenter"

return function(NAME)
    local _M = {}
    function _M.init(...)
        datacenter.set(NAME, ...)
    end
    function _M.get(...)
        return assert(datacenter.get(NAME, ...))
    end
    return _M
end
