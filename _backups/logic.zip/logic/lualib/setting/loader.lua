local skynet = require "skynet"
local json = require "rapidjson.c"
local setting = require "setting"

local _M = {}

function _M.init_from_dir(svr_type, svr_id)
    local _svr_type = svr_type or skynet.getenv("svr_type")
    local _svr_id = svr_id or skynet.getenv("svr_id")
    local setting_host = skynet.getenv("setting_host")

    local name = string.format("%s_%d", _svr_type, _svr_id)
    local fname = string.format("%s/%s.json", setting_host, name)

    local file = io.open(fname)
    local code = file:read("*a")
    file:close()
    local s = json.decode(code)
    setting.init(s)
end

return _M
