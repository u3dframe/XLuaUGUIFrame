local sys_traceback = debug.traceback
local traceback = require "trace.c"
debug.traceback = traceback
debug.sys_traceback = sys_traceback

--require "debug.profile_service"--require "debug.profile_client"
