local function getupvalue_byname(func, name)
    for i = 1, math.maxinteger do
        local nm, value = debug.getupvalue(func, i)
        if not nm then
            break
        end
        if nm == name then
            return value, i, name
        end
    end
    error("not found upvalue " .. tostring(name))
end

return function(func, ...)
    for _, name in pairs({...}) do
        func = getupvalue_byname(func, name)
    end
    return func
end
