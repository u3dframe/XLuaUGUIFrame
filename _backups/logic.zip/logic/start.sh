#!/bin/bash

export ROOT=$(
	cd $(dirname $0)
	pwd
)

function die() {
	echo "ERROR:$1" && exit $2
}

function usage() {
	[ -n "$1" ] && echo $1
	echo "Usage: start.sh [-t SVR_TYPE] [-i SVR_ID] [options]"
	echo "Options:"
	echo "	-c,	The configure directory"
	echo "		Now:$ROOT/cfg"
	echo "	-d,	Run this in deamon"
	echo "	-D, Run this in deamon,but tailf $LOGGER"
	echo "	-g,	Start this with gdb"
	echo "	-h,	This small usage guide"
	echo "	-H	Setting host"
	echo "		Now:$ROOT/runtime"
	echo "	-i,	This program id setup in Setting host"
	echo "	-k,	check and Send quit message to this"
	echo "	-K,	force Send quit message to this"
	echo "	-l,	This log directory"
	echo "		Now:$LOGPATH"
	echo "	-r,	This run directory"
	echo "		Now:$RUNPATH"
	echo "	-s,	Service boot for SVR_TYPE tool"
	echo "	-t,	This program type setup in Setting host"
	echo "	-T	Skynet work thread number"
	echo "		Now:$THREADN"
	[ -n "$1" ] && exit -1
	exit 0
}

export NEED_TAILF=0
export THREADN=8
export OP_TYPE=0
export UUIDS=$(cat /proc/sys/kernel/random/uuid | sed 's/-//g')
params=()

while getopts "DdhkKgs:e:H:i:l:r:t:c:T:" arg; do
	case $arg in
	c) export CFGPATH=$OPTARG ;;
	d)
		export OP_TYPE=1
		export NEED_TAILF=0
		;;
	D) export OP_TYPE=1 ;;
	g) export OP_TYPE=2 ;;
	H) export SETTING_HOST=$OPTARG ;;
	h) usage ;;
	i) export SVR_ID=$OPTARG ;;
	k) export OP_TYPE=3 ;;
	K) export OP_TYPE=4 ;;
	l) export LOGPATH=$OPTARG ;;
	r) export RUNPATH=$OPTARG ;;
	s) params[${#params[*]}]=$OPTARG ;;
	t) export SVR_TYPE=$OPTARG ;;
	T) export THREADN=$OPTARG ;;
	?) usage "unknow argument "$OPTARG ;;
	esac
done

[ -z "$SVR_ID" ] && usage "expected SVR_ID use options -i"
[ -z "$SVR_TYPE" ] && usage "expected SVR_TYPE use options -t"

NODE_NAME=$SVR_TYPE"_"$SVR_ID

RUNPATH=${RUNPATH:-$ROOT"/runtime"}
export CFGPATH=${CFGPATH:-$ROOT"/../cfg"}
export SETTING_HOST=${SETTING_HOST:-$ROOT"/runtime"}
export JE_MALLOC_CONF="background_thread:true,narenas:$(expr $THREADN + 1)"

export LOGPATH=${LOGPATH:-$RUNPATH"/log"}
export PIDFILE=$RUNPATH"/"$NODE_NAME".pid"
export DEBUGPORT=$RUNPATH"/"$NODE_NAME".debugport"
export LOGGER=$LOGPATH"/"$NODE_NAME".log"
export BOOTPARAMS="${params[@]}"

function send2proc() {
	[ -f $DEBUGPORT ] || die "no such file:$DEBUGPORT" 1
	echo $1 | nc 127.0.0.1 $(cat $DEBUGPORT) -v -d1 &>/dev/null
	[ $? -eq 0 ] || die "nc 127.0.0.1 $(cat $DEBUGPORT) failure" 1
}

function shutdown() {
	send2proc "start quit"
	if [ -f $PIDFILE ]; then
		PID=$(cat $PIDFILE)
		while [ -f $PIDFILE ]; do
			kill -0 $PID &>/dev/null || break
			sleep 1
		done
	fi
	[ -f $PIDFILE ] && die "shutdown $NODE_NAME success,but $PIDFILE still exist" 0
	echo "shutdown $NODE_NAME success"
	exit 0
}

function prepare_boot() {
	touch $LOGGER
	export DAEMON=""
	if [ $1 -eq 1 ]; then
		export DAEMON=$PIDFILE
	fi
	if [ -f $ROOT/proto/run.sh ]; then
		$ROOT/proto/run.sh || die "make proto failure"
	fi
}

#set -x
function checklog() {
	[ $OP_TYPE -eq 1 ] || return
	if [ $1 -eq "0" ]; then
		if [ $NEED_TAILF -eq 1 ]; then
			tailf $LOGGER # for -d
		else
			# for -d -s
			PID=$(cat $PIDFILE)
			while kill -0 $PID &>/dev/null; do
				if [ $(grep -a "boot $UUIDS end" $LOGGER | wc -l) -eq "1" ]; then
					[ $(grep -a "boot $UUIDS end" $LOGGER | awk '{print $6}') == "success" ] || die "boot $NODE_NAME failure,plz check $LOGGER" 1
					echo "boot $NODE_NAME success"
					return 0
				fi
				sleep 1
			done
			die "boot $NODE_NAME failure,$PID has die,plz check $LOGGER" 1
		fi
	else
		if [ $NEED_TAILF -eq 1 ]; then
			tailf $LOGGER # for -d
		else
			# for -d -s
			exit 1
		fi
	fi
}

case $OP_TYPE in
"0" | "1")
	prepare_boot $OP_TYPE
	$ROOT/skynet/skynet $ROOT/runtime/$SVR_TYPE.config $SVR_ID
	checklog $?
	exit 0
	;;
"2")
	prepare_boot $OP_TYPE
	gdb -iex 'add-auto-load-safe-path .' --args $ROOT/skynet/skynet $ROOT/runtime/$SVR_TYPE.config $SVR_ID
	;;
"3")
	[ -f $PIDFILE ] || die "no such file:$PIDFILE" 0
	shutdown
	;;
"4")
	shutdown
	;;
*) ;;

esac
