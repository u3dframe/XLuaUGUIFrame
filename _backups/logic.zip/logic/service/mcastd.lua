local skynet = require "skynet"

local command = {}
local channel = {}
local caches = {}
local waitlist = {}

local function publish(source, c, pack)
    local group = channel[c]
    if group then
        for k in pairs(group) do
            skynet.redirect(k, source, "mcast", 0, pack)
        end
    end
end

skynet.register_protocol {
    name = "mcast",
    id = 111
}

local function sub(source, c)
    local group = channel[c]
    if not group then
        group = {}
        channel[c] = group
    end
    group[source] = true
end

function command.PUB(source, c, ...)
    local pack = skynet.packstring(c, ...)
    caches[c] = {source, pack}
    publish(source, c, pack)
    local waits = waitlist[c]
    if waits then
        waitlist[c] = nil
        for _, co in ipairs(waits) do
            skynet.wakeup(co)
        end
    end
end

function command.SUB(source, c, waitdata)
    sub(source, c)
    if waitdata then
        local cache = caches[c]
        if cache then
            skynet.redirect(cache[1], source, "mcast", 0, cache[2])
        else
            local waits = waitlist[c]
            if not waits then
                waits = {}
                waitlist[c] = waits
            end
            table.insert(waits, (coroutine.running()))
            skynet.wait()
        end
    end
end

function command.USUB(source, c)
    local group = assert(channel[c])
    if group[source] then
        group[source] = nil
    end
end

skynet.start(
    function()
        skynet.dispatch(
            "lua",
            function(_, source, cmd, ...)
                local f = assert(command[cmd])
                skynet.retpack(f(source, ...))
            end
        )
    end
)
