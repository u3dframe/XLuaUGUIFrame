local skynet = require "skynet"

local selfid = string.format(":%08x", skynet.self())
local function base_quit()
    local procuuid = skynet.getenv("procuuid")
    require "skynet.manager"
    local c = require "skynet.core"

    while true do
        local finish = true
        local list = skynet.call(".launcher", "lua", "LIST")
        for k, v in pairs(list) do
            local n = string.match(v, "^snlua ([^ ]+)")
            if selfid ~= k then
                finish = false
                skynet.error(string.format("quit force KILL %s(%s) ", k, n))
                skynet.call(".launcher", "lua", "KILL", k)
            end
        end
        if finish then
            break
        end
    end

    skynet.send(".cslave", "lua", "STOP")
    c.command("KILL", ".launcher")
    c.command("KILL", ".service")
    c.command("KILL", ".cslave")
    skynet.error(string.format("%s quit end %d", procuuid, skynet.now()))
    skynet.rawsend(".logger", "lua", "")
    c.command("EXIT")
    skynet.wait()
end

skynet.start(
    function()
        skynet.error("shutdown start")
        skynet.call(skynet.uniqueservice "quitmgr", "lua", "stopall")
        base_quit() -- never return
    end
)
