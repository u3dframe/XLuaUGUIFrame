local bootbase = require "bootbase"
local skynet = require "skynet"
local ustring = require "util.string"
local parallels = require "parallels"

skynet.start(
    function()
        skynet.error(skynet.getenv("params"))
        bootbase.main(
            function()
                skynet.error "Server start"
                local list = ustring.split(skynet.getenv("bootparams"))
                local pa = parallels()
                for _, s in ipairs(list) do
                    pa:add(
                        function()
                            skynet.error("Boot", s)
                            local addr = skynet.newservice(s)
                            pcall(skynet.call, addr, "debug", "LINK")
                        end
                    )
                end
                pa:wait()
                skynet.newservice("quit")
            end
        )
    end
)
