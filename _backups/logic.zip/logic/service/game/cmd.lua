local service = require "service"
local str2cmd = require "debug.str2cmd"
local _LUA = require "lua_handler"

function _LUA.agent_comand(rid, str)
    local param = str2cmd.prepare_param(str)
    if not param then
        return
    end
    param.rid = rid
    return true, str2cmd.execute(param)
end

function _LUA.getall_cmd()
    return {e = 0, list = str2cmd.getcmd()}
end

service.start {}

local C = str2cmd

C "attrs(int id,int cnt)"
C "battle()"
C "email(int award)"
C "item(int itemtype,int itemid,int itemcnt,int arg1,int arg2,int arg3)"
C "item_del(int itemtype,int itemid,int itemcnt)"
C "kick(int ti)"
C "soldier(int id,int cnt)"
C "soldier_cure_add(int id,int cnt)"
C "recruit(int type,int m,int mark,int cnt)"
C "time(string type,int num)"
C "time_to(string val)"
C "battle_lose()"
