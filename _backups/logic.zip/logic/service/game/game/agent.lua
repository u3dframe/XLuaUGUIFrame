local skynet = require "skynet"
local service = require "service"
local client = require "client.dispatch"
local log = require "log"
local rolelock = require "skynet.queue"()
local mods = require "role.mods"
require "role.init"

local reference_server = require "reference.server"

local manager
skynet.init(
    function()
        manager = skynet.uniqueservice "game/manager"
    end
)

local _LUA = require "lua_handler"
local _MASTER = require "master_handler"

local ROLE

skynet.register_protocol {
    name = "client",
    id = skynet.PTYPE_CLIENT,
    unpack = function(...)
        return ...
    end,
    pack = function()
        error("NOT RET")
    end
}

function _LUA.kick(self, why)
    why = why or "Unknown error"
    skynet.call(skynet.uniqueservice("game/tokenmgr"), "lua", "kick", self.uid, self.fd)
    client.pushfd(self.fd, "game_over", {why = why})
    skynet.send(self.gate, "lua", "kick", self.fd, why)
    return true
end

local function load(self) -- in lock
    reference_server.init(
        function()
            skynet.send(skynet.self(), "lua", "stop")
        end,
        300
    )
    self.fd = nil
    self.agent = skynet.self()
    self.proxy = skynet.call(skynet.uniqueservice("db/mgr"), "lua", "query", "DB_GAME")
    --self.STATE=nil
    skynet.fork(
        rolelock,
        function()
            assert(self.STATE == 1)
            mods.loadafter(self)
            self.STATE = 2
        end
    )
    mods.load(self)
    --mods.loaded(self)
    self.STATE = 1
    return self
end

local function agent_exit(self)
    if self then
        if self.exit then
            return
        end
        self.exit = true

        local fd = self.fd
        if self.STATE == 3 then
            if fd then
                self.fd = nil
                mods.afk(self)
                skynet.send(manager, "lua", "kickfd", fd, "agent_exit")
            end
            self.STATE = 2
            mods.leave(self)
        end
        assert(self.STATE == 2)
        log("%d(%s) skynet.exit", self.rid, self.rname)
        self.STATE = nil
        mods.unload(self)
        skynet.call(manager, "lua", "agent_exit", fd, self.rid)
    else
        skynet.send(manager, "lua", "agent_exit", nil, nil, skynet.self())
        log("not inited agent")
    end
end

local function enter(self, args)
    assert(self.STATE == 2 or self.STATE == 3)
    reference_server.ref()
    local fd = args.fd
    if self.fd ~= fd then
        if self.fd then
            _LUA.kick(self, string.format("re_enter %s", tostring(args.fd)))
            reference_server.unref()
        end
    end
    --- check fd see debug.callasclient
    if fd and not skynet.call(args.gate, "lua", "forward", args.fd) then
        reference_server.unref()
        error("forward failure")
    end
    self.fd = args.fd
    self.gate = args.gate
    self.auth = args.auth
    self.ip = args.ip
    client.push(self, "role_object", self)
    mods.enter(self)
    self.STATE = 3
    return true
end

function _LUA.load(_, args)
    rolelock(
        function(...)
            assert(not ROLE)
            ROLE = load(...)
        end,
        args
    )
end

function _LUA.enter(self, args)
    if self and self.exit then
        return false
    end
    if not args.fd then
        return true
    end
    return rolelock(enter, self, args)
end

local function on_afk(self, fd)
    if not self.fd then
        return
    end
    if self.fd ~= fd then
        return
    end
    self.fd = nil
    if self.STATE == 3 then
        require("timer").add(
            6000,
            function()
                rolelock(
                    function()
                        if self.STATE == 3 and not self.fd then
                            self.STATE = 2
                            mods.leave(self)
                            reference_server.unref()
                        end
                    end
                )
            end
        )
    end
    mods.afk(self)
end

function _LUA.afk(self, fd)
    log("%d(%s) afk", fd, self.rname)
    rolelock(on_afk, self, fd)
end

local ret = service.ret

-- 该接口会延后执行消息,注意消息顺序
function _LUA.online_call(self, ...)
    if self.STATE ~= 3 then
        return
    end
    return true, skynet.call(skynet.self(), ...)
end

-- 该接口会延后执行消息,注意消息顺序
function _LUA.online_send(self, ...)
    if self.STATE ~= 3 then
        return
    end
    return skynet.send(skynet.self(), ...)
end

service.start {
    dispatch = {
        lua = function(_, _, cmd, ...)
            local f = _LUA[cmd]
            if f then
                ret(f(ROLE, ...))
            else
                log("Unknown command : [%s]", cmd)
                skynet.response()(false)
            end
        end,
        client = function(_, _, msg, sz)
            skynet.ignoreret()
            local ok, err = pcall(client.dispatch, ROLE, msg, sz)
            if not ok then
                local str = string.format("agent dispatch_error:%s", tostring(err))
                _LUA.kick(ROLE, str)
                error(str)
            end
        end,
        master = function(session, _, cmd, ...)
            local f = _MASTER[cmd]
            if f then
                ret(f(ROLE, ...))
            else
                log("Unknown command : [%s]", cmd)
                skynet.response()(false)
            end
        end
    },
    init = function()
        client.init("proto.c2s", "proto.s2c")
    end,
    release = function()
        rolelock(
            function()
                agent_exit(ROLE)
            end
        )
    end
}
