local skynet = require "skynet"
local service = require "service"
local setting = require "setting"

local manager
skynet.init(
    function()
        manager = skynet.uniqueservice "game/manager"
        --skynet.uniqueservice "game/map"
    end
)

service.start {
    regquit = true,
    init = function()
        local conf = setting.get("auth")
        skynet.call(
            manager,
            "lua",
            "open",
            {
                address = conf.listen_ip,
                port = conf.listen_port,
                maxclient = conf.maxclient,
                nodelay = true,
                pktspeed = 100,
                timeout = 30000 --300s
            }
        )
    end,
    release = function()
        skynet.call(manager, "lua", "stopagent")
    end
}
