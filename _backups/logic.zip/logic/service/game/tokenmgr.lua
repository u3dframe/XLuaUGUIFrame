local skynet = require "skynet"
require "skynet.queue"
local circ_queue = require "circ_queue"
local authmethod = require "login.authmethod"
--local variable_cache=require "variable.cache"
--local cluster=require "skynet.cluster"
local service = require "service"
local log = require "log"
--local VERSION = require "world.version"
local _M = require "lua_handler"
local client = require "client.dispatch"
--[[local o={
	token=token,
	uid=uid,
	auth = skynet.self(),
	iswhite=iswhite,
	channel=channel,
	dev_id=msg.idfa or msg.imei or "",
	dev_type=tonumber(msg.device) or 0,
	dev_pkg=...
}
]]
--local serverid=assert(tonumber(skynet.getenv("svr_id")))
local token = {} -- uid/{lock,token}
local queue = circ_queue() --{uid,token}
local direct_login_cnt = 0
local function clear_timeout()
    while true do
        local head = queue.top()
        if head then
            local uid, endtime = head[1], head[2]
            if endtime + 7000 <= skynet.now() then -- timeout 60s
                queue.pop()
                local tk = token[uid]
                if tk and endtime == tk.endtime then
                    token[uid] = nil
                    if tk.direct_login then
                        direct_login_cnt = direct_login_cnt - 1
                    end
                    log("token destory %s direct_login %s", uid, direct_login_cnt)
                end
            else
                break
            end
        else
            break
        end
    end
end

local function deal_auth_result(result, msg, tk, uid, gate, fd, flag)
    if result then
        local oldfd = tk.fd
        if oldfd then
            log("game_auth %s success %d(%d) kick %d", flag, uid, fd, oldfd)
            client.pushfd(oldfd, "game_over", {why = "re_enter"})
            pcall(skynet.call, tk.gate, "lua", "kick", oldfd, "re_enter")
        else
            log("game_auth %s success %d(%d) %s", flag, uid, fd, msg)
        end
        tk.fd = fd
        tk.gate = gate
        tk.ref = tk.ref + 1
        tk.endtime = nil
        return true
    else
        log("game_auth %s auth failure %d(%d) %s", flag, uid, fd, msg)
    end
end

local function auth_check(tk, gate, fd, uid, msg)
    local authinfo = tk.authinfo
    --if authinfo then
    --	local auth_result=authmethod.check(authinfo,msg.token,msg.ti)
    --	if auth_result and deal_auth_result(auth_result,"OK",tk,uid,gate,fd,"local") then
    --		return 0,authinfo,tk.direct_login
    --	end
    --end
    --local auth=assert(msg.auth)
    local e, err
    --authinfo,e,err=cluster.call("login_"..auth,"@authmgr","token_check",serverid,uid,msg.token,msg.ti)
    authinfo, e, err = {uid = uid}, 0, nil
    if authinfo then
        tk.authinfo = authinfo
    end
    if deal_auth_result(authinfo, err or "OK", tk, uid, gate, fd, "remote") then
        return 0, authinfo, tk.direct_login
    end
    return e, err
end

function _M.auth(gate, fd, msg)
    --if msg.version ~= VERSION then
    --	return 3,"VERSION_ERROR"
    --end
    local uid = assert(msg.uid)
    local tk = token[uid]
    if not tk then
        tk = {
            lock = skynet.queue(),
            ref = 0,
            uid = uid,
            endtime = skynet.now(),
            direct_login = nil
        }
        token[uid] = tk
        queue.push {uid, tk.endtime}
        log("token create for %s", uid)
    end
    return tk.lock(auth_check, tk, gate, fd, uid, msg)
end

function _M.queue_finish(uid)
    local tk = token[uid]
    if not tk or not tk.direct_login then
        --if variable_cache.online_max<=direct_login_cnt then
        --	return false
        --end
        tk.direct_login = true
        direct_login_cnt = direct_login_cnt + 1
    end
    --print("queue_finish",direct_login_cnt)
    return true
end

local function unauth(tk, uid)
    assert(tk.ref > 0)
    tk.ref = tk.ref - 1
    if tk.ref == 0 then
        tk.endtime = skynet.now()
        queue.push {uid, tk.endtime}
    end
end

function _M.unauth(uid)
    local tk = token[uid]
    if tk then
        tk.lock(unauth, tk, uid)
    end
end

local function kick(tk, fd)
    if tk.fd == fd then
        tk.authinfo = nil
    end
end

function _M.kick(uid, fd)
    local tk = token[uid]
    if tk then
        tk.lock(kick, tk, fd)
    end
end

service.start {
    init = function()
        client.init("proto.c2s", "proto.s2c")
        skynet.fork(
            function()
                while true do
                    clear_timeout()
                    skynet.sleep(500)
                end
            end
        )
    end,
    regquit = true
}
