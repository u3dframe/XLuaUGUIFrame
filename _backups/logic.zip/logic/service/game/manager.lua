local utime = require "util.time"
local skynet = require "skynet"
local client = require "client.dispatch"
local service = require "service"
local log = require "log"
local rolelist = require "mysql.rolelist"
local circ_queue = require "circ_queue"
-- local variable_cache=require "variable.cache"
local reference_client = require "reference.client"
local cluster = require "skynet.cluster"
-- local roleinfo=require "roleinfo"
local _H = require "client.handler"
local _LUA = require "lua_handler"
local _MASTER = require "master_handler"

local _S = {}
local QUIT

local enter_queue = circ_queue()
local enterqueue_size = 0

local users = {}
local socket = {}
local uid2socket = setmetatable({}, {__mode = "v"})
local listengate
local tokenmgr

local dbmgr
skynet.init(
    function()
        dbmgr = skynet.uniqueservice("db/mgr")
        tokenmgr = skynet.uniqueservice("game/tokenmgr")
    end
)

local online = 0
local role_agent = 0
local prepool = {}
local presize = 0
local in_prepare
local function thread_prepareagent(sz)
    for _ = #prepool + 1, sz or presize do
        table.insert(prepool, skynet.newservice("game/agent", skynet.self()))
    end
end

local function new_agent(role)
    local agent = table.remove(prepool)
    if not agent then
        agent = skynet.newservice("game/agent", skynet.self())
    end
    role_agent = role_agent + 1
    if not in_prepare then
        in_prepare = true
        skynet.fork(
            function()
                local ok, err = pcall(thread_prepareagent)
                in_prepare = nil
                if not ok then
                    error(err)
                end
            end
        )
    end
    local ok, err = pcall(skynet.call, agent, "lua", "load", role)
    if not ok then
        skynet.send(agent, "lua", "stop")
        error(err)
    end
    return agent
end

local in_assign = 0
local assigning = {}
local function agent_load(role)
    assert(not QUIT)
    local rid = role.rid
    local agent = users[rid]
    if agent then
        return agent
    end
    local waitlist = assigning[rid]
    if waitlist then
        table.insert(waitlist, (coroutine.running()))
        skynet.wait()
        agent = users[rid]
        if not agent then
            error("agent load failure " .. rid)
        end
        return agent
    else
        waitlist = {}
        assigning[rid] = waitlist
        in_assign = in_assign + 1
        local ok
        ok, agent = pcall(new_agent, role)
        in_assign = in_assign - 1
        assigning[rid] = nil

        for _, co in ipairs(waitlist) do
            skynet.wakeup(co)
        end

        if not ok then
            error(agent)
        else
            users[rid] = agent
            log("load :%08x (rname:%s,rid:%d)", agent, role.rname, role.rid)
        end
        return agent
    end
end

local function push_rolelist(self)
    client.push(
        self,
        "role_list",
        {
            roles = self.roles
            -- startgc=variable_cache.startgc
        }
    )
end

local function finish_queue(self)
    if self.removed then
        return
    end
    self.in_enterqueue = nil
    enterqueue_size = enterqueue_size - 1
    self.proxy = skynet.call(dbmgr, "lua", "query", "DB_GAME")
    self.roles = rolelist.select_rolelist(self.proxy, self)
    push_rolelist(self)
    self.online = true
    online = online + 1
end

local function enterqueue_enter()
    local cnt = 0
    while true do
        -- if cnt>=variable_cache.enterqueue_speed then break end
        local self = enter_queue.top()
        if not self then
            break
        end
        if self.removed then
            enter_queue.pop()
            break
        else
            if not skynet.call(tokenmgr, "lua", "queue_finish", self.uid) then
                break
            end
            enter_queue.pop()
            cnt = cnt + 1
            finish_queue(self)
        end
    end
    return cnt
end

local function enterqueue_push(self)
    -- if enterqueue_size>=variable_cache.enterqueue_max then return false end
    enter_queue.push(self)
    enterqueue_size = enterqueue_size + 1
    self.in_enterqueue = true
    return true
end

local function enterqueue_updatepos()
    local index = 0
    for _, self in pairs(enter_queue) do
        if not self.removed then
            index = index + 1
            local ok, msg = pcall(client.push, self, "login_pos", {pos = index})
            if not ok then
                log("agent_pos error %s", msg)
            end
        end
    end
end

local function thread_aquene_update()
    while true do
        enterqueue_enter()
        enterqueue_updatepos()
        skynet.sleep(100)
    end
end

function _LUA.kickfd(fd, why)
    local s = socket[fd]
    if s then
        s.agent = nil
        skynet.call(s.gate, "lua", "kick", fd, why)
    end
end

local function query_agent(rid, role)
    rid = assert(tonumber(rid))
    while true do
        local agent = users[rid]
        if agent then
            local ref = reference_client.ref(agent, true)
            if ref then
                return ref
            end
            skynet.yield()
        else
            if role == nil then
                local proxy = skynet.call(dbmgr, "lua", "query", "DB_GAME")
                role = rolelist.select_role(proxy, rid)
                if not role then
                    error("role not exist " .. rid)
                end
            end
            agent_load(role)
        end
    end
end

local function query_agent_loaded(rid)
    local agent = users[rid]
    if agent then
        local ref = reference_client.ref(agent, true)
        if ref then
            return ref
        end
    end
end

local function autounref(ref, ...)
    reference_client.unref(ref)
    return ...
end

function _LUA.agent_call_loaded(rid, ...)
    local ref = query_agent_loaded(rid)
    if ref then
        return autounref(ref, skynet.call(ref.addr, "lua", "online_call", ...))
    end
end

function _LUA.agent_call(rid, ...)
    local ref = query_agent(rid)
    return autounref(ref, skynet.call(ref.addr, ...))
end

function _LUA.agent_send(rid, ...)
    local ref = query_agent(rid)
    return autounref(ref, skynet.send(ref.addr, ...))
end

function _LUA.fcbngfcn09856(rid, ...)
    local ref = query_agent_loaded(rid)
    if ref then
        return autounref(ref, skynet.send(ref.addr, ...))
    end
end

function _LUA.agent_online_send(rid, ...)
    local ref = query_agent_loaded(rid)
    if ref then
        skynet.send(ref.addr, ...)
        reference_client.unref(ref)
    end
end

function _LUA.agent_send_all(...)
    local copy = {}
    for rid in pairs(users) do
        copy[rid] = true
    end
    for rid in pairs(copy) do
        _LUA.agent_online_send(rid, ...)
    end
end

function _LUA.open(gateargs)
    local gate = skynet.newservice("game/gate")
    gateargs.watchdog = skynet.self()
    skynet.call(gate, "lua", "open", gateargs)
    listengate = gate
    return true
end

local function stop_thread(us)
    while true do
        local rid, agent = next(us)
        if not rid then
            break
        end
        us[rid] = nil
        local ok, err = pcall(skynet.call, agent, "lua", "stop")
        if not ok then
            log(err)
        end
    end
end

function _LUA.stopagent()
    while next(users) do
        local copy = {}
        for rid, agent in pairs(users) do
            copy[rid] = agent
        end
        for _ = 1, 100 do
            skynet.fork(stop_thread, copy)
        end
        while next(copy) do
            skynet.sleep(50)
        end
        skynet.sleep(100)
    end
    for _, agent in pairs(prepool) do
        skynet.call(agent, "lua", "stop")
    end
end

function _LUA.agent_exit(fd, rid, addr)
    if rid then
        if users[rid] then
            users[rid] = nil
            role_agent = role_agent - 1
        end
    end
    if fd then
        _LUA.kickfd(fd, "agent_exit")
    end
    if addr then
        for idx, agent in ipairs(prepool) do
            if agent == addr then
                table.remove(prepool, idx)
                break
            end
        end
    end
end

local auth_cnt_total = 0
local function game_auth(self, msg)
    self.uid = msg.uid
    self.sid = msg.sid or 0
    self.auth = msg.auth
    local e, authinfo, direct_login = skynet.call(tokenmgr, "lua", "auth", self.gate, self.fd, msg)
    if e ~= 0 then
        return {e = e, m = authinfo}
    end
    self.authinfo = authinfo
    self.auth_result = true
    if not direct_login then
        if not enterqueue_push(self) then
            return {e = 2}
        end
    else
        skynet.fork(finish_queue, self)
    end
    auth_cnt_total = auth_cnt_total + 1
    return {e = 0, time = math.floor(utime.time()), now = utime.now()}
end

function _S.data(gate, fd, msg, sz)
    local s = socket[fd]
    if s.auth_result == true then
        local ok, err = pcall(client.dispatch, s, msg, sz)
        if not ok then
            local str = string.format("dispatc_error %s", err)
            log(str)
            skynet.call(skynet.uniqueservice("game/tokenmgr"), "lua", "kick", s.uid, fd)
            client.pushfd(fd, "game_over", {why = str})
            skynet.send(s.gate, "lua", "kick", fd, str)
            error(str)
        end
    elseif s.auth_result == nil then
        s.auth_result = false
        local ok, err = pcall(client.dispatch_special, s, game_auth, msg, sz)
        if ok and s.auth_result then
            return
        end
        skynet.call(s.gate, "lua", "kick", fd, "auth failure")
        if not ok then
            error(string.format("gate_auth error %s", tostring(err)))
        end
    else
        -- 第一次game_auth没有成功之前不能发送其他消息
        skynet.call(s.gate, "lua", "kick", fd, "plz wait game_auth 1th")
    end
end

function _S.open(gate, fd, addr)
    socket[fd] = {gate = gate, addr = addr, fd = fd}
    skynet.call(gate, "lua", "accept", fd)
    log("accept %d(%s)", fd, addr)
end

function _S.close(gate, fd)
    log("close %d", fd)
    local s = socket[fd]
    if s.auth_result then
        skynet.send(tokenmgr, "lua", "unauth", s.uid)
    end
    socket[fd] = nil
    if s.agent then
        pcall(skynet.call, s.agent, "lua", "afk", fd)
    end
    if s.in_enterqueue then
        s.removed = true
        enterqueue_size = enterqueue_size - 1
    end
    if s.uid then
        if uid2socket[s.uid] == s then
            uid2socket[s.uid] = nil
        end
    end
    if s.online then
        online = online - 1
    end
    s.fd = nil
end

function _S.error(gate, fd)
    log("error %d", fd)
    _S.close(gate, fd)
end

function _S.warning(gate, fd, size)
    local s = socket[fd]
    if s then
        skynet.send(gate, "lua", "kick", fd, string.format("write buffer too big %dK", size))
    end
end

local crole_total = 0
function _H:role_create(msg)
    msg.uid = self.uid
    msg.sid = self.sid
    local e, rid, rname = rolelist.role_create(self.proxy, msg)
    if e == 0 then
        crole_total = crole_total + 1
        self.roles = rolelist.select_rolelist(self.proxy, self)
        -- push_rolelist(self)
        -- local ip=self.addr and string.sub(self.addr,1,string.find(self.addr,":")-1) or "0.0.0.0"
        msg.rname = rname
        msg.rid = rid
        return {e = 0, rid = rid, roles = self.roles}
    else
        return {e = e}
    end
end

function _H:role_login(msg)
    -- local rid=tonumber(msg.rid)
    -- local role=self.roles[rid]
    local rid, role = next(self.roles)
    if not role then
        return {e = 1}
    end
    if not self.fd then
        return {e = 2}
    end

    role.gate = self.gate
    -- role.addr=self.addr
    role.fd = self.fd
    role.auth = self.auth
    if self.addr then
        role.ip = string.sub(self.addr, 1, string.find(self.addr, ":") - 1)
    end

    local ref = query_agent(rid, role)
    local agent = ref.addr
    skynet.call(agent, "lua", "enter", role)
    self.agent = agent
    reference_client.unref(ref)
    log("enter :%08x (rname:%s,rid:%d) %d", agent, role.rname, rid, role.fd or 0)
    return {e = 0}
end

function _H.ping(_, msg)
    return msg
end

function _LUA.dispatch_agent_send(cmd, rid, ...)
    local agent = users[rid]
    if agent then
        skynet.call(agent, "lua", cmd, ...)
    end
end

function _LUA.dispatch_call_agent(cmd, rid, ...)
    local agent = users[rid]
    if agent then
        return true, skynet.call(agent, "lua", cmd, ...)
    else
        return false
    end
end

local function dispatch_lua(_, source, cmd, scmd, ...)
    if cmd == "socket" then
        _S[scmd](source, ...)
    else
        local f = _LUA[cmd]
        if f then
            skynet.retpack(f(scmd, ...))
        else
            log("Unknown command : %s", cmd)
            skynet.response()(false)
        end
    end
end

local function dispatch_master(session, source, cmd, msg)
    local f = _MASTER[cmd]
    if f then
        return skynet.retpack(f(msg))
    end
    local rid = tonumber(msg.rid)
    if rid then
        local ref = query_agent(rid)
        local requirestr = string.format([[require "role.master.%s"]], string.match(cmd, "([^_]+)"))
        skynet.call(ref.addr, "debug", "RUN", requirestr)
        return skynet.retpack(autounref(ref, skynet.call(ref.addr, "master", cmd, msg)))
    else
        error(string.format("Unknown command : [%s]", cmd))
    end
end

local function release()
    QUIT = true
    local gate
    listengate, gate = nil, listengate
    if gate then
        skynet.call(gate, "lua", "close")
        skynet.call(gate, "lua", "kickall", "manger_release")
        skynet.sleep(200)
    end
    while in_assign > 0 do
        skynet.sleep(10)
    end
    _LUA.stopagent()
    log("ONLINE %d PREAGENT %d", online, #prepool)
end

service.start {
    info = nil,
    regquit = true,
    master = "role",
    dispatch = {lua = dispatch_lua, master = dispatch_master},
    init = function()
        client.init("proto.c2s", "proto.s2c")
        skynet.fork(thread_prepareagent)
        skynet.fork(thread_aquene_update)
        cluster.register("manager")
    end,
    release = release
}
