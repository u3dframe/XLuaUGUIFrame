local skynet = require "skynet"
--local cluster = require "skynet.cluster"
local bootbase = require "bootbase"

local function boot()
    skynet.error("Server start")
    bootbase.start(
        function()
            local proto = skynet.uniqueservice "protoloader"
            skynet.call(
                proto,
                "lua",
                "load",
                {
                    "proto.c2s",
                    "proto.s2c"
                }
            )
            skynet.newservice("sys/cfgloader")
        end,
        function()
            --skynet.uniqueservice "game/chatd"
            skynet.uniqueservice "game/bootlast"
        end
    )
end

skynet.start(
    function()
        bootbase.main(boot)
    end
)
