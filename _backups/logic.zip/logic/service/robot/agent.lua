local skynet = require 'skynet'
local socket = require 'skynet.socket'
local timer = require 'timer.second'

local logerr = require 'log.err'
local _H = require 'client.handler'

local client = require 'client.dispatch'
require 'robot'

local ARGS = {...}
local TEST, ID, IP, PORT = ...

local function read_packet(self)
    local fd = self.fd
    local s = assert(socket.read(fd, 2), 'closed')
    local sz = string.unpack('>H', s)
    local msg = assert(socket.read(fd, sz), 'closed')
    return msg, sz
end

local role_list_wait
local ROLE_LIST
function _H.role_list(_, msg)
    skynet.error('recv role_list', role_list_wait)
    ROLE_LIST = msg.roles
    for _, v in pairs(msg.roles) do
        skynet.error(v.rid, v.rname)
    end
    local co = role_list_wait
    if co then
        role_list_wait = nil
        skynet.wakeup(co)
    end
end

local RAND = {
    'a',
    'b',
    'c',
    'd',
    'e',
    'f',
    'g',
    'h',
    'i',
    'j',
    'k',
    'l',
    'm',
    'n',
    'o',
    'p',
    'q',
    'r',
    's',
    't',
    'u',
    'v',
    'w',
    'x',
    'y',
    'z',
    'A',
    'B',
    'C',
    'D',
    'E',
    'F',
    'G',
    'H',
    'I',
    'J',
    'K',
    'L',
    'M',
    'N',
    'O',
    'P',
    'Q',
    'R',
    'S',
    'T',
    'U',
    'V',
    'W',
    'X',
    'Y',
    'Z',
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9',
    '0'
}
local function role_create(self)
    local nms = {}
    for _ = 1, 10 do
        table.insert(nms, RAND[math.random(1, #RAND)])
    end
    local rname = table.concat(nms)
    local ret = assert(client.request(self, 100, 'role_create', {rname = rname}))
    if ret.e ~= 0 then
        --error("role_create "..ret.e)
        return role_create(self)
    end
    ROLE_LIST = ret.roles
end

local function role_login(self)
    local rid = next(ROLE_LIST)
    if not rid then
        role_create(self)
        return role_login(self)
    end
    local ret = assert(client.request(self, 100, 'role_login', {rid = rid}))
    if ret.e ~= 0 then
        error('role_login ' .. ret.e)
    end
end

function _H.role_object(self, msg)
    for k, v in pairs(msg) do
        self[k] = v
    end
end

function _H.money_all(self, msg)
end

function _H.money_change(self, msg)
end

function _H.pushtext(msg)
    skynet.error(msg.text)
end

local function game_auth(self)
    local ret = assert(client.request(self, 100, 'game_auth', self))
    if ret.e ~= 0 then
        error('game_auth ' .. ret.e)
    end
    local co = coroutine.running()
    assert(not role_list_wait)
    assert(not ROLE_LIST)
    role_list_wait = co
    skynet.wait()
end

local function dispatch(self)
    local msg, sz = assert(read_packet(self))
    skynet.fork(
        function()
            local ok, err = pcall(client.dispatch, self, msg, sz)
            if not ok then
                logerr(err)
            end
        end
    )
end

local function exit(where, why)
    skynet.error('exit', where, why or 'exit')
    skynet.sleep(math.random(100, 500))
    skynet.exit()
end

local function game_loop()
    local ip, port = IP, tonumber(PORT)
    local fd = assert(socket.open(ip, port))
    local self = {
        fd = fd,
        uid = ID
    }
    skynet.fork(
        function()
            while true do
                local ok, err = pcall(dispatch, self)
                if not ok then
                    exit('msgloop', err)
                end
            end
        end
    )
    game_auth(self)
    role_login(self)
    local onlogin = require 'robot.onlogin'
    onlogin.reg(
        function(self)
            while true do
                timer.wait(60)
                client.push(self, 'ping', {})
            end
        end
    )
    onlogin.occur(self)
end

local function loop()
    local reboot =
        setmetatable(
        {},
        {
            __gc = function()
                skynet.send('.launcher', 'lua', 'LAUNCH', 'snlua', SERVICE_NAME, table.unpack(ARGS))
            end
        }
    )
    local ok, err = pcall(game_loop)
    exit('loop', err)
end

skynet.start(
    function()
        client.init('proto.s2c', 'proto.c2s')
        skynet.fork(loop)

        do
            local getupvalue = require 'debug.getupvalue'
            local handler = getupvalue(client.dispatch, 'handler')
            local host = getupvalue(client.dispatch, 'host')
            local handle_msg = getupvalue(client.dispatch, 'handle_msg')
            function client.dispatch(self, msg, sz)
                local type, name, args, response = host:dispatch(msg, sz)
                if type == 'REQUEST' then
                    local f = handler[name]
                    if f then
                        handle_msg(name, response, f, self, args)
                    else
                        error('Invalid command ' .. require('util').dump({name, args}))
                    end
                else
                    local session, result, _ = name, args, response
                    client.response(session, result)
                end
            end
        end
    end
)
