local skynet = require "skynet"
local bootbase = require "bootbase"

local ip = "127.0.0.1"
local port = 1024

skynet.start(
    function()
        skynet.error("Server start")
        local proto = skynet.uniqueservice "protoloader"
        skynet.call(
            proto,
            "lua",
            "load",
            {
                "proto.c2s",
                "proto.s2c"
            }
        )
        skynet.newservice("sys/cfgloader")
        for id = 1, 1 do
            skynet.newservice("robot/agent", "robot.test", id + 100, ip, port)
        end

        skynet.exit()
    end
)
