local skynet = require "skynet"
local crab = require "crab.c"
local utf8ex = require "utf8ex.c"
local lfs = require "lfs"
local utf8 = utf8

local core
local charset

local _M = {}

function _M.loaddirty()
    local root = skynet.getenv("cfgpath")
    local name = string.format("%s/wordfilter.txt", root)
    local alltext = {}
    for line in io.lines(name) do
        line = string.gsub(line, "\r", "")
        local text = {}
        assert(utf8ex.toutf32(line, text) > 0, line)
        table.insert(alltext, text)
    end
    core = crab.open(alltext)
end

function _M.load_table(tables)
    local alltext = {}
    for _, line in ipairs(tables) do
        line = string.gsub(line, "\r", "")
        local text = {}
        assert(utf8ex.toutf32(line, text) > 0, line)
        table.insert(alltext, text)
    end
    core = crab.open(alltext)
end

function _M.dirtycheck(str)
    local text = {}
    local ret = utf8ex.toutf32(str, text)
    if not ret then
        error("utf8ex string error")
    end
    return crab.check(core, text)
end
function _M.dirtyfilter(str)
    local text = {}
    local ret = utf8ex.toutf32(str, text)
    if not ret then
        error("utf8ex string error")
    end
    local f = crab.filter(core, text)
    if f then
        return utf8ex.toutf8(text)
    else
        return str
    end
end

local function loadcharset(file)
    local ret = {}
    for line in io.lines(file) do
        line = string.gsub(line, "\r", "")
        for _, c in utf8.codes(line) do
            local v = utf8.char(c)
            ret[v] = true
        end
    end
    return ret
end

function _M.loadcharset()
    local root = skynet.getenv("cfgpath")
    local ret = {}
    for file in lfs.dir(root .. "/charset") do
        if file ~= "." and file ~= ".." then
            local pos = string.find(file, ".txt$")
            if pos then
                local name = string.sub(file, 1, pos - 1)
                ret[name] = loadcharset(string.format("%s/charset/%s", root, file))
            end
        end
    end
    charset = ret
end

--- @param set string
--- @param str string
--- @return nil|number
function _M.charcheck(str, set)
    local grp = charset[set or "zh-cn"]
    if not grp then
        return
    end
    local cnt = 0
    for _, c in utf8.codes(str) do
        local v = utf8.char(c)
        if not grp[v] then
            return
        end
        cnt = cnt + 1
    end
    return cnt
end

skynet.dispatch(
    "lua",
    function(_, _, cmd, ...)
        skynet.retpack(_M[cmd](...))
    end
)

-- sys/words
skynet.start(
    function()
        _M.loaddirty()
        _M.loadcharset()
    end
)
