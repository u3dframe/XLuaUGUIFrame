local skynet = require "skynet"
local service = require "service"
local system = require "exporter.system"
local cluster = require "skynet.cluster"

local _LUA = require "lua_handler"
local _IN = require "inner"

require("exporter.registry")(
    function()
        local D = {}
        system(D)
        return D
    end
)

local _REG = {}

function _LUA.data()
    local D = {}
    for addr in pairs(_REG) do
        local ret = skynet.call(addr, "inner", "exporter_info")
        for k, v in pairs(ret) do
            D[k] = v
        end
    end
    return D
end

function _IN.register(addr)
    _REG[addr] = true
end

service.start {
    init = function()
        cluster.register("exporterd", skynet.self())
    end
}
