local skynet = require "skynet"
local codecache = require "skynet.codecache"
local cluster = require "skynet.cluster"
local service = require "service"
local ustring = require "util.string"
local timecore = require "time.core"

local _MASTER = require "master_handler"
local _LUA = require "lua_handler"

local function adjust_address(address)
    if address:sub(1, 1) ~= ":" then
        address = assert(tonumber("0x" .. address), "Need an address") | (skynet.harbor(skynet.self()) << 24)
    end
    return address
end

local function service_list()
    return skynet.call(".launcher", "lua", "LIST")
end

function _MASTER.list(_)
    local list = service_list()
    return {e = 0, list = list}
end

function _MASTER.stat(_)
    local stat = skynet.call(".launcher", "lua", "STAT")
    local ret = {}
    local list = service_list()
    for addr, info in pairs(stat) do
        info.addr = addr
        info.name = list[addr] or "unknow"
        local t = skynet.hpc()
        local ok, kb = pcall(skynet.call, adjust_address(addr), "debug", "MEM")
        info.ping = (skynet.hpc() - t) / 1000000
        if not ok then
            info.mem = string.format("ERROR (%s)", kb)
        else
            info.mem = kb
        end
        table.insert(ret, info)
    end
    return {e = 0, list = ret}
end

function _MASTER.mem(_)
    local list = skynet.call(".launcher", "lua", "MEM")
    return {e = 0, list = list}
end

local function master_pcall(call)
    local ok, ret = pcall(call)
    if ok then
        return ret
    end
    return {e = 1, m = ret}
end

function _MASTER.detail(msg)
    return master_pcall(
        function()
            local address = adjust_address(msg.addr)
            local ok, err = skynet.call(address, "debug", "RUN", "require 'debug.detail'")
            if not ok then
                return {e = 1, m = err}
            end
            local t = skynet.hpc()
            local ret = skynet.call(address, "debug", "DETAIL")
            ret.ping = (skynet.hpc() - t) / 1000000
            return {e = 0, ret = ret}
        end
    )
end

function _MASTER.kill(msg)
    local ok, err = pcall(skynet.call, ".launcher", "lua", "KILL", msg.addr)
    if ok then
        return {e = 0}
    else
        return {e = 1, m = err}
    end
end

function _MASTER.stop(msg)
    local ok, err = pcall(skynet.call, adjust_address(msg.addr), "lua", "stop")
    if ok then
        return {e = 0}
    else
        return {e = 1, m = err}
    end
end

function _MASTER.kill(msg)
    local ok, err =
        pcall(skynet.call, adjust_address(msg.addr), "debug", "RUN", 'require("skynet").fork(require("skynet").exit')
    if not ok then
        return {e = 1, m = err}
    else
        return {e = 0}
    end
end

function _MASTER.start(msg)
    local ok, addr = pcall(skynet.newservice, msg.val)
    if ok then
        if addr then
            return {e = 0, addr = skynet.address(addr)}
        else
            return {e = 1, m = "Exit"}
        end
    else
        return {e = 3, m = "Failed"}
    end
end

function _MASTER.gc(msg)
    if msg.addr then
        local address = adjust_address(msg.addr)
        skynet.send(address, "debug", "GC")
        return {e = 0}
    else
        return {e = 0, list = skynet.call(".launcher", "lua", "GC")}
    end
end

function _MASTER.gcall()
    local list = skynet.call(".launcher", "lua", "LIST")
    for address in pairs(list) do
        pcall(skynet.call, address, "debug", "GC")
    end
    return {e = 0}
end

function _MASTER.registry(msg)
    local address = adjust_address(msg.addr)
    local ok, err = skynet.call(address, "debug", "RUN", "require 'debug.registry'")
    if not ok then
        return {e = 1, m = err}
    end

    local val = msg.val
    if msg.valstring then
        val = ustring.split(msg.valstring, ";")
    end
    local keys, vals = skynet.call(address, "debug", "REGISTRY", table.unpack(val or {}))
    return {e = 0, vals = vals, keys = keys}
end

function _MASTER.serviceinfo(msg)
    local address = adjust_address(msg.addr)
    local ok, err = skynet.call(address, "debug", "RUN", "require 'debug.service_info'")
    if not ok then
        return {e = 1, m = err}
    end

    local val = msg.val
    if msg.valstring then
        val = ustring.split(msg.valstring, ";")
    end
    local keys, vals = skynet.call(address, "debug", "SERVICE_INFO", table.unpack(val or {}))
    return {e = 0, vals = vals, keys = keys}
end

function _MASTER.clearcache()
    codecache.clear()
    return {e = 0}
end

function _LUA.changetime(ti)
    local now = timecore.time()
    timecore.time_elapse(math.max(0, ti - now))
    local nnow = timecore.time()
    local diff = nnow - now
    skynet.error("changetime", nnow, diff)
    return nnow, diff
end

service.init {
    master = "debug",
    init = function()
        cluster.register("debuggerd")
    end
}
