local skynet = require "skynet"
local minheap = require "minheap.c"
local service = require "service"
local utime = require "util.time"
local expression = require "calendar.expression"
local logerr = require "log.err"
local heap_add = minheap.add
local heap_pop = minheap.pop

local _M = require "inner"

local HEAP = minheap.new()
local IDTAB = {}

local function timeout(uniq_id, now)
    local self = IDTAB[uniq_id]
    if not self then
        return
    end
    local ti = self[3]
    skynet.send(self[1], "inner", "calendard_timeout", uniq_id, ti)
    local nexti = expression.next_time(self[2], now)
    if nexti then
        self[3] = nexti
        heap_add(HEAP, uniq_id, nexti)
    else
        IDTAB[uniq_id] = nil
        skynet.send(self[1], "inner", "calendard_finish", uniq_id)
    end
end

local function update()
    local traceback = debug.traceback
    while true do
        local now = utime.time_int()
        while true do
            local uniq_id = heap_pop(HEAP, now)
            if not uniq_id then
                break
            end
            --print("update "..uniq_id)
            local ok, err = xpcall(timeout, traceback, uniq_id, now)
            if not ok then
                logerr(err)
            end
        end
        skynet.sleep(100)
    end
end

local cron_cache = setmetatable({}, {__mode = "v"})
local next_cache = setmetatable({}, {__mode = "k"})
local function calc_next_time(cron_str, ti)
    local cron = cron_cache[cron_str]
    if not cron then
        cron = expression.expression(cron_str)
        cron_cache[cron_str] = cron
    end
    if not ti then
        ti = utime.time_int()
    end
    local next_c = next_cache[cron]
    local next_ti
    if not next_c or next_c[1] ~= ti then
        next_ti = expression.next_time(cron, ti)
        next_cache[cron] = {ti, next_ti}
    else
        next_ti = next_c[2]
    end
    return next_ti, cron
end

local function subscribe(addr, uniq_id, cron_str, ti)
    local next_ti, cron = calc_next_time(cron_str, ti)
    if not next_ti then
        return skynet.fork(skynet.send, addr, "inner", "calendard_finish", uniq_id)
    end
    local now = utime.time_int()
    if next_ti < now then
        skynet.fork(skynet.send, addr, "inner", "calendard_timeout", uniq_id, next_ti)
        return subscribe(addr, uniq_id, cron_str, now)
    end
    IDTAB[uniq_id] = {addr, cron, next_ti, uniq_id}
    heap_add(HEAP, uniq_id, next_ti)
end

function _M.cron_subscribe(addr, uniq_id, cron_str, ti)
    subscribe(addr, uniq_id, cron_str, ti)
end

function _M.cron_unsubscribe(uniq_id)
    IDTAB[uniq_id] = nil
end

function _M.next_time(cron_str, ti)
    return (calc_next_time(cron_str, ti))
end

function _M.near_time(cron_str, ti)
    local now = utime.time_int()
    local next_ti = calc_next_time(cron_str, ti)
    if not next_ti then
        return
    end
    if next_ti > now then
        return ti
    else
        next_ti = calc_next_time(cron_str, now)
        if not next_ti then
            return
        end
        return now
    end
end

service.start {
    init = function()
        skynet.fork(update)
    end
}
