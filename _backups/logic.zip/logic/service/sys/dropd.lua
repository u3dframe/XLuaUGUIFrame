local udrop = require "util.drop"
local cfgdata = require "cfg.data"

local _LUA = require "lua_handler"

local ipairs = ipairs
local insert = table.insert
local random = math.random

local function cal(rid, num, itemtab)
    itemtab = itemtab or {}
    local drop_render = cfgdata.drop_render
    local renderrandom = cfgdata.drop_renderrandom[rid]
    for _ = 1, num do
        local id = udrop.nexts(renderrandom)
        for _, v in ipairs(drop_render[id].items) do
            insert(itemtab, v)
        end
    end
    return itemtab
end

function _LUA.rand_calc(rid, num)
    local itemtable = {}
    cal(rid, num, itemtable)
    return itemtable
end

function _LUA.calc(id, count)
    local reward = {}
    count = count or 1
    local cfg = cfgdata.drop[id]
    for _, r in ipairs(cfg.render) do
        local rid, num, p = r[1], r[2], r[3]
        for _ = 1, count do
            if p >= random(1, 10000) then
                cal(rid, num, reward)
            end
        end
    end
    return reward
end

require("service").start {}
