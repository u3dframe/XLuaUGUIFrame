local skynet = require "skynet"
local service = require "service"
local setting = require "setting"

service.start {
    init = function()
        local port = setting.get("debugport")
        local host = "127.0.0.1"
        local file = assert(io.open(skynet.getenv("debugport"), "w"))
        file:write(port)
        file:close()
        skynet.uniqueservice("debug_console", host, port)
    end
}
