local skynet = require "skynet"
local cluster = require "skynet.cluster"
require "master_handler" -- // register master proto

local _M = {}

local interfaces = {}
function _M.reg(source, name, address)
    if not address then
        address = source
    end
    local old = interfaces[name]
    if old and old ~= address then
        skynet.error(string.format("masterd %s(%08x) to %s(%08x)", name, address, name, old))
    else
        skynet.error(string.format("masterd %s(%08x)", name, address))
    end
    interfaces[name] = address
end

local function dispatch(session, source, cmd, ...)
    local f = _M[cmd]
    if f then
        return skynet.retpack(f(source, ...))
    end
    for name, address in pairs(interfaces) do
        local m = string.match(cmd, name .. "_(.+)")
        if m then
            return skynet.retpack(skynet.call(address, "master", m, ...))
        end
    end
    error("not find " .. tostring(cmd))
end

skynet.start(
    function()
        skynet.dispatch("lua", dispatch)
        cluster.register("masterd")
    end
)
