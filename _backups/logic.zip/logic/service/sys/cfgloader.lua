local skynet = require "skynet"
local sharetable = require "skynet.sharetable"
local loader = require "cfg.loader"
local parallels = require "parallels"

local mcast = require("mcast")("cfgupdate")

local same_table
local function same_value(lv, rv)
    if lv ~= rv then
        local type_lv, type_rv = type(lv), type(rv)
        if type_lv == "table" and type_lv == type_rv then
            return same_table(lv, rv)
        else
            return false
        end
    else
        return true
    end
end

function same_table(l, r)
    local ks = {}
    for k, lv in pairs(l) do
        local rv = r[k]
        if not same_value(lv, rv) then
            return false
        end
        ks[k] = true
    end
    for k, rv in pairs(r) do
        if not ks[k] then
            local lv = l[k]
            if not same_value(lv, rv) then
                return false
            end
        end
    end
    return true
end

local function compare_and_load(tables)
    local changes = {}
    local pa = parallels()
    for name, data in pairs(tables) do
        pa:add(
            function()
                local old = sharetable.query(name)
                if not same_value(data, old) then
                    sharetable.loadtable(name, data)
                    changes[name] = true
                end
            end
        )
    end
    pa:wait()
    mcast:publish(changes)
end

skynet.start(
    function()
        local root = skynet.getenv("cfgpath")
        compare_and_load(loader(root))
        skynet.exit()
    end
)
