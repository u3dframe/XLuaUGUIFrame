local settingloader = require "setting.loader"
local skynet = require "skynet"
local mysql = require "skynet.db.mysql"
local setting = require "setting"
local utable = require "util.table"

local function query(con, sql)
    local d = con:query(sql)
    if d.errno then
        error(string.format("[(%s)%s]%s", d.errno, d.err, sql))
    end
    skynet.error(sql)
    return d
end

local function drop()
    local conf = setting.get("db")
    for _, cfg in pairs(conf) do
        local opt = utable.copy(cfg)
        opt.database = "mysql"

        local con = mysql.connect(opt)
        local sql = string.format("DROP DATABASE IF EXISTS `%s`", cfg.database)
        query(con, sql)
        con:disconnect()
    end
end

skynet.start(
    function()
        settingloader.init_from_dir("game", skynet.getenv("svr_id"))
        drop()
        skynet.exit()
    end
)
