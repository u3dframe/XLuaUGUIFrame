local skynet = require "skynet"
local setting = require "setting"

local LOCK = require("skynet.queue")()
local DB = {}
local INDEX = {}
local UNIQUE = {}

local _LUA = require "lua_handler"

skynet.init(
    function()
        skynet.newservice("db/init")
    end
)

local function start(name, opt)
    if DB[name] then
        return
    end
    opt.compact_arrays = true
    local ret = {}
    for i = 1, math.max(opt.count, 1) do
        local hostinfo = string.format("%s@%s:%d/%s", opt.user or "", opt.host, opt.port or 3306, opt.database or "")
        local s = skynet.newservice("db/mysqlc", string.format("[%s.%d]", name, i), hostinfo)
        assert(skynet.call(s, "lua", "start", opt))
        table.insert(ret, s)
    end
    DB[name] = ret
end

function _LUA.query(db)
    local list = DB[db]
    if not list then
        LOCK(start, db)
        return _LUA.query(db)
    end
    local idx = INDEX[db] or 1
    INDEX[db] = idx + 1
    idx = idx % (#list)
    if idx == 0 then
        idx = #list
    end
    return list[idx]
end

function _LUA.query_list(db)
    local list = DB[db]
    if not list then
        LOCK(start, db)
        return _LUA.query_list(db)
    end
    return list
end

function _LUA.query_unique(db, flag)
    local s = string.format("%s@%s", flag, db)
    local r = UNIQUE[s]
    if not r then
        r = _LUA.query(db)
        if not UNIQUE[s] then
            UNIQUE[s] = r
        else
            r = UNIQUE[s]
        end
    end
    return r
end

require("service").start {
    init = function()
        local conf = setting.get("db")
        for db, opt in pairs(conf) do
            start(db, opt)
        end
    end,
    release = function()
        local dbs = {}
        DB, dbs = dbs, DB
        for _, v in pairs(dbs) do
            for _, s in pairs(v) do
                skynet.call(s, "lua", "stop")
            end
        end
    end,
    regquit = true
}
