local skynet = require "skynet"
local mysql = require "skynet.db.mysql"
local setting = require "setting"
local utable = require "util.table"
local mysqlauto = require "mysql.mysqlauto"

local function query(con, sql)
    local d = con:query(sql)
    if d.errno then
        error(string.format("[(%s)%s]%s", d.errno, d.err, sql))
    end
    skynet.error(sql)
    return d
end

local function init()
    local conf = setting.get("db")
    for name, cfg in pairs(conf) do
        local opt = utable.copy(cfg)
        opt.database = "mysql"

        local con = mysql.connect(opt)
        local sql =
            string.format("CREATE DATABASE IF NOT EXISTS `%s` /*!40100 DEFAULT CHARACTER SET utf8 */", cfg.database)
        query(con, sql)
        con:disconnect()
        opt = utable.copy(cfg)
        opt.compact_arrays = false
        con = mysql.connect(opt)
        local ctx =
            mysqlauto.newctx(
            {
                name = name,
                dir = skynet.getenv("root") .. "/dump",
                query = function(...)
                    return query(con, ...)
                end
            }
        )
        mysqlauto.file2db(ctx)
        con:disconnect()
    end
end

skynet.start(
    function()
        init()
        skynet.exit()
    end
)
