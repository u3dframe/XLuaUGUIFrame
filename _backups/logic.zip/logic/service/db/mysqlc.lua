local skynet = require "skynet"
local mysql = require "skynet.db.mysql"

local con
local opt
local _LUA = require "lua_handler"

local cnt_all = 0
local cnt_fin = 0

local function ret(f, sql, d, ...)
    if f then
        f(sql, d)
    end
    return ...
end

local last_query_time
local function check_ping()
    while con do
        local now = skynet.now()
        local nextti = last_query_time + opt.ping * 100 - now
        if nextti > 0 then
            skynet.sleep(nextti)
        else
            last_query_time = now
            local o, e = pcall(mysql.ping, con)
            if not o then
                skynet.error(e)
            end
        end
    end
end

local function inner_execute(call, sql, ...)
    last_query_time = skynet.now()
    cnt_all = cnt_all + 1
    local o, d = xpcall(call, debug.traceback, con, sql, ...)
    cnt_fin = cnt_fin + 1
    if not o then
        error(string.format("[%s]%s", tostring(d), sql))
    end
    if d.multiresultset then
        return d, table.unpack(d)
    else
        return d, d
    end
end

local function error_check(sql, d)
    if d.errno then
        error(string.format("[(%s)%s]%s", d.errno, d.err, sql))
    end
end

function _LUA.query(sql)
    return ret(error_check, sql, inner_execute(mysql.query, sql))
end

function _LUA.safe_query(sql)
    return ret(nil, sql, inner_execute(mysql.query, sql))
end

function _LUA.stmt(sql, ...)
    return ret(error_check, sql, inner_execute(mysql.stmt_query, sql, ...))
end

function _LUA.start(o)
    opt = o
    con = mysql.connect(opt)
    last_query_time = skynet.now()
    skynet.fork(check_ping)
    return true
end

require("service").start{
    release = function()
        if con then
            while cnt_all > cnt_fin do
                skynet.sleep(10)
            end
            mysql.disconnect(con)
            con=nil
        end
    end
}
