local skynet = require "skynet"
local mysql = require "skynet.db.mysql"
local setting = require "setting"
local util = require "util"
local mysqlauto = require "mysql.mysqlauto"

local function query(con, sql)
    local d = con:query(sql)
    if d.errno then
        error(string.format("[(%s)%s]%s", d.errno, d.err, sql))
    end
    skynet.error(sql)
    return d
end

skynet.start(
    function()
        local conf = setting.get("db")
        for name, opt in pairs(conf) do
            opt.compact_arrays = false
            local con = mysql.connect(opt)
            local ctx =
                mysqlauto.newctx(
                {
                    name = name,
                    dir = skynet.getenv("root") .. "/dump",
                    query = function(...)
                        return query(con, ...)
                    end
                }
            )
            mysqlauto.db2file(ctx)
            con:disconnect()
        end
        skynet.exit()
    end
)
