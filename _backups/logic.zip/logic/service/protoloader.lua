local skynet = require "skynet"
local sprotoparser = require "sprotoparser"
local sprotoloader = require "sprotoloader"

local loader = {}
local data = {}

local function load(name)
    local filename = string.format(skynet.getenv("root") .. "/proto/%s.sproto", name)
    local f = assert(io.open(filename), "Can't open " .. name)
    local t = f:read "a"
    f:close()
    return sprotoparser.parse(t, name)
end

function loader.load(list)
    for i, name in ipairs(list) do
        local p = load(name)
        skynet.error(string.format("load proto [%s] in slot %d", name, i))
        data[name] = i
        sprotoloader.save(p, i)
    end
end

function loader.index(name)
    return data[name]
end

skynet.start(
    function()
        skynet.dispatch(
            "lua",
            function(_, _, cmd, ...)
                local f = loader[cmd]
                if not f then
                    skynet.response()(false)
                else
                    skynet.retpack(f(...))
                end
            end
        )
    end
)
