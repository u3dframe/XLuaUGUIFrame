local skynet = require "skynet"

local LIST = {}
local _M = {}

function _M.reg(addr, name)
    assert(addr)
    table.insert(LIST, {addr, name})
end

function _M.stopall()
    while true do
        local addr = table.remove(LIST)
        if not addr then
            break
        end

        skynet.error(string.format("stop :%08x(%s)", addr[1], addr[2] or "Unknown"))
        local ok, err = pcall(skynet.call, addr[1], "lua", "stop")
        if not ok then
            skynet.error(err)
        end
    end
end

local WAIT_QUIT
function _M.stop()
    if WAIT_QUIT then
        local co = coroutine.running()
        table.insert(WAIT_QUIT, co)
        skynet.wait(co)
    else
        WAIT_QUIT = {}
        _M.stopall()
        for _, co in pairs(WAIT_QUIT) do
            skynet.wakeup(co)
        end
        skynet.fork(skynet.exit) --//wakeup queue run before fork queue
    end
end

skynet.dispatch(
    "lua",
    function(_, _, cmd, ...)
        local f = _M[cmd]
        skynet.retpack(f(...))
    end
)

skynet.start(
    function()
    end
)
